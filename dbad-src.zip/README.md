# DBAD

### DON'T BE A DICK.
*Because apparently some people still need reminding.*

DBAD is an Australian community noticeboard for calling out inconsiderate
**behaviour** — never people. Someone parks across the footpath, abandons a
trolley in a bay, leaves a picnic's worth of rubbish for the wind to sort. You
spot it, you snap it, you DBAD it: one photo with the faces and plates blurred on
your own phone, one sentence about what happened, and the community casts a
verdict on the Dick-o-meter — Not a dick move, Bit of a dick move, Definitely a
dick move, or Absolute dickery. You also get a printable A5 or A6 notice with a
QR code to leave under a wiper, where lawful. And when someone fixes it, the
nomination gets stamped **REDEEMED**, which is the whole point.

It is built so it can never become a dossier on anyone. There is no database
table for "the person who did the dick move", and there never will be. Photos are
downscaled, stripped of EXIF and pixelated on the device before anything is
uploaded; every photo nomination waits for a human moderator; locations are
rounded to roughly a kilometre and only ever shown at suburb level; text is
scanned for phone numbers, emails, plates, addresses and names in the browser, on
the server and again in the database. Anyone who thinks a nomination is about
them can ask for removal, a correction, anonymisation, added context, a right of
reply or redemption status — without an account and without identifying
themselves. There is a **NOT A DICK** feed for people doing the right thing,
because the point was never to be cruel. It is Next.js 15, React 19, TypeScript,
Tailwind v4 and Supabase, and it runs on a phone in under a minute.

---

## Screenshots

> Placeholder — drop the images into `docs/screenshots/` and they will appear.

| | |
| --- | --- |
| ![Home](docs/screenshots/home.png)<br>**Home** — the loop, the weekly pick, the map | ![Feed](docs/screenshots/feed.png)<br>**Feed** — filterable, searchable, shareable URLs |
| ![Nomination](docs/screenshots/nomination.png)<br>**Nomination** — evidence, verdict, comments | ![Dick-o-meter](docs/screenshots/dick-o-meter.png)<br>**Dick-o-meter** — the community verdict |
| ![Wizard](docs/screenshots/wizard.png)<br>**Wizard** — photo → words → place → review | ![Redaction](docs/screenshots/redaction.png)<br>**Redaction** — drag to blur, on device |
| ![Notice studio](docs/screenshots/notice-studio.png)<br>**Notice studio** — five templates, A5/A6, PDF | ![Notice A5](docs/screenshots/notice-a5.png)<br>**Official Warning** — the printed article |
| ![Map](docs/screenshots/map.png)<br>**Map** — regions, never addresses | ![Redemption](docs/screenshots/redemption.png)<br>**Redemption** — the good ending |
| ![Moderation queue](docs/screenshots/admin-queue.png)<br>**Queue** — every photo seen by a human | ![Appeals](docs/screenshots/admin-appeals.png)<br>**Appeals** — "Is this about you?" |
| ![Mobile](docs/screenshots/mobile.png)<br>**Mobile** — thumb-reachable, sub-minute | ![Open Graph](docs/screenshots/open-graph.png)<br>**Open Graph** — Facebook-friendly share card |

---

## Quick start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open <http://localhost:3000>.

With no Supabase credentials in `.env.local`, DBAD runs in **demo mode**: an
in-memory store seeded with 12 members, 31 nominations and 24 comments across the
South Coast, Canberra and the rest of the country. Votes stick, comments appear,
nominations land in the moderation queue, and everything resets when you restart
the process.

Sign in at `/sign-in` as one of three demo accounts — no password:

| Account | Role | Handle | What it shows you |
| --- | --- | --- | --- |
| **Jen** | Member | `southcoastspotter` | The member experience, with badges already earned |
| **Sarah** | Moderator | `mod_sarah` | The full moderation console at `/admin` |
| **DBAD HQ** | Admin | `dbad_hq` | Everything, including role changes |

For the real thing, fill in `NEXT_PUBLIC_SUPABASE_URL` and
`NEXT_PUBLIC_SUPABASE_ANON_KEY`, apply the migrations, and it switches over
automatically. See [docs/08-deployment.md](docs/08-deployment.md).

**Requires** Node ≥ 20.9. [Bun](https://bun.sh) is optional and only needed for
the preview harness and the asset generators.

---

## Scripts

| Script | What it does |
| --- | --- |
| `npm run dev` | Next.js dev server |
| `npm run build` | Production build (`output: "standalone"`) |
| `npm start` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit`, strict, against the real vendor types |
| `npm run lint` | ESLint 9 with `next/core-web-vitals` + `next/typescript` |
| `npm run preview` | The offline design harness (`bun run tools/preview/server.ts`) |
| `npm run preview:css` | Rebuild only the harness's Tailwind bundle |
| `npm run illustrations` | Regenerate the 25 seed illustrations and the contact sheet |
| `npm run db:reset` | `supabase db reset` — migrations then seed |
| `npm run db:test` | Run `supabase/tests/rls.test.sql` against `$DATABASE_URL` |

---

## Project structure

```
dbad/
├── docs/                  Product and architecture documentation
├── public/
│   ├── fonts/             Self-hosted WOFF (DBAD Display, Public Sans, IBM Plex Mono)
│   ├── pdf-fonts/         TTFs for the PDF and Open Graph renderers
│   ├── icons/             PWA icons, generated from the wordmark geometry
│   ├── seed/              25 generated demo illustrations + contact sheet
│   ├── sw.js              Service worker (app-shell caching)
│   └── offline.html       Offline fallback page
├── src/
│   ├── app/               Next.js App Router — routes, actions, api, metadata
│   ├── components/        Views: ui · brand · layout · feature folders · admin
│   ├── lib/               domain · data · loaders · actions · ai · notice · client
│   └── middleware.ts      Session refresh and the /admin, /me, /notifications gate
├── supabase/
│   ├── migrations/        0001 schema · 0002 views · 0003 functions · 0004 rls · 0005 storage
│   ├── tests/             local-pg.sh + rls.test.sql
│   ├── config.toml        Supabase CLI configuration
│   └── seed.sql           The demo site, in SQL
├── tools/
│   ├── preview/           Bun design-preview harness (server, routes, shims)
│   ├── typecheck/         Offline strict type-check with hand-written vendor stubs
│   ├── brand/             PWA icon generator
│   └── illustrations/     Seed illustration generator
├── Dockerfile             Standalone production image
├── docker-compose.yml     Publishes 8792 behind an existing Cloudflare Tunnel
└── next.config.ts
```

---

## Documentation

| Document | Contents |
| --- | --- |
| [01 — Information architecture](docs/01-information-architecture.md) | Every route, the navigation model, URL conventions |
| [02 — User journeys](docs/02-user-journeys.md) | The mobile journey, verdicts, redemption, notices, right of reply, moderation |
| [03 — Data model](docs/03-data-model.md) | Tables, views, RPCs, the RLS matrix, privacy invariants in SQL |
| [04 — Moderation model](docs/04-moderation-model.md) | Statuses, automatic checks, the action catalogue, roles, what admins cannot do |
| [05 — Privacy controls](docs/05-privacy-controls.md) | The redaction pipeline, location coarsening, the honest limitations |
| [06 — Design system](docs/06-design-system.md) | Palette, typography, the wordmark, visual devices, voice and tone, notice templates |
| [07 — Component architecture](docs/07-component-architecture.md) | The layering, why it is shaped that way, and how to extend it |
| [08 — Deployment](docs/08-deployment.md) | Environments, Docker, Supabase setup, CI, and the go-live checklist |

---

## The verification harness

DBAD was built where `npm install` could not reach a registry, so it carries its
own way of proving the code works. All three run offline.

```bash
bun run tools/preview/server.ts     # http://127.0.0.1:4801
```

A ~160-line Bun server that bundles the **real** React views against the **real**
in-memory repository, with six Next.js primitives shimmed (`next/link`,
`next/image`, `next/navigation`, `next/font/local`, `server-only`,
`client-only`). Every public, member and admin route is registered. Three genuine
route handlers — `/api/qr`, `/api/notices/:id/pdf`, `/api/ai/rewrite` — are
mounted directly, because they are plain `Request → Response` functions. Switch
identity with `?viewer=u_jen` / `u_sarah` / `u_hq`. Not the production server —
that is `next start`.

```bash
bash tools/typecheck/run.sh         # add --quiet for the summary only
```

Strict `tsc` (`strict`, `noUncheckedIndexedAccess`, `noImplicitOverride`) against
hand-written vendor declarations in `tools/typecheck/types/` for `next`, `react`,
`react-dom` and `@supabase/*`. Prints errors by file and by rule. CI runs
`npm run typecheck` against the *real* packages — the stubs are the offline
fallback, not a replacement.

```bash
bash supabase/tests/local-pg.sh     # KEEP=1 to leave the cluster running
```

Spins up a throwaway PostgreSQL 16 cluster on port 54329, stubs the parts of
Supabase the migrations legitimately need (`auth.users`, `auth.uid()`, the
`storage` schema, the three roles), applies every migration and the seed, then
runs `rls.test.sql`. It asserts the RLS matrix from each role's point of view,
the PII triggers, the role guard, the storage policies, and every `moderate()`
branch. Each check prints `PASS`; the first failure takes the exit code with it.

---

## Deployment

Docker image with Next.js standalone output, published on port **8792** and
reached only through an existing Cloudflare Tunnel — never bound publicly.

```bash
cp .env.example .env.production     # fill it in
docker compose up -d --build
curl -s http://127.0.0.1:8792/api/health
```

Full instructions, the Supabase setup, CI, and the go-live checklist are in
[docs/08-deployment.md](docs/08-deployment.md).

---

## Licence

Application code © Disruptive Labs Pty Ltd. All rights reserved.

Bundled fonts are third-party open-source and remain under their own licences:

| Font | Source | Licence |
| --- | --- | --- |
| **DBAD Display** | An instanced condensed-black cut of [Roboto Flex](https://github.com/TypeNetwork/Roboto-Flex) | SIL Open Font License 1.1 |
| **Public Sans** | [U.S. Web Design System](https://github.com/uswds/public-sans) | SIL Open Font License 1.1 |
| **IBM Plex Mono** | [IBM](https://github.com/IBM/plex) | SIL Open Font License 1.1 |

Roboto is a trademark of Google. IBM Plex is a registered trademark of IBM Corp.
Neither owner endorses DBAD.

Seed illustrations and demo data are generated and fictional. No real person,
vehicle, business or address appears anywhere in this repository.

---

**DBAD. DON'T BE A DICK. THE WORLD HAS ENOUGH ALREADY.**
