# 01 — Information architecture

Every route in the application, what it is for, and where its data comes from.
Routes live in `src/app/`; the data always arrives through the `Repository`
interface (`src/lib/data/repository.ts`) via a loader in `src/lib/loaders/`.
See [07 — Component architecture](./07-component-architecture.md) for why the
layering is shaped that way, and [03 — Data model](./03-data-model.md) for what
the repository is talking to.

---

## Public routes

| Route | File | Purpose | Data source |
| --- | --- | --- | --- |
| `/` | `app/page.tsx` | Home. Hero, the three-step loop, Dick Move of the Week, latest nominations, redemption strip, map teaser. `revalidate = 60`. | `loadHome()` → `getFeatured`, `listIncidents`, `getMapClusters` |
| `/feed` | `app/feed/page.tsx` | Every approved Dick Move, filterable and searchable. | `loadFeed(kind: "dick_move")` → `listIncidents`, `getMapClusters` |
| `/not-a-dick` | `app/not-a-dick/page.tsx` | The positive feed. Same view component, `kind: "not_a_dick"`. | `loadFeed(kind: "not_a_dick")` |
| `/week` | `app/week/page.tsx` | Dick Move of the Week plus the greatest hits, most-redeemed and latest redemptions. `revalidate = 300`. | `repo.getFeatured()` |
| `/map` | `app/map/page.tsx` | The Australian Dickery Map — region clusters over a schematic outline, and the nominations for the selected region. | `loadMap()` → `getMapClusters`, `listIncidents({region})` |
| `/moves/[slug]` | `app/moves/[slug]/page.tsx` | A single nomination: evidence, Dick-o-meter, reactions, redemption, comments, notice preview, related. | `loadIncident()` → `getIncidentBySlug`, `listRelated` |
| `/moves/[slug]/opengraph-image` | `.../opengraph-image.tsx` | 1200×630 PNG share card for that nomination (`next/og`, brand TTFs from `public/pdf-fonts`). | `getIncidentBySlug` + `summariseVotes` |
| `/moves/code/[code]` | `.../route.ts` | Resolves a printed short code (`DBAD-0042`) to its nomination and 302s to `/moves/<slug>?via=qr`. Falls back to `/?via=qr`. | `repo.getIncidentByCode()` |
| `/nominate` | `app/nominate/page.tsx` | The four-step nomination wizard. Accepts `?kind=not_a_dick` and `?category=<id>`. | Server actions only (`submitNomination`, `suggestWording`) |
| `/notice/new` | `app/notice/new/page.tsx` | Creates a notice — for `?incident=<id>` or a blank standalone one — then redirects to the studio. `dynamic = "force-dynamic"`. | `createNoticeFor()` → `createNotice` |
| `/notice/[id]` | `app/notice/[id]/page.tsx` | Notice studio: template picker, editable lines, QR link mode, print / PDF / share. | `loadNotice()` → `getNotice`, `getIncidentById` |
| `/about-you` | `app/about-you/page.tsx` | "Is this about you?" — the right-of-reply and appeal form. Accepts `?code=DBAD-0042` and `?action=<AppealAction>`. | `getIncidentByCode` + `submitAppeal` action |
| `/about` | `app/about/page.tsx` | The philosophy page. Static. | — |
| `/standards` | `app/standards/page.tsx` | The community standard: ten rules, never-publish / fine lists, reporting and appeal routes. Static. | — |
| `/privacy` | `app/privacy/page.tsx` | What DBAD collects and what it refuses to. Static. | — |
| `/u/[handle]` | `app/u/[handle]/page.tsx` | A member's public profile: stats, badges, recent nominations. | `repo.getProfileByHandle()` |
| `/sign-in` | `app/sign-in/page.tsx` | Demo-account picker (demo mode) or email OTP + OAuth (Supabase mode). Honours `?next=`. `robots: noindex`. | `dataMode()`, `DEMO_ACCOUNTS`, `PROFILES` |
| `/opengraph-image` | `app/opengraph-image.tsx` | Site-wide 1200×630 share card. | Static copy from `SITE` |

### Generated files

| Route | File | Notes |
| --- | --- | --- |
| `/manifest.webmanifest` | `app/manifest.ts` | PWA manifest: standalone, portrait, `#0f0f0f` theme, two shortcuts (Nominate, Feed). |
| `/robots.txt` | `app/robots.ts` | Allows `/`, disallows `/admin`, `/api/`, `/me`, `/notifications`, `/auth/`. |
| `/sitemap.xml` | `app/sitemap.ts` | Ten static paths plus every approved nomination (up to 500 of each kind). `revalidate = 3600`. |

### Redirects

| From | To | Where |
| --- | --- | --- |
| `/d/:code` | `/moves/code/:code` | `next.config.ts` `redirects()`, `permanent: false` |

`/d/DBAD-0042` is the short link printed on every notice QR. Two hops: the
config redirect resolves the shape, the route handler resolves the code. The
permanent flag is deliberately off so codes can be re-pointed later.

---

## Member routes

Gated by `src/middleware.ts`, which redirects an anonymous visitor to
`/sign-in?next=<path>`.

| Route | File | Purpose | Data source |
| --- | --- | --- | --- |
| `/me` | `app/me/page.tsx` | Your own profile, with a sign-out action. `robots: noindex`. | `repo.getProfileById(viewer.id)` |
| `/notifications` | `app/notifications/page.tsx` | Your notifications; marks them read on view. `dynamic = "force-dynamic"`. | `listNotifications`, `markNotificationsRead` |

---

## Admin routes

`app/admin/layout.tsx` re-checks the role with `isModerator()` and redirects to
`/sign-in?next=/admin` if the viewer is not a moderator or admin — the
middleware check is a first line, not the only one. The layout is
`dynamic = "force-dynamic"` and wraps every page in `AdminShell` through
`AdminSectionProvider`, which derives the active section from the pathname.

| Route | File | Purpose | Data source |
| --- | --- | --- | --- |
| `/admin` | `admin/page.tsx` | Dashboard: headline counts and the five oldest items needing attention in each queue. | `loadAdminDashboard()` |
| `/admin/queue` | `admin/queue/page.tsx` | The moderation queue — nominations with `moderation_status = pending`, oldest first. | `loadQueue()` → `listModerationQueue` |
| `/admin/reports` | `admin/reports/page.tsx` | Reported nominations and comments. `?status=open\|reviewing\|resolved\|dismissed`. | `loadReports()` |
| `/admin/appeals` | `admin/appeals/page.tsx` | "Is this about you?" requests. `?status=open\|in_review\|actioned\|declined`. | `loadAppeals()` |
| `/admin/comments` | `admin/comments/page.tsx` | All comments with their parent nomination. `?status=visible\|hidden\|removed`. | `loadAdminComments()` |
| `/admin/nominations` | `admin/nominations/page.tsx` | Every nomination regardless of status, searchable. `?status=`, `?q=`. | `loadAdminIncidents()` |
| `/admin/members` | `admin/members/page.tsx` | Member list with stats and badges; role changes (admin only). `?q=`. | `loadMembers()` → `listUsers` |
| `/admin/categories` | `admin/categories/page.tsx` | Category copy. Editing records an `edit_category` action. | `CATEGORIES` constant |
| `/admin/templates` | `admin/templates/page.tsx` | Notice template copy. Editing records an `edit_template` action. | `NOTICE_TEMPLATES` constant |
| `/admin/audit` | `admin/audit/page.tsx` | The moderation audit log, most recent 120 entries. | `loadAudit()` → `listAuditLog` |

Every admin page receives the same `actions={{ moderate }}` prop. All
moderation goes through one server action and one repository method — see
[04 — Moderation model](./04-moderation-model.md).

`?status=` and `?q=` are parsed by `parseReportStatus` / `parseAppealStatus` /
`parseCommentStatus` / `parseIncidentAdminStatus` in `src/lib/loaders/admin.ts`,
so a hand-typed value can never reach the repository.

---

## API routes

| Route | File | Method | Purpose |
| --- | --- | --- | --- |
| `/api/ai/rewrite` | `api/ai/rewrite/route.ts` | POST | Turns an angry description into three DBAD-voiced suggestions. Input capped at 1 500 characters, `cache-control: no-store`, nothing stored. |
| `/api/health` | `api/health/route.ts` | GET | Liveness probe: `{ ok, service, mode, time }`. Used by the Docker `HEALTHCHECK`. |
| `/api/qr` | `api/qr/route.ts` | GET | SVG QR code. Refuses any text that is not a DBAD URL, a site-relative path, or localhost — this is not a public QR service. |
| `/api/notices/[id]/pdf` | `api/notices/[id]/pdf/route.ts` | GET | Vector A5/A6 PDF of a saved notice (`?size=a5\|a6`). `cache-control: private, no-store`; `x-dbad-fonts` header reports `brand` or `standard`. |
| `/auth/callback` | `app/auth/callback/route.ts` | GET | Supabase Auth redirect target. Exchanges the code for a session, then sends the member to a validated `?next=`. |

DECISION: the rewrite endpoint exists as a route handler *and* as a server
action (`suggestWording`). The wizard calls the action; the route is there for
the preview harness and for anything that needs a plain HTTP call.

---

## Navigation model

### Header — `components/layout/site-header.tsx`

Sticky, near-black, with a 2px hazard strip above it. Left: stencil wordmark in
warning yellow plus the "Don't be a dick." lockup from `md` up. Centre (`lg`
and up): the five primary links from `NAV` in `src/lib/site.ts` —

1. Latest Dick Moves → `/feed`
2. Dick Move of the Week → `/week`
3. Not A Dick → `/not-a-dick`
4. Map → `/map`
5. About → `/about`

Right: the "Nominate a dick move" button (`sm` and up), the notification bell
with an unread badge, and the member avatar linking to `/me` — or a Sign in
button when anonymous. Below `lg` a hamburger opens a stacked panel with the
same five links plus the primary actions and a link to the community standard.

The unread count is computed once in `app/layout.tsx` and passed down; a failed
lookup falls back to zero rather than breaking the shell.

### Mobile bottom bar — `components/layout/mobile-nav.tsx`

Five thumb-reachable targets, fixed to the bottom, hidden at `lg` and above and
padded for `env(safe-area-inset-bottom)`:

| Slot | Target | Notes |
| --- | --- | --- |
| Feed | `/feed` | |
| Map | `/map` | |
| **Nominate** | `/nominate` | Raised yellow camera button — the point of the whole app |
| Not a dick | `/not-a-dick` | |
| Me | `/me` | |

DECISION: the bar hides itself on `/nominate`, `/notice/*` and `/admin*`. Those
screens have their own sticky action bars, and two competing bottom bars on a
phone is exactly the sort of thing DBAD would nominate.

### Footer — `components/layout/site-footer.tsx`

Hazard tape, then a concrete-textured dark block in three columns: the wordmark
and supporting line; **The board** (feed, week, not-a-dick, map, nominate); and
**The rules** (`FOOTER_NAV`: community standard, is this about you?, philosophy,
make a notice, privacy) plus sign-in. The bottom strip carries the closing line
— `THE WORLD HAS ENOUGH ALREADY.` — and a 20-unit spacer so the mobile bar never
covers it.

### Admin chrome — `components/admin/admin-shell.tsx`

Inside `/admin` the public header and footer stay, but the content is wrapped in
its own shell: a concrete header strip with the viewer's handle and role, a
sidebar of the ten sections at `lg` and up, and a horizontally scrolling tab row
below that. Denser than the public site, and built to work one-handed at 390px
because that is where a lot of moderating happens.

---

## URL conventions

| Pattern | Meaning |
| --- | --- |
| `/moves/<slug>` | Canonical nomination page. Slug is `slugify(dickMove)-slugify(suburb)-<4-digit seq>`, e.g. `blocking-the-footpath-batemans-bay-0042`. Stable; the sequence suffix keeps it unique. |
| `/d/<code>` | The short link printed on notices and encoded in the QR. `<code>` is the human short code, `DBAD-0042`. Redirects twice and lands on the nomination with `?via=qr`. |
| `/notice/<id>` | A saved printable notice. Notices are `noindex` but publicly readable by id — the artefact is meant to be handed out. |
| `/u/<handle>` | Member profile. Handles are matched case-insensitively. |
| `/about-you?code=<CODE>` | Right-of-reply form pre-filled with the nomination the code resolves to. Also accepts `?action=<AppealAction>`. |
| `?category=`, `?state=`, `?status=`, `?sort=`, `?region=`, `?q=`, `?cursor=` | Feed filters. Built by `feedHref()` and parsed by `parseFeedFilters()` in `src/lib/loaders/feed.ts`. The URL *is* the filter state, so a filtered feed is shareable and works without JavaScript. |
| `?next=<path>` | Post-sign-in destination. Validated: must start with a single `/`. |
| `?via=qr`, `?source=pwa`, `?source=shortcut` | Provenance markers, read by nothing in the app today. They exist so arrival channels can be told apart in server logs without a tracker. |
| `?viewer=<demo id>` | **Harness only.** `tools/preview/entry.tsx` reads it to switch demo identities. The Next.js app never reads it — sessions come from the `dbad_demo_user` cookie or a Supabase session. |

ASSUMPTION: short codes are treated as public but unguessable-enough for the
purpose. `DBAD-0042` is sequential and trivially enumerable — it is a lookup key
printed on a piece of paper, not a secret. Nothing behind `/d/<code>` is private:
it resolves only to approved nominations (`getIncidentByCode` filters on
`moderation_status = approved`).

---

## What deliberately has no route

- **No offender profiles.** There is no `/person/…`, no offender search, no
  "previously nominated" lookup. The data model has no entity to hang one on.
- **No public moderation history for a member.** The audit log is behind
  `/admin/audit` and shows moderator actions, not member conduct.
- **No public report list.** Reports are moderator-only; a reporter gets a
  confirmation message and nothing else.
- **No exact-location page.** The finest public geography is a suburb, or a
  named public place inside one.
