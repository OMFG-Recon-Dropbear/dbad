# 02 — User journeys

Each journey is written as numbered steps with what the system does at every
step. Where a step enforces something — validation, a PII scan, a moderation
gate — that is stated rather than implied.

Component references are to `src/components/`; validation rules to
`src/lib/domain/validation.ts`; scanning rules to `src/lib/domain/pii.ts`.

---

## 1. The primary mobile journey — spot it, snap it, DBAD it

The target is under a minute on a phone, standing next to the thing. Route:
`/nominate`. Component: `components/nominate/nominate-wizard.tsx`.

The wizard has four steps, and **step 3 disappears entirely when there are no
photos** — a text-only nomination is three steps.

### Step 1 — What happened

1. The member taps the raised camera button in the mobile bottom bar and lands
   on `/nominate`. The kind defaults to `dick_move`; `?kind=not_a_dick` and
   `?category=<id>` pre-set it.
2. **Take photo** opens the rear camera directly (`<input type="file"
   accept="image/*" capture="environment">`). **Upload** opens the library and
   accepts multiple files. Up to `LIMITS.photos` = 4; extras are dropped with a
   toast.
3. *System:* each file goes through `downscale()` in `src/lib/client/images.ts`
   — drawn to a canvas at a maximum of 1 600px on the long edge and re-encoded
   as JPEG at quality 0.82. Re-encoding strips all EXIF, GPS included. Nothing
   has left the device yet.
4. Optional: paste a public Facebook post URL. *System:* validated against
   `isFacebookUrl()`. DBAD never fetches it — the member still describes the
   incident themselves.
5. Pick a category from nine tiles. *System:* categories carrying a `caution`
   (Road, Neighbourhood, Dog, Internet, Workplace) show it immediately in a
   yellow warning box — "Never film while driving", "The dog is never the dick",
   and so on.
6. Write what happened, angry if that is what comes out. *System:* `scanText()`
   runs on every keystroke. Findings above `note` severity are printed under the
   field with the matched text and the reason. A `block` finding — a threat, a
   phone number, an email, a personal profile link — prevents the step advancing.
7. Tap **Make it funny**. *System:* `actions.suggest()` → `rewrite()` in
   `src/lib/ai/rewrite.ts`. `softenText()` strips personal attacks and profanity
   first and reports what it removed ("Removed: idiot, bloody. The behaviour
   stays, the abuse goes."), then either the Anthropic Messages API (when
   `ANTHROPIC_API_KEY` is set) or the built-in deterministic rewriter produces
   three suggestions tagged `dry`, `cheeky` and `factual`. Model output is run
   back through `scanText()` before it is shown — belt and braces.
8. Tap **Use this** on a suggestion. *System:* fills the one-liner, the plain
   "dick move" statement and the description; all three stay editable.
9. Optionally pick who was affected, from ten chips.
10. **Continue.** *System:* `validateStep(1)` checks category, description
    ≥ 12 chars, dick move ≥ 4, title ≥ 4, Facebook URL shape, and re-runs the
    PII scan on all three text fields. In Supabase mode, photos with no signed-in
    member are refused here with a link to sign in.

### Step 2 — Where and when

11. Tap **Use my general location**. *System:* `navigator.geolocation` with
    `enableHighAccuracy: false`. The fix is passed through `coarsen()` — rounded
    to two decimal places, roughly a kilometre — **before** it is stored in the
    draft, then `nearestPlace()` finds the closest entry in the 100-odd place
    index in `src/lib/domain/geo.ts` and pre-fills suburb and state. The UI says
    what it did: "Near Batemans Bay, NSW (about 4 km). Coordinates rounded to
    ~1 km — we never store anything precise."
12. Coordinates outside Australia return no suggestion and a toast.
13. Suburb and state can be typed instead; the map pin can be removed entirely.
14. Optional public place: "Coles car park", "Corrigans Beach". *System:* the
    combined suburb + place string is tested against a street-address pattern and
    rejected with "That looks like a street address. Public places only — 'Coles
    car park' is fine, '14 Smith St' is not."
15. Pick the date (day precision, no future dates) and roughly what time of day.
    *System:* exact timestamps are never collected; `partOfDay` is a coarse enum.

### Step 3 — Redaction check (only when photos exist)

16. Each photo opens in `RedactionEditor` — a canvas sized to the downscaled
    image. Drag anywhere to draw a box; it pixelates as you drag.
17. *System:* `pixelate()` downsamples the region to a coarse grid and draws it
    back with smoothing off. Block size scales with the region, so a small plate
    is destroyed just as thoroughly as a large face.
18. **Auto-detect faces** is enabled only when the browser exposes
    `FaceDetector`. Found boxes are padded by 35% of their longest edge. Where
    the API is absent the button is disabled and the caption says
    "auto-detect unavailable here, draw by hand".
19. Undo removes the last box; Clear removes all.
20. *System:* a mandatory checkbox — "I've checked every photo for faces, plates,
    house numbers and anything else identifying." Step 3 will not advance
    without it, and `validateNomination()` re-checks it on the server.

### Step 4 — Review and submit

21. The review card shows the nomination as it will appear, plus a live preview
    of the printable notice built by `buildNoticeLines()`.
22. The community standard is restated in five lines with a second mandatory
    checkbox: "I agree. I'm calling out the action, not the person."
23. An anonymous member is told plainly that the nomination will not appear on a
    profile and will not earn badges.
24. **DBAD it.** *System, in order:*
    - `applyRedactions()` renders each photo with its boxes burned in and exports
      a fresh JPEG data URL. **The un-redacted original never leaves the device.**
    - `validateNomination()` runs client-side first, so errors surface without a
      round trip.
    - `actions.submit()` calls the `submitNomination` server action, which calls
      `repo.createIncident()`, which validates *again* — the server is the
      authority.
    - Text fields are stored as `scanText(...).cleaned`, so anything maskable is
      masked at rest.
    - A short code and slug are allocated; a first printable notice is created
      from `buildNoticeLines()`.
25. **The moderation gate.** `moderationStatus` is set by one rule:

    ```
    kind === "not_a_dick" || photos.length === 0  →  "approved"
    otherwise                                     →  "pending"
    ```

    Positive nominations and text-only posts publish immediately. Anything with
    a photo waits for a human. See
    [04 — Moderation model](./04-moderation-model.md).
26. The success screen stamps `DBAD'D`, shows the reference (`DBAD-0043`), and
    offers **Print the DBAD notice** and **View nomination**. If the post is
    pending it says so — "usually within a few hours. Your notice is ready now."
27. Below the hazard tape, unprompted: place the notice where lawful, never on
    private property, never on paintwork, never in a way that starts a
    confrontation.

LIMITATION: photo transport differs by mode. In demo mode the redacted JPEG
travels inside the server action as a data URL (the 8 MB server-action body
limit in `next.config.ts` exists for exactly this). In Supabase mode
`SupabaseRepository.preparePhotos()` uploads to the `incident-photos` bucket
under `<user id>/…` first and only the public URL and storage path go into the
RPC — which is why photos require an account there.

---

## 2. Casting a verdict

Route: `/moves/<slug>`. Component: `components/incident/incident-interactive.tsx`.

1. A visitor reads the nomination. The Dick-o-meter shows the community position
   and the vote distribution.
2. Below it: four chips — Not a dick move · Bit of a dick move · Definitely a
   dick move · Absolute dickery.
3. Anonymous visitors get a toast and an inline sign-in link. Verdicts require a
   member.
4. The submitter cannot vote on their own nomination — enforced in the UI
   ("Nice try") and again in `castVote()`.
5. *System:* the tally updates optimistically, then `actions.castVote()` runs.
   On failure the previous tally and the previous chip state are both restored
   and a red toast explains why.
6. A verdict is one per member and changeable; re-selecting the same verdict is
   a no-op.
7. *System:* under `MIN_VOTES_FOR_VERDICT` = 5 the meter reads "Jury's still
   out" and no band is claimed. At five or more, `summariseVotes()` computes the
   mean dickery level (not = 0, bit = ⅓, definitely = ⅔, absolute = 1), the band
   from `bandFor()` (<25 not, <50 bit, <80 definitely, else absolute) and the
   share line `Community verdict: N% Dick Move`, where N is the share of voters
   who thought it was *at least* a bit of a dick move.
8. *System:* the moment the fifth vote lands, the submitter gets a
   `verdict_reached` notification.
9. Separately from verdicts, four reactions toggle freely: Fair call, Classic,
   Dick move, Redemption.

DECISION: the maths is deliberately simple and published. Anyone can reproduce
the score on the back of a beer coaster. "Top" ordering and Dick Move of the
Week use `dickeryRank()`, the same mean damped by `total / (total + 8)` so five
votes cannot beat five hundred.

---

## 3. Redemption

1. Any Dick Move that is not already redeemed shows a green-bordered panel:
   "Has this been fixed?"
2. The **Mark redeemed** button appears only for the submitter or a moderator.
   Everyone else sees "Submitter or a moderator can confirm".
3. A dialog asks what got fixed, capped at 300 characters.
4. *System:* `markRedeemed()` re-checks the permission, runs the note through
   `scanText().cleaned`, defaults an empty note to "Sorted. Humanity survives
   another day.", sets `status = "redeemed"`, records who confirmed it
   (`submitter` or `moderator`), and increments the redemption reaction.
5. The card flips to a green REDEEMED panel with the note; the stamp appears on
   feed cards, the map counts it, and `/feed?sort=redeemed` picks it up.
6. *System:* badges are re-evaluated for the submitter — five redemptions earns
   REDEMPTION ARC.
7. A moderator can also reach the same outcome from `/admin/nominations` or by
   actioning a `redemption` appeal.

---

## 4. Printing and placing a notice

Route: `/notice/<id>`. Component: `components/notice/notice-studio.tsx`.

1. Arrive from the wizard's success screen, from a nomination's notice preview,
   or from `/notice/new` for a blank standalone card.
2. The studio shows a live preview on the left and controls on the right.
3. Choose one of five templates: Official Warning, Friendly Reminder, Maximum
   Dickery, Australian Public Service Announcement, Minimal DBAD. *System:*
   switching template swaps the headline **only** if the current headline is
   still the previous template's default — a hand-written headline survives.
4. Edit the five lines: headline (60), the dick move (90), why you're here (220),
   location (80), community advice (140). *System:* every edit is debounced by
   500 ms and saved via `updateNotice()`, and each line is passed through
   `scanText().cleaned` and hard-truncated server-side.
5. Choose what the QR points at: the DBAD site, or this nomination
   (`/d/DBAD-0042`). The nomination option is disabled for standalone notices.
6. Choose A5 or A6. *System:* an inline `@page` rule sets the print size, and the
   label notes that A6 gives two per A5 sheet.
7. **Print notice** uses the browser print dialog against the print styles in
   `globals.css`. **Download PDF** opens `/api/notices/<id>/pdf?size=a5|a6` — a
   vector PDF drawn with `pdf-lib`, no headless browser. **Share** uses the Web
   Share API where available and falls back to copying the link.
8. *System:* the QR is generated by the dependency-free encoder in
   `src/lib/domain/qr.ts` — the same module renders it in the browser, in the
   PDF (as rectangles) and in the OG image.
9. **Where lawful.** Both the studio and the wizard success screen carry the same
   guidance, unprompted: under a wiper is generally fine, on the paint is not; a
   noticeboard is fine, someone's front door is not; never confront anyone to
   deliver it. Don't be a dick while telling someone else not to be a dick.

ASSUMPTION: "where lawful" is guidance, not legal advice, and the wording stays
deliberately non-specific about jurisdiction. Australian law on leaving notices
on vehicles and property varies by state and by council.

---

## 5. Facebook-originated submission

DBAD never scrapes Facebook. The journey is manual by design.

1. A member sees a dick move in a public Facebook group.
2. They open `/nominate` and paste the post URL into **Submit from Facebook**.
3. *System:* `isFacebookUrl()` accepts `facebook.com`, `fb.com` and `fb.watch`
   links with a path. Nothing is fetched.
4. The member describes the incident in their own words — the same step 1 as any
   other nomination, with the same PII scan and the same wording helper.
5. Screenshots of names, profiles or private messages are forbidden by the
   Internet category's caution and by the community standard. A screenshot that
   slipped through gets caught at the redaction step or by a moderator.
6. *System:* on submit the URL is stored as a `SocialSource` with
   `retrievedVia: "manual"`. It is provenance for moderators, not public content.
7. Sharing runs the other way too: every nomination has a Facebook share button
   built on `sharer.php`, plus an Open Graph card generated per nomination with
   the verdict line baked in.

LIMITATION: `FACEBOOK_APP_ID` and `FACEBOOK_APP_SECRET` appear in
`.env.example` for a future official oEmbed lookup. No code reads them today —
`retrievedVia` can be `"oembed"` in the type, but nothing ever sets it.

---

## 6. Right of reply — "Is this about you?"

Route: `/about-you`. Component: `components/content/about-you-view.tsx`.
No account required, and no need to identify yourself publicly.

1. Someone finds a notice under their wiper, scans the QR, lands on the
   nomination, and follows the "Is this about you?" link — which carries the
   short code through as `?code=DBAD-0042`.
2. Or they type the code straight into the lookup field. *System:*
   `getIncidentByCode()` resolves it and the matching nomination is shown so
   they can confirm they have the right one.
3. Pick one of six requests: Remove it · Correct it · Anonymise it · Add context
   · Right of reply · Mark it redeemed.
4. Write the message. *System:* minimum 10 characters, stored capped at 2 000.
5. Optionally leave a contact. *System:* stored capped at 200 characters,
   moderator-visible only, never published.
6. **Send.** *System:* `submitAppeal()` creates an appeal with status `open` and
   returns an eight-character reference.
7. The confirmation stamps RECEIVED, shows the reference, and says requests
   about identifying details are actioned first.
8. *System:* the appeal lands in `/admin/appeals`. If a moderator actions a
   `reply`, the published text appears beneath the nomination as a public reply
   — with no identity attached.

---

## 7. Reporting

1. Every nomination has a **Report this nomination** link; every comment has a
   flag icon.
2. The dialog offers nine reasons: identifies a person · private address ·
   children · harassment or threat · unsupported accusation · not actually a dick
   move · duplicate · spam · something else. Plus optional details.
3. *System:* no account is required. `reportContent()` checks the target exists,
   stores the report with status `open` and the details capped at 1 000
   characters, and returns "Thanks. A moderator will take a look. If it
   identifies someone, it comes down fast."
4. *System:* reports are moderator-only. The reporter gets a confirmation and
   nothing else — no status page, no visible report count.

LIMITATION: the flag icon on a comment currently opens the same report dialog
as the nomination, and the submitted report targets the *nomination*, not the
comment. Comment-level reporting exists in the data model and in the repository
(`targetType: "comment"`), and moderators can act on comment reports raised
automatically — but the per-comment UI path does not set the comment target.

---

## 8. Moderator queue review

Route: `/admin/queue`. Component: `components/admin/queue-view.tsx`.

1. A moderator signs in and opens the console. The sidebar badge shows how many
   nominations are pending.
2. The queue lists pending nominations oldest first, with full-size evidence
   photos, the redaction count per photo, the location, the affected groups and
   the submitter.
3. The moderator checks the photo against the standard: any face, plate, house
   number or other identifying detail the submitter missed.
4. Actions available on each item:
   - **Approve** — publishes it, notifies the submitter, re-evaluates their
     badges.
   - **Reject** with a note — sets `rejected`, notifies the submitter with the
     note and a link to `/standards`.
   - **Redact photo** — removes the offending photo, keeping the nomination.
   - **Anonymise** — detaches the submitter and coarsens the location to
     suburb-only.
   - **Feature this week** — promotes it to Dick Move of the Week.
5. *System:* every action is one `ModerationCommand` through the single
   `moderate` server action, which re-checks the role, applies the change, writes
   an audit row and revalidates the affected paths.
6. Pending nominations are invisible to the public. The submitter and moderators
   can see them; the page shows an explicit "only visible to you until a
   moderator has checked it" banner and `robots: noindex`.

---

## 9. Featuring Dick Move of the Week

1. An admin or moderator opens `/admin/nominations` (or the queue) and picks a
   nomination worth the award.
2. **Feature** sends `feature_week` with an optional `payload.week`; the default
   is `weekOf(new Date())` — the Monday of the current ISO week.
3. *System:* any other nomination already holding that week is unfeatured first.
   One award per week, no ties.
4. *System:* the submitter is notified (`featured`) with a link to `/week`.
5. `/week` shows the current pick, previous winners ordered by `dickeryRank()`,
   the greatest hits, the most-redeemed and the latest redemptions. The home page
   shows the same pick in its "Community pick" band. `/week` revalidates every
   300 seconds.
6. **Unfeature** clears it.

DECISION: featuring is a human decision informed by the ranking, not an
automatic cron job. The ranking sorts the candidates; a moderator still has to
agree the thing is funny and fair.
