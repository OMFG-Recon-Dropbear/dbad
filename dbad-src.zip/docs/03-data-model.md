# 03 — Data model

The DBAD database is PostgreSQL 16 on Supabase. Everything in this document is
defined in `supabase/migrations/` and exercised by `supabase/tests/local-pg.sh`.

The rule the whole schema is built around:

> **DBAD records behaviour, never people.**

There is no table, column or index for "the person who did the dick move", and
there never will be. The two places a real person can appear — the member who
submitted a nomination and the person appealing about one — are both detachable
(`incidents.anonymised`) or private (`appeals.contact`).

---

## Files

| File | What it contains |
| --- | --- |
| `0001_schema.sql` | Enums, tables, indexes, constraints, triggers |
| `0002_views.sql` | The verdict maths, `member_stats`, `appeal_replies` |
| `0003_functions.sql` | The RPC surface and its helpers |
| `0004_rls.sql` | Table privileges and every row level security policy |
| `0005_storage.sql` | The `incident-photos` bucket and its object policies |
| `seed.sql` | The demo site: 12 members, 31 nominations, 24 comments |

They apply cleanly in order on an empty database. `supabase db reset` runs all
five and then the seed.

---

## Entities

| Table | Purpose |
| --- | --- |
| `profiles` | Public member profile, 1:1 with `auth.users`. Handle, display name, avatar seed, role, chosen home area. Nothing private lives here. |
| `categories` | The nine nomination categories. Copy is editable by an admin through `moderate('edit_category')`. |
| `locations` | A suburb, a state, and at most a named **public** place. Coordinates are suburb centroids; `precision` records how precise the row claims to be. |
| `incidents` | The nomination itself: what happened, where (by suburb), roughly when, who it affected. Carries the denormalised vote/reaction/comment tallies the feed reads. |
| `incident_photos` | Evidence. Redacted and downscaled in the browser before upload; `redacted` records that the submitter completed the redaction review. |
| `social_sources` | Provenance for community examples that started on a public Facebook post. DBAD never scrapes — a member pastes the link. |
| `votes` | The Dick-o-meter. One verdict per member per nomination, changeable. |
| `reactions` | Fair call / classic / dick move / redemption. A set per member per nomination. |
| `comments` | Community commentary. Anything that looks like it identifies a person is stored `hidden` and reported automatically. |
| `reports` | Content flags. Anyone may file one, including anonymous visitors. Moderators only may read them. |
| `appeals` | Right of reply for someone who believes a nomination is about them. `contact` is **private**; the published reply is exposed through a view. |
| `redemptions` | The good ending. One per incident; also stamps `incidents.redeemed_at`. |
| `moderation_actions` | Append-only audit log. Every moderator decision, with actor, target and payload. |
| `printable_notices` | The five lines of a printable DBAD notice. Public by design — the thing is meant to be handed out. |
| `badges` / `user_badges` | Badge catalogue and who has earned what. |
| `notifications` | Per-member notifications. Own-only, always. |

### Views

| View | Why it exists |
| --- | --- |
| `member_stats` | The six numbers behind every profile page, the badge rules and the admin member list, computed once instead of six times. |
| `appeal_replies` | The **only** public window onto `appeals`. The table is moderator-only at row level because it holds a private contact and a private message; the published right of reply is exposed here, with the private columns left behind. The view deliberately runs with the owner's rights (not `security_invoker`) — that is what lets an anonymous reader see a reply without being able to see the appeal it came from. |

### Relationships

```mermaid
erDiagram
    auth_users  ||--|| profiles          : "is"
    profiles    ||--o{ incidents         : submits
    profiles    ||--o{ comments          : writes
    profiles    ||--o{ votes             : casts
    profiles    ||--o{ reactions         : leaves
    profiles    ||--o{ notifications     : receives
    profiles    ||--o{ user_badges       : earns
    profiles    ||--o{ moderation_actions: decides
    badges      ||--o{ user_badges       : "awarded as"
    categories  ||--o{ incidents         : classifies
    locations   ||--o{ incidents         : "happened in"
    incidents   ||--o{ incident_photos   : "evidenced by"
    incidents   ||--o| social_sources    : "sourced from"
    incidents   ||--o{ votes             : "judged by"
    incidents   ||--o{ reactions         : "reacted to"
    incidents   ||--o{ comments          : "discussed in"
    incidents   ||--o| redemptions       : "redeemed by"
    incidents   ||--o{ appeals           : "appealed against"
    incidents   ||--o{ printable_notices : "printed as"
```

`reports.target_id` is polymorphic (an incident or a comment, per
`target_type`), so it carries no foreign key; `report_content()` checks the
target exists before writing the row.

### Denormalised columns

Three sets of columns on `incidents` are caches, written only by triggers:

- `votes_*`, `react_*`, `comment_count` — maintained from `votes`, `reactions`
  and `comments`. `comment_count` counts **visible** comments only, so hiding a
  comment drops the count without any extra work in `moderate()`.
- `state`, `region`, `location_label` — copied from the incident's location so
  the feed can filter by state or region, and search by place, without a join.
  A change to a location row re-syncs every incident that points at it.
- `redeemed_at` — stamped from the redemption row so "latest redemptions" can be
  ordered without reaching into a joined table.

And two generated columns: `votes_total`, and `dickery_rank`, the
confidence-weighted score behind "top" and Dick Move of the Week. It mirrors
`dickeryRank()` in `src/lib/domain/verdict.ts` exactly, so the SQL ordering and
the TypeScript display agree.

---

## Privacy invariants enforced in SQL

These are constraints and triggers, not conventions. They hold no matter which
client is talking to the database.

| Invariant | How |
| --- | --- |
| No published text carries a contact detail | `reject_contact_details()` trigger on `incidents` (title, dick move, description, advice), `comments.body`, all five `printable_notices` lines, `appeals.public_reply` and `redemptions.note`. The patterns are POSIX ports of `EMAIL` and `PHONE` in `src/lib/domain/pii.ts`. |
| Identifying details are masked before they are stored | Every write RPC runs `scrub_text()`, which mirrors `scanText().cleaned`: phone, email, personal profile URL, social handle, street address, rego and named person all become `[… removed]`. |
| A comment that identifies someone never goes public | `add_comment()` stores it `hidden` and files an `identifies_person` report for a moderator. |
| A threat is refused outright | `contains_threat()` — the one finding that cannot be masked away. |
| A location is never an address | `locations.place` is capped at 80 characters and rejected outright if it starts with a street number (`locations_no_street_address`). `submit_nomination()` refuses "12 Smith Street" shapes with the same message the wizard uses. |
| Coordinates are Australian and approximate | `approx_lat` between -44 and -10, `approx_lng` between 112 and 154, `numeric(9,6)`, documented as suburb centroids. `precision` must be `suburb` unless a place is actually named. |
| An anonymised nomination has no submitter | `incidents_anonymised_has_no_submitter` check. `moderate('anonymise')` nulls the submitter *and* repoints the incident at the suburb-only location (locations are shared rows, so it creates or reuses one rather than editing the place out from under every other nomination in the same car park). |
| Incident timing is day-precision | `occurred_on` is a `date`, and `part_of_day` is a coarse enum. An exact timestamp is identifying. |
| An appeal's contact never leaks | `appeals` is moderator-only at row level and has no public policy; `appeal_replies` exposes `public_reply` and nothing else. |
| Roles cannot be self-assigned | `profiles_guard_role` rejects any change to `profiles.role` unless the transaction-local flag `dbad.role_change` is set, which only `moderate('change_role')` — admins only — does. |
| Unredacted photos never go public | The `incident_photos` select policy requires `redacted` for anyone but the submitter and moderators. |
| Uploads are namespaced by uploader | Storage objects must live under `<auth.uid()>/…` with an image extension. |

---

## RPC surface

Every write goes through one of these. They are `SECURITY DEFINER` with
`set search_path = public`, they authorise the caller themselves with
`auth.uid()` and `viewer_role()`, and they answer with an `ActionResult`-shaped
`jsonb` (`{ ok, message?, fieldErrors?, … }`) rather than raising — every one of
these failures is a thing to say to a member, not a 500.

| Function | Who may call it | What it does |
| --- | --- | --- |
| `submit_nomination(payload jsonb)` | anon, member | Validates (server-side authority for `validateNomination`), creates the location, incident, photos, social source and first printable notice. Positive nominations and photo-less posts go straight to `approved`; anything with a photo waits for a moderator. Returns `{ id, slug, short_code, notice_id, moderation_status }`. |
| `cast_vote(incident uuid, verdict text)` | member | Upserts the vote and returns the tally. Refuses your own nomination, and anything not yet public. Notifies the submitter the moment the fifth vote lands. |
| `toggle_reaction(incident uuid, kind text)` | member | Adds or removes one reaction; returns the tally and the viewer's set. |
| `add_comment(incident uuid, body text)` | member | Scrubs, then publishes — or holds the comment as `hidden` with an automatic report if it looked like it identified someone. |
| `mark_redeemed(incident uuid, note text)` | submitter, moderator | Records the redemption and the confirming reaction. |
| `report_content(payload jsonb)` | **anon**, member | Flags an incident or a comment. Reporting something that identifies a person must never require an account. |
| `submit_appeal(payload jsonb)` | **anon**, member | Files an appeal and returns its short reference. The person appealing is, by definition, not a member of the community that posted about them. |
| `moderate(command jsonb)` | moderator, admin | Every `ModerationActionKind`: approve, reject, remove, restore, anonymise, redact_photo, mark_redeemed, mark_overruled, feature_week, unfeature, hide_comment, restore_comment, resolve_report, dismiss_report, action_appeal, decline_appeal, publish_reply, change_role (admin only), edit_category, edit_template. Writes the audit row and the notifications. |
| `admin_stats()` | moderator, admin | The dashboard numbers in one round trip. |
| `profile_stats(uuid)` | anyone | The six profile counters as `jsonb`. |
| `refresh_badges(uuid)` | service role (and internally) | Applies the rules in `src/lib/domain/badges.ts` and notifies anything newly earned. Idempotent. |
| `map_clusters()` | anyone | One row per region: approximate centroid, counts, top category. Never a point per incident. |

Helpers worth knowing about: `viewer_role()`, `is_moderator()`, `is_admin()`,
`verdict_percent/agree_percent/band/share_line()`, `slugify()`, `hash32()`,
`week_of()`, `guess_region()`, `scrub_text()`, `pii_kinds()`,
`build_notice_lines()`. Each mirrors a named function in `src/lib/domain` so the
browser, the server and the database all agree on the same rule.

---

## RLS matrix

Row level security is on for **every** table in `public`. Privileges are revoked
from `anon` and `authenticated` first and granted back deliberately, because a
hosted Supabase project grants `ALL` on new public tables by default.

`moderator` and `admin` are ordinary `authenticated` sessions whose rows are
widened by policy — the role comes from `profiles.role` via `viewer_role()`.

Legend: **✓** allowed · **own** only your own rows · **—** denied.
`S I U D` = select, insert, update, delete.

| Table | anon | member | moderator | admin |
| --- | --- | --- | --- | --- |
| `profiles` | S | S, U own | S, U own | S, U own |
| `categories` | S | S | S | S (edits via `moderate`) |
| `badges`, `user_badges` | S | S | S | S |
| `locations` | S | S | S | S |
| `incidents` | S approved | S approved + own | S all | S all |
| `incident_photos` | S redacted, approved | + own | S all | S all |
| `social_sources` | S visible incidents | S visible incidents | S all | S all |
| `redemptions` | S visible incidents | S visible incidents | S all | S all |
| `comments` | S visible, approved | S visible + own, I own | S all | S all |
| `votes` | — | S own, I own, U own | S all | S all |
| `reactions` | — | S own, I own, D own | S all | S all |
| `reports` | I | I | S, I | S, I |
| `appeals` | I | I | S, I | S, I |
| `appeal_replies` (view) | S | S | S | S |
| `member_stats` (view) | S | S | S | S |
| `moderation_actions` | — | — | S | S |
| `printable_notices` | S, I, U own/anon | S, I, U own | S, I, U any | S, I, U any |
| `notifications` | — | S own, U own | S own, U own | S own, U own |

Nothing in the table above includes `UPDATE` or `DELETE` on `incidents`,
`votes` tallies, `redemptions`, `reports`, `appeals` or `moderation_actions`.
Those all move through the RPCs, which is what keeps the audit log honest.

Extra conditions worth spelling out:

- A member may insert a vote only on an **approved** incident that is **not
  their own** — enforced in the policy `with check`, not just in `cast_vote()`.
- A member may insert a comment only on an approved incident, only as
  themselves, and only with `status = 'visible'`; holding a comment is
  `add_comment()`'s job, hiding one is `moderate()`'s.
- A submitter can always read their own pending or rejected nomination, and its
  photos, so the "awaiting review" page works.
- Anonymous notices (`created_by is null`) can be edited by anyone who has the
  id, matching the demo store — a notice is a printable artefact, not a record.

### Storage

Bucket `incident-photos`, public read, 8 MiB, `image/jpeg|png|webp|avif`.

| Action | Rule |
| --- | --- |
| select | anyone, any object in the bucket |
| insert | `authenticated`, path must start `<auth.uid()>/`, image extension only |
| update | `authenticated`, only within `<auth.uid()>/` (both the old and the new name) |
| delete | `authenticated`, only within `<auth.uid()>/` |

Moderators redact by deleting the photo row through `moderate('redact_photo')`;
the object itself is removed by the moderation job running as the service role.

---

## Testing

```bash
./supabase/tests/local-pg.sh      # throwaway PostgreSQL 16 cluster on port 54329
```

It initialises a temporary cluster, stubs the parts of Supabase the migrations
legitimately depend on (`auth.users`, `auth.uid()`, `auth.role()`, `auth.jwt()`,
the `storage` schema, and the `anon` / `authenticated` / `service_role` roles),
applies every migration and the seed, then runs `rls.test.sql`.

That file asserts the invariants above from each role's point of view using
`set local role` plus `request.jwt.claims`: what an anonymous visitor can and
cannot see, that a member cannot read another member's notifications or vote on
their own nomination, that roles cannot be self-assigned, that the PII trigger
rejects a phone number, that `moderate()` does what the demo store does for
every action kind, and that the storage policies hold. Each check prints
`PASS`; the first failure takes the exit code with it.

---

## Notes and deliberate choices

- **Enums over check constraints.** Every closed set in
  `src/lib/domain/types.ts` is a PostgreSQL enum of the same name, so a typo
  fails at write time and `supabase gen types` produces the same unions the
  application already uses. `affected` is the exception: it is `text[]` with an
  allow-list check, because a member picks several.
- **`citext` for handles.** `profiles.handle` is `citext`, so
  `.eq('handle', …)` is case-insensitive without an `ilike` (and without `_`
  being read as a wildcard). The extension lives in `public`, which means a
  `supabase gen types` run also emits its helper functions.
- **`seq` and `short_code`.** `seq` is an identity column; `short_code` is
  generated from it (`DBAD-0042`). The seed sets explicit values and then
  restarts the sequence at 45, so demo codes match the ones in the demo store.
- **Slugs.** Generated by trigger when not supplied:
  `slugify(dick_move)-slugify(suburb)-0042`, identical to the demo store's rule.
- **`edit_template` is audit-only.** Notice template copy lives in
  `src/lib/notice/lines.ts`, same as in the demo store, so the command records
  the request rather than changing a table. `edit_category` does update the
  `categories` row, because that table exists here and the demo's comment says
  copy edits are configuration in Supabase mode.
- **`mark_redeemed` moves the redemption tally by inserting a reaction** from
  the person confirming it, rather than bumping the counter behind the
  reactions table's back. The visible effect is the same as the demo store's.
- **`map_clusters()` picks a region's state by mode**, not by "whichever
  incident happens to be first" — Canberra spans the ACT and part of NSW.
- **Feed search is full text, not substring.** The demo store does a
  case-insensitive `includes()`; here the query runs against the `search`
  tsvector (title and dick move weighted A, description B, location C) through
  `websearch_to_tsquery`. Word-level matching with a GIN index is the version
  that survives a real corpus, at the cost of not matching mid-word.
- **Voting, reacting and commenting require an approved nomination.** The demo
  store only checks that the incident exists; here the RPC and the RLS policy
  both require `moderation_status = 'approved'`, so nothing can accumulate
  votes while it is still in the queue.
