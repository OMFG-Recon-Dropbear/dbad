# 04 — Moderation model

Everything a moderator can do, everything the platform does automatically, and
the things nobody can do at all. The rules here live in three places that agree
with each other: `src/lib/domain/pii.ts` and `validation.ts` (the checks),
`src/lib/data/demo/demo-repository.ts` (`moderate()`), and the SQL `moderate()`
RPC described in [03 — Data model](./03-data-model.md).

---

## Two statuses, two different questions

A nomination carries two independent status fields, and conflating them is the
easiest way to get this wrong.

| Field | Type | Question it answers | Values |
| --- | --- | --- | --- |
| `moderationStatus` | `ModerationStatus` | *May this post be seen?* | `pending` · `approved` · `rejected` · `removed` |
| `status` | `IncidentStatus` | *Where did the behaviour end up?* | `open` · `redeemed` · `overruled` |

**Only `approved` is public.** Every public read path filters on it:
`publicIncidents()` in the demo store, the RLS select policy in Supabase, the
sitemap, the map clusters, `getIncidentByCode()`.

- `pending` — waiting for a moderator. Visible to the submitter and to
  moderators only. The nomination page shows an explicit banner and sets
  `robots: noindex`.
- `rejected` — did not meet the community standard. The submitter is notified
  with the moderator's note and a link to `/standards`.
- `removed` — was public, taken down. Reversible with `restore`.

The behaviour statuses are the human story: `open` is the default, `redeemed`
means somebody fixed it, `overruled` means the community decided it was not a
dick move after all and the submitter wore it.

Comments have their own three: `visible` · `hidden` · `removed`. Reports have
`open` · `reviewing` · `resolved` · `dismissed`. Appeals have `open` ·
`in_review` · `actioned` · `declined`.

---

## What publishes immediately, and what waits

One rule, in `createIncident()`:

```ts
moderationStatus:
  input.kind === "not_a_dick" || photos.length === 0 ? "approved" : "pending"
```

| Nomination | Result | Why |
| --- | --- | --- |
| Not-A-Dick, with or without a photo | `approved` | A positive nomination cannot ruin anyone's day. The downside of publishing it unchecked is close to nil. |
| Dick Move, no photo | `approved` | Text has already been scanned twice — in the browser and again on the server — and text-only posts carry no face, no plate, no house number. |
| Dick Move, one or more photos | `pending` | A photo is the one thing an automated check cannot be trusted with. A human looks before it goes public. |

DECISION: this is the entire pre-publication gate. It is deliberately narrow —
a queue that holds everything gets skimmed, and a queue that gets skimmed is
worse than no queue. Photos are the only category where automation genuinely
cannot substitute for a person, so photos are the only thing that waits.

ASSUMPTION: moderator throughput can keep up with photo nominations. The
success screen promises "usually within a few hours". At the volumes DBAD is
built for that holds; it is a staffing assumption, not a technical one.

---

## Automatic checks

### Text scanning — `scanText()`

`scanText()` runs client-side for instant feedback and server-side as the
authority. Nine rules, three severities. The order matters: findings are sorted
by position, overlaps are resolved in favour of the more severe finding, and
`cleaned` is the text with every maskable match replaced.

| Kind | Severity | Mask | What it catches |
| --- | --- | --- | --- |
| `threat` | **block** | — | "I'll find him", "watch your back", "I know where you live", threats of violence. Cannot be masked away. |
| `phone` | **block** | `[phone removed]` | Australian mobile, landline, 1300/1800 and 13xx numbers. |
| `email` | **block** | `[email removed]` | Any email address. |
| `personal_profile_url` | **block** | `[profile link removed]` | Links to a person's Facebook / Instagram / TikTok / LinkedIn / X profile. Post, group, share, video and reel URLs are excluded. |
| `social_handle` | warn | `[handle removed]` | `@something` of 3–30 characters. |
| `street_address` | warn | `[address removed]` | "14 Smith Street", "3/22 Beach Rd" and 30-odd other street-type suffixes. |
| `rego` | warn | `[rego removed]` | Common Australian plate shapes. Requires a letter *and* a digit; `DBAD`, `COVID`, `ABN`, `GST` are excluded. |
| `named_person` | warn | `[name removed]` | "his name is Dave", "named Sarah", "Mr Thompson". |
| `child` | note | — | Mentions of kids. Informational only — children being *affected* is legitimate; identifying one is not. |

The severities do different jobs in different places, which is the subtlety
worth reading twice:

- `ScanResult.blocked` is `true` **only for a threat**. That is the one finding
  that has no safe rewrite.
- `validateNomination()` is stricter: for the title, dick move and description
  it refuses on a threat *and* refuses on any other `block`-severity finding
  with "Remove identifying details: phone, email…". A phone number in a
  nomination stops the submission.
- `validateComment()` only refuses on a threat. Identifying details in a comment
  are handled by holding the comment instead (below).
- Stored text is always `scanText(...).cleaned`, so even an accepted string has
  its maskable matches replaced at rest. That covers nomination text, comment
  bodies, redemption notes, all five notice lines, published replies, and the
  description supplied with an `anonymise` action.

### Auto-held comments

`addComment()` refuses outright on a threat. Otherwise it checks for findings of
kind `phone`, `email`, `personal_profile_url`, `named_person`, `street_address`
or `rego`. If any are present:

1. The comment is stored with `status = "hidden"` — never publicly visible.
2. A report is filed automatically: `targetType: "comment"`, reason
   `identifies_person`, details "Auto-held: comment contained identifying
   details.", status `open`.
3. The member is told: *"That comment looked like it identified someone, so it's
   been held for a moderator. Describe the behaviour, not the person."*
4. The parent nomination's comment count is **not** incremented — hidden
   comments do not count.

LIMITATION: `social_handle` is a `warn` finding and is masked in the stored
body, but it is not in the auto-hold list. A comment containing `@someone` is
published with the handle replaced by `[handle removed]` rather than held.

### Wording helper

The rewriter (`src/lib/ai/rewrite.ts`) is a safety feature as much as a comedy
one. `softenText()` strips a fixed list of personal attacks and profanity and
reports what it removed, so the member sees the abuse leaving. Anthropic output
is run back through `scanText()` before it is displayed — the model is never
trusted to have obeyed the system prompt.

LIMITATION: the profanity list in `pii.ts` includes the word `absolute`, which
is also half of the verdict label "Absolute dickery". `softenText()` will strip
it from a submitter's own words. Cosmetic, and only in the "factual" suggestion.

---

## Moderation action catalogue

Every moderator decision is one `ModerationCommand` — `{ action, targetType,
targetId, note?, payload? }` — sent through one server action
(`app/actions/admin.ts`) to one repository method (`repo.moderate()`). Members
are refused before anything else happens; **every successful action writes an
audit row**.

| Action | Target | Effect |
| --- | --- | --- |
| `approve` | incident | `moderationStatus = approved`. Notifies the submitter, re-evaluates their badges. |
| `reject` | incident | `moderationStatus = rejected`. Notifies the submitter with the moderator's note and a link to `/standards`. |
| `remove` | incident | `moderationStatus = removed`. Takes a published nomination down. |
| `restore` | incident | `moderationStatus = approved`. Undoes a removal. |
| `anonymise` | incident | Sets `anonymised`, nulls the submitter, strips the place name and drops the location precision to `suburb`. An optional `payload.description` replaces the description (scrubbed first). |
| `redact_photo` | photo | Removes the photo named by `payload.photoId` from the nomination. The nomination survives. |
| `mark_redeemed` | incident | `status = redeemed`, creates a redemption confirmed by `moderator` with `payload.note`, notifies the submitter, re-evaluates badges. |
| `mark_overruled` | incident | `status = overruled`. Notifies the submitter: "The community reckons this one wasn't a dick move. Owning it earns respect." |
| `feature_week` | incident | Clears whoever held `payload.week` (default: this ISO Monday), sets it here, notifies the submitter. One award per week. |
| `unfeature` | incident | Clears `featuredWeek`. |
| `hide_comment` | comment | `status = hidden`; decrements the parent's visible comment count. |
| `restore_comment` | comment | `status = visible`; increments the count if it was not already visible. |
| `resolve_report` | report | `status = resolved`, stamps who and when. |
| `dismiss_report` | report | `status = dismissed`, stamps who and when. |
| `action_appeal` | appeal | `status = actioned`. Optional `payload.publicReply` is scrubbed and capped at 600 characters. |
| `decline_appeal` | appeal | `status = declined`. |
| `publish_reply` | appeal | Sets the public reply (scrubbed, 600) and marks the appeal actioned. |
| `change_role` | user | **Admin only.** Sets `member`, `moderator` or `admin`; anything else is refused. |
| `edit_category` | category | Records the copy change. In Supabase mode it updates the `categories` row; the demo store keeps the shipped copy. |
| `edit_template` | template | Audit-only in both modes — notice template copy lives in `src/lib/notice/lines.ts`, so the command records the request. |

The `switch` ends in `cmd.action satisfies never`, so adding a
`ModerationActionKind` without handling it is a compile error rather than a
silent no-op.

---

## Reports

1. **Anyone** can file one — no account required. That is deliberate: the person
   most likely to notice that a photo identifies someone is the person it
   identifies, and they are by definition not a member.
2. Nine reasons: identifies a person · private address · harassment · defamatory
   · children · not a dick move · duplicate · spam · other. Details capped at
   1 000 characters.
3. `reportContent()` verifies the target exists, then stores the report `open`.
4. Reports also arrive automatically from the comment auto-hold.
5. Moderators work them at `/admin/reports`, filterable by status. From each row
   they can act on the target directly — `remove` or `anonymise` an incident,
   `hide_comment` a comment — with the report reason carried through as the audit
   note, then `resolve_report` or `dismiss_report`.
6. Reports are moderator-only at row level. The reporter gets a confirmation
   message and nothing else — no status page, no visible report counter.

The dashboard's "reported content" figure counts reports in `open` or
`reviewing`.

---

## Appeals

Appeals come from `/about-you`, the right-of-reply route. The person appealing
is, almost always, not a member.

1. Six requested actions: `removal`, `correction`, `anonymisation`, `context`,
   `reply`, `redemption`.
2. The appellant identifies the nomination by its printed short code. Message
   minimum 10 characters, stored capped at 2 000. Contact optional, capped at
   200, **moderator-visible only**.
3. `submitAppeal()` returns an eight-character reference. The confirmation says
   requests about identifying details are actioned first.
4. Moderators work them at `/admin/appeals`. The view pairs the appeal with the
   nomination and offers the underlying remedy alongside the appeal outcome:
   `remove` or `anonymise` or `mark_redeemed` on the incident (audit note:
   "Appeal <ref>: removal requested"), then `action_appeal` or `decline_appeal`.
5. `publish_reply` puts the appellant's words beneath the nomination as a public
   reply, with no identity attached. `IncidentDetail.publicReplies` only ever
   surfaces appeals that are `actioned` and have reply text.

DECISION: the appeal contact is never joined to anything. It is a reply-to
address and nothing else. Nothing in the schema links an appellant to a
nomination as its subject — doing so would create exactly the offender record the
whole platform refuses to keep.

---

## Anonymisation instead of deletion

When something goes wrong, the default remedy is `anonymise`, not `delete`.

`anonymise` sets `anonymised = true`, nulls `submitterId`, clears the place name
and drops the location precision to `suburb`. The nomination, its verdict, its
comments and its redemption survive; the thread that led back to a person does
not.

Reasons:

- **The audit log stays honest.** A deleted row leaves a hole; an anonymised row
  leaves a record of what was decided.
- **Redemption stays visible.** A nomination that ended in redemption is the best
  content on the site. Deleting it deletes the good ending too.
- **It is the proportionate remedy.** Most appeals are not "this is defamatory",
  they are "that's my car and I'd rather it wasn't obvious". Dropping the place
  name usually fixes that completely.

`remove` still exists for content that should not be up at all, and `restore`
undoes it. In Supabase this is enforced structurally: an
`incidents_anonymised_has_no_submitter` check, and `moderate('anonymise')`
repoints the incident at a suburb-only location row rather than editing the
place out from under every other nomination in the same car park.

---

## Audit logging

Every successful moderation action appends a `ModerationAction`: actor, action
kind, target type, target id, optional note, timestamp. Nothing in the admin UI
can bypass it — the audit write is at the end of `moderate()`, after the switch,
so an action either happens *and* is logged or does neither.

`/admin/audit` shows the most recent 120 entries with the actor's handle
resolved. The dashboard shows the most recent 8.

The log is append-only. In Supabase, `moderation_actions` has no update or
delete privilege for any role — the only way in is through `moderate()`.

---

## Roles and permissions

Three roles, defined in `src/lib/domain/types.ts` and carried on the profile.

| Capability | member | moderator | admin |
| --- | --- | --- | --- |
| Nominate, vote, react, comment | ✓ | ✓ | ✓ |
| Mark own nomination redeemed | ✓ | ✓ | ✓ |
| Report content | ✓ (so can anon) | ✓ | ✓ |
| See pending nominations | own only | all | all |
| Open `/admin` | — | ✓ | ✓ |
| Approve / reject / remove / restore | — | ✓ | ✓ |
| Anonymise, redact a photo | — | ✓ | ✓ |
| Mark redeemed or overruled on any nomination | — | ✓ | ✓ |
| Feature / unfeature Dick Move of the Week | — | ✓ | ✓ |
| Hide / restore comments | — | ✓ | ✓ |
| Resolve or dismiss reports | — | ✓ | ✓ |
| Action, decline or publish a reply to an appeal | — | ✓ | ✓ |
| Read appeal contact details | — | ✓ | ✓ |
| Read the audit log | — | ✓ | ✓ |
| Change a member's role | — | — | ✓ |
| Edit category / template copy | — | ✓ | ✓ |

Enforcement is layered, and each layer assumes the others might not be there:

1. `src/middleware.ts` redirects anonymous visitors away from `/admin`, `/me`
   and `/notifications`.
2. `app/admin/layout.tsx` calls `isModerator()` and redirects a plain member.
3. The `moderate` server action re-checks the role before touching the
   repository.
4. `repo.moderate()` refuses `role === "member"` itself, and `change_role`
   refuses anyone who is not an admin.
5. In Supabase, RLS policies and the `SECURITY DEFINER` RPCs authorise
   independently of anything the application believes, and a
   `profiles_guard_role` trigger blocks any role change that did not come
   through `moderate('change_role')`.

---

## What administrators cannot do

This is as much a part of the model as what they can.

- **There is no offender scoring, and no offender record to score.** No table,
  no column, no aggregate. Nobody — moderator, admin or service role — can look
  up "everything about this person", because the data to answer it was never
  collected. Gamification (badges, stats, the profile) applies to *contributors*
  only. This is stated on `/privacy` as a promise and enforced in the schema as
  an absence.
- **No admin can promote themselves.** `change_role` is admin-only, and the SQL
  trigger rejects any role change that did not come through it.
- **No admin can edit a member's words.** The verbs are hide, remove and
  anonymise. The one exception is `anonymise` with a replacement description,
  which is logged like everything else.
- **No admin can quietly delete history.** The audit log is append-only.
- **No admin can un-blur a photo.** Redaction happens on the submitter's device
  before upload; the original never reaches the server. A moderator can remove a
  photo, not recover one.
- **No admin can read an appellant's contact for any purpose but replying**, and
  nothing joins it to the nomination's subject.

---

## Community standard enforcement

The standard at `/standards` is ten rules, and each maps to a mechanism rather
than a hope:

| Rule | Enforced by |
| --- | --- |
| Photograph the behaviour, not the person | Device-side redaction, mandatory review checkbox, moderator re-check on every photo nomination |
| Don't publish identifying information | `scanText()` in the browser, in the server action and in a SQL trigger; auto-held comments |
| Don't trespass | Moderator judgement at the queue; rejection with a note |
| Don't interfere with vehicles or property | Notice-placement guidance on the studio and the success screen |
| Don't confront people for content | Guidance; category cautions ("Never film while driving") |
| Don't manufacture incidents | Moderator judgement; reports |
| Don't settle personal disputes | Moderator judgement; category cautions on Neighbourhood and Workplace |
| Don't encourage harassment | Threat rule blocks outright; pile-on comments removed |
| If you're wrong, own it | `mark_overruled` and the overruled stamp, framed as respect rather than punishment |
| If they fix it, acknowledge it | `mark_redeemed`, the REDEMPTION ARC badge, the redemption feed and the green stamp |

The submitter agrees to the standard explicitly at step 4 of the wizard —
`acceptedStandard` is a required field and `validateNomination()` refuses
without it.
