# 05 — Privacy controls

DBAD publishes photographs of things people did in public and invites a country
to have an opinion about them. That is only defensible if the platform never
becomes a dossier. This document is the honest account of how that is enforced,
including where it depends on a human rather than a machine.

The public-facing version of this is `/privacy`
(`components/content/privacy-view.tsx`). This document is the engineering
version: same promises, with the mechanisms and the gaps.

---

## The one structural decision

> **There is no entity for "the person who did the dick move."**

Not a table, not a column, not an index, not a foreign key. The domain types say
so in a comment at the top of `src/lib/domain/types.ts`; the schema says so by
omission (see [03 — Data model](./03-data-model.md)).

Everything else in this document is a control. This is not a control — it is the
shape of the thing. A control can be misconfigured. An absent table cannot be
queried.

The two places a real person can appear are both handled:

| Person | Where they appear | Protection |
| --- | --- | --- |
| The submitting member | `incidents.submitterId` | Detachable — `anonymise` nulls it permanently |
| Someone appealing about a nomination | `appeals.contact` | Never public; moderator-only at row level; used to reply and nothing else |

---

## What is never stored

| Never stored | Enforced by |
| --- | --- |
| Names of nominated people | `named_person` scan rule; the standard; moderator review |
| Phone numbers | `phone` rule — blocks a nomination, masks anywhere else |
| Email addresses | `email` rule — same |
| Registration plates (in text) | `rego` rule; in photos, the redaction step |
| Faces | Device-side pixelation; mandatory review; moderator re-check |
| Residential addresses | `street_address` rule; a second address check in `validateNomination()` on the suburb + place pair; the SQL `locations_no_street_address` constraint |
| Personal social-media profile links | `personal_profile_url` rule |
| Precise coordinates | `coarsen()` before the value enters the draft; the ~±44 to ~±10 / 112 to 154 bounds check; `precision` recorded on every location |
| Exact timestamps of an incident | `occurredOn` is a date; `partOfDay` is a coarse enum |
| Uploaded avatars | There are none — avatars are generated from a hash of the handle |
| Anything about children beyond "they were affected" | `child` scan note; `children` report reason actioned first; the standard |
| Third-party analytics identifiers | There is no analytics |

---

## The redaction pipeline

Five stages. Only the last two involve a server.

### 1. Downscale and re-encode — on the device

`downscale()` in `src/lib/client/images.ts` draws the selected file to a canvas
at a maximum of `MAX_DIMENSION` = 1 600px on the long edge and re-encodes it as
JPEG at `JPEG_QUALITY` = 0.82.

Re-encoding through a canvas **discards all EXIF**, including GPS coordinates,
camera serial, and the original capture timestamp. The privacy benefit is a side
effect of a performance decision — the same step is what makes a nomination
possible on mobile data — which is a good place for a privacy control to live,
because nobody is tempted to remove it.

### 2. Pixelation — on the device

`pixelate()` downsamples a rectangle to a coarse grid and draws it back with
image smoothing off. Block size is `max(10, longest edge / 6)` pixels, so the
blur scales with the region: a small number plate is destroyed as thoroughly as
a large face rather than merely softened.

`RedactionEditor` (`components/nominate/redaction-editor.tsx`) is a touch-first
canvas — drag to draw, and it pixelates as you drag. Manual boxes are outlined in
warning yellow, auto-detected faces in alert red. Undo removes the last box;
Clear removes all.

### 3. Face detection — progressive enhancement

`detectFaces()` uses the browser's Shape Detection API (`window.FaceDetector`)
when it exists, with `maxDetectedFaces: 12` and each bounding box padded by 35%
of its longest edge. Any failure returns an empty array.

`faceDetectionAvailable()` drives the UI honestly: where the API is missing, the
Auto-detect button is disabled with the tooltip "Automatic face detection isn't
available in this browser — draw the boxes by hand", and the caption reads
"auto-detect unavailable here, draw by hand".

LIMITATION: `FaceDetector` is a Chromium API and is not universally available;
Safari on iOS — a large share of DBAD's likely traffic — does not expose it. The
code comment says it plainly: *"Never the only line of defence — the manual
review step is mandatory."*

LIMITATION: **there is no automatic number-plate detection at all.** The
`Region` type has a `plate` kind, and the editor colours it, but nothing produces
one. Plates are found by the submitter, then by a moderator.

LIMITATION: `.env.example` documents `DBAD_VISION_PROVIDER` (`none | anthropic`)
for a server-side vision pass. **No code reads it today.** It is a planned hook,
not a shipped control. Do not count it in a privacy assessment.

### 4. Mandatory review — the actual guarantee

Step 3 of the wizard cannot be passed without ticking:

> *"I've checked every photo for faces, plates, house numbers and anything else
> identifying."*

with the reassurance that a moderator who finds something missed will blur or
remove the photo rather than delete the nomination.

`validateNomination()` re-checks it server-side: `photos.length > 0 &&
!reviewedRedaction` is a field error. A client that skips the step is refused.

Only at submit time does `applyRedactions()` render the boxes permanently into
a new JPEG. **The un-redacted original never leaves the device**, in either data
mode.

### 5. Moderator re-check — the second pair of eyes

Every photo nomination lands in the queue as `pending`. The queue view shows
full-size evidence and the redaction count per photo. A moderator can:

- `approve` — it is clean;
- `redact_photo` — remove the offending photo and keep the nomination;
- `anonymise` — keep the nomination, drop the submitter and the place name;
- `reject` with a note — it should not be published at all.

Moderators can remove a photo. Nobody can recover one — the server never had the
original.

---

## Location coarsening

Four layers, applied in order:

1. **Round before storing.** `coarsen()` rounds latitude and longitude to two
   decimal places — roughly one kilometre — *before* the value is written into
   the wizard's draft state. The precise fix exists only in the browser's
   geolocation callback and is discarded on the next line.
2. **Snap to a known place.** `nearestPlace()` matches the coarsened point
   against a hand-built index of about 100 Australian towns and suburbs in
   `src/lib/domain/geo.ts` — centroids only, no third-party geocoder, no network
   request, nothing to log on someone else's server. It returns the place and the
   distance so the UI can be honest: *"Near Batemans Bay, NSW (about 4 km).
   Coordinates rounded to ~1 km — we never store anything precise."*
3. **Suburb-level display.** `Location.precision` records whether the row claims
   `suburb` or `place` accuracy. `/map` renders region clusters over a
   deliberately schematic outline of Australia — the comment in
   `components/map/australia-map.tsx` explains why: *"DBAD shows areas, never
   addresses, so a stencil-style map is more honest than a street map would be."*
   Cluster coordinates are the mean of the member locations in a region, never a
   point per incident.
4. **Reject addresses outright.** A street-address pattern is tested against the
   suburb + place pair in the wizard *and* in `validateNomination()`, with the
   same message both times: *"Public places only — 'Coles car park' is fine,
   '14 Smith St' is not."* In Supabase a check constraint enforces it at the
   table.

Coordinates outside Australia (lat −44 to −10, lng 112 to 154) are refused by
both `nearestPlace()` and `validateNomination()`.

A public business, road, park or facility may be named — that is the whole point
of a community noticeboard. A home may not.

`Permissions-Policy` in `next.config.ts` is `camera=(self), geolocation=(self),
microphone=()`. The microphone is switched off at the browser level because
nothing in DBAD has any business with it.

---

## Text scanning

Covered in detail in [04 — Moderation model](./04-moderation-model.md). The
privacy-relevant summary:

- The same `scanText()` runs in the browser (instant feedback), in the server
  action (authority) and — in Supabase mode — again in SQL triggers, so the rule
  holds no matter which client is talking to the database.
- Nomination text is refused outright if it contains a phone number, an email, a
  personal profile link or a threat.
- Everything stored is stored as `cleaned` — maskable matches replaced with
  `[phone removed]`, `[address removed]` and so on.
- Comments that look like they identify someone are held, not published, and a
  report is filed automatically.
- Model output from the wording helper is re-scanned before it is displayed.

---

## Appeal and report privacy

- Reporting requires **no account**. The person best placed to notice that a
  photo identifies someone is often the person it identifies, and they are not a
  member.
- Appealing requires **no account** and no public identification. The appellant
  proves nothing about who they are; they quote the short code from the notice.
- `appeals.contact` is optional, capped at 200 characters, visible to moderators
  only, and used to reply. In Supabase the `appeals` table is moderator-only at
  row level and has no public policy at all; the public view `appeal_replies`
  exposes `public_reply` and nothing else, deliberately running with the owner's
  rights so an anonymous reader can see a reply without being able to see the
  appeal it came from.
- A published right of reply carries no identity.
- Report details are capped at 1 000 characters and the dialog asks explicitly:
  *"Don't include personal information here either."*
- Nothing joins an appellant to a nomination as its subject. Building that link
  would create the offender record the platform refuses to keep.

---

## Facebook

**DBAD never scrapes Facebook.** A member pastes a public post URL; the platform
does not fetch it, render it, embed it or store its contents. The URL is kept as
a `SocialSource` with `retrievedVia: "manual"` — provenance for moderators, not
public content. The member writes their own description, which goes through the
same scan as any other nomination.

The Internet category carries an explicit caution: *"No screenshots of names,
profiles or private messages."*

Sharing runs outward only: a `sharer.php` link and a per-nomination Open Graph
card generated locally by `next/og`. No Facebook SDK, no pixel, no script from
any Meta domain is loaded anywhere in the application.

LIMITATION: `FACEBOOK_APP_ID` / `FACEBOOK_APP_SECRET` sit in `.env.example`
against a possible future official oEmbed lookup. Nothing reads them.

---

## No third parties

- **Fonts are self-hosted.** Seven WOFF files under `public/fonts`, four TTFs
  under `public/pdf-fonts`, all declared with `@font-face` in `globals.css` and
  two preloaded in the root layout. There is no request to Google Fonts or any
  other font CDN.
- **No analytics, no advertising, no tag manager, no session recorder.** There is
  no third-party script tag anywhere in the application.
- **No third-party geocoder.** The place index ships with the code.
- **No remote images by default.** `next.config.ts` allows exactly one remote
  pattern, and only when `NEXT_PUBLIC_SUPABASE_URL` is set: that project's public
  storage bucket.
- **Only one outbound call at runtime**, and it is optional: the Anthropic
  Messages API, when `ANTHROPIC_API_KEY` is set, for the wording helper. It has a
  12-second timeout and falls back to the local rewriter on any failure. The
  route sends `cache-control: no-store` and stores nothing.
- Security headers on every response: `X-Content-Type-Options: nosniff`,
  `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy:
  strict-origin-when-cross-origin`, and the `Permissions-Policy` above.
  `poweredByHeader` is off.
- The service worker (`public/sw.js`) explicitly refuses to cache `/api/`,
  `/auth/` and `/admin` — nothing personal or privileged is written to the
  device cache. Pages are network-first, static assets cache-first.
- Aggregate statistics (dick moves per week, most active areas, the map counts)
  are computed from published nominations only.

---

## Member data

An account holds an email address (or the Google / Apple / Facebook identity used
to sign in), a handle, a display name, an optional self-chosen home *area* — not
an address — and the member's activity: nominations, verdicts, reactions,
comments, badges.

Avatars are generated, not uploaded: `components/brand/avatar.tsx` derives a
colour, a shape, a rotation and an initial from `hash32(handle)`. No image to
upload, no face to moderate, no storage to leak.

A member can nominate anonymously — a nomination with no viewer is stored with
`anonymised: true` and `submitterId: null` from the outset. It earns no badges
and appears on no profile, and the wizard says so before submission.

---

## Data retention

What the code actually does:

| Data | Behaviour |
| --- | --- |
| Nominations, comments, verdicts | Kept indefinitely. Removed by `remove`, de-linked by `anonymise`. |
| Photos | Kept with the nomination. `redact_photo` removes the row; the storage object is deleted by a job running as the service role. |
| Notifications | Kept indefinitely; marked read when `/notifications` is viewed. |
| Reports and appeals | Kept with their resolution, actor and timestamp — that is what makes the decision reviewable. |
| Audit log | Append-only. Kept indefinitely by design. |
| Demo-mode data | In-memory, per process. It lives on `globalThis` and dies with the container. Nothing is written to disk. |
| Wording-helper input | Not stored anywhere, by the route or by the action. |
| Sessions | Demo: a `dbad_demo_user` cookie, httpOnly, SameSite=Lax, 30 days. Supabase: standard Supabase Auth cookies, refreshed by middleware. |

LIMITATION: **there is no automated retention or expiry job in this codebase.**
Nothing ages out notifications, prunes resolved reports, or expires storage
objects for removed photos. Deletion is a moderator action, or a service-role
job that is described in [03 — Data model](./03-data-model.md) but not
implemented here. A production deployment should decide its retention periods
and add the job; this document should be updated when it does.

---

## The honest summary

The controls that are *guaranteed*:

- No entity exists for the nominated person, so nothing can be aggregated about
  them.
- The un-redacted original never leaves the device.
- EXIF, GPS included, is destroyed by re-encoding.
- Coordinates are rounded before they are stored, and the map only ever shows
  areas.
- Street addresses are refused by the client, the server and the database.
- Text is scanned in all three places, and stored masked.
- Every photo nomination is seen by a human before the public sees it.

The controls that are *best-effort*:

- Automatic face detection, which depends on a browser API a large share of
  visitors will not have.
- Automatic plate detection, which does not exist.
- Regex-based PII detection, which will always have false negatives — an unusual
  plate format, a name written in an unusual way, a landmark that identifies a
  house.

The guarantee is the human. Everything automatic is there to reduce what the
human has to catch, not to replace them — which is why the redaction review
checkbox is mandatory, why photos are the one thing that waits for the queue,
and why the remedy for a mistake is anonymisation rather than an argument.
