# 06 — Design system

The visual identity, the tokens behind it, and the rules for using them. Tokens
are defined once in `src/app/globals.css` under Tailwind v4's `@theme`; there is
no `tailwind.config.js`.

---

## The concept

The comment at the top of `globals.css` is the brief:

> *A council notice, Reddit, Top Gear and an Australian pub noticeboard had a
> child.*

Four references, each pulling its weight:

- **Council notice** — the authority of officialdom, deadpan. Hazard tape, a
  reference number, a stamp, a box for "Community advice". It looks like it means
  it, which is what makes it funny.
- **Reddit** — the community mechanics. Verdicts, reactions, comments, a
  weekly pick. The crowd decides, not the platform.
- **Top Gear** — the tone. Dry, self-aware, generous about the absurd. Laughing
  at the situation, never at a person.
- **Australian pub noticeboard** — the texture. Dirty off-white paper, hand-lettered
  emphasis, torn edges, things pinned over other things.

Everything below is that idea made specific. The overriding rule: **it should
look printed, not rendered.** Hard borders, offset shadows, square corners,
paper grain, no gradients except where a real surface would have one.

---

## Palette

Five families, all warm-shifted. Nothing is pure white or pure black — paper is
dirty, ink is charcoal.

### Ink — near-black, the default foreground

| Token | Hex | Use |
| --- | --- | --- |
| `ink-950` | `#0f0f0f` | Body text, every border, the header, hard shadows. The default. |
| `ink-900` | `#171717` | Dark section backgrounds; the base of the `concrete` texture. |
| `ink-800` | `#232323` | Hover state on dark buttons. |
| `ink-700` | `#2f2f2f` | Secondary body text on paper; avatar shape fill. |
| `ink-600` | `#444441` | Rarely used; the warmest ink. |

### Concrete — muted, slightly warm greys

| Token | Hex | Use |
| --- | --- | --- |
| `concrete-600` | `#6f6f68` | Metadata, mono labels, the `--color-muted` alias. |
| `concrete-500` | `#8a8a82` | Placeholder text, disabled stamps. |
| `concrete-400` | `#a9a9a1` | Dashed empty-state borders. |
| `concrete-300` | `#c9c9c1` | Rules, the pending Dick-o-meter band. |
| `concrete-200` | `#dcdcd4` | Skeletons, bar-chart troughs, the notice-studio backdrop. |
| `concrete-100` | `#e9e8e0` | Rarely used; the lightest grey. |

### Paper — dirty white, the default background

| Token | Hex | Use |
| --- | --- | --- |
| `paper-50` | `#f7f3ea` | Page background (`--color-background`), cards, text on dark. |
| `paper-100` | `#f1ecdf` | Recessed panels, the alternate section band, torn cards. |
| `paper-200` | `#e7dfcc` | The Friendly Reminder notice ground. |
| `paper-300` | `#d8cdb3` | The darkest paper; used sparingly for depth. |

### Warning yellow — the brand colour

| Token | Hex | Use |
| --- | --- | --- |
| `warning-300` | `#ffe066` | Lightest tint. |
| `warning-400` | `#ffd21f` | Hover state on primary buttons. |
| `warning-500` | `#f5c400` | **The DBAD yellow.** Hazard tape, primary buttons, the wordmark on dark, the focus ring, selection, active states, evidence-frame corner ticks. |
| `warning-600` | `#d9ad00` | Yellow text on paper, where 500 would be too pale to read. |
| `warning-700` | `#a68400` | Warn-severity scan messages. |

### Alert red — used sparingly

| Token | Hex | Use |
| --- | --- | --- |
| `alert-400` | `#ef4b5f` | Hover on alert buttons; secondary text in the Maximum Dickery notice. |
| `alert-500` | `#d7263d` | The DICK MOVE stamp, destructive buttons, the top band of the Dick-o-meter, unread badges, auto-detected face outlines. |
| `alert-600` | `#b71c31` | Red text on paper — field errors, block-severity scan messages. |
| `alert-700` | `#8f1425` | Darkest; rarely used. |

**Rule: red means "this is the bad end of the scale" or "this destroys
something."** It is never decoration and never a section background outside the
Maximum Dickery notice template. If a page has more than one red element in
view, one of them is wrong.

### Redemption green — the one hopeful colour

| Token | Hex | Use |
| --- | --- | --- |
| `redeem-400` | `#5cb870` | Hover on redeem buttons; positive values in the comment-rules list. |
| `redeem-500` | `#3f9d57` | REDEEMED panels, the Not-A-Dick header, the "not a dick" end of the meter, the redeem button. |
| `redeem-600` | `#2f7d44` | Green text on paper; the redemption panel border. |
| `redeem-700` | `#245f34` | The stamp plate on a green panel. |

**Rule: green is reserved for redemption and for Not-A-Dick.** It is never a
generic "success" colour — a saved form does not turn green. Keeping green rare
is what makes REDEEMED feel like something.

### Semantic aliases

`--color-background` → `paper-50` · `--color-foreground` → `ink-950` ·
`--color-muted` → `concrete-600` · `--color-border` → `ink-950`.

Every border in the system is `ink-950`. There is no border palette, because a
council notice does not have subtle borders.

---

## Typography

Three families, all self-hosted from `public/fonts` — no request ever leaves for
a font CDN. Two are preloaded in the root layout.

| Role | Family | Stack | Weights shipped |
| --- | --- | --- | --- |
| Display | **DBAD Display** | `"Arial Narrow", Impact, "Helvetica Neue", Arial, sans-serif` | 900 Black, 700 Bold (WOFF) |
| Body | **Public Sans** | `system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif` | 100–900 variable, roman + italic (WOFF) |
| Mono | **IBM Plex Mono** | `ui-monospace, SFMono-Regular, Menlo, Consolas, monospace` | 500, 600, 700 (WOFF) |

**DBAD Display** is an instanced cut of **Roboto Flex** — condensed and black
(`usWeightClass` 1000, `usWidthClass` 3). Roboto Flex is a variable face with a
width axis, so a genuinely condensed black instance can be extracted without
distorting anything. It carries every headline, every button, every stamp, and
the wordmark geometry is derived from its outlines. It is always uppercase and
always tight: `h1, h2, h3, .display` get `uppercase`, `tracking-tight`,
`line-height: 0.92` and `text-wrap: balance`.

**Public Sans** carries body copy. It is a variable font, so any weight from 100
to 900 is available from one 31 KB file, plus a matching italic. Set at
`text-base` with `leading-relaxed` for prose and `leading-snug` for card copy;
`p` gets `text-wrap: pretty`.

**IBM Plex Mono** carries anything that should read as a machine wrote it:
metadata strips, short codes, kickers, timestamps, statistics, the `Meta`
component. Almost always uppercase with wide tracking — `tracking-wider` for
metadata, `tracking-[0.2em]` for kickers — and `font-variant-numeric:
tabular-nums` via the `tabular` utility wherever numbers change in place.

The body sets `font-feature-settings: "ss01", "cv05"` for Public Sans's
alternate letterforms.

Four TTFs live separately under `public/pdf-fonts` for the PDF and Open Graph
renderers, which need real font files rather than WOFF: DBAD Display Black,
Public Sans Regular and SemiBold, IBM Plex Mono SemiBold. `next.config.ts` traces
that directory into the standalone build for the three routes that read it.

---

## The wordmark

Four letters — D B A D — as a stencil.

`src/components/brand/wordmark-geometry.ts` holds the geometry: four SVG paths
that are the outlines of the display face's letters, plus eight
`[x, y, width, height]` rectangles that are the stencil bridges. The viewBox is
4952 × 1456 font units.

`src/components/brand/wordmark.tsx` renders it as inline SVG: the paths are
filled with `currentColor` and masked by a white rectangle with the eight cuts
painted black. So the wordmark:

- is crisp at any size, from a 20px header lockup to a 512px app icon;
- inherits colour, so it is yellow on dark and ink on paper with no variants;
- is a single element with a per-instance mask id (`React.useId()` plus a
  counter), because two masks with the same id on one page fight.

DECISION: bridges as *masked rectangles* rather than baked into the paths. A
counter shape can be reopened, the bridge width can be tuned, and the same
geometry drives three renderers: the browser SVG, the PDF (`Draw.wordmark()`
paints the paths then paints the background colour back over the cut positions),
and the PWA icon generator in `tools/brand/icons.ts`.

Two lockups ship with it: `WordmarkPlate` (wordmark on a yellow plate with a
3px ink border — the sticker treatment) and `Lockup` (wordmark stacked over
"Don't be a dick.").

LIMITATION: the file header says the geometry is generated by
`tools/brand/wordmark.py`. That script is not in the repository — only
`tools/brand/icons.ts`, which consumes the geometry. Treat
`wordmark-geometry.ts` as the source of truth and do not hand-edit it.

---

## Visual devices

Custom Tailwind v4 `@utility` rules, all in `globals.css`.

| Device | Utility | What it is | Where it earns its place |
| --- | --- | --- | --- |
| **Hazard tape** | `hazard`, `hazard-thin`, `hazard-red` | 45° repeating stripes. Black on yellow at 14px (`hazard`) or 6px (`hazard-thin`); red on paper for Maximum Dickery. | Header top strip, section dividers, the footer lead-in, wizard progress, notice borders. The brand's punctuation mark. |
| **Rubber stamp** | `stamp`, `stamp-flat` | Display type, uppercase, 0.18em border, rotated −6°, `mix-blend-mode: multiply`, masked by an inline `feTurbulence` SVG so the ink breaks up. `stamp-flat` drops the grunge for dark backgrounds and print. | REDEEMED · OVERRULED · DICK MOVE OF THE WEEK · AWAITING MODERATION · 404 · ERROR. |
| **Torn card** | `torn-bottom`, `torn-top` | A 28-point `clip-path` polygon that reads as a torn paper edge. `TornCard` layers an ink shadow behind it and adds grain. | Community "paper" content — anything meant to look pinned to the board. |
| **Ticket edge** | `ticket-edge` | Two radial-gradient masks punching a semicircle out of the left and right edges. | Perforated, tear-off-strip surfaces. |
| **Paper grain** | `grain` | A `::after` overlay of fractal-noise SVG at 18% opacity, `mix-blend-mode: multiply`. | Torn cards and paper surfaces, so a flat colour reads as stock. |
| **Concrete** | `concrete` | `ink-900` with two soft radial highlights and a white-noise SVG at 7%. | Dark sections: the footer, page headers in dark mode, the admin header strip. |
| **Evidence frame** | `evidence-frame` | Ink ground, 3px border, and a `::before` painting eight yellow corner ticks 8px inside the edge. | Every photo. `EvidenceFrame` adds a mono caption strip, a redaction-count chip, and — for text-only nominations — a big category icon on hazard yellow so they still look intentional in the feed. |
| **Code plate** | `CodePlate` | Mono bold, wide tracking, paper ground, 2px ink border, 2px radius. Three sizes. | `DBAD-0042` wherever it appears. Reads as a number plate, which is the joke. |
| **Dick-o-meter** | `DickOMeter`, `VerdictBar` | A four-band gauge with a needle: green → yellow → dark yellow → red, with tick marks at 25/50/75% and a distribution list beneath. Pending reads at dead centre at 40% opacity. | The verdict, everywhere. `VerdictBar` is the one-line version for feed cards. |
| **Text outline** | `text-outline` | 2px `-webkit-text-stroke`, transparent fill. | Oversized display type used as texture. |
| **Scrollbar-none** | `scrollbar-none` | Hides the scrollbar on horizontally scrolling chip rows without disabling the scroll. | Category chips, admin tabs, filter rows. |

---

## Spacing, radii and shadows

**Spacing** is stock Tailwind. Containers come from `Container` in
`site-shell.tsx`: `md` (48rem), `lg` (64rem), `xl` (80rem, the default) and `2xl`
(90rem), each with `px-4 sm:px-5`. Section rhythm is `py-8` to `py-12`; page
headers `py-8 sm:py-12`.

**Radii** are almost nothing, on purpose — *this is a notice, not a fintech app*:

| Token | Value | Use |
| --- | --- | --- |
| `radius-none` | `0` | Hazard tape, section bands, photo frames |
| `radius-xs` | `2px` | Badges, code plates, checkboxes |
| `radius-sm` | `3px` | Buttons, inputs, chips, tabs |
| `radius-md` | `4px` | The largest button size |
| `radius-lg` / `radius-xl` | `6px` / `10px` | Defined; effectively unused |

**Shadows** are hard offsets, never blurs. A card looks like a sticker sitting on
paper, not a pane floating in space.

| Token | Value | Use |
| --- | --- | --- |
| `shadow-hard` | `4px 4px 0 0 #0f0f0f` | Cards, buttons, the default |
| `shadow-hard-sm` | `2px 2px 0 0 #0f0f0f` | Chips, inputs, dense admin rows |
| `shadow-hard-lg` | `8px 8px 0 0 #0f0f0f` | Dialogs, the notice preview |
| `shadow-hard-yellow` | `4px 4px 0 0 #f5c400` | Active/selected state on dark surfaces |
| `shadow-hard-red` | `4px 4px 0 0 #d7263d` | Defined; reserved for maximum-severity emphasis |
| `shadow-lift` | `0 10px 30px -12px rgb(15 15 15 / 0.45)` | The one soft shadow. Use it almost never. |

The offset shadow does double duty as an interaction model: buttons carry
`active:translate-x-[2px] active:translate-y-[2px] active:shadow-none`, so
pressing one physically presses it into the page.

---

## Motion

Three animations, defined as `@keyframes` inside `@theme`:

| Token | Timing | What it does |
| --- | --- | --- |
| `animate-stamp-in` | 420ms `cubic-bezier(0.2, 1.4, 0.4, 1)` | Scale 1.8 and −14° down to 1.0 and −6°, overshooting slightly. A rubber stamp coming down. Used on REDEEMED, on the wizard success stamp, on RECEIVED. |
| `animate-fade-up` | 400ms ease-out | 8px rise with a fade. Toasts, dialogs, the redemption panel. |
| `animate-wiggle` | 600ms ease-in-out | ±1.5° rotation. Available for attention-grabbing; used sparingly. |

Everything else is a short transition on `transform`, `box-shadow` and
`background-color` — 100ms on buttons, 500ms on the Dick-o-meter needle.

`@media (prefers-reduced-motion: reduce)` collapses every animation and
transition to 0.01ms and turns off smooth scrolling, globally, in the base layer.
Nothing in the app has to opt in.

---

## Accessibility

**Focus.** One rule in the base layer, applied to `:focus-visible` everywhere:
`outline: 3px solid var(--color-warning-500)` with `outline-offset: 2px` and
`box-shadow: 0 0 0 5px var(--color-ink-950)`. Yellow-on-ink is visible on paper,
on concrete and on yellow — the last case being why the ink halo is there. No
component overrides it.

**Contrast.** Measured ratios for the combinations that carry meaning:

| Pair | Ratio | Verdict |
| --- | --- | --- |
| `ink-950` on `paper-50` — body text | 17.3:1 | AAA |
| `paper-50` on `ink-900` — dark sections | 16.2:1 | AAA |
| `ink-700` on `paper-50` — secondary prose | 12.1:1 | AAA |
| `ink-950` on `warning-500` — primary button | 11.7:1 | AAA |
| `warning-500` on `ink-900` — nav, kickers on dark | 10.9:1 | AAA |
| `alert-600` on `paper-50` — field errors | 5.9:1 | AA |
| `redeem-600` on `paper-50` — redemption text | 4.6:1 | AA |
| `concrete-600` on `paper-50` — metadata | 4.6:1 | AA |
| `paper-50` on `alert-500` — alert button | 4.5:1 | AA (large/bold) |
| `warning-700` on `paper-50` — warn-severity scan messages | 3.2:1 | AA large only |
| `paper-50` on `redeem-500` — Not-A-Dick header | 3.1:1 | AA large only |
| `warning-600` on `paper-50` — emphasis words in display headings | **1.9:1** | **Fails** |

This is why the primary button is dark text on yellow rather than the other way
around, and why yellow text on paper is always `warning-600` rather than
`warning-500` — `warning-500` on paper is worse still.

LIMITATION: `warning-600` on paper does not meet WCAG contrast at any size. As
text it appears in a handful of places, always as one emphasised phrase inside a
large display heading whose surrounding words are `ink-950` — *Latest **dick
moves***, *Where the **dick moves** are*, the closing line on `/about` — so no
information is carried by the colour alone. It is nonetheless a real gap.
Anything that must be *read* rather than merely *seen* uses `ink-950`, `ink-700`
or `concrete-600`. Its other uses (the `yellow` stamp tone, a star icon) are
decorative.

LIMITATION: `paper-50` on `redeem-500` is 3.1:1 — AA for large text only. The
Not-A-Dick page header and the REDEEMED panel use it at display and `text-lg`
sizes, which is inside the allowance, but the metadata line beneath the header
drops to `text-paper-50/90` at 11–12px, which is not. Do not reuse this pairing
for small copy.

LIMITATION: `warning-700` on `paper-50` is 3.2:1 and carries the warn-severity
scan messages in the wizard at `text-sm` semibold — below the large-text
threshold, so it fails AA. Those messages are also duplicated as inline text next
to the matched string, so the information is not colour-only, but the colour
should be darkened.

**Touch targets.** The icon button is `size-11` (44px). Inputs are `py-3` with
3px borders, landing near 48px. Chips are `py-2` with generous horizontal
padding. The mobile-nav camera button is `size-14` (56px) and raised above the
bar. Nothing interactive is smaller than 44px in the primary flows.

**Semantics.** `aria-pressed` on every chip and toggle; `aria-current="page"` on
active navigation; `role="search"` on the feed form; `aria-live="polite"` on the
toast region; `aria-invalid` plus `role="alert"` on field errors; a skip link as
the first focusable element; `aria-label` on every icon-only control. Modals use
the native `<dialog>` element, so focus trapping, Escape and the top layer are
the browser's job rather than a library's.

**Viewports.** Mobile-first throughout, with an extra breakpoint token:
`--breakpoint-xs: 25rem` (400px), added specifically for foldable cover screens.

DECISION: the layout is exercised at two Fold-shaped ranges — the cover screen at
roughly **320–440px** wide, and the unfolded inner screen at roughly
**620–990px**. The `xs` breakpoint is where the wizard's category grid and the
button type step up; `sm` (640px) is where the unfolded screen picks up
two-column layouts. The admin console has its own floor: the shell comment
commits to working one-handed at 390px.

ASSUMPTION: those two ranges are a design target, not something the code asserts.
`xs` is the only token that encodes any of it; the rest is a testing convention.

**Print.** `@page { margin: 8mm }`, white background, `.print-hidden` removed,
`.print-only` revealed, `break-inside: avoid` on `.print-page`, and links
stripped of underline and colour. The notice studio injects its own `@page size`
for A5 or A6.

---

## Voice and tone

The rule that generates all the others: **call out the action, not the person.**

**Approved.**

- Australian English throughout — *nominate*, *suburb*, *rubbish*, *car park*,
  *footpath*, *anonymise*, *apologise*, *behaviour*.
- The house vocabulary: *dick move*, *dickery*, *DBAD'd*, *fair call*, *classic*,
  *redeemed*, *overruled*, *legend*, *take the piss*.
- Dry understatement over exclamation. *"One car. Two bays. Zero
  self-awareness."* *"That's in the future. Impressive, but no."*
- Second person, plain, unhedged. *"Do better next time."* *"The bin was three
  metres away. Three."*
- Self-aware about the platform itself. *"We've all been a dick at some point."*
  *"Not your fault. Probably ours."*
- Generous at the end. Every punitive flow has a redemptive exit — REDEEMED,
  OVERRULED framed as respect, "No hard feelings. Just fix it."

**Forbidden.**

- Personal attacks. The list in `pii.ts` (`PERSONAL_ATTACKS`) is stripped by
  `softenText()` before the rewriter sees the text: *idiot, moron, prick,
  wanker, dickhead, scum, loser, bogan, karen, boomer, stupid, lazy, entitled*
  and the rest. Note that appearance and character words are in there too —
  *fat*, *ugly*, *selfish* — because they attack the person, not the act.
- Profanity. `PROFANITY` is stripped the same way. The single permitted rude word
  is **dick**, and only in the platform's own constructions.
- Threats. Blocked outright, everywhere, with no rewrite offered.
- Naming, identifying, or speculating about who someone is. The system prompt
  puts it as *"no 'type of person' language."*
- Cruelty, pile-ons, "someone should…".
- Blaming the dog. The Dog category caution is explicit: *"The dog is never the
  dick. The human holding (or not holding) the lead is."*
- Marketing register. No "seamless", no "empower", no exclamation marks in UI
  copy, no emoji.

The tone contract is also encoded as data. The comments header renders it as a
literal list — *Humour: yes · Criticising the behaviour: yes · Threatening
people: no · Identifying people: no · Doxxing: absolutely not · Pile-ons: no* —
and the rewriter's system prompt in `src/lib/ai/rewrite.ts` restates the same
rules for the model.

---

## Printable notice templates

Five, defined in `src/lib/notice/lines.ts` and drawn twice: as HTML in
`components/notice/notice-card.tsx` for on-screen preview and browser printing,
and as vector PDF in `src/lib/notice/pdf.ts` for download. Every one carries the
five `NoticeLines` — headline, the dick move, why you're here, location,
community advice — plus a QR and, where there is a nomination, its short code.

| Template | Default headline | Intent | Treatment |
| --- | --- | --- | --- |
| **Official Warning** | `YOU HAVE BEEN DBAD'D.` | The default. Looks like a parking notice from a council with a sense of humour — authority as the joke. | Paper ground, hazard tape top and bottom, wordmark, huge `DON'T BE A DICK.`, labelled fields, a tilted red `VERDICT: DICK MOVE` stamp. |
| **Friendly Reminder** | `FRIENDLY REMINDER.` | The de-escalating one, and the default for Not-A-Dick. A pat on the shoulder from the community. | Warm off-white, a yellow header band, a dashed box around the content, and a green `NO HARD FEELINGS. JUST FIX IT.` sign-off. |
| **Maximum Dickery** | `ABSOLUTE DICKERY DETECTED.` | For the genuinely spectacular. The only template that shouts. | Ink ground, red-on-paper hazard bands, red wordmark, `ABSOLUTE DICKERY.` at 15 units, labels like "THE OFFENCE AGAINST DECENCY". |
| **Australian Public Service Announcement** | `PUBLIC SERVICE ANNOUNCEMENT.` | Straight-faced and plain-spoken, the way a warning label would say it. The bureaucratic register carries the comedy. | White ground, ink header band, a yellow warning triangle, a numbered four-point list (what happened / where / what to do / verdict), and `DON'T BE A DICK.` in a yellow box. |
| **Minimal DBAD** | `DON'T BE A DICK.` | Black, white, four words, devastating. For anyone who finds the others too much. | White, 1.2-unit border, `DON'T / BE A / DICK.` at 22 units, the dick move in concrete grey, wordmark and a large QR at the foot. |

DECISION: the PDF is drawn with `pdf-lib` rather than rendered from HTML by a
headless browser. The output is vector, a few kilobytes, prints crisply at any
size, and needs no Chromium in the container. The cost is that each template is
implemented twice and the two implementations have to be kept in agreement by
eye. Given five templates that change rarely, that trade is worth it.

The PDF renderer works in a percentage-of-page-width unit (`Draw.u`), mirroring
the container-query units the HTML card uses, so the same numeric layout produces
the same proportions at A5 and A6. Brand TTFs are embedded when
`@pdf-lib/fontkit` is available; otherwise it falls back to Helvetica and
Courier, and the response says which via the `x-dbad-fonts` header.
