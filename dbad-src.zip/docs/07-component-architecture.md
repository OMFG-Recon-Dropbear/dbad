# 07 — Component architecture

How the code is layered, why it is layered that way, and the two recipes you
will actually need: adding a page, and adding a moderation action.

---

## The layers

Data flows down. Nothing reaches back up.

```
┌──────────────────────────────────────────────────────────────────┐
│  src/lib/domain/          pure TypeScript, zero imports          │
│  types · categories · verdict · badges · pii · validation        │
│  qr · geo · time · utils                                         │
└──────────────────────────────────────────────────────────────────┘
                              ▲
┌──────────────────────────────────────────────────────────────────┐
│  src/lib/data/            Repository interface + 2 implementations│
│  repository.ts  ·  demo/demo-repository.ts  ·  supabase/…         │
└──────────────────────────────────────────────────────────────────┘
                              ▲
┌──────────────────────────────────────────────────────────────────┐
│  src/lib/loaders/         async (repo, viewer, params) → props    │
│  home · feed · incident · map · notice · admin                    │
└──────────────────────────────────────────────────────────────────┘
                              ▲
┌───────────────────────────────┬──────────────────────────────────┐
│  src/app/**/page.tsx          │  tools/preview/*routes.tsx        │
│  Next.js route files, thin    │  the Bun harness, equally thin    │
└───────────────────────────────┴──────────────────────────────────┘
                              ▲
┌──────────────────────────────────────────────────────────────────┐
│  src/components/**        views — presentational, framework-light │
│  client islands receive an `actions` prop, never server code      │
└──────────────────────────────────────────────────────────────────┘
```

### 1. Domain — pure

`src/lib/domain/` has no imports outside itself. No React, no Next, no Supabase,
no `fetch`, no `process.env`. Everything here is a value, a type or a pure
function, and it runs identically in a browser, in a server action, in a route
handler, in Bun and in a PDF renderer.

| Module | Holds |
| --- | --- |
| `types.ts` | Every domain type and union. The header states the rule the model is built around: *we record BEHAVIOUR, not PEOPLE*. |
| `categories.ts` | The nine categories, the ten affected groups, the six parts of day, the eight states. |
| `verdict.ts` | The Dick-o-meter maths — `VERDICT_LEVEL`, `summariseVotes()`, `bandFor()`, `applyVote()`, `dickeryRank()`, `MIN_VOTES_FOR_VERDICT`. |
| `badges.ts` | The six badges and `evaluateBadges(stats)`. |
| `pii.ts` | Nine scan rules, `scanText()`, `softenText()`, and the attack/profanity word lists. |
| `validation.ts` | `LIMITS`, `validateNomination()`, `validateComment()`, `isFacebookUrl()`. |
| `qr.ts` | A dependency-free QR encoder (ISO/IEC 18004, byte mode, versions 1–10) with SVG, path and rectangle outputs. |
| `geo.ts` | ~100 Australian place centroids, `nearestPlace()`, `coarsen()`, `projectAU()`. |
| `time.ts` | Australia/Sydney formatting, `relativeTime()`, `occurrenceLabel()`, `stampDate()`. |
| `utils.ts` | `slugify`, `hash32`, `weekOf`, `shortCodeFromSequence`, and friends. |

DECISION: no schema library. Validation is hand-rolled so the identical rules
run in the browser for instant feedback, in the server action as the authority,
and in the harness with zero dependencies. The cost is writing the checks by
hand; the benefit is that there is exactly one implementation of every rule and
it has no version to keep in step.

DECISION: the QR encoder is hand-written for the same reason. DBAD renders QR
codes in three runtimes — browser SVG, PDF rectangles, Open Graph — and one
small audited module beats pulling a library into all three.

### 2. Data — one interface, two implementations

`src/lib/data/repository.ts` declares `Repository`: every read and write the
application performs — 31 methods, grouped by area. Also `Viewer`,
`requireRole()` and `isModerator()`.

| Implementation | When | Notes |
| --- | --- | --- |
| `DemoRepository` | No Supabase configured, or `DBAD_DATA_MODE=demo` | In-memory store seeded from `demo/seed.ts` (12 members, 31 nominations, 24 comments). Lives on `globalThis` so state survives hot reloads within a process. `DemoRepository.isolated()` gives a fresh store for tests. |
| `SupabaseRepository` | `NEXT_PUBLIC_SUPABASE_URL` + anon key set | Reads through views and `select`; every write goes through a `SECURITY DEFINER` RPC. Uploads photos to the `incident-photos` bucket before calling `submit_nomination`. |

`src/lib/data/index.ts` picks one. It is `server-only`, exports
`isSupabaseConfigured()`, `dataMode()` and `getRepository()`, and imports the
Supabase modules dynamically so a demo-mode build never pulls them in.

**Nothing outside this folder names a concrete implementation.** Pages, actions,
loaders and the harness all talk to `Repository`.

### 3. Loaders — pure `repo → props`

`src/lib/loaders/*.ts` are plain async functions that take a `Repository`, a
viewer and route params, and return exactly the props a view needs. They import
no React and no Next.

```ts
export async function loadIncident(repo, viewer, slug): Promise<IncidentPageProps | null>
```

They are the only place fan-out lives — `loadHome()` makes six repository calls
in one `Promise.all`; `loadFeed()` makes two. They also own query-string
parsing (`parseFeedFilters`, `parseReportStatus`, …), so an unknown `?status=`
can never reach the repository from either front end.

### 4. Views — presentational and framework-light

`src/components/**` render props. They import from `@/lib/domain`, from other
components, and from `next/link` / `next/image` — nothing else from the
framework, and never from `@/lib/data` except for the `Viewer` *type*.

Interactive views are `"use client"` and receive their behaviour as a single
`actions` prop typed by an interface in `src/lib/actions/types.ts`:

```ts
export interface CommunityActions {
  castVote(incidentId: string, verdict: Verdict): Promise<ActionResult<…>>;
  toggleReaction(incidentId: string, kind: ReactionKind): Promise<ActionResult<…>>;
  addComment(incidentId: string, body: string): Promise<ActionResult<…>>;
  reportContent(input: ReportInput): Promise<ActionResult>;
  markRedeemed(incidentId: string, note: string): Promise<ActionResult>;
}
```

Five such contracts exist: `CommunityActions`, `NominationActions`,
`NoticeActions`, `AppealActions`, `AdminActions`. A client component never
imports server code; it calls what it was handed.

### 5. Route files — thin

Every `page.tsx` does the same four things and then gets out of the way:

```tsx
export default async function IncidentPage({ params }: Params) {
  const { slug } = await params;
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const data = await loadIncident(repo, viewer, slug);
  if (!data) notFound();
  return <IncidentView {...data} actions={{ castVote, toggleReaction, addComment, reportContent, markRedeemed }} />;
}
```

Resolve the repository and viewer, call a loader, handle not-found, render a
view with actions. Most page files are under thirty lines; the longest is
`moves/[slug]/page.tsx` at 46, and two-thirds of that is `generateMetadata`,
which sits alongside wherever a route needs per-item metadata.

### 6. Server actions

`src/app/actions/*.ts` are the only `"use server"` files: `admin.ts`,
`appeal.ts`, `auth.ts`, `community.ts`, `nomination.ts`, `notice.ts`. Each does
the same three things: resolve repository and viewer, delegate to the
repository, revalidate the affected paths on success. They add no business
logic — authorisation and validation live in the repository, which is what makes
the harness's action shims equivalent.

---

## Why this shape

**Because the UI has to be exercisable without a Next.js build.** This project
was developed where `npm install` could not reach a registry. `tools/preview/`
is a ~160-line Bun server that bundles `entry.tsx`, aliases six Next.js
primitives to shims (`next/link`, `next/image`, `next/navigation`,
`next/font/local`, `server-only`, `client-only`), builds the Tailwind CSS, and
serves the **real views** against the **real demo repository** in a browser. It
also mounts three genuine route handlers — `/api/qr`, `/api/notices/:id/pdf`,
`/api/ai/rewrite` — because those are plain `Request → Response` functions.

That harness only works because of the layering. The views are framework-light,
so shims are small. The loaders are pure, so the harness calls the same ones the
Next pages call. The actions are interfaces, so `tools/preview/actions.ts` can
implement them directly against `DemoRepository`. **The harness renders the same
components the production site renders** — it is not a Storybook approximation.

The secondary benefits are the usual ones and they are real: the domain layer is
trivially unit-testable; swapping demo for Supabase changed no view; and a
reviewer can read `repository.ts` and know every data operation the application
can perform.

---

## Component inventory

### `ui/` — the primitives

| File | Exports | Notes |
| --- | --- | --- |
| `button.tsx` | `Button`, `ButtonLink`, `IconButton`, `buttonVariants` | 8 variants × 5 sizes. `ButtonLink` detects external hrefs and adds `target`/`rel`. |
| `input.tsx` | `Input`, `Textarea`, `Select`, `Label`, `FieldError`, `Help`, `Checkbox`, `Chip` | One shared `base` class string. `Checkbox` is a stamp-box built on a `peer` sibling. `Chip` carries `aria-pressed`. |
| `card.tsx` | `Card`, `CardHeader`, `CardTitle`, `CardContent`, `CardFooter`, `TornCard` | `Card` takes an `as` prop for `div`/`article`/`section`/`li`. |
| `badge.tsx` | `Badge`, `Meta` | `Meta` is the mono metadata label used everywhere. |
| `dialog.tsx` | `Dialog` | **Client.** Native `<dialog>` + `showModal()`. |
| `toast.tsx` | `ToastProvider`, `useToast` | **Client.** Four tones, 4.2s auto-dismiss, `aria-live="polite"`. |
| `tabs.tsx` | `LinkTabs` | Link-based, not stateful. |
| `empty-state.tsx` | `EmptyState`, `ErrorState`, `Skeleton` | |

### `brand/` — the identity

`wordmark.tsx` (`Wordmark`, `WordmarkPlate`, `Lockup`) ·
`wordmark-geometry.ts` (generated paths and bridge cuts) ·
`stamp.tsx` (`Stamp`, `StatusStamp`) ·
`hazard.tsx` (`HazardTape`, `SectionHeading`, `CodePlate`) ·
`dick-o-meter.tsx` (`DickOMeter`, `VerdictBar`) ·
`evidence.tsx` (`EvidenceFrame`) ·
`avatar.tsx` (deterministic generated sticker avatar).

### `layout/`

`site-shell.tsx` (`SiteShell`, `Container`, `PageHeader`) ·
`site-header.tsx` (**client** — needs `usePathname`) ·
`site-footer.tsx` ·
`mobile-nav.tsx` (**client**).

### `icons/`

`ui.tsx` — 48 hand-drawn inline SVG icons, no icon library. `categories.tsx` —
`CategoryIcon`, one glyph per `CategoryId`.

### Feature folders

| Folder | Components |
| --- | --- |
| `home/` | `home-view.tsx` — hero, the three-step loop, Dick Move of the Week, latest, redemption strip, map teaser, closing CTA |
| `feed/` | `feed-view.tsx` (serves `/feed` and `/not-a-dick`), `week-view.tsx` |
| `incident/` | `incident-card.tsx` (`IncidentCard`, `IncidentRow`, `locationLabel`), `incident-view.tsx`, `incident-interactive.tsx` (**client** — verdicts, reactions, comments, report, redeem) |
| `nominate/` | `nominate-wizard.tsx` (**client**, four steps), `redaction-editor.tsx` (**client**, canvas) |
| `notice/` | `notice-card.tsx` (five templates in HTML), `notice-mini.tsx` (preview thumbnail), `notice-studio.tsx` (**client**) |
| `map/` | `map-view.tsx`, `australia-map.tsx` (`AustraliaMap`, `ClusterList`) |
| `profile/` | `profile-view.tsx` (`ProfileView`, `NotificationsView`) |
| `content/` | `about-view`, `standards-view`, `privacy-view`, `about-you-view` (**client**) |
| `auth/` | `sign-in-view.tsx` (**client**) |
| `admin/` | `admin-shell.tsx` (**client** — the chrome, `ADMIN_SECTIONS`, and the shared admin kit), `admin-section.tsx` (**client** — derives the section from the pathname), plus ten section views, all **client** |
| `og/` | `og-card.tsx` — `OgCard` and `ogFonts()` for `next/og`. Inline styles only; satori supports no Tailwind. |
| `pwa/` | `register-sw.tsx` (**client**) — registers the service worker in production only |

Roughly a quarter of components are client components, and they are exactly the
ones that need an event handler, a canvas, or the pathname.

---

## Conventions

**`cn` and `variants`, not `clsx` and `cva`.** `src/lib/utils.ts` is fifteen
lines: `cn()` filters and joins class strings, `variants()` is a `cva`-shaped
helper that builds a class function from a base plus variant maps and default
variants. Same ergonomics as shadcn, no dependencies, and no
`tailwind-merge` — which means later classes do not automatically beat earlier
ones. Order your overrides.

**Native `<dialog>`.** No portal library. The browser handles focus trapping,
Escape and the top layer; `Dialog` syncs `open` to `showModal()`/`close()` and
listens for the native `close` event so an Escape press still calls `onClose`.

**URL state for anything shareable.** `LinkTabs` renders links, not buttons.
Feed filters live entirely in the query string, built by `feedHref()` and read
by `parseFeedFilters()`, so a filtered feed is bookmarkable, shareable and works
with JavaScript off. Admin list filters follow the same pattern. React state is
for drafts and for what is on screen right now, never for what the page is
showing.

**Optimistic updates with an explicit rollback.** Verdicts and reactions apply
immediately, then call the action. On failure the previous value *and* the
previous tally are restored and a red toast says why:

```ts
const prev = viewerVote, prevVotes = votes;
setViewerVote(v); setVotes(applyLocally(votes, v, prev));
const res = await actions.castVote(incident.id, v);
if (!res.ok) { setViewerVote(prev); setVotes(prevVotes); toast.push({ tone: "red", … }); }
else { setVotes(res.data.votes); setViewerVote(res.data.viewerVote); }
```

**`ActionResult<T>` everywhere.** `{ ok, message?, data?, fieldErrors? }`. A
failure is a thing to say to a member, not an exception — the repository never
throws for a business-rule failure, and the SQL RPCs return the same shape.

**Debounced autosave** in the notice studio: 500ms, with a visible
"Saving…"/"Saved" indicator.

**Toasts for outcomes, inline errors for fields.** `FieldError` renders
`role="alert"` beneath the input; toasts announce the result of an action.

**Exhaustive switches.** `moderate()` ends with `cmd.action satisfies never`, so
an unhandled action kind is a compile error.

---

## How to add a page

1. **Loader.** Add `loadThing()` to `src/lib/loaders/thing.ts`, returning a
   `ThingProps` interface. Repository calls only.
2. **View.** Add `components/thing/thing-view.tsx` taking `ThingProps`. Keep it a
   server component unless it needs an event handler.
3. **Route.** Add `src/app/thing/page.tsx`: resolve repo and viewer, call the
   loader, render the view. Export `metadata` or `generateMetadata`.
4. **Actions**, if it is interactive: add the contract to
   `src/lib/actions/types.ts`, implement it in `src/app/actions/`, and pass it as
   `actions={{ … }}`.
5. **Navigation.** Add it to `NAV` or `FOOTER_NAV` in `src/lib/site.ts` if it is
   a primary destination, and to `app/sitemap.ts` if it should be indexed.
6. **Harness.** Register it in `tools/preview/extra-routes.tsx`:
   `registerRoute("/thing", async (_p, url, ctx) => <ThingView {...(await loadThing(ctx.repo, ctx.viewer))} />)`.
7. **Middleware**, if it needs auth: add the prefix to the `needsAuth` check in
   `src/middleware.ts`.

---

## How to add a moderation action, end to end

Say you want `pin_comment`.

1. **Domain type.** Add `"pin_comment"` to `ModerationActionKind` in
   `src/lib/domain/types.ts`. The compiler now fails in `moderate()` because of
   the `satisfies never` — that is the point.

2. **Demo repository.** Add a case to `DemoRepository.moderate()` in
   `src/lib/data/demo/demo-repository.ts`:

   ```ts
   case "pin_comment": {
     const c = this.store.comments.find((x) => x.id === cmd.targetId);
     if (!c) return { ok: false, message: "Comment not found." };
     c.pinned = true;
     break;
   }
   ```

   Do not write the audit row — the shared `this.log(actor, cmd)` after the
   switch does that for every action. Add any notification with `this.notify()`.

3. **SQL.** Add the branch to the `moderate(command jsonb)` RPC in
   `supabase/migrations/0003_functions.sql`, matching the demo behaviour exactly,
   and add an assertion to `supabase/tests/rls.test.sql`. Add a column or table
   in `0001_schema.sql` if the action needs one, with the RLS policy in
   `0004_rls.sql`. Run `bash supabase/tests/local-pg.sh`.

4. **Supabase repository.** Usually nothing — `SupabaseRepository.moderate()`
   forwards the whole command to the RPC. Only touch it if the action needs a
   client-side step first, the way photo upload does.

5. **Admin view.** Add the control to the relevant view in
   `src/components/admin/`, dispatching the command:

   ```ts
   await actions.moderate({ action: "pin_comment", targetType: "comment", targetId: c.id });
   ```

   Follow the surrounding pattern: optimistic where it is safe, a toast for the
   outcome, `router.refresh()` where the list must reload.

6. **Revalidation.** If the action changes something public, add the path to the
   `revalidatePath` list in `src/app/actions/admin.ts`.

7. **Documentation.** Add the row to the action catalogue in
   [04 — Moderation model](./04-moderation-model.md), and to the RPC table in
   [03 — Data model](./03-data-model.md) if the SQL surface changed.

The invariants worth keeping while you do it: **one command type**, **one server
action**, **one repository method**, **one audit row**, and **two
implementations that behave identically** — which is exactly what the SQL test
suite is for.
