# 08 — Deployment

How to run DBAD, what it needs, and — stated plainly — what was and was not
verified in the environment it was built in.

---

## Environments

| Environment | Data mode | Auth | Notes |
| --- | --- | --- | --- |
| Local dev | demo | Demo cookie | `npm run dev`. No Supabase, no accounts, no network. |
| Local dev (full) | supabase | Supabase Auth | `supabase start` + `.env.local` with the local project values. |
| Preview harness | demo | `?viewer=` switch | `bun run tools/preview/server.ts`. Not Next.js — see below. |
| Production | supabase | Supabase Auth | Docker image behind an existing Cloudflare Tunnel. |

---

## Environment variables

From `.env.example`. Copy it to `.env.local` for development, or
`.env.production` for the compose file. Never commit real values — `.env`,
`.env.local` and `.env.*.local` are gitignored.

| Variable | Required | Default | Purpose |
| --- | --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Yes in production | `https://dontbeadick.com.au` | Absolute origin for Open Graph tags, QR payloads, auth redirects and the sitemap. Trailing slash is stripped. |
| `DBAD_DATA_MODE` | No | unset | Set to `demo` to force the in-memory store even when Supabase is configured. Any other value defers to whether the Supabase vars are set. |
| `NEXT_PUBLIC_SUPABASE_URL` | For Supabase mode | — | Project URL. Also derives the single allowed remote image host. |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | For Supabase mode | — | Public anon key. |
| `SUPABASE_SERVICE_ROLE_KEY` | No | — | Server-only. Read by `createSupabaseServiceClient()`; throws if requested and absent. Never reaches the browser. |
| `ANTHROPIC_API_KEY` | No | — | Enables the Anthropic wording helper. Without it, the built-in local rewriter is used. |
| `DBAD_AI_MODEL` | No | `claude-sonnet-4-5` | Model for the wording helper. |
| `DBAD_IGNORE_TS_ERRORS` | No | unset | `=1` lets `next build` proceed past type errors. Set in the Dockerfile; **unset in CI**. |
| `PORT` / `HOSTNAME` | No | `3000` / `0.0.0.0` | Standalone server bind. Set in the image. |

Documented in `.env.example` but **not read by any code today** — treat as
placeholders for planned work, not as configuration:

| Variable | Status |
| --- | --- |
| `DBAD_VISION_PROVIDER` | LIMITATION: no code path reads it. Server-side vision redaction is not implemented; see [05 — Privacy controls](./05-privacy-controls.md). |
| `FACEBOOK_APP_ID`, `FACEBOOK_APP_SECRET` | LIMITATION: no code path reads them. Official oEmbed lookup is not implemented. |

`supabase/config.toml` additionally expects `SUPABASE_AUTH_GOOGLE_CLIENT_ID`,
`SUPABASE_AUTH_GOOGLE_SECRET`, and the Apple and Facebook equivalents, for the
local Supabase stack. They are not in `.env.example`; add them to `.env.local`
if you run OAuth locally.

---

## Demo mode versus Supabase mode

`src/lib/data/index.ts`:

```ts
export function isSupabaseConfigured(): boolean {
  if (process.env.DBAD_DATA_MODE === "demo") return false;
  return Boolean(NEXT_PUBLIC_SUPABASE_URL && NEXT_PUBLIC_SUPABASE_ANON_KEY);
}
```

| | Demo | Supabase |
| --- | --- | --- |
| Store | In-memory, on `globalThis` | PostgreSQL 16 |
| Seed | `src/lib/data/demo/seed.ts` — 12 members, 31 nominations, 24 comments, 4 reports, 2 appeals | `supabase/seed.sql` — the same site |
| Auth | `dbad_demo_user` cookie; three demo accounts on the sign-in page | Email OTP + Google / Apple / Facebook |
| Photos | Redacted JPEG travels in the server action as a data URL | Uploaded to the `incident-photos` bucket first; only the URL and path reach the RPC |
| Anonymous photo nominations | Allowed | Refused — storage requires an authenticated uploader |
| Persistence | Dies with the process | Durable |
| Category / template copy edits | Audit-only | `edit_category` updates the row |
| Feed search | Case-insensitive substring | Full-text (`websearch_to_tsquery`) |

`/api/health` reports which mode is live:
`{"ok":true,"service":"dbad","mode":"demo","time":"…"}`.

DECISION: demo mode is a first-class runtime, not a mock. It implements the
entire `Repository` interface, enforces the same validation and the same
moderation rules, and is what the design-preview harness and a zero-dependency
`npm run dev` both run against.

---

## Docker

`output: "standalone"` in `next.config.ts` means the image ships only the server
and its traced dependencies.

Three stages:

1. **deps** — `node:22-alpine`, `npm ci` if a lockfile exists, otherwise
   `npm install`.
2. **builder** — takes the public Supabase values as build args, because
   `NEXT_PUBLIC_*` is baked into the client bundle at build time. Leave them empty
   to build a demo-mode image. `DBAD_IGNORE_TS_ERRORS` defaults to `1` here so a
   vendor type nit cannot block a deploy; CI runs the strict check separately.
3. **runner** — copies `public`, `.next/standalone` and `.next/static`, runs as
   the unprivileged `nextjs` user, exposes 3000, and carries a `HEALTHCHECK`
   hitting `/api/health` every 30s.

```bash
docker build -t dbad \
  --build-arg NEXT_PUBLIC_SITE_URL=https://dontbeadick.com.au \
  --build-arg NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co \
  --build-arg NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ… .

docker run -p 8792:3000 --env-file .env.production dbad
```

### Compose, behind an existing Cloudflare Tunnel

`docker-compose.yml` publishes **`8792:3000`** and nothing else.

> **The tunnel is the only public ingress.**
>
> Do **not** add a `cloudflared` service to this compose file, and do **not**
> bind the container to a public interface. Reuse the existing tunnel and add a
> published application route pointing at `http://<host>:8792`.

```bash
cp .env.example .env.production   # fill it in
docker compose up -d --build
curl -s http://127.0.0.1:8792/api/health
```

Secrets come from `env_file: .env.production` at runtime; only the
`NEXT_PUBLIC_*` values are passed as build args, because only those need to be
in the client bundle. `SUPABASE_SERVICE_ROLE_KEY` and `ANTHROPIC_API_KEY` are
runtime-only and must never be build args.

The compose healthcheck mirrors the image's: `wget -qO-
http://127.0.0.1:3000/api/health`, 30s interval, 20s start period, 3 retries.
`restart: unless-stopped`.

ASSUMPTION: the host already runs a Cloudflare Tunnel with an ingress route to
add. If it does not, that is a prerequisite, not part of this deployment.

---

## Supabase project setup

1. **Create the project.** PostgreSQL 16. Note the project URL, anon key and
   service role key.

2. **Apply the migrations, in order.** `0001_schema.sql`, `0002_views.sql`,
   `0003_functions.sql`, `0004_rls.sql`, `0005_storage.sql`. They apply cleanly
   on an empty database.

   ```bash
   supabase link --project-ref <ref>
   supabase db push
   ```

   Locally, `supabase db reset` applies all five and then the seed.

3. **Seed, if you want the demo site.** `supabase/seed.sql` creates the same 12
   members, 31 nominations and 24 comments as the demo store, with explicit
   sequence values and the identity restarted at 45 so the short codes match.
   Skip it for a real deployment.

4. **Storage.** `0005_storage.sql` creates the `incident-photos` bucket:
   public-read, 8 MiB limit, `image/jpeg|png|webp|avif` only. Writes are
   namespaced — an object must live under `<auth.uid()>/`. Public read is
   deliberate: what lands there is already the redacted, published image.

5. **Auth providers.** `supabase/config.toml` enables email (with
   confirmations), Google, Apple and Facebook. In the hosted dashboard, add the
   client IDs and secrets, and set the redirect URLs to match:

   - Site URL → `https://dontbeadick.com.au`
   - Redirect URLs → `https://dontbeadick.com.au/auth/callback`,
     `https://www.dontbeadick.com.au/auth/callback`, and
     `http://localhost:3000/auth/callback` for development.

   Anonymous sign-ins are **off**. Sign-up is on — you do not need an account to
   nominate, report or appeal, but you do to vote or comment.

6. **The service role key** is used only by `createSupabaseServiceClient()`, for
   privileged jobs — notably deleting storage objects for photos removed by
   `redact_photo`, and `refresh_badges()`. Keep it server-side, out of build
   args, out of the client bundle, out of the repository.

7. **Verify the policies** before opening the doors:

   ```bash
   bash supabase/tests/local-pg.sh
   ```

   See [03 — Data model](./03-data-model.md) for the RLS matrix and the
   invariants the suite asserts.

---

## Continuous integration

`.github/workflows/ci.yml`, three jobs:

| Job | Steps |
| --- | --- |
| **build** | Node 22 → `npm ci` → `npm run typecheck` (strict, real vendor types, `DBAD_IGNORE_TS_ERRORS` unset) → `npm run lint` → `npm run build` in demo mode. |
| **database** | PostgreSQL 16 service container → `bash supabase/tests/local-pg.sh` — every migration, the seed, then `rls.test.sql`. |
| **docker** | Needs `build`. Buildx image build, not pushed. |

LIMITATION: **there is no `package-lock.json` in the repository.** CI runs
`npm ci`, which fails without one. The Dockerfile already handles the absence
(`npm ci` if present, else `npm install`). Generate and commit a lockfile before
relying on CI, or change the CI step to match the Dockerfile's behaviour.

---

## Health endpoint

`GET /api/health` — `runtime: nodejs`, `dynamic: force-dynamic`,
`cache-control: no-store`.

```json
{ "ok": true, "service": "dbad", "mode": "supabase", "time": "2026-09-05T…Z" }
```

It is the Docker and compose healthcheck target and a sensible uptime-monitor
target. `mode` is the fastest way to confirm a container came up against the
database you meant.

Note that `robots.txt` disallows `/api/`, and the service worker never caches
it.

---

## Image optimisation

`next.config.ts`:

- Formats `image/avif` then `image/webp`.
- `deviceSizes` starts at 360 and 414 — phone widths first, because that is
  where the traffic is.
- `remotePatterns` contains **exactly one** entry, and only when
  `NEXT_PUBLIC_SUPABASE_URL` is set: that project's host, restricted to
  `/storage/v1/object/public/**`. A demo-mode build allows no remote images at
  all.
- Seed illustrations are served from `public/seed/` and optimised by the same
  pipeline.

The 25 seed images are generated, not photographed —
`bun run tools/illustrations/generate.ts` composes flat-vector scenes as SVG and
rasterises them with `sharp` to 1200×900 JPEGs, with a contact sheet at
`public/seed/contact-sheet.png`. The house rules are baked into the generator:
no readable text in any scene, every number plate a pixelated mosaic, people
faceless or seen from behind, and a scrubbed metadata strip on each frame. The
seed data obeys the same privacy rules the community does.

---

## PDF fonts

`src/lib/notice/pdf.ts` embeds the brand TTFs from `public/pdf-fonts` when
`@pdf-lib/fontkit` can be imported, and falls back to the PDF standard fonts —
Helvetica, Helvetica-Bold, Courier-Bold — when it cannot.

- The import is by variable (`const moduleName = "@pdf-lib/fontkit"`) so a
  bundler does not fail the build when the optional package is missing.
- `serverExternalPackages: ["pdf-lib", "@pdf-lib/fontkit"]` keeps both as plain
  Node modules on the server.
- `outputFileTracingIncludes` copies `public/pdf-fonts/**` into the standalone
  build for `/api/notices/[id]/pdf`, `/opengraph-image` and
  `/moves/[slug]/opengraph-image`.
- The response header `x-dbad-fonts: brand | standard` says which path was taken.
  **If a production PDF comes back `standard`, fontkit or the font files did not
  make it into the image.**

The Open Graph routes read the same TTFs and have no fallback — `next/og` needs
real font data, so a missing `public/pdf-fonts` breaks share cards.

---

## What the build sandbox verified, and what it did not

This is the honest ledger. DBAD was developed in an environment with **no access
to an npm registry**.

**Verified:**

| What | How |
| --- | --- |
| Strict type-checking of all application code | `bash tools/typecheck/run.sh` — `tsc` with `strict`, `noUncheckedIndexedAccess` and `noImplicitOverride`, against hand-written vendor declarations in `tools/typecheck/types/` for `next`, `react`, `react-dom` and `@supabase/*`. `pdf-lib` and `@types/node` resolve normally. |
| Every view, at every route, with real data | `bun run tools/preview/server.ts` on `127.0.0.1:4801` — the real components against the real `DemoRepository`, with six Next.js primitives shimmed. |
| Interaction, layout and visual regression | Playwright against the harness, including the Fold viewport ranges. |
| Three route handlers | `/api/qr`, `/api/notices/:id/pdf` and `/api/ai/rewrite` are mounted directly in the harness — they are plain `Request → Response` functions. |
| The whole database layer | `bash supabase/tests/local-pg.sh` — a throwaway PostgreSQL 16 cluster on port 54329, every migration, the seed, then `rls.test.sql` asserting the RLS matrix, the PII triggers, the role guard and every `moderate()` branch from each role's point of view. |
| Font, PDF and QR output | Rendered and inspected via the harness. |

**Not verified:**

| What | Why |
| --- | --- |
| `next build` | LIMITATION: `next` was never installed. The production build has not been run here. Everything about the App Router — route conventions, `generateMetadata`, server actions, `next/og`, standalone output, the middleware matcher — is written to the documented contracts and type-checked against hand-written stubs, but **not compiled by Next.js**. Run `npm run build` first on any real machine. |
| `npm ci` / dependency resolution | LIMITATION: no registry, and no lockfile committed. Versions in `package.json` are unverified against each other. |
| ESLint | LIMITATION: `eslint` and `eslint-config-next` were never installed. `npm run lint` has not run. |
| The real Supabase client | The type-check used a hand-written `@supabase/supabase-js` / `@supabase/ssr` stub. The SQL side is fully tested; the **client binding** between `SupabaseRepository` and the real library is not. |
| The Docker image | LIMITATION: no Docker daemon. The Dockerfile and compose file are written but unbuilt. |
| Anthropic wording helper | No API key and no outbound network. The local rewriter is exercised; the Anthropic path is not. |
| Real OAuth flows | No Supabase project. Google, Apple and Facebook sign-in are configured, not tested. |

DECISION: the hand-written vendor stubs are checked in under
`tools/typecheck/types/` rather than being throwaway scaffolding, because they
document exactly which slice of each vendor API the application depends on. They
are a fallback for offline work, **not** a substitute for CI's `npm run
typecheck` against the real packages — which is why CI runs both.

---

## Go-live checklist

**Before the first deploy**

- [ ] `npm install` on a machine with a registry; **commit `package-lock.json`**.
- [ ] `npm run typecheck` against real vendor types. Fix everything.
- [ ] `npm run lint`.
- [ ] `npm run build` with `DBAD_IGNORE_TS_ERRORS` unset. This is the step the
      sandbox could not run.
- [ ] `bash supabase/tests/local-pg.sh` — all checks `PASS`.

**Supabase**

- [ ] Project created; migrations applied in order.
- [ ] `incident-photos` bucket exists, public-read, 8 MiB, image MIME types only.
- [ ] RLS on for every table in `public`; `local-pg.sh` green against the real
      project's schema.
- [ ] Auth: site URL and all three redirect URLs registered; provider secrets in
      the dashboard; anonymous sign-ins off.
- [ ] Seed applied only if you want the demo content. **Do not seed a real
      deployment.**
- [ ] Service role key stored as a runtime secret only.
- [ ] At least one admin account exists — promote it with
      `moderate('change_role')` or a one-off SQL update, and confirm the
      `profiles_guard_role` trigger blocks self-promotion afterwards.

**Application**

- [ ] `.env.production` complete; `NEXT_PUBLIC_SITE_URL` matches the real origin
      exactly (QR payloads and auth redirects both depend on it).
- [ ] Image built with the correct `NEXT_PUBLIC_*` build args — they are baked
      in, so a wrong value means a rebuild.
- [ ] `SUPABASE_SERVICE_ROLE_KEY` and `ANTHROPIC_API_KEY` supplied at runtime,
      never as build args.
- [ ] `/api/health` returns `"mode":"supabase"`.
- [ ] `/api/notices/<id>/pdf` returns `x-dbad-fonts: brand`.
- [ ] Open Graph cards render: check `/opengraph-image` and one
      `/moves/<slug>/opengraph-image`.
- [ ] `/manifest.webmanifest`, `/robots.txt` and `/sitemap.xml` all serve, with
      the correct origin.
- [ ] The service worker registers and `/offline.html` appears when offline.

**Network**

- [ ] Container publishes `8792` on loopback or LAN only. **Never bind
      publicly.**
- [ ] Cloudflare Tunnel route added: `dontbeadick.com.au` →
      `http://<host>:8792`.
- [ ] HTTPS terminates at Cloudflare; the origin is not reachable directly.
- [ ] Security headers present on a live response: `X-Content-Type-Options`,
      `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`.

**Content and moderation**

- [ ] A moderator is rostered before photo nominations open — the queue is the
      privacy guarantee, not a formality.
- [ ] `/standards`, `/privacy` and `/about-you` reviewed and accurate for the
      launch jurisdiction.
- [ ] Notice-placement guidance checked against local law.
- [ ] A retention policy decided and the job written — see
      [05 — Privacy controls](./05-privacy-controls.md); there is none in the
      codebase.

**After go-live**

- [ ] `/api/health` on an uptime monitor.
- [ ] Watch `x-dbad-fonts` and the PDF route for the first real notice.
- [ ] Walk the full mobile journey on a real phone: camera → redaction →
      submit → queue → approve → verdict → notice → print.
