import type { NextConfig } from "next";

/**
 * DBAD Next.js configuration.
 *
 * - `output: "standalone"` so the Docker image only ships what the server needs.
 * - Image optimisation for Supabase Storage hosts (public bucket URLs) and local seed images.
 * - Server Actions accept up to 8 MB so the demo-mode nomination flow can post a
 *   redacted, downscaled photo without a storage bucket. In Supabase mode photos are
 *   uploaded directly to Storage and only the object path travels through the action.
 * - `DBAD_IGNORE_TS_ERRORS=1` lets a deployment build proceed even if a vendor type
 *   mismatch slips through; CI runs `npm run typecheck` with the flag unset so real
 *   type errors are still surfaced.
 */
const supabaseHost = (() => {
  try {
    return process.env.NEXT_PUBLIC_SUPABASE_URL
      ? new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).hostname
      : undefined;
  } catch {
    return undefined;
  }
})();

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: true,
  poweredByHeader: false,
  images: {
    formats: ["image/avif", "image/webp"],
    deviceSizes: [360, 414, 640, 750, 828, 1080, 1280, 1600, 1920],
    remotePatterns: [
      ...(supabaseHost
        ? [{ protocol: "https" as const, hostname: supabaseHost, pathname: "/storage/v1/object/public/**" }]
        : []),
    ],
  },
  experimental: {
    serverActions: {
      bodySizeLimit: "8mb",
    },
  },
  // pdf-lib (+ optional fontkit) run as plain Node modules on the server.
  serverExternalPackages: ["pdf-lib", "@pdf-lib/fontkit"],
  // The PDF and Open Graph routes read brand fonts from disk at runtime.
  outputFileTracingIncludes: {
    "/api/notices/[id]/pdf": ["./public/pdf-fonts/**"],
    "/opengraph-image": ["./public/pdf-fonts/**"],
    "/moves/[slug]/opengraph-image": ["./public/pdf-fonts/**"],
  },
  typescript: {
    ignoreBuildErrors: process.env.DBAD_IGNORE_TS_ERRORS === "1",
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(self), geolocation=(self), microphone=()" },
        ],
      },
      {
        source: "/fonts/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=31536000, immutable" }],
      },
      {
        source: "/sw.js",
        headers: [{ key: "Cache-Control", value: "no-cache" }],
      },
    ];
  },
  async redirects() {
    return [
      // Short QR-friendly incident links: /d/DBAD-0042 -> /moves/by-code/DBAD-0042
      { source: "/d/:code", destination: "/moves/code/:code", permanent: false },
    ];
  },
};

export default nextConfig;
