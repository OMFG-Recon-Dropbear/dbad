import type { Metadata } from "next";
import { getRepository } from "@/lib/data";
import type { AppealAction } from "@/lib/domain/types";
import { AboutYouView } from "@/components/content/about-you-view";
import { submitAppeal } from "@/app/actions/appeal";

export const metadata: Metadata = {
  title: "Is this about you?",
  description: "Ask for removal, correction, anonymisation, context, a right of reply or redemption status — without identifying yourself publicly.",
  alternates: { canonical: "/about-you" },
};

const ACTIONS: AppealAction[] = ["removal", "correction", "anonymisation", "context", "reply", "redemption"];

export default async function AboutYouPage({ searchParams }: { searchParams: Promise<{ code?: string; action?: string }> }) {
  const [repo, sp] = await Promise.all([getRepository(), searchParams]);
  const code = sp.code?.trim().toUpperCase();
  const incident = code ? await repo.getIncidentByCode(code) : null;
  const initialAction = ACTIONS.includes(sp.action as AppealAction) ? (sp.action as AppealAction) : undefined;
  return <AboutYouView incident={incident} code={code} actions={{ submit: submitAppeal }} initialAction={initialAction} />;
}
