import type { Metadata } from "next";
import { AboutView } from "@/components/content/about-view";

export const metadata: Metadata = {
  title: "About DBAD",
  description: "DBAD isn't about ruining someone's day. It's about recognising the small choices we all make that affect everyone around us.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return <AboutView />;
}
