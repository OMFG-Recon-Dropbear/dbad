"use server";

import { revalidatePath } from "next/cache";
import type { ModerationCommand } from "@/lib/data/repository";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";

export async function moderate(command: ModerationCommand) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  if (!viewer || viewer.role === "member") return { ok: false, message: "Moderators only." };
  const res = await repo.moderate(command, viewer);
  if (res.ok) {
    revalidatePath("/admin", "layout");
    revalidatePath("/");
    revalidatePath("/feed");
    revalidatePath("/week");
    revalidatePath("/not-a-dick");
    revalidatePath("/map");
    revalidatePath("/moves/[slug]", "page");
  }
  return res;
}
