"use server";

import type { AppealInput } from "@/lib/data/repository";
import { getRepository } from "@/lib/data";

export async function submitAppeal(input: AppealInput) {
  const repo = await getRepository();
  return repo.submitAppeal(input);
}
