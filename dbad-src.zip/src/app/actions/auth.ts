"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { DEMO_ACCOUNTS, DEMO_COOKIE } from "@/lib/auth/session";
import { isSupabaseConfigured } from "@/lib/data";
import { SITE } from "@/lib/site";

function safeNext(next: string | undefined): string {
  if (!next || !next.startsWith("/") || next.startsWith("//")) return "/";
  return next;
}

export async function demoSignIn(id: string, next: string) {
  if (isSupabaseConfigured()) redirect("/sign-in");
  if (!DEMO_ACCOUNTS.some((a) => a.id === id)) redirect("/sign-in?error=unknown");
  const store = await cookies();
  store.set(DEMO_COOKIE, id, { httpOnly: true, sameSite: "lax", path: "/", maxAge: 60 * 60 * 24 * 30, secure: process.env.NODE_ENV === "production" });
  redirect(safeNext(next));
}

export async function signOut() {
  const store = await cookies();
  if (isSupabaseConfigured()) {
    const { createSupabaseServerClient } = await import("@/lib/supabase/server");
    const supabase = await createSupabaseServerClient();
    await supabase.auth.signOut();
  } else {
    store.delete(DEMO_COOKIE);
  }
  redirect("/");
}

export async function emailSignIn(email: string, next: string): Promise<{ ok: boolean; message?: string }> {
  if (!isSupabaseConfigured()) return { ok: false, message: "Email sign-in needs Supabase configured." };
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { ok: false, message: "That doesn't look like an email address." };
  const { createSupabaseServerClient } = await import("@/lib/supabase/server");
  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.auth.signInWithOtp({
    email,
    options: { emailRedirectTo: `${SITE.url}/auth/callback?next=${encodeURIComponent(safeNext(next))}` },
  });
  if (error) return { ok: false, message: error.message };
  return { ok: true, message: "Check your email for a sign-in link. It's valid for an hour." };
}

export async function oauthSignIn(provider: "google" | "apple" | "facebook", next: string) {
  if (!isSupabaseConfigured()) redirect("/sign-in");
  const { createSupabaseServerClient } = await import("@/lib/supabase/server");
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider,
    options: { redirectTo: `${SITE.url}/auth/callback?next=${encodeURIComponent(safeNext(next))}` },
  });
  if (error || !data?.url) redirect(`/sign-in?error=${encodeURIComponent(error?.message ?? "oauth")}`);
  redirect(data.url);
}
