"use server";

import { revalidatePath } from "next/cache";
import type { ReactionKind, Verdict } from "@/lib/domain/types";
import type { ReportInput } from "@/lib/data/repository";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import type { CommunityActions } from "@/lib/actions/types";

export async function castVote(incidentId: string, verdict: Verdict) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return repo.castVote(incidentId, verdict, viewer);
}

export async function toggleReaction(incidentId: string, kind: ReactionKind) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return repo.toggleReaction(incidentId, kind, viewer);
}

export async function addComment(incidentId: string, body: string) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return repo.addComment(incidentId, body, viewer);
}

export async function reportContent(input: ReportInput) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return repo.reportContent(input, viewer);
}

export async function markRedeemed(incidentId: string, note: string) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const res = await repo.markRedeemed(incidentId, note, viewer);
  if (res.ok) {
    revalidatePath("/");
    revalidatePath("/feed");
    revalidatePath("/moves/[slug]", "page");
  }
  return res;
}

/** Bundle passed to client components as a single prop. */
export async function communityActions(): Promise<CommunityActions> {
  return { castVote, toggleReaction, addComment, reportContent, markRedeemed };
}
