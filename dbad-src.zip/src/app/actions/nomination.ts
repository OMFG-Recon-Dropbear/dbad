"use server";

import { revalidatePath } from "next/cache";
import type { NominationInput } from "@/lib/domain/types";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { rewrite, type RewriteInput } from "@/lib/ai/rewrite";

export async function submitNomination(input: NominationInput) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const res = await repo.createIncident(input, viewer);
  if (res.ok) {
    revalidatePath("/");
    revalidatePath("/feed");
    revalidatePath("/not-a-dick");
    revalidatePath("/map");
  }
  return res;
}

export async function suggestWording(input: RewriteInput) {
  return rewrite({ ...input, text: input.text.slice(0, 1500) });
}
