"use server";

import type { CreateNoticeInput } from "@/lib/data/repository";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";

export async function updateNotice(id: string, patch: Partial<CreateNoticeInput>) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return repo.updateNotice(id, patch, viewer);
}

export async function createNotice(input: CreateNoticeInput) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return repo.createNotice(input, viewer);
}
