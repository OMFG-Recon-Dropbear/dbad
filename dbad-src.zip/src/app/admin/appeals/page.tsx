import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadAppeals, parseAppealStatus } from "@/lib/loaders/admin";
import { AppealsView } from "@/components/admin/appeals-view";
import { moderate } from "@/app/actions/admin";

export default async function AppealsPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  return <AppealsView {...(await loadAppeals(repo, parseAppealStatus(sp.status)))} viewer={viewer!} actions={{ moderate }} />;
}
