import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadAudit } from "@/lib/loaders/admin";
import { AuditView } from "@/components/admin/audit-view";
import { moderate } from "@/app/actions/admin";

export default async function AuditPage() {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return <AuditView {...(await loadAudit(repo))} viewer={viewer!} actions={{ moderate }} />;
}
