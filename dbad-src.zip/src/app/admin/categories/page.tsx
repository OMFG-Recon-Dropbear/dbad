import { getViewer } from "@/lib/auth/session";
import { CategoriesView } from "@/components/admin/categories-view";
import { moderate } from "@/app/actions/admin";

export default async function CategoriesPage() {
  const viewer = await getViewer();
  return <CategoriesView viewer={viewer!} actions={{ moderate }} />;
}
