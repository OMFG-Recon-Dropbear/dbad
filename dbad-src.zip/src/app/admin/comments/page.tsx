import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadAdminComments, parseCommentStatus } from "@/lib/loaders/admin";
import { CommentsView } from "@/components/admin/comments-view";
import { moderate } from "@/app/actions/admin";

export default async function AdminCommentsPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  return <CommentsView {...(await loadAdminComments(repo, parseCommentStatus(sp.status)))} viewer={viewer!} actions={{ moderate }} />;
}
