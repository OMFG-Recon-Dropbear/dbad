import type { Metadata } from "next";
import type * as React from "react";
import { redirect } from "next/navigation";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { isModerator } from "@/lib/data/repository";
import { loadAdminCounts } from "@/lib/loaders/admin";
import { AdminSectionProvider } from "@/components/admin/admin-section";

export const metadata: Metadata = { title: "Moderation", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  if (!isModerator(viewer)) redirect("/sign-in?next=/admin");
  const counts = await loadAdminCounts(repo);
  return (
    <AdminSectionProvider viewer={viewer} counts={counts}>
      {children}
    </AdminSectionProvider>
  );
}
