import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadMembers } from "@/lib/loaders/admin";
import { MembersView } from "@/components/admin/members-view";
import { moderate } from "@/app/actions/admin";

export default async function MembersPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  return <MembersView {...(await loadMembers(repo, sp.q?.trim() || undefined))} viewer={viewer!} actions={{ moderate }} />;
}
