import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadAdminIncidents, parseIncidentAdminStatus } from "@/lib/loaders/admin";
import { IncidentsAdminView } from "@/components/admin/incidents-admin-view";
import { moderate } from "@/app/actions/admin";

export default async function AdminNominationsPage({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  const props = await loadAdminIncidents(repo, { status: parseIncidentAdminStatus(sp.status), query: sp.q?.trim() || undefined });
  return <IncidentsAdminView {...props} viewer={viewer!} actions={{ moderate }} />;
}
