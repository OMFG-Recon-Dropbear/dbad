import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadAdminDashboard } from "@/lib/loaders/admin";
import { DashboardView } from "@/components/admin/dashboard-view";
import { moderate } from "@/app/actions/admin";

export default async function AdminDashboardPage() {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const props = await loadAdminDashboard(repo);
  return <DashboardView {...props} viewer={viewer!} actions={{ moderate }} />;
}
