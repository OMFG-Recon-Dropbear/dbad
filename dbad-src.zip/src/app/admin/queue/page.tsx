import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadQueue } from "@/lib/loaders/admin";
import { QueueView } from "@/components/admin/queue-view";
import { moderate } from "@/app/actions/admin";

export default async function QueuePage() {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  return <QueueView {...(await loadQueue(repo))} viewer={viewer!} actions={{ moderate }} />;
}
