import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadReports, parseReportStatus } from "@/lib/loaders/admin";
import { ReportsView } from "@/components/admin/reports-view";
import { moderate } from "@/app/actions/admin";

export default async function ReportsPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  return <ReportsView {...(await loadReports(repo, parseReportStatus(sp.status)))} viewer={viewer!} actions={{ moderate }} />;
}
