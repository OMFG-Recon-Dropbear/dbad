import { getViewer } from "@/lib/auth/session";
import { TemplatesView } from "@/components/admin/templates-view";
import { moderate } from "@/app/actions/admin";

export default async function TemplatesPage() {
  const viewer = await getViewer();
  return <TemplatesView viewer={viewer!} actions={{ moderate }} />;
}
