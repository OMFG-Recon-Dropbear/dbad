import { rewrite, type RewriteInput } from "@/lib/ai/rewrite";
import { CATEGORY_MAP } from "@/lib/domain/categories";

export const runtime = "nodejs";

/**
 * POST /api/ai/rewrite { text, categoryId, affected?, kind? }
 * Turns an angry description into humorous, factual DBAD wording. Uses Anthropic when
 * configured, otherwise the built-in rewriter. Never stores the input.
 */
export async function POST(req: Request): Promise<Response> {
  let body: Partial<RewriteInput>;
  try {
    body = (await req.json()) as Partial<RewriteInput>;
  } catch {
    return Response.json({ error: "Invalid JSON" }, { status: 400 });
  }
  const text = typeof body.text === "string" ? body.text.slice(0, 1500) : "";
  if (text.trim().length < 4) return Response.json({ error: "Write a sentence first." }, { status: 400 });
  const categoryId = body.categoryId && body.categoryId in CATEGORY_MAP ? body.categoryId : "other";
  const result = await rewrite({
    text,
    categoryId,
    affected: Array.isArray(body.affected) ? body.affected.slice(0, 10) : undefined,
    kind: body.kind === "not_a_dick" ? "not_a_dick" : "dick_move",
  });
  return Response.json(result, { headers: { "cache-control": "no-store" } });
}
