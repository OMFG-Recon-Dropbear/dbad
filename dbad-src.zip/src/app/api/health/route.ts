import { dataMode } from "@/lib/data";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Liveness/readiness probe for Docker, the tunnel and uptime checks. */
export async function GET(): Promise<Response> {
  return Response.json(
    { ok: true, service: "dbad", mode: dataMode(), time: new Date().toISOString() },
    { headers: { "cache-control": "no-store" } },
  );
}
