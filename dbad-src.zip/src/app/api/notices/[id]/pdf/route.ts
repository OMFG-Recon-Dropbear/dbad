import { getRepository } from "@/lib/data";
import { renderNoticePdf, type NoticeSize } from "@/lib/notice/pdf";
import { SITE } from "@/lib/site";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET /api/notices/:id/pdf?size=a5|a6 — vector PDF of a saved notice. */
export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }): Promise<Response> {
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const size: NoticeSize = url.searchParams.get("size") === "a6" ? "a6" : "a5";
  const repo = await getRepository();
  const notice = await repo.getNotice(id);
  if (!notice) return new Response("Notice not found", { status: 404 });
  const incident = notice.incidentId ? await repo.getIncidentById(notice.incidentId) : null;
  const qrUrl = notice.linkMode === "incident" && incident ? `${SITE.url}/d/${incident.shortCode}` : SITE.url;
  const { bytes, customFonts } = await renderNoticePdf({
    template: notice.template,
    lines: notice.lines,
    code: incident?.shortCode,
    qrUrl,
    linkMode: notice.linkMode,
    size,
  });
  const filename = `DBAD-notice-${incident?.shortCode ?? notice.id.slice(-6)}-${size.toUpperCase()}.pdf`;
  return new Response(bytes as unknown as BodyInit, {
    headers: {
      "content-type": "application/pdf",
      "content-disposition": `inline; filename="${filename}"`,
      "cache-control": "private, no-store",
      "x-dbad-fonts": customFonts ? "brand" : "standard",
    },
  });
}
