import { qrSvg, type EcLevel } from "@/lib/domain/qr";
import { SITE } from "@/lib/site";

export const runtime = "nodejs";

/**
 * GET /api/qr?text=<url>&size=240&ec=M&dark=%230f0f0f&light=%23ffffff
 * Returns an SVG QR code. Only DBAD URLs may be encoded (this is not a public QR service).
 */
export async function GET(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const text = url.searchParams.get("text") ?? SITE.url;
  if (!text.startsWith(SITE.url) && !text.startsWith("/") && !/^https?:\/\/(?:127\.0\.0\.1|localhost)/.test(text)) {
    return new Response("Only DBAD links can be encoded.", { status: 400 });
  }
  const size = Math.min(1024, Math.max(64, Number(url.searchParams.get("size")) || 240));
  const ec = (url.searchParams.get("ec") ?? "M").toUpperCase() as EcLevel;
  const dark = url.searchParams.get("dark") ?? "#0f0f0f";
  const light = url.searchParams.get("light") ?? "#ffffff";
  const safeColor = (c: string) => (/^#[0-9a-fA-F]{3,8}$/.test(c) || c === "none" ? c : "#0f0f0f");
  const svg = qrSvg(text.startsWith("/") ? `${SITE.url}${text}` : text, { size, ecLevel: ["L", "M", "Q", "H"].includes(ec) ? ec : "M", dark: safeColor(dark), light: safeColor(light) as never });
  return new Response(svg, {
    headers: {
      "content-type": "image/svg+xml; charset=utf-8",
      "cache-control": "public, max-age=86400, immutable",
    },
  });
}
