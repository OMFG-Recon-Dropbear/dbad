import { NextResponse, type NextRequest } from "next/server";
import { isSupabaseConfigured } from "@/lib/data";

/** Supabase Auth redirect target: exchanges the code for a session, then sends the member on. */
export async function GET(request: NextRequest) {
  const url = request.nextUrl.clone();
  const code = url.searchParams.get("code");
  const next = url.searchParams.get("next") ?? "/";
  const safeNext = next.startsWith("/") && !next.startsWith("//") ? next : "/";
  url.pathname = safeNext;
  url.search = "";
  if (!isSupabaseConfigured() || !code) return NextResponse.redirect(url);
  const { createSupabaseServerClient } = await import("@/lib/supabase/server");
  const supabase = await createSupabaseServerClient();
  const { error } = await supabase.auth.exchangeCodeForSession(code);
  if (error) {
    url.pathname = "/sign-in";
    url.searchParams.set("error", error.message);
  }
  return NextResponse.redirect(url);
}
