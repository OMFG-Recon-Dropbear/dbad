"use client";

import { useEffect } from "react";
import { Container } from "@/components/layout/site-shell";
import { ErrorState } from "@/components/ui/empty-state";
import { Button } from "@/components/ui/button";

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);
  return (
    <Container size="md" className="py-16">
      <ErrorState title="Something went sideways." body="Not your fault. Probably ours. The nomination you were writing is still in this tab." />
      <div className="mt-6 flex justify-center">
        <Button variant="dark" onClick={reset}>Try again</Button>
      </div>
      {error.digest && <p className="mt-4 text-center font-mono text-[11px] uppercase tracking-widest text-concrete-600">Ref {error.digest}</p>}
    </Container>
  );
}
