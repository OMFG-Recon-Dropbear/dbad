import type { Metadata } from "next";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadFeed, type SearchParams } from "@/lib/loaders/feed";
import { FeedView } from "@/components/feed/feed-view";

export const metadata: Metadata = {
  title: "Latest dick moves",
  description: "Fresh nominations from the DBAD community. Cast your verdict, have a laugh, keep an eye out for redemption.",
  alternates: { canonical: "/feed" },
};

export default async function FeedPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  const props = await loadFeed(repo, viewer, sp, "dick_move", "/feed");
  return <FeedView {...props} />;
}
