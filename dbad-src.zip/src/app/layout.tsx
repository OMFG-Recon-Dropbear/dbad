import type { Metadata, Viewport } from "next";
import type * as React from "react";
import "./globals.css";
import { SITE } from "@/lib/site";
import { getViewer } from "@/lib/auth/session";
import { getRepository } from "@/lib/data";
import { SiteShell } from "@/components/layout/site-shell";
import { RegisterServiceWorker } from "@/components/pwa/register-sw";

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: {
    default: SITE.fullName,
    template: `%s · DBAD`,
  },
  description: SITE.description,
  applicationName: "DBAD",
  keywords: ["don't be a dick", "dick move", "community", "Australia", "parking", "noticeboard", "redemption"],
  manifest: "/manifest.webmanifest",
  openGraph: {
    type: "website",
    siteName: "DBAD — Don't Be A Dick.",
    locale: SITE.locale,
    url: SITE.url,
    title: SITE.fullName,
    description: SITE.description,
  },
  twitter: {
    card: "summary_large_image",
    site: SITE.twitterHandle,
    title: SITE.fullName,
    description: SITE.description,
  },
  icons: {
    icon: [{ url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }, { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" }],
    apple: [{ url: "/icons/apple-touch-icon.png", sizes: "180x180" }],
    shortcut: ["/favicon.ico"],
  },
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "DBAD" },
  robots: { index: true, follow: true },
  alternates: { canonical: SITE.url },
};

export const viewport: Viewport = {
  themeColor: "#0f0f0f",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const viewer = await getViewer();
  let unread = 0;
  if (viewer) {
    try {
      const repo = await getRepository();
      unread = (await repo.listNotifications(viewer)).filter((n) => !n.readAt).length;
    } catch {
      unread = 0;
    }
  }
  return (
    <html lang="en-AU">
      <head>
        <link rel="preload" href="/fonts/DBADDisplay-Black.woff" as="font" type="font/woff" crossOrigin="anonymous" />
        <link rel="preload" href="/fonts/PublicSans-Variable.woff" as="font" type="font/woff" crossOrigin="anonymous" />
      </head>
      <body>
        <SiteShell viewer={viewer} unread={unread}>
          {children}
        </SiteShell>
        <RegisterServiceWorker />
      </body>
    </html>
  );
}
