import { Container } from "@/components/layout/site-shell";
import { Skeleton } from "@/components/ui/empty-state";

export default function Loading() {
  return (
    <Container className="py-10 space-y-6" aria-busy="true" aria-label="Loading">
      <Skeleton className="h-10 w-2/3 max-w-md" />
      <Skeleton className="h-5 w-1/2 max-w-sm" />
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 pt-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="border-[3px] border-concrete-300 bg-paper-100">
            <Skeleton className="aspect-[4/3]" />
            <div className="p-4 space-y-3">
              <Skeleton className="h-6 w-5/6" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-3 w-full" />
            </div>
          </div>
        ))}
      </div>
    </Container>
  );
}
