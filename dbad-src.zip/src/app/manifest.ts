import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "DBAD — Don't Be A Dick.",
    short_name: "DBAD",
    description: "Call out dick moves. The behaviour, never the person. Nominate, vote, print a notice, celebrate redemption.",
    start_url: "/?source=pwa",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#171717",
    theme_color: "#0f0f0f",
    lang: "en-AU",
    categories: ["social", "lifestyle"],
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
      { src: "/icons/icon-512-maskable.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
    shortcuts: [
      { name: "Nominate a dick move", short_name: "Nominate", url: "/nominate?source=shortcut", icons: [{ src: "/icons/icon-192.png", sizes: "192x192" }] },
      { name: "Latest dick moves", short_name: "Feed", url: "/feed?source=shortcut" },
    ],
  };
}
