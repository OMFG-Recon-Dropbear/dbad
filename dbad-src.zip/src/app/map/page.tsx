import type { Metadata } from "next";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadMap } from "@/lib/loaders/map";
import { MapView } from "@/components/map/map-view";

export const metadata: Metadata = {
  title: "Australian Dickery Map",
  description: "Where the dick moves are. Approximate areas only — suburb or public place, never a home.",
  alternates: { canonical: "/map" },
};

export default async function MapPage({ searchParams }: { searchParams: Promise<{ region?: string }> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  const props = await loadMap(repo, viewer, sp.region);
  return <MapView {...props} />;
}
