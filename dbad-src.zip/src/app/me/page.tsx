import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { ProfileView } from "@/components/profile/profile-view";
import { signOut } from "@/app/actions/auth";

export const metadata: Metadata = { title: "Your profile", robots: { index: false } };

export default async function MePage() {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  if (!viewer) redirect("/sign-in?next=/me");
  const page = await repo.getProfileById(viewer.id);
  if (!page) redirect("/sign-in?next=/me");
  return <ProfileView page={page} viewer={viewer} isSelf signOutAction={signOut} />;
}
