import { ImageResponse } from "next/og";
import { getRepository } from "@/lib/data";
import { summariseVotes } from "@/lib/domain/verdict";
import { SITE, absoluteUrl } from "@/lib/site";
import { ogFonts, OgCard } from "@/components/og/og-card";

export const runtime = "nodejs";
export const alt = "DBAD — Don't Be A Dick.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default async function Image({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const repo = await getRepository();
  const inc = await repo.getIncidentBySlug(slug);
  const fonts = await ogFonts();
  if (!inc) {
    return new ImageResponse(<OgCard kicker="DBAD" title="Don't be a dick." sub={SITE.subline} verdict="" location="" />, { ...size, fonts });
  }
  const positive = inc.kind === "not_a_dick";
  const s = summariseVotes(inc.votes);
  const verdictLine = positive ? "DEFINITELY NOT A DICK." : s.band === "pending" ? "COMMUNITY VERDICT PENDING" : `${s.label.toUpperCase()} · ${s.agreePercent}% DICK MOVE`;
  return new ImageResponse(
    <OgCard
      kicker={positive ? "DEFINITELY NOT A DICK" : inc.status === "redeemed" ? `${inc.category.label} · REDEEMED` : inc.category.label}
      title={inc.dickMove}
      sub={inc.title}
      verdict={verdictLine}
      location={`${inc.location.suburb}, ${inc.location.state} · ${inc.shortCode}`}
      positive={positive}
      photoUrl={inc.photos[0] ? absoluteUrl(inc.photos[0].url) : undefined}
    />,
    { ...size, fonts },
  );
}
