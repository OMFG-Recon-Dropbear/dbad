import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadIncident } from "@/lib/loaders/incident";
import { IncidentView } from "@/components/incident/incident-view";
import { summariseVotes } from "@/lib/domain/verdict";
import { SITE } from "@/lib/site";
import { castVote, toggleReaction, addComment, reportContent, markRedeemed } from "@/app/actions/community";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const repo = await getRepository();
  const inc = await repo.getIncidentBySlug(slug);
  if (!inc) return { title: "Not found" };
  const positive = inc.kind === "not_a_dick";
  const verdict = summariseVotes(inc.votes);
  const title = positive ? `Definitely not a dick: ${inc.dickMove}` : `${inc.category.label}: ${inc.dickMove}`;
  const description = `${inc.title} — ${inc.location.suburb}, ${inc.location.state}. ${positive ? "Definitely not a dick." : verdict.shareLine}`;
  return {
    title,
    description,
    alternates: { canonical: `/moves/${inc.slug}` },
    openGraph: {
      type: "article",
      title: `DBAD — ${inc.title}`,
      description,
      url: `${SITE.url}/moves/${inc.slug}`,
      publishedTime: inc.createdAt,
      section: inc.category.label,
      tags: [inc.category.short, inc.location.suburb, inc.location.state, positive ? "Not a dick" : "Dick move"],
    },
    twitter: { card: "summary_large_image", title: `DBAD — ${inc.title}`, description },
    robots: inc.moderationStatus === "approved" ? undefined : { index: false, follow: false },
  };
}

export default async function IncidentPage({ params }: Params) {
  const { slug } = await params;
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const data = await loadIncident(repo, viewer, slug);
  if (!data) notFound();
  return <IncidentView {...data} actions={{ castVote, toggleReaction, addComment, reportContent, markRedeemed }} />;
}
