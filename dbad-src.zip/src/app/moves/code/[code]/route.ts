import { NextResponse } from "next/server";
import { getRepository } from "@/lib/data";
import { SITE } from "@/lib/site";

/** /moves/code/DBAD-0042 (via /d/DBAD-0042) → the nomination page. Falls back to the home page. */
export async function GET(_req: Request, ctx: { params: Promise<{ code: string }> }) {
  const { code } = await ctx.params;
  const repo = await getRepository();
  const inc = await repo.getIncidentByCode(decodeURIComponent(code));
  return NextResponse.redirect(inc ? `${SITE.url}/moves/${inc.slug}?via=qr` : `${SITE.url}/?via=qr`, 302);
}
