import type { Metadata } from "next";
import { getViewer } from "@/lib/auth/session";
import { isSupabaseConfigured } from "@/lib/data";
import { CATEGORY_MAP } from "@/lib/domain/categories";
import type { CategoryId } from "@/lib/domain/types";
import { NominateWizard } from "@/components/nominate/nominate-wizard";
import { submitNomination, suggestWording } from "@/app/actions/nomination";

export const metadata: Metadata = {
  title: "Nominate a dick move",
  description: "Spot it. Snap it. DBAD it. Under a minute, on your phone, with faces and plates blurred before anything leaves your device.",
  robots: { index: true, follow: false },
};

export default async function NominatePage({ searchParams }: { searchParams: Promise<{ kind?: string; category?: string }> }) {
  const [viewer, sp] = await Promise.all([getViewer(), searchParams]);
  const category = sp.category && sp.category in CATEGORY_MAP ? (sp.category as CategoryId) : undefined;
  return (
    <NominateWizard
      viewer={viewer}
      actions={{ submit: submitNomination, suggest: suggestWording }}
      initialKind={sp.kind === "not_a_dick" ? "not_a_dick" : "dick_move"}
      initialCategory={category}
      requireAuthForPhotos={isSupabaseConfigured()}
    />
  );
}
