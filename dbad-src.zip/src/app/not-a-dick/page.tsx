import type { Metadata } from "next";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadFeed, type SearchParams } from "@/lib/loaders/feed";
import { FeedView } from "@/components/feed/feed-view";

export const metadata: Metadata = {
  title: "Definitely not a dick",
  description: "Trolleys returned, rubbish picked up, cars moved the second someone realised. The community standard, demonstrated.",
  alternates: { canonical: "/not-a-dick" },
};

export default async function NotADickPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  const props = await loadFeed(repo, viewer, sp, "not_a_dick", "/not-a-dick");
  return <FeedView {...props} />;
}
