import type { Metadata } from "next";
import { Container } from "@/components/layout/site-shell";
import { Stamp } from "@/components/brand/stamp";
import { ButtonLink } from "@/components/ui/button";

export const metadata: Metadata = { title: "Not found" };

export default function NotFound() {
  return (
    <Container size="md" className="py-20 text-center">
      <Stamp tone="concrete" size="xl" flat className="bg-paper-50">404</Stamp>
      <h1 className="mt-8 text-5xl sm:text-6xl">Not here, mate.</h1>
      <p className="mt-3 text-ink-700">Either it never existed, it was removed, or someone typed it with their elbows.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <ButtonLink href="/">Home</ButtonLink>
        <ButtonLink href="/feed" variant="dark">Latest dick moves</ButtonLink>
      </div>
    </Container>
  );
}
