import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadNotice } from "@/lib/loaders/notice";
import { NoticeStudio } from "@/components/notice/notice-studio";
import { updateNotice, createNotice } from "@/app/actions/notice";

type Params = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { id } = await params;
  const repo = await getRepository();
  const notice = await repo.getNotice(id);
  if (!notice) return { title: "Notice not found" };
  return {
    title: `DBAD notice — ${notice.lines.dickMove}`,
    description: `${notice.lines.headline} ${notice.lines.why}`,
    robots: { index: false, follow: true },
  };
}

export default async function NoticePage({ params }: Params) {
  const { id } = await params;
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const data = await loadNotice(repo, viewer, id);
  if (!data) notFound();
  return <NoticeStudio {...data} actions={{ update: updateNotice, create: createNotice }} />;
}
