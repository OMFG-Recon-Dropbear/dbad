import { redirect } from "next/navigation";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { createNoticeFor } from "@/lib/loaders/notice";

export const dynamic = "force-dynamic";

/** Creates a notice (for an incident, or a standalone one) and opens the studio. */
export default async function NewNoticePage({ searchParams }: { searchParams: Promise<{ incident?: string }> }) {
  const [repo, viewer, sp] = await Promise.all([getRepository(), getViewer(), searchParams]);
  const { notice } = await createNoticeFor(repo, viewer, sp.incident);
  redirect(`/notice/${notice.id}`);
}
