import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { NotificationsView } from "@/components/profile/profile-view";

export const metadata: Metadata = { title: "Notifications", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function NotificationsPage() {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  if (!viewer) redirect("/sign-in?next=/notifications");
  const notifications = await repo.listNotifications(viewer);
  await repo.markNotificationsRead(viewer);
  return <NotificationsView notifications={notifications} />;
}
