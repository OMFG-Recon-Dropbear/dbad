import { ImageResponse } from "next/og";
import { SITE } from "@/lib/site";
import { ogFonts, OgCard } from "@/components/og/og-card";

export const runtime = "nodejs";
export const alt = "DBAD — Don't Be A Dick.";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default async function Image() {
  const fonts = await ogFonts();
  return new ImageResponse(
    <OgCard kicker="Community noticeboard · Australia" title="Don't be a dick." sub={SITE.subline} verdict="See a dick move? Call it out." location={SITE.domain} />,
    { ...size, fonts },
  );
}
