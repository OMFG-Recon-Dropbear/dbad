import type { Metadata } from "next";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { loadHome } from "@/lib/loaders/home";
import { HomeView } from "@/components/home/home-view";
import { SITE } from "@/lib/site";

export const revalidate = 60;

export const metadata: Metadata = {
  title: SITE.fullName,
  description: `${SITE.subline} ${SITE.description}`,
  alternates: { canonical: "/" },
};

export default async function HomePage() {
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const props = await loadHome(repo, viewer);
  return <HomeView {...props} />;
}
