import type { Metadata } from "next";
import { PrivacyView } from "@/components/content/privacy-view";

export const metadata: Metadata = {
  title: "Privacy",
  description: "What DBAD collects, and what it refuses to. Built so the platform never becomes a dossier on anyone.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return <PrivacyView />;
}
