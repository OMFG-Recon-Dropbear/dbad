import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { DEMO_ACCOUNTS, getViewer } from "@/lib/auth/session";
import { dataMode } from "@/lib/data";
import { PROFILES } from "@/lib/data/demo/seed";
import { SignInView } from "@/components/auth/sign-in-view";
import { demoSignIn, emailSignIn, oauthSignIn } from "@/app/actions/auth";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function SignInPage({ searchParams }: { searchParams: Promise<{ next?: string; error?: string }> }) {
  const [viewer, sp] = await Promise.all([getViewer(), searchParams]);
  const next = sp.next && sp.next.startsWith("/") ? sp.next : "/";
  if (viewer) redirect(next);
  const mode = dataMode();
  const demoAccounts = DEMO_ACCOUNTS.map((a) => ({ ...a, handle: PROFILES.find((p) => p.id === a.id)?.handle ?? a.id }));
  return <SignInView mode={mode} demoAccounts={demoAccounts} next={next} actions={{ demoSignIn, emailSignIn, oauthSignIn }} error={sp.error} />;
}
