import type { MetadataRoute } from "next";
import { SITE } from "@/lib/site";
import { getRepository } from "@/lib/data";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const repo = await getRepository();
  const [moves, positive] = await Promise.all([repo.listIncidents({ kind: "dick_move", limit: 500 }), repo.listIncidents({ kind: "not_a_dick", limit: 500 })]);
  const statics: MetadataRoute.Sitemap = ["/", "/feed", "/not-a-dick", "/week", "/map", "/about", "/standards", "/about-you", "/privacy", "/nominate"].map((p) => ({
    url: `${SITE.url}${p}`,
    changeFrequency: p === "/" || p === "/feed" ? "hourly" : "weekly",
    priority: p === "/" ? 1 : 0.7,
  }));
  const items: MetadataRoute.Sitemap = [...moves.items, ...positive.items].map((i) => ({
    url: `${SITE.url}/moves/${i.slug}`,
    lastModified: i.redemption?.createdAt ?? i.createdAt,
    changeFrequency: "daily",
    priority: 0.6,
  }));
  return [...statics, ...items];
}
