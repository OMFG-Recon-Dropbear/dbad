import type { Metadata } from "next";
import { StandardsView } from "@/components/content/standards-view";

export const metadata: Metadata = {
  title: "Community standard",
  description: "Photograph the behaviour, not the person. Don't publish identifying information. Don't be a dick while telling someone else not to be a dick.",
  alternates: { canonical: "/standards" },
};

export default function StandardsPage() {
  return <StandardsView />;
}
