import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getRepository } from "@/lib/data";
import { getViewer } from "@/lib/auth/session";
import { ProfileView } from "@/components/profile/profile-view";

type Params = { params: Promise<{ handle: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { handle } = await params;
  return { title: `${handle} · DBAD member`, description: `Nominations, verdicts and badges from ${handle} on DBAD.` };
}

export default async function ProfilePage({ params }: Params) {
  const { handle } = await params;
  const [repo, viewer] = await Promise.all([getRepository(), getViewer()]);
  const page = await repo.getProfileByHandle(handle);
  if (!page) notFound();
  return <ProfileView page={page} viewer={viewer} isSelf={viewer?.id === page.profile.id} />;
}
