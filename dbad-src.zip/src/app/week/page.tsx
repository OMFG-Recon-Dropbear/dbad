import type { Metadata } from "next";
import { getRepository } from "@/lib/data";
import { WeekView } from "@/components/feed/week-view";

export const revalidate = 300;

export const metadata: Metadata = {
  title: "Dick Move of the Week",
  description: "Chosen by community verdict and a moderator's sanity check. An award nobody wants, for behaviour everybody recognises.",
  alternates: { canonical: "/week" },
};

export default async function WeekPage() {
  const repo = await getRepository();
  const featured = await repo.getFeatured();
  return <WeekView featured={featured} />;
}
