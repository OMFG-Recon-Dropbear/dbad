"use client";

import type * as React from "react";

import { usePathname } from "next/navigation";
import type { Viewer } from "@/lib/data/repository";
import type { AdminCounts } from "@/lib/loaders/admin";
import { ADMIN_SECTIONS, AdminShell, type AdminSection } from "./admin-shell";

/** Derives the active admin section from the URL so the Next layout can wrap every admin page once. */
export function AdminSectionProvider({ viewer, counts, children }: { viewer: Viewer; counts: AdminCounts; children: React.ReactNode }) {
  const pathname = usePathname();
  const match = [...ADMIN_SECTIONS].sort((a, b) => b.href.length - a.href.length).find((s) => pathname === s.href || pathname.startsWith(s.href + "/"));
  const section: AdminSection = match?.id ?? "dashboard";
  return (
    <AdminShell viewer={viewer} section={section} counts={counts}>
      {children}
    </AdminShell>
  );
}
