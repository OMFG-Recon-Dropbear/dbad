"use client";

import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { AdminActions } from "@/lib/actions/types";
import type { ModerationCommand, Viewer } from "@/lib/data/repository";
import type {
  AppealAction,
  AppealStatus,
  Comment,
  ModerationActionKind,
  ModerationStatus,
  ReportReason,
  ReportStatus,
} from "@/lib/domain/types";
import { scanText } from "@/lib/domain/pii";
import { cn } from "@/lib/utils";
import { Wordmark } from "@/components/brand/wordmark";
import { Avatar } from "@/components/brand/avatar";
import { Badge, Meta } from "@/components/ui/badge";
import { useToast } from "@/components/ui/toast";
import {
  CameraIcon,
  ClockIcon,
  FilterIcon,
  FlagIcon,
  GridIcon,
  ListIcon,
  MegaphoneIcon,
  PrintIcon,
  ShieldIcon,
  UserIcon,
  WarningIcon,
} from "@/components/icons/ui";

/**
 * The moderation console chrome, plus the small kit of pieces every admin view shares.
 *
 * Denser than the public site — moderators are working, not browsing — but the same
 * rules apply: hard black borders, offset shadows, warning yellow, and it has to work
 * one-handed on a phone at 390px because that is where half the moderating happens.
 */

export type AdminSection =
  | "dashboard"
  | "queue"
  | "reports"
  | "appeals"
  | "comments"
  | "nominations"
  | "members"
  | "categories"
  | "templates"
  | "audit";

type IconType = (p: React.SVGProps<SVGSVGElement>) => React.JSX.Element;

export const ADMIN_SECTIONS: Array<{ id: AdminSection; label: string; href: string; short: string; Icon: IconType }> = [
  { id: "dashboard", label: "Dashboard", short: "Dash", href: "/admin", Icon: GridIcon },
  { id: "queue", label: "Queue", short: "Queue", href: "/admin/queue", Icon: ClockIcon },
  { id: "reports", label: "Reports", short: "Reports", href: "/admin/reports", Icon: FlagIcon },
  { id: "appeals", label: "Appeals", short: "Appeals", href: "/admin/appeals", Icon: MegaphoneIcon },
  { id: "comments", label: "Comments", short: "Comments", href: "/admin/comments", Icon: ListIcon },
  { id: "nominations", label: "Nominations", short: "Noms", href: "/admin/nominations", Icon: CameraIcon },
  { id: "members", label: "Members", short: "Members", href: "/admin/members", Icon: UserIcon },
  { id: "categories", label: "Categories", short: "Cats", href: "/admin/categories", Icon: FilterIcon },
  { id: "templates", label: "Notice templates", short: "Notices", href: "/admin/templates", Icon: PrintIcon },
  { id: "audit", label: "Audit log", short: "Audit", href: "/admin/audit", Icon: ShieldIcon },
];

export function AdminShell({
  viewer,
  section,
  counts,
  children,
}: {
  viewer: Viewer;
  section: AdminSection;
  counts?: Partial<Record<AdminSection, number>>;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-paper-100 min-h-[70vh]">
      {/* ------------------------------------------------------------ header strip */}
      <div className="concrete text-paper-50 border-b-[3px] border-ink-950">
        <div className="mx-auto flex w-full max-w-[100rem] items-center gap-3 px-4 py-3 sm:px-5">
          <Link href="/admin" className="flex shrink-0 items-center gap-2.5" aria-label="DBAD moderation home">
            <Wordmark className="h-5 w-auto text-warning-500 sm:h-6" />
            <span className="border-l-2 border-paper-50/25 pl-2.5 font-display text-base uppercase leading-none sm:text-lg">
              Moderation
            </span>
          </Link>
          <span className="ml-auto flex items-center gap-2 sm:gap-3">
            <span className="hidden text-right leading-tight sm:block">
              <span className="block font-semibold text-sm">{viewer.handle}</span>
              <Meta className="text-paper-50/60">{ROLE_LABEL[viewer.role]}</Meta>
            </span>
            <Badge tone={viewer.role === "admin" ? "yellow" : "outline-light"} size="sm" className="sm:hidden">
              {ROLE_LABEL[viewer.role]}
            </Badge>
            <Avatar seed={viewer.handle} size={34} className="border-2 border-paper-50" />
          </span>
        </div>
      </div>

      <div className="mx-auto flex w-full max-w-[100rem]">
        {/* ---------------------------------------------------------- sidebar (desktop) */}
        <aside className="hidden w-[14.5rem] shrink-0 border-r-[3px] border-ink-950 bg-ink-950 text-paper-50 lg:block xl:w-[16rem]">
          <div className="sticky top-24 p-3">
            <p className="px-2 pb-2 font-mono text-[11px] uppercase tracking-[0.2em] text-paper-50/45">Sections</p>
            <nav aria-label="Moderation sections">
              <ul className="space-y-1">
                {ADMIN_SECTIONS.map((s) => (
                  <li key={s.id}>
                    <SidebarLink item={s} active={s.id === section} count={counts?.[s.id]} />
                  </li>
                ))}
              </ul>
            </nav>
            <div className="mt-4 border-t-2 border-paper-50/15 px-2 pt-3">
              <Link
                href="/feed"
                className="font-mono text-[11px] uppercase tracking-wider text-paper-50/60 underline decoration-warning-500 decoration-2 underline-offset-2 hover:text-warning-500"
              >
                Back to the public site
              </Link>
            </div>
          </div>
        </aside>

        <div className="min-w-0 flex-1">
          {/* -------------------------------------------------------- tabs (mobile) */}
          <nav
            aria-label="Moderation sections"
            className="flex gap-1.5 overflow-x-auto scrollbar-none border-b-[3px] border-ink-950 bg-ink-950 px-3 py-2 lg:hidden"
          >
            {ADMIN_SECTIONS.map((s) => {
              const active = s.id === section;
              const count = counts?.[s.id];
              return (
                <Link
                  key={s.id}
                  href={s.href}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "inline-flex shrink-0 items-center gap-1.5 rounded-xs border-2 px-2.5 py-1.5 font-display text-sm uppercase leading-none",
                    active
                      ? "border-warning-500 bg-warning-500 text-ink-950"
                      : "border-paper-50/25 text-paper-50/80 hover:border-paper-50 hover:text-paper-50",
                  )}
                >
                  <s.Icon className="size-4" />
                  {s.short}
                  {typeof count === "number" && count > 0 && (
                    <span className={cn("font-mono text-[10px] tabular", active ? "text-ink-950/70" : "text-warning-500")}>{count}</span>
                  )}
                </Link>
              );
            })}
          </nav>

          <div className="px-4 pb-28 pt-5 sm:px-5 sm:pt-6 lg:pb-12">{children}</div>
        </div>
      </div>
    </div>
  );
}

const ROLE_LABEL: Record<Viewer["role"], string> = { member: "Member", moderator: "Moderator", admin: "Admin" };

function SidebarLink({
  item,
  active,
  count,
}: {
  item: { id: AdminSection; label: string; href: string; Icon: IconType };
  active: boolean;
  count?: number;
}) {
  return (
    <Link
      href={item.href}
      aria-current={active ? "page" : undefined}
      className={cn(
        "flex items-center gap-2.5 border-2 px-2.5 py-2 font-display text-[15px] uppercase leading-none tracking-wide transition-colors",
        active
          ? "border-paper-50 bg-warning-500 text-ink-950"
          : "border-transparent text-paper-50/80 hover:border-paper-50/30 hover:bg-ink-900 hover:text-warning-500",
      )}
    >
      <item.Icon className="size-4 shrink-0" />
      <span className="min-w-0 flex-1 truncate">{item.label}</span>
      {typeof count === "number" && (
        <span
          className={cn(
            "shrink-0 rounded-xs border px-1.5 py-0.5 font-mono text-[10px] leading-none tabular",
            active ? "border-ink-950 bg-ink-950 text-warning-500" : "border-paper-50/25 text-paper-50/70",
          )}
        >
          {count}
        </span>
      )}
    </Link>
  );
}

// ---------------------------------------------------------------------------
// Shared admin kit
// ---------------------------------------------------------------------------

/** Page heading inside the console: big title, mono kicker, optional right-hand slot. */
export function AdminHead({
  kicker,
  title,
  intro,
  action,
  children,
}: {
  kicker?: string;
  title: React.ReactNode;
  intro?: React.ReactNode;
  action?: React.ReactNode;
  children?: React.ReactNode;
}) {
  return (
    <header className="mb-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          {kicker && <p className="mb-1.5 font-mono text-[11px] uppercase tracking-[0.2em] text-concrete-600">{kicker}</p>}
          <h1 className="text-3xl sm:text-4xl">{title}</h1>
        </div>
        {action && <div className="shrink-0">{action}</div>}
      </div>
      {intro && <p className="mt-2 max-w-3xl text-sm leading-snug text-ink-700 sm:text-base">{intro}</p>}
      {children && <div className="mt-4">{children}</div>}
      <div className="hazard-thin mt-4 h-1.5" aria-hidden />
    </header>
  );
}

/** Bordered admin panel with a dark title bar. */
export function Panel({
  title,
  kicker,
  action,
  className,
  bodyClassName,
  children,
}: {
  title: React.ReactNode;
  kicker?: string;
  action?: React.ReactNode;
  className?: string;
  /** Replaces the default body padding when given (e.g. `"p-0"` for a flush list). */
  bodyClassName?: string;
  children: React.ReactNode;
}) {
  return (
    <section className={cn("border-[3px] border-ink-950 bg-paper-50 shadow-hard", className)}>
      <div className="flex flex-wrap items-center justify-between gap-2 border-b-[3px] border-ink-950 bg-ink-950 px-3 py-2 text-paper-50">
        <div className="min-w-0">
          <h2 className="font-display text-lg uppercase leading-none text-paper-50 sm:text-xl">{title}</h2>
          {kicker && <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.18em] text-paper-50/55">{kicker}</p>}
        </div>
        {action && <div className="shrink-0">{action}</div>}
      </div>
      <div className={bodyClassName ?? "p-3 sm:p-4"}>{children}</div>
    </section>
  );
}

const TILE_TONE = {
  paper: "bg-paper-50",
  yellow: "bg-warning-500",
  red: "bg-alert-500 text-paper-50",
  green: "bg-redeem-500 text-paper-50",
  ink: "bg-ink-950 text-paper-50",
} as const;

/** Big number tile. Optionally a link when there is somewhere to act. */
export function StatTile({
  label,
  value,
  hint,
  tone = "paper",
  href,
}: {
  label: string;
  value: number;
  hint?: string;
  tone?: keyof typeof TILE_TONE;
  href?: string;
}) {
  const body = (
    <>
      <p className="font-display text-4xl leading-none tabular sm:text-5xl">{value}</p>
      <p className="mt-1.5 font-display text-[13px] uppercase leading-tight tracking-wide sm:text-sm">{label}</p>
      {hint && (
        <p className={cn("mt-1 font-mono text-[10px] uppercase tracking-wider", tone === "paper" || tone === "yellow" ? "text-concrete-600" : "text-paper-50/65")}>
          {hint}
        </p>
      )}
    </>
  );
  const className = cn(
    "block border-[3px] border-ink-950 p-3 shadow-hard-sm",
    TILE_TONE[tone],
    href && "transition-transform hover:-translate-y-0.5 hover:shadow-hard",
  );
  return href ? (
    <Link href={href} className={className}>
      {body}
    </Link>
  ) : (
    <div className={className}>{body}</div>
  );
}

/** Distribution bars, same language as the Dick-o-meter's vote breakdown. */
export function BarList({
  items,
  emptyLabel = "Nothing to chart yet.",
  barClassName = "bg-warning-500",
}: {
  items: Array<{ key: string; label: React.ReactNode; value: number }>;
  emptyLabel?: string;
  barClassName?: string;
}) {
  const max = items.reduce((m, i) => Math.max(m, i.value), 0);
  if (items.length === 0) return <p className="text-sm text-concrete-600">{emptyLabel}</p>;
  return (
    <ul className="space-y-2">
      {items.map((i) => (
        <li key={i.key} className="flex items-center gap-2 text-sm">
          <span className="w-28 shrink-0 truncate font-semibold sm:w-40">{i.label}</span>
          <span className="h-3 flex-1 border border-ink-950/30 bg-concrete-200">
            <span className={cn("block h-full", barClassName)} style={{ width: `${max > 0 ? Math.round((i.value / max) * 100) : 0}%` }} />
          </span>
          <span className="w-7 text-right font-mono text-xs tabular">{i.value}</span>
        </li>
      ))}
    </ul>
  );
}

/** Runs a set of texts past the PII scanner and reports what a moderator should look at. */
export function PiiScan({ fields, className }: { fields: Array<{ label: string; text: string }>; className?: string }) {
  const findings = fields.flatMap((f) =>
    scanText(f.text).findings.map((finding) => ({ ...finding, field: f.label, id: `${f.label}:${finding.start}:${finding.kind}` })),
  );
  if (findings.length === 0) {
    return (
      <p className={cn("flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-redeem-700", className)}>
        <ShieldIcon className="size-4" /> PII scan clear
      </p>
    );
  }
  return (
    <div className={cn("border-2 border-alert-500 bg-paper-100 p-2.5", className)}>
      <p className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-wider text-alert-600">
        <WarningIcon className="size-4" /> PII scan · {findings.length} finding{findings.length === 1 ? "" : "s"}
      </p>
      <ul className="mt-1.5 space-y-1">
        {findings.map((f) => (
          <li key={f.id} className="text-[13px] leading-snug">
            <Badge tone={f.severity === "block" ? "red" : f.severity === "warn" ? "yellow" : "concrete"} size="sm" className="mr-1.5 align-[1px]">
              {f.severity}
            </Badge>
            <span className="font-mono text-xs uppercase tracking-wider text-concrete-600">{f.field}</span>{" "}
            <span className="font-semibold">&ldquo;{f.match}&rdquo;</span> — {f.message}
          </li>
        ))}
      </ul>
    </div>
  );
}

/** Renders text with anything the PII scanner flagged marked up in place. */
export function HighlightedText({ text, className }: { text: string; className?: string }) {
  const findings = scanText(text).findings;
  if (findings.length === 0) return <p className={className}>{text}</p>;
  const parts: React.ReactNode[] = [];
  let cursor = 0;
  findings.forEach((f, i) => {
    if (f.start > cursor) parts.push(text.slice(cursor, f.start));
    parts.push(
      <mark
        key={`${f.start}-${i}`}
        title={f.message}
        className={cn(
          "px-0.5 font-semibold",
          f.severity === "block" ? "bg-alert-500 text-paper-50" : f.severity === "warn" ? "bg-warning-500 text-ink-950" : "bg-concrete-200 text-ink-950",
        )}
      >
        {text.slice(f.start, f.end)}
      </mark>,
    );
    cursor = f.end;
  });
  if (cursor < text.length) parts.push(text.slice(cursor));
  return <p className={className}>{parts}</p>;
}

/** Stamp-like badge for an audited moderation action. */
export function ActionBadge({ action }: { action: ModerationActionKind }) {
  return (
    <span
      className={cn(
        "inline-block rounded-xs border-2 border-current px-1.5 py-1 font-display text-[11px] uppercase leading-none tracking-[0.05em]",
        ACTION_TONE[action],
      )}
    >
      {MODERATION_ACTION_LABEL[action]}
    </span>
  );
}

// ---------------------------------------------------------------------------
// Labels
// ---------------------------------------------------------------------------

export const MODERATION_ACTION_LABEL: Record<ModerationActionKind, string> = {
  approve: "Approved",
  reject: "Rejected",
  remove: "Removed",
  restore: "Restored",
  anonymise: "Anonymised",
  redact_photo: "Photo removed",
  mark_redeemed: "Redeemed",
  mark_overruled: "Overruled",
  feature_week: "Featured",
  unfeature: "Unfeatured",
  hide_comment: "Comment hidden",
  restore_comment: "Comment restored",
  resolve_report: "Report resolved",
  dismiss_report: "Report dismissed",
  action_appeal: "Appeal actioned",
  decline_appeal: "Appeal declined",
  publish_reply: "Reply published",
  change_role: "Role changed",
  edit_category: "Category edited",
  edit_template: "Template edited",
};

const ACTION_TONE: Record<ModerationActionKind, string> = {
  approve: "text-redeem-600",
  reject: "text-alert-500",
  remove: "text-alert-500",
  restore: "text-redeem-600",
  anonymise: "text-ink-950",
  redact_photo: "text-ink-950",
  mark_redeemed: "text-redeem-600",
  mark_overruled: "text-concrete-500",
  feature_week: "text-warning-700",
  unfeature: "text-concrete-500",
  hide_comment: "text-alert-500",
  restore_comment: "text-redeem-600",
  resolve_report: "text-redeem-600",
  dismiss_report: "text-concrete-500",
  action_appeal: "text-warning-700",
  decline_appeal: "text-concrete-500",
  publish_reply: "text-warning-700",
  change_role: "text-ink-950",
  edit_category: "text-ink-950",
  edit_template: "text-ink-950",
};

export const REPORT_REASON_LABEL: Record<ReportReason, string> = {
  identifies_person: "Identifies a person",
  private_address: "Private address",
  harassment: "Harassment",
  defamatory: "Defamatory",
  children: "Involves children",
  not_a_dick_move: "Not a dick move",
  duplicate: "Duplicate",
  spam: "Spam",
  other: "Other",
};

/** Reports that touch a real person come first. */
export const REPORT_REASON_TONE: Record<ReportReason, "red" | "yellow" | "concrete"> = {
  identifies_person: "red",
  private_address: "red",
  harassment: "red",
  children: "red",
  defamatory: "yellow",
  not_a_dick_move: "yellow",
  duplicate: "concrete",
  spam: "concrete",
  other: "concrete",
};

export const REPORT_STATUS_LABEL: Record<ReportStatus, string> = {
  open: "Open",
  reviewing: "Reviewing",
  resolved: "Resolved",
  dismissed: "Dismissed",
};

export const APPEAL_ACTION_LABEL: Record<AppealAction, string> = {
  removal: "Remove the post",
  correction: "Correct a detail",
  anonymisation: "Anonymise it",
  context: "Add context",
  reply: "Right of reply",
  redemption: "Mark it redeemed",
};

export const APPEAL_STATUS_LABEL: Record<AppealStatus, string> = {
  open: "Open",
  in_review: "In review",
  actioned: "Actioned",
  declined: "Declined",
};

export const MODERATION_STATUS_LABEL: Record<ModerationStatus, string> = {
  pending: "Pending",
  approved: "Approved",
  rejected: "Rejected",
  removed: "Removed",
};

export const MODERATION_STATUS_TONE: Record<ModerationStatus, "yellow" | "green" | "red" | "concrete"> = {
  pending: "yellow",
  approved: "green",
  rejected: "red",
  removed: "concrete",
};

export const COMMENT_STATUS_LABEL: Record<Comment["status"], string> = {
  visible: "Visible",
  hidden: "Hidden",
  removed: "Removed",
};

// ---------------------------------------------------------------------------
// Moderation runner
// ---------------------------------------------------------------------------

export interface ModerateRun {
  /** Identifies the button that is busy, so only that one shows a spinner state. */
  key: string;
  command: ModerationCommand;
  success: string;
  detail?: string;
  tone?: "yellow" | "green" | "red" | "ink";
  /** Applied before the round-trip so the console feels instant. */
  optimistic?: () => void;
  /** Undo of `optimistic`, applied when the command is refused. */
  rollback?: () => void;
}

/**
 * One place for "run a moderation command": optimistic local update, toast, and a
 * router refresh so the server-rendered counts catch up.
 */
export function useModerate(actions: AdminActions) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = React.useState<string | null>(null);

  const run = React.useCallback(
    async (o: ModerateRun): Promise<boolean> => {
      setBusy(o.key);
      o.optimistic?.();
      const res = await actions.moderate(o.command);
      setBusy(null);
      if (res.ok) {
        toast.push({ tone: o.tone ?? "yellow", title: o.success, body: o.detail });
        router.refresh();
        return true;
      }
      o.rollback?.();
      toast.push({ tone: "red", title: "Not done", body: res.message ?? "That didn't stick. Try again." });
      return false;
    },
    [actions, router, toast],
  );

  return { busy, run };
}
