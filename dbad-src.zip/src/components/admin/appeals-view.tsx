"use client";

import * as React from "react";
import type { AdminActions } from "@/lib/actions/types";
import type { AppealWithIncident, ModerationCommand, Viewer } from "@/lib/data/repository";
import type { AppealsProps } from "@/lib/loaders/admin";
import type { AppealStatus } from "@/lib/domain/types";
import { relativeTime } from "@/lib/domain/time";
import { AdminHead, APPEAL_ACTION_LABEL, APPEAL_STATUS_LABEL, useModerate } from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { Help, Label, Textarea } from "@/components/ui/input";
import { LinkTabs } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/toast";
import { IncidentRow } from "@/components/incident/incident-card";
import { CodePlate } from "@/components/brand/hazard";
import { EyeIcon, EyeOffIcon } from "@/components/icons/ui";

const TABS: Array<{ value: string; label: string }> = [
  { value: "", label: "All" },
  { value: "open", label: "Open" },
  { value: "in_review", label: "In review" },
  { value: "actioned", label: "Actioned" },
  { value: "declined", label: "Declined" },
];

const STATUS_TONE: Record<AppealStatus, "red" | "yellow" | "green" | "concrete"> = {
  open: "red",
  in_review: "yellow",
  actioned: "green",
  declined: "concrete",
};

/** What actioning an appeal does to the nomination itself, beyond closing the appeal. */
const SIDE_EFFECT: Record<AppealWithIncident["requestedAction"], string> = {
  removal: "The nomination is removed from the public site.",
  correction: "Nothing changes automatically — fix the wording from Nominations.",
  anonymisation: "The nomination is anonymised: submitter dropped, exact place dropped.",
  context: "Your reply is published beneath the nomination.",
  reply: "Your reply is published beneath the nomination.",
  redemption: "The nomination is stamped REDEEMED.",
};

const WANTS_PUBLIC_REPLY: Array<AppealWithIncident["requestedAction"]> = ["reply", "context", "redemption"];

type DialogMode = { kind: "action" | "decline"; appeal: AppealWithIncident } | null;

/**
 * "Is this about you?" requests. These come from the person the nomination is about, so
 * the private contact stays behind a deliberate reveal and never renders by default.
 */
export function AppealsView({ appeals, status, viewer, actions }: AppealsProps & { viewer: Viewer; actions: AdminActions }) {
  const { busy, run } = useModerate(actions);
  const toast = useToast();
  const [rows, setRows] = React.useState(appeals);
  const [revealed, setRevealed] = React.useState<string[]>([]);
  const [dialog, setDialog] = React.useState<DialogMode>(null);
  const canSeeContact = viewer.role !== "member";

  const settle = (appeal: AppealWithIncident, next: AppealStatus, publicReply?: string) =>
    setRows((list) =>
      status && status !== next
        ? list.filter((a) => a.id !== appeal.id)
        : list.map((a) => (a.id === appeal.id ? { ...a, status: next, publicReply: publicReply || a.publicReply } : a)),
    );
  const undo = (appeal: AppealWithIncident) =>
    setRows((list) => (list.some((a) => a.id === appeal.id) ? list.map((a) => (a.id === appeal.id ? appeal : a)) : [appeal, ...list]));

  function sideCommand(a: AppealWithIncident, reply: string): ModerationCommand | null {
    switch (a.requestedAction) {
      case "removal":
        return { action: "remove", targetType: "incident", targetId: a.incidentId, note: `Appeal ${reference(a.id)}: removal requested.` };
      case "anonymisation":
        return { action: "anonymise", targetType: "incident", targetId: a.incidentId, note: `Appeal ${reference(a.id)}: anonymisation requested.` };
      case "redemption":
        return {
          action: "mark_redeemed",
          targetType: "incident",
          targetId: a.incidentId,
          note: `Appeal ${reference(a.id)}: redemption confirmed.`,
          payload: { note: reply || "Sorted after a word from the person involved." },
        };
      default:
        return null;
    }
  }

  async function submitAction(a: AppealWithIncident, reply: string) {
    const side = sideCommand(a, reply);
    if (side) {
      const res = await actions.moderate(side);
      if (!res.ok) {
        toast.push({ tone: "red", title: "Nomination not updated", body: res.message ?? "The appeal has been left open." });
        return;
      }
    }
    const ok = await run({
      key: `action:${a.id}`,
      command: {
        action: "action_appeal",
        targetType: "appeal",
        targetId: a.id,
        note: `${APPEAL_ACTION_LABEL[a.requestedAction]} — actioned.`,
        ...(reply ? { payload: { publicReply: reply } } : {}),
      },
      success: "Appeal actioned",
      detail: SIDE_EFFECT[a.requestedAction],
      tone: "green",
      optimistic: () => settle(a, "actioned", reply),
      rollback: () => undo(a),
    });
    if (ok) setDialog(null);
  }

  return (
    <>
      <AdminHead
        kicker={`${rows.length} shown`}
        title={<>Is this about you?</>}
        intro="Requests from the person a nomination is about. Read it properly — most of these are someone having a rough day, and a right of reply usually settles it."
      >
        <LinkTabs
          size="sm"
          className="!mx-0 !px-0"
          current={status ?? ""}
          items={TABS.map((t) => ({ ...t, href: t.value ? `/admin/appeals?status=${t.value}` : "/admin/appeals" }))}
        />
      </AdminHead>

      {rows.length === 0 ? (
        <EmptyState
          stamp="NO APPEALS"
          title="Nobody wants un-DBAD'ing today."
          body="When someone recognises themselves in a nomination, their request lands here. Until then, enjoy the quiet."
          action={{ href: "/admin/appeals", label: "Show all appeals" }}
        />
      ) : (
        <ul className="space-y-4">
          {rows.map((a) => {
            const settled = a.status === "actioned" || a.status === "declined";
            const isRevealed = revealed.includes(a.id);
            return (
              <li key={a.id} className="border-[3px] border-ink-950 bg-paper-50 shadow-hard">
                <div className="flex flex-wrap items-center gap-2 border-b-[3px] border-ink-950 bg-paper-100 px-3 py-2">
                  <Badge tone="yellow" size="sm">
                    {APPEAL_ACTION_LABEL[a.requestedAction]}
                  </Badge>
                  <Badge tone={STATUS_TONE[a.status]} size="sm">
                    {APPEAL_STATUS_LABEL[a.status]}
                  </Badge>
                  <CodePlate code={reference(a.id)} size="sm" />
                  <Meta className="ml-auto">{relativeTime(a.createdAt)}</Meta>
                </div>

                <div className="space-y-3 p-3 sm:p-4">
                  <blockquote className="border-l-[6px] border-warning-500 pl-3 text-sm leading-snug">{a.message}</blockquote>

                  {/* private contact — never rendered without a deliberate reveal */}
                  <div className="flex flex-wrap items-center gap-2 border-2 border-dashed border-concrete-400 bg-paper-100 px-2.5 py-2">
                    <Meta>Private contact</Meta>
                    {!canSeeContact ? (
                      <span className="text-sm text-concrete-600">Moderators only.</span>
                    ) : !a.contact ? (
                      <span className="text-sm text-concrete-600">None given.</span>
                    ) : isRevealed ? (
                      <span className="text-sm font-semibold">{a.contact}</span>
                    ) : (
                      <span className="text-sm text-concrete-600">Hidden. Only open it if you intend to reply.</span>
                    )}
                    {canSeeContact && a.contact && (
                      <Button
                        variant="paper"
                        size="sm"
                        className="ml-auto"
                        aria-pressed={isRevealed}
                        aria-label={isRevealed ? `Hide private contact for appeal ${reference(a.id)}` : `Reveal private contact for appeal ${reference(a.id)}`}
                        onClick={() => setRevealed((list) => (isRevealed ? list.filter((id) => id !== a.id) : [...list, a.id]))}
                      >
                        {isRevealed ? <EyeOffIcon className="size-4" /> : <EyeIcon className="size-4" />}
                        {isRevealed ? "Hide" : "Reveal"}
                      </Button>
                    )}
                  </div>

                  {a.publicReply && (
                    <div className="border-2 border-ink-950 bg-warning-500 p-2.5">
                      <Meta className="text-ink-950/70">Published right of reply</Meta>
                      <p className="text-sm leading-snug">{a.publicReply}</p>
                    </div>
                  )}

                  <div>
                    <p className="mb-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">The nomination</p>
                    <IncidentRow incident={a.incident} />
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 border-t-[3px] border-ink-950 bg-paper-100 px-3 py-2.5">
                  <Button
                    variant="primary"
                    size="sm"
                    aria-label={`Action appeal ${reference(a.id)}: ${APPEAL_ACTION_LABEL[a.requestedAction]}`}
                    disabled={settled || busy === `action:${a.id}`}
                    onClick={() => setDialog({ kind: "action", appeal: a })}
                  >
                    Action appeal
                  </Button>
                  <Button
                    variant="paper"
                    size="sm"
                    aria-label={`Decline appeal ${reference(a.id)}`}
                    disabled={settled || busy === `decline:${a.id}`}
                    onClick={() => setDialog({ kind: "decline", appeal: a })}
                  >
                    Decline
                  </Button>
                  <Meta className="ml-auto max-w-full">{SIDE_EFFECT[a.requestedAction]}</Meta>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <Dialog open={dialog?.kind === "action"} onClose={() => setDialog(null)} title="Action appeal" size="sm">
        {dialog?.kind === "action" && (
          <AppealForm
            appeal={dialog.appeal}
            submitLabel="Action appeal"
            variant="primary"
            withReply={WANTS_PUBLIC_REPLY.includes(dialog.appeal.requestedAction)}
            onSubmit={(reply) => submitAction(dialog.appeal, reply)}
          />
        )}
      </Dialog>

      <Dialog open={dialog?.kind === "decline"} onClose={() => setDialog(null)} title="Decline appeal" size="sm">
        {dialog?.kind === "decline" && (
          <AppealForm
            appeal={dialog.appeal}
            submitLabel="Decline appeal"
            variant="alert"
            requireNote
            noteLabel="Why it's being declined"
            onSubmit={async (note) => {
              const a = dialog.appeal;
              const ok = await run({
                key: `decline:${a.id}`,
                command: { action: "decline_appeal", targetType: "appeal", targetId: a.id, note },
                success: "Appeal declined",
                detail: "Logged with your reason.",
                optimistic: () => settle(a, "declined"),
                rollback: () => undo(a),
              });
              if (ok) setDialog(null);
            }}
          />
        )}
      </Dialog>
    </>
  );
}

function AppealForm({
  appeal,
  submitLabel,
  variant,
  withReply,
  requireNote,
  noteLabel,
  onSubmit,
}: {
  appeal: AppealWithIncident;
  submitLabel: string;
  variant: "primary" | "alert";
  withReply?: boolean;
  requireNote?: boolean;
  noteLabel?: string;
  onSubmit: (text: string) => Promise<void>;
}) {
  const id = React.useId();
  const [text, setText] = React.useState(appeal.publicReply ?? "");
  const [saving, setSaving] = React.useState(false);
  const showField = withReply || requireNote;
  const disabled = saving || (requireNote && text.trim().length < 4);
  return (
    <form
      className="space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        if (disabled) return;
        setSaving(true);
        await onSubmit(text.trim());
        setSaving(false);
      }}
    >
      <div className="border-2 border-ink-950 bg-paper-100 p-2.5">
        <Meta>They asked for</Meta>
        <p className="font-display text-xl uppercase leading-none">{APPEAL_ACTION_LABEL[appeal.requestedAction]}</p>
        <p className="mt-1.5 text-sm leading-snug text-ink-700">{SIDE_EFFECT[appeal.requestedAction]}</p>
      </div>

      {showField && (
        <div>
          <Label htmlFor={id} hint={requireNote ? undefined : "Published under the nomination, credited to the person involved."}>
            {noteLabel ?? "Public reply (optional)"}
          </Label>
          <Textarea
            id={id}
            rows={4}
            maxLength={600}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={requireNote ? "It doesn't identify anyone and the nomination is accurate." : "Fair cop. Came back and moved it as soon as I saw the notice."}
          />
          {!requireNote && <Help>Leave it blank to close the appeal without publishing anything.</Help>}
        </div>
      )}

      <div className="flex justify-end">
        <Button type="submit" variant={variant} disabled={disabled}>
          {saving ? "Saving…" : submitLabel}
        </Button>
      </div>
    </form>
  );
}

function reference(id: string): string {
  return id.slice(-8).toUpperCase();
}
