"use client";

import * as React from "react";
import type { AdminActions } from "@/lib/actions/types";
import type { Viewer } from "@/lib/data/repository";
import type { AuditProps } from "@/lib/loaders/admin";
import { formatDateTimeAU, relativeTime } from "@/lib/domain/time";
import { ActionBadge, AdminHead } from "./admin-shell";
import { Meta } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { Avatar } from "@/components/brand/avatar";
import { CodePlate } from "@/components/brand/hazard";

/**
 * The audit log. Every moderator action, who did it, and what they said about it.
 * Nobody moderates DBAD anonymously — that's rather the point.
 */
export function AuditView({ audit, viewer, actions }: AuditProps & { viewer: Viewer; actions: AdminActions }) {
  void viewer;
  void actions;

  return (
    <>
      <AdminHead
        kicker={`${audit.length} entries`}
        title="Audit log"
        intro="Every moderation action, newest first. Attached to a handle, kept forever, and the first thing we'd show anyone who asked how a decision got made."
      />

      {audit.length === 0 ? (
        <EmptyState
          stamp="NO HISTORY"
          title="Nobody has moderated anything."
          body="Either the queue has never had anything in it, or this is a very fresh install."
          action={{ href: "/admin/queue", label: "Open the queue" }}
        />
      ) : (
        <ol className="border-[3px] border-ink-950 bg-paper-50 shadow-hard divide-y-2 divide-concrete-300">
          {audit.map((entry) => (
            <li key={entry.id} className="flex gap-3 p-3">
              <Avatar seed={entry.actor.handle} size={32} className="mt-0.5 shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-x-2 gap-y-1.5">
                  <span className="font-semibold">{entry.actor.handle}</span>
                  <ActionBadge action={entry.action} />
                  <CodePlate code={`${entry.targetType}:${entry.targetId}`} size="sm" className="max-w-full truncate" />
                  <Meta className="ml-auto whitespace-nowrap" title={formatDateTimeAU(entry.createdAt)}>
                    {relativeTime(entry.createdAt)}
                  </Meta>
                </div>
                {entry.note ? (
                  <p className="mt-1 text-sm leading-snug text-ink-700">&ldquo;{entry.note}&rdquo;</p>
                ) : (
                  <Meta className="mt-1 block">No note left</Meta>
                )}
              </div>
            </li>
          ))}
        </ol>
      )}
    </>
  );
}
