"use client";

import * as React from "react";
import type { AdminActions } from "@/lib/actions/types";
import type { Viewer } from "@/lib/data/repository";
import type { Category } from "@/lib/domain/types";
import { CATEGORIES } from "@/lib/domain/categories";
import { AdminHead, useModerate } from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { CategoryIcon } from "@/components/icons/categories";
import { InfoIcon } from "@/components/icons/ui";

/**
 * The nine categories, as editable copy. The wizard, the chips and the notices all read
 * from here, so the caution lines are the guard-rails people actually see.
 */
export function CategoriesView({ viewer, actions }: { viewer: Viewer; actions: AdminActions }) {
  void viewer;
  const { busy, run } = useModerate(actions);

  return (
    <>
      <AdminHead
        kicker={`${CATEGORIES.length} categories`}
        title="Categories"
        intro="Loud label for the notice, short label for the chips, a blurb for the wizard, and a caution where the category needs a guard-rail."
      />

      <p className="mb-4 flex items-start gap-2.5 border-[3px] border-ink-950 bg-warning-500 p-3 text-sm leading-snug shadow-hard-sm">
        <InfoIcon className="mt-0.5 size-5 shrink-0" />
        <span>
          <strong>Demo mode.</strong> Edits are validated and written to the audit log, but the shipped copy is what renders — category text
          lives in configuration, not the demo store. On Supabase this saves for real.
        </span>
      </p>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {CATEGORIES.map((c) => (
          <CategoryCard
            key={c.id}
            category={c}
            busy={busy === `cat:${c.id}`}
            onSave={(payload) =>
              run({
                key: `cat:${c.id}`,
                command: { action: "edit_category", targetType: "category", targetId: c.id, payload, note: `Edited ${c.id} copy.` },
                success: "Category saved",
                detail: "Logged. Shipped copy still renders in demo mode.",
              })
            }
          />
        ))}
      </div>
    </>
  );
}

function CategoryCard({
  category,
  busy,
  onSave,
}: {
  category: Category;
  busy: boolean;
  onSave: (payload: Record<string, string>) => Promise<boolean>;
}) {
  const [label, setLabel] = React.useState(category.label);
  const [short, setShort] = React.useState(category.short);
  const [blurb, setBlurb] = React.useState(category.blurb);
  const [caution, setCaution] = React.useState(category.caution ?? "");
  const dirty = label !== category.label || short !== category.short || blurb !== category.blurb || caution !== (category.caution ?? "");

  return (
    <form
      className="flex flex-col border-[3px] border-ink-950 bg-paper-50 shadow-hard"
      onSubmit={async (e) => {
        e.preventDefault();
        if (!dirty || busy) return;
        await onSave({ label, short, blurb, caution });
      }}
    >
      <div className="flex items-center gap-2 border-b-[3px] border-ink-950 bg-ink-950 px-3 py-2 text-paper-50">
        <CategoryIcon id={category.id} className="size-5 shrink-0 text-warning-500" />
        <h2 className="min-w-0 flex-1 truncate font-display text-lg uppercase leading-none">{category.short}</h2>
        <Badge tone="outline-light" size="sm">
          {category.id}
        </Badge>
      </div>

      <div className="grid flex-1 gap-3 p-3">
        <div>
          <Label htmlFor={`cat-label-${category.id}`} className="!mb-1 !text-sm">
            Loud label
          </Label>
          <Input id={`cat-label-${category.id}`} value={label} maxLength={40} onChange={(e) => setLabel(e.target.value)} className="py-2 text-sm" />
        </div>
        <div>
          <Label htmlFor={`cat-short-${category.id}`} className="!mb-1 !text-sm">
            Chip label
          </Label>
          <Input id={`cat-short-${category.id}`} value={short} maxLength={24} onChange={(e) => setShort(e.target.value)} className="py-2 text-sm" />
        </div>
        <div>
          <Label htmlFor={`cat-blurb-${category.id}`} className="!mb-1 !text-sm">
            Blurb
          </Label>
          <Textarea id={`cat-blurb-${category.id}`} rows={3} maxLength={220} value={blurb} onChange={(e) => setBlurb(e.target.value)} className="min-h-0 py-2 text-sm" />
        </div>
        <div>
          <Label htmlFor={`cat-caution-${category.id}`} className="!mb-1 !text-sm">
            Caution
          </Label>
          <Textarea
            id={`cat-caution-${category.id}`}
            rows={2}
            maxLength={180}
            value={caution}
            placeholder="No guard-rail on this one."
            onChange={(e) => setCaution(e.target.value)}
            className="min-h-0 py-2 text-sm"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 border-t-[3px] border-ink-950 bg-paper-100 px-3 py-2">
        <Meta>{dirty ? "Unsaved changes" : "Saved"}</Meta>
        <Button type="submit" variant={dirty ? "dark" : "paper"} size="sm" className="ml-auto" disabled={!dirty || busy}>
          {busy ? "Saving…" : "Save"}
        </Button>
      </div>
    </form>
  );
}
