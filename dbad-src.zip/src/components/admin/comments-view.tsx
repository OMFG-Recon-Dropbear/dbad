"use client";

import * as React from "react";
import Link from "next/link";
import type { AdminActions } from "@/lib/actions/types";
import type { Viewer } from "@/lib/data/repository";
import type { AdminComment, AdminCommentsProps } from "@/lib/loaders/admin";
import type { Comment } from "@/lib/domain/types";
import { relativeTime } from "@/lib/domain/time";
import { scanText } from "@/lib/domain/pii";
import { AdminHead, COMMENT_STATUS_LABEL, HighlightedText, useModerate } from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { LinkTabs } from "@/components/ui/tabs";
import { Avatar } from "@/components/brand/avatar";
import { ExternalIcon, WarningIcon } from "@/components/icons/ui";

const TABS: Array<{ value: string; label: string }> = [
  { value: "", label: "All" },
  { value: "visible", label: "Visible" },
  { value: "hidden", label: "Hidden" },
  { value: "removed", label: "Removed" },
];

const STATUS_TONE: Record<Comment["status"], "green" | "yellow" | "concrete"> = {
  visible: "green",
  hidden: "yellow",
  removed: "concrete",
};

/**
 * Every comment on the site, newest first, with anything the PII scanner objects to
 * marked in the text. Take the piss; don't take it too far.
 */
export function CommentsView({ comments, status, viewer, actions }: AdminCommentsProps & { viewer: Viewer; actions: AdminActions }) {
  void viewer;
  const { busy, run } = useModerate(actions);
  const [rows, setRows] = React.useState(comments);

  const settle = (c: AdminComment, next: Comment["status"]) =>
    setRows((list) => (status && status !== next ? list.filter((x) => x.id !== c.id) : list.map((x) => (x.id === c.id ? { ...x, status: next } : x))));
  const undo = (c: AdminComment) => setRows((list) => (list.some((x) => x.id === c.id) ? list.map((x) => (x.id === c.id ? c : x)) : [c, ...list]));

  const flagged = rows.filter((c) => scanText(c.body).findings.some((f) => f.severity !== "note")).length;

  return (
    <>
      <AdminHead
        kicker={`${rows.length} shown · ${flagged} flagged by the scanner`}
        title="Comments"
        intro="Hidden comments stay in the record but leave the page. Anything that names or locates a person comes down first and gets explained second."
      >
        <LinkTabs
          size="sm"
          className="!mx-0 !px-0"
          current={status ?? ""}
          items={TABS.map((t) => ({ ...t, href: t.value ? `/admin/comments?status=${t.value}` : "/admin/comments" }))}
        />
      </AdminHead>

      {rows.length === 0 ? (
        <EmptyState
          stamp="NO COMMENTS"
          title="Nothing to read here."
          body="No comments match that filter. The community has gone quiet, or you've filtered them all away."
          action={{ href: "/admin/comments", label: "Show all comments" }}
        />
      ) : (
        <ul className="border-[3px] border-ink-950 bg-paper-50 shadow-hard divide-y-2 divide-concrete-300">
          {rows.map((c) => {
            const findings = scanText(c.body).findings.filter((f) => f.severity !== "note");
            return (
              <li key={c.id} className="p-3 sm:p-4">
                <div className="flex gap-3">
                  <Avatar seed={c.author.handle} size={36} className="mt-0.5" />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <span className="font-semibold">{c.author.handle}</span>
                      <Badge tone={STATUS_TONE[c.status]} size="sm">
                        {COMMENT_STATUS_LABEL[c.status]}
                      </Badge>
                      {findings.length > 0 && (
                        <Badge tone="red" size="sm" className="gap-1">
                          <WarningIcon className="size-3.5" /> {findings.length} flag{findings.length === 1 ? "" : "s"}
                        </Badge>
                      )}
                      <Meta className="ml-auto whitespace-nowrap">{relativeTime(c.createdAt)}</Meta>
                    </div>

                    <HighlightedText text={c.body} className="mt-1 text-sm leading-snug" />

                    {findings.length > 0 && (
                      <ul className="mt-1.5 space-y-0.5">
                        {findings.map((f) => (
                          <li key={`${f.start}-${f.kind}`} className="text-[13px] font-semibold leading-snug text-alert-600">
                            &ldquo;{f.match}&rdquo; — {f.message}
                          </li>
                        ))}
                      </ul>
                    )}

                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      {c.incident.slug ? (
                        <Link
                          href={`/moves/${c.incident.slug}#comments`}
                          className="inline-flex max-w-full items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider text-concrete-600 underline decoration-warning-500 decoration-2 underline-offset-2 hover:text-ink-950"
                        >
                          <ExternalIcon className="size-3.5 shrink-0" />
                          <span className="truncate">{c.incident.title}</span>
                        </Link>
                      ) : (
                        <Meta>Parent nomination has gone</Meta>
                      )}

                      <span className="ml-auto flex gap-2">
                        {c.status === "visible" ? (
                          <Button
                            variant="alert"
                            size="sm"
                            aria-label={`Hide the comment by ${c.author.handle}`}
                            disabled={busy === `hide:${c.id}`}
                            onClick={() =>
                              run({
                                key: `hide:${c.id}`,
                                command: { action: "hide_comment", targetType: "comment", targetId: c.id },
                                success: "Comment hidden",
                                detail: "It's off the nomination page.",
                                optimistic: () => settle(c, "hidden"),
                                rollback: () => undo(c),
                              })
                            }
                          >
                            Hide
                          </Button>
                        ) : (
                          <Button
                            variant="redeem"
                            size="sm"
                            aria-label={`Restore the comment by ${c.author.handle}`}
                            disabled={busy === `restore:${c.id}`}
                            onClick={() =>
                              run({
                                key: `restore:${c.id}`,
                                command: { action: "restore_comment", targetType: "comment", targetId: c.id },
                                success: "Comment restored",
                                tone: "green",
                                optimistic: () => settle(c, "visible"),
                                rollback: () => undo(c),
                              })
                            }
                          >
                            Restore
                          </Button>
                        )}
                      </span>
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
