"use client";

import * as React from "react";
import Link from "next/link";
import type { AdminActions } from "@/lib/actions/types";
import type { Viewer } from "@/lib/data/repository";
import type { AdminDashboardProps } from "@/lib/loaders/admin";
import { getCategory } from "@/lib/domain/categories";
import { relativeTime } from "@/lib/domain/time";
import { locationLabel } from "@/components/incident/incident-card";
import {
  ActionBadge,
  AdminHead,
  APPEAL_ACTION_LABEL,
  BarList,
  Panel,
  REPORT_REASON_LABEL,
  REPORT_REASON_TONE,
  StatTile,
  useModerate,
} from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button, ButtonLink } from "@/components/ui/button";
import { Avatar } from "@/components/brand/avatar";
import { CodePlate } from "@/components/brand/hazard";
import { ArrowRightIcon } from "@/components/icons/ui";
import { CategoryIcon } from "@/components/icons/categories";

/**
 * The moderator's front page: what happened, what is waiting, and the two or three
 * buttons that clear it. Everything else is one tap away in the sidebar.
 */
export function DashboardView({
  stats,
  queue,
  reports,
  appeals,
  audit,
  viewer,
  actions,
}: AdminDashboardProps & { viewer: Viewer; actions: AdminActions }) {
  const { busy, run } = useModerate(actions);
  const [pendingQueue, setPendingQueue] = React.useState(queue);
  const [openReports, setOpenReports] = React.useState(reports);
  const [openAppeals] = React.useState(appeals);

  return (
    <>
      <AdminHead
        kicker={`Signed in as ${viewer.handle}`}
        title="Moderation dashboard"
        intro="What the community has been up to, and what is waiting on a human. Clear the queue, keep the noticeboard honest, go outside."
        action={
          <ButtonLink href="/admin/queue" variant="dark" size="sm">
            Open the queue <ArrowRightIcon className="size-4" />
          </ButtonLink>
        }
      />

      {/* ------------------------------------------------------------ numbers */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatTile label="Dick moves today" value={stats.dickMovesToday} hint="last 24 hours" />
        <StatTile label="This week" value={stats.dickMovesThisWeek} hint="last 7 days" />
        <StatTile label="Redemptions" value={stats.redemptions} tone="green" hint="all time" />
        <StatTile label="Pending moderation" value={stats.pendingModeration} tone="yellow" hint="waiting on you" href="/admin/queue" />
        <StatTile label="Reported content" value={stats.reportedContent} tone={stats.reportedContent > 0 ? "red" : "paper"} hint="open + reviewing" href="/admin/reports" />
        <StatTile label="Open appeals" value={stats.openAppeals} tone="yellow" hint="is this about you?" href="/admin/appeals" />
        <StatTile label="Members" value={stats.membersTotal} hint="registered" href="/admin/members" />
        <StatTile label="Not-a-dicks this week" value={stats.notADickThisWeek} tone="green" hint="the balance" />
      </div>

      {/* ------------------------------------------------------------ charts */}
      <div className="mt-5 grid grid-cols-1 items-start gap-4 md:grid-cols-2">
        <Panel title="Most active areas" kicker="Approved dick moves by region">
          <BarList
            items={stats.mostActiveAreas.map((a) => ({ key: a.region, label: a.region, value: a.count }))}
            emptyLabel="No approved nominations yet. Suspiciously well-behaved."
          />
        </Panel>
        <Panel title="Most common categories" kicker="What humanity keeps doing">
          <BarList
            barClassName="bg-alert-500"
            items={stats.mostCommonCategories.map((c) => {
              const cat = getCategory(c.categoryId);
              return {
                key: c.categoryId,
                label: (
                  <span className="inline-flex items-center gap-1.5">
                    <CategoryIcon id={c.categoryId} className="size-4 shrink-0" />
                    {cat.short}
                  </span>
                ),
                value: c.count,
              };
            })}
            emptyLabel="Nothing categorised yet."
          />
        </Panel>
      </div>

      {/* ------------------------------------------------------------ needs attention */}
      <h2 className="mt-7 mb-3 text-2xl">Needs attention</h2>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Panel
          title="Moderation queue"
          kicker={`${stats.pendingModeration} pending`}
          action={
            <Link href="/admin/queue" aria-label="Open the full moderation queue" className="font-mono text-[11px] uppercase tracking-wider text-warning-500 underline decoration-2 underline-offset-2">
              All
            </Link>
          }
          bodyClassName="p-0"
        >
          {pendingQueue.length === 0 ? (
            <PanelEmpty>Queue clear. Humanity is improving. Or asleep.</PanelEmpty>
          ) : (
            <ul className="divide-y-2 divide-concrete-300">
              {pendingQueue.map((inc) => (
                <li key={inc.id} className="p-3">
                  <div className="flex items-start gap-2">
                    <CategoryIcon id={inc.categoryId} className="mt-0.5 size-5 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="line-clamp-2 text-sm font-semibold leading-snug">{inc.dickMove}</p>
                      <Meta className="mt-0.5 block">
                        {locationLabel(inc)} · {relativeTime(inc.createdAt)}
                      </Meta>
                    </div>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="redeem"
                      aria-label={`Approve ${inc.shortCode}`}
                      disabled={busy === `approve:${inc.id}`}
                      onClick={() =>
                        run({
                          key: `approve:${inc.id}`,
                          command: { action: "approve", targetType: "incident", targetId: inc.id },
                          success: "Approved",
                          detail: "It's on the public site now.",
                          tone: "green",
                          optimistic: () => setPendingQueue((q) => q.filter((x) => x.id !== inc.id)),
                          rollback: () => setPendingQueue((q) => (q.some((x) => x.id === inc.id) ? q : [inc, ...q])),
                        })
                      }
                    >
                      Approve
                    </Button>
                    <ButtonLink href="/admin/queue" variant="paper" size="sm" aria-label={`Review ${inc.shortCode} in the queue`}>
                      Review
                    </ButtonLink>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel
          title="Reports"
          kicker={`${stats.reportedContent} to look at`}
          action={
            <Link href="/admin/reports" aria-label="Open all reports" className="font-mono text-[11px] uppercase tracking-wider text-warning-500 underline decoration-2 underline-offset-2">
              All
            </Link>
          }
          bodyClassName="p-0"
        >
          {openReports.length === 0 ? (
            <PanelEmpty>Nothing reported. Either we&rsquo;re nailing it or nobody&rsquo;s looking.</PanelEmpty>
          ) : (
            <ul className="divide-y-2 divide-concrete-300">
              {openReports.map((r) => (
                <li key={r.id} className="p-3">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone={REPORT_REASON_TONE[r.reason]} size="sm">
                      {REPORT_REASON_LABEL[r.reason]}
                    </Badge>
                    <Meta>{relativeTime(r.createdAt)}</Meta>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-sm leading-snug">
                    {r.details ?? (r.targetType === "incident" ? r.incident?.dickMove : r.comment?.body) ?? "No detail given."}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="dark"
                      aria-label={`Resolve report: ${REPORT_REASON_LABEL[r.reason]}`}
                      disabled={busy === `resolve:${r.id}`}
                      onClick={() =>
                        run({
                          key: `resolve:${r.id}`,
                          command: { action: "resolve_report", targetType: "report", targetId: r.id },
                          success: "Report resolved",
                          optimistic: () => setOpenReports((list) => list.filter((x) => x.id !== r.id)),
                          rollback: () => setOpenReports((list) => (list.some((x) => x.id === r.id) ? list : [r, ...list])),
                        })
                      }
                    >
                      Resolve
                    </Button>
                    <ButtonLink href="/admin/reports?status=open" variant="paper" size="sm" aria-label={`Review report: ${REPORT_REASON_LABEL[r.reason]}`}>
                      Review
                    </ButtonLink>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel
          title="Appeals"
          kicker={`${stats.openAppeals} open`}
          action={
            <Link href="/admin/appeals" aria-label="Open all appeals" className="font-mono text-[11px] uppercase tracking-wider text-warning-500 underline decoration-2 underline-offset-2">
              All
            </Link>
          }
          bodyClassName="p-0"
        >
          {openAppeals.length === 0 ? (
            <PanelEmpty>No one is asking to be un-DBAD&rsquo;d today.</PanelEmpty>
          ) : (
            <ul className="divide-y-2 divide-concrete-300">
              {openAppeals.map((a) => (
                <li key={a.id} className="p-3">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge tone="yellow" size="sm">
                      {APPEAL_ACTION_LABEL[a.requestedAction]}
                    </Badge>
                    <Meta>{relativeTime(a.createdAt)}</Meta>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-sm leading-snug">{a.message}</p>
                  <Meta className="mt-1 block truncate">{a.incident.dickMove}</Meta>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <ButtonLink href="/admin/appeals?status=open" variant="primary" size="sm" aria-label={`Action appeal: ${APPEAL_ACTION_LABEL[a.requestedAction]}`}>
                      Action it
                    </ButtonLink>
                    <ButtonLink href={`/moves/${a.incident.slug}`} variant="paper" size="sm" aria-label={`Open the nomination: ${a.incident.title}`}>
                      The post
                    </ButtonLink>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>

      {/* ------------------------------------------------------------ recent activity */}
      <div className="mt-5">
        <Panel
          title="Latest moderator actions"
          kicker="Everything is logged. Yes, everything."
          action={
            <Link href="/admin/audit" className="font-mono text-[11px] uppercase tracking-wider text-warning-500 underline decoration-2 underline-offset-2">
              Full audit log
            </Link>
          }
          bodyClassName="p-0"
        >
          {audit.length === 0 ? (
            <PanelEmpty>No moderator has touched anything. Yet.</PanelEmpty>
          ) : (
            <ul className="divide-y-2 divide-concrete-300">
              {audit.map((entry) => (
                <li key={entry.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 px-3 py-2 text-sm">
                  <Avatar seed={entry.actor.handle} size={24} />
                  <span className="font-semibold">{entry.actor.handle}</span>
                  <ActionBadge action={entry.action} />
                  <CodePlate code={`${entry.targetType}:${entry.targetId}`} size="sm" className="max-w-full truncate" />
                  <Meta className="ml-auto whitespace-nowrap">{relativeTime(entry.createdAt)}</Meta>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </>
  );
}

function PanelEmpty({ children }: { children: React.ReactNode }) {
  return <p className="border-2 border-dashed border-concrete-400 bg-paper-100 p-4 text-center text-sm text-concrete-600">{children}</p>;
}
