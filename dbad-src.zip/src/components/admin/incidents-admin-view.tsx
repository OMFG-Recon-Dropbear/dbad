"use client";

import * as React from "react";
import Link from "next/link";
import type { AdminActions } from "@/lib/actions/types";
import type { Viewer } from "@/lib/data/repository";
import type { AdminIncidentsProps } from "@/lib/loaders/admin";
import type { IncidentSummary } from "@/lib/domain/types";
import { relativeTime } from "@/lib/domain/time";
import { weekOf } from "@/lib/domain/utils";
import { AdminHead, MODERATION_STATUS_LABEL, MODERATION_STATUS_TONE, useModerate } from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { Label, Textarea } from "@/components/ui/input";
import { LinkTabs } from "@/components/ui/tabs";
import { CodePlate } from "@/components/brand/hazard";
import { StatusStamp } from "@/components/brand/stamp";
import { locationLabel } from "@/components/incident/incident-card";
import { CategoryIcon } from "@/components/icons/categories";
import { ExternalIcon, SearchIcon, StarIcon } from "@/components/icons/ui";

const TABS: Array<{ value: string; label: string }> = [
  { value: "", label: "All" },
  { value: "pending", label: "Pending" },
  { value: "approved", label: "Approved" },
  { value: "rejected", label: "Rejected" },
  { value: "removed", label: "Removed" },
  { value: "redeemed", label: "Redeemed" },
  { value: "overruled", label: "Overruled" },
];

/**
 * Every nomination ever, searchable, with the whole moderation vocabulary on each row.
 * This is the screen you end up on when someone emails at 11pm about DBAD-0042.
 */
export function IncidentsAdminView({ incidents, status, query, viewer, actions }: AdminIncidentsProps & { viewer: Viewer; actions: AdminActions }) {
  void viewer;
  const { busy, run } = useModerate(actions);
  const [rows, setRows] = React.useState(incidents);
  const [redeeming, setRedeeming] = React.useState<IncidentSummary | null>(null);
  const thisWeek = React.useMemo(() => weekOf(new Date()), []);

  const patch = (id: string, next: Partial<IncidentSummary>) => setRows((list) => list.map((i) => (i.id === id ? { ...i, ...next } : i)));
  const undo = (inc: IncidentSummary) => setRows((list) => list.map((i) => (i.id === inc.id ? inc : i)));

  const tabHref = (value: string) => {
    const p = new URLSearchParams();
    if (value) p.set("status", value);
    if (query) p.set("q", query);
    const qs = p.toString();
    return qs ? `/admin/nominations?${qs}` : "/admin/nominations";
  };

  return (
    <>
      <AdminHead kicker={`${rows.length} nomination${rows.length === 1 ? "" : "s"}`} title="All nominations" intro="Search by words, suburb or short code. Every action here is logged against your handle.">
        <form action="/admin/nominations" method="get" role="search" className="flex max-w-xl gap-2">
          {status && <input type="hidden" name="status" value={status} />}
          <label className="sr-only" htmlFor="admin-nom-q">
            Search nominations
          </label>
          <div className="relative flex-1">
            <SearchIcon className="pointer-events-none absolute left-3 top-1/2 size-5 -translate-y-1/2 text-concrete-600" />
            <input
              id="admin-nom-q"
              name="q"
              defaultValue={query ?? ""}
              placeholder="DBAD-0042, footpath, Batemans Bay…"
              className="w-full rounded-sm border-[3px] border-ink-950 bg-white py-2.5 pl-11 pr-3 text-base shadow-hard-sm"
            />
          </div>
          <button type="submit" className="rounded-sm border-[3px] border-ink-950 bg-ink-950 px-4 font-display uppercase text-warning-500 shadow-hard-yellow">
            Search
          </button>
        </form>
        <div className="mt-3">
          <LinkTabs size="sm" className="!mx-0 !px-0" current={status ?? ""} items={TABS.map((t) => ({ ...t, href: tabHref(t.value) }))} />
        </div>
      </AdminHead>

      {rows.length === 0 ? (
        <EmptyState
          stamp="NOTHING FOUND"
          title="No nominations match that."
          body="Try a shorter search, or clear the filter. Short codes work too — DBAD-0042."
          action={{ href: "/admin/nominations", label: "Clear the search" }}
        />
      ) : (
        <ul className="border-[3px] border-ink-950 bg-paper-50 shadow-hard divide-y-2 divide-concrete-300">
          {rows.map((inc) => {
            const featured = inc.featuredWeek === thisWeek;
            return (
              <li key={inc.id} className="p-3 sm:p-4">
                <div className="flex gap-3">
                  <div className="flex size-14 shrink-0 items-center justify-center overflow-hidden border-2 border-ink-950 bg-warning-500 sm:size-16">
                    {inc.photos[0] ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={inc.photos[0].url} alt="" className="size-full object-cover" loading="lazy" />
                    ) : (
                      <CategoryIcon id={inc.categoryId} className="size-7" />
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1.5">
                      <CodePlate code={inc.shortCode} size="sm" />
                      <Badge tone={MODERATION_STATUS_TONE[inc.moderationStatus]} size="sm">
                        {MODERATION_STATUS_LABEL[inc.moderationStatus]}
                      </Badge>
                      {inc.kind === "not_a_dick" && (
                        <Badge tone="green" size="sm">
                          Not a dick
                        </Badge>
                      )}
                      {inc.anonymised && (
                        <Badge tone="concrete" size="sm">
                          Anonymised
                        </Badge>
                      )}
                      {inc.status !== "open" && (
                        <span className="px-1">
                          <StatusStamp status={inc.status === "redeemed" ? "redeemed" : "overruled"} />
                        </span>
                      )}
                      {featured && (
                        <span className="px-1">
                          <StatusStamp status="week" />
                        </span>
                      )}
                      <Meta className="ml-auto whitespace-nowrap">{relativeTime(inc.createdAt)}</Meta>
                    </div>

                    <p className="mt-1.5 font-display text-lg normal-case leading-tight tracking-tight">{inc.title}</p>
                    <Meta className="mt-0.5 block">
                      {inc.category.short} · {locationLabel(inc, true)}
                      {inc.submitter ? ` · ${inc.submitter.handle}` : " · anonymous"}
                    </Meta>

                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                      {inc.moderationStatus !== "approved" ? (
                        <Button
                          variant="redeem"
                          size="sm"
                          aria-label={`${inc.moderationStatus === "pending" ? "Approve" : "Restore"} ${inc.shortCode}`}
                          disabled={busy === `approve:${inc.id}`}
                          onClick={() =>
                            run({
                              key: `approve:${inc.id}`,
                              command: { action: inc.moderationStatus === "pending" ? "approve" : "restore", targetType: "incident", targetId: inc.id },
                              success: inc.moderationStatus === "pending" ? "Approved" : "Restored",
                              tone: "green",
                              optimistic: () => patch(inc.id, { moderationStatus: "approved" }),
                              rollback: () => undo(inc),
                            })
                          }
                        >
                          {inc.moderationStatus === "pending" ? "Approve" : "Restore"}
                        </Button>
                      ) : (
                        <Button
                          variant="alert"
                          size="sm"
                          aria-label={`Remove ${inc.shortCode}`}
                          disabled={busy === `remove:${inc.id}`}
                          onClick={() =>
                            run({
                              key: `remove:${inc.id}`,
                              command: { action: "remove", targetType: "incident", targetId: inc.id },
                              success: "Removed",
                              detail: "It's off the public site.",
                              optimistic: () => patch(inc.id, { moderationStatus: "removed" }),
                              rollback: () => undo(inc),
                            })
                          }
                        >
                          Remove
                        </Button>
                      )}

                      <Button variant="paper" size="sm" aria-label={`Mark ${inc.shortCode} redeemed`} disabled={inc.status === "redeemed"} onClick={() => setRedeeming(inc)}>
                        Mark redeemed
                      </Button>

                      <Button
                        variant="paper"
                        size="sm"
                        aria-label={`Mark ${inc.shortCode} overruled`}
                        disabled={inc.status === "overruled" || busy === `overrule:${inc.id}`}
                        onClick={() =>
                          run({
                            key: `overrule:${inc.id}`,
                            command: { action: "mark_overruled", targetType: "incident", targetId: inc.id },
                            success: "Marked overruled",
                            detail: "The community reckons it wasn't a dick move.",
                            optimistic: () => patch(inc.id, { status: "overruled" }),
                            rollback: () => undo(inc),
                          })
                        }
                      >
                        Overrule
                      </Button>

                      <Button
                        variant={featured ? "dark" : "paper"}
                        size="sm"
                        aria-label={`${featured ? "Unfeature" : "Feature"} ${inc.shortCode} as Dick Move of the Week`}
                        disabled={busy === `feature:${inc.id}`}
                        onClick={() =>
                          run({
                            key: `feature:${inc.id}`,
                            command: featured
                              ? { action: "unfeature", targetType: "incident", targetId: inc.id }
                              : { action: "feature_week", targetType: "incident", targetId: inc.id, payload: { week: thisWeek } },
                            success: featured ? "Unfeatured" : "Dick Move of the Week",
                            optimistic: () => {
                              setRows((list) =>
                                list.map((i) => {
                                  if (i.id === inc.id) return { ...i, featuredWeek: featured ? undefined : thisWeek };
                                  return i.featuredWeek === thisWeek && !featured ? { ...i, featuredWeek: undefined } : i;
                                }),
                              );
                            },
                            rollback: () => undo(inc),
                          })
                        }
                      >
                        <StarIcon className="size-4" /> {featured ? "Unfeature" : "Feature week"}
                      </Button>

                      <Button
                        variant="paper"
                        size="sm"
                        aria-label={`Anonymise ${inc.shortCode}`}
                        disabled={inc.anonymised || busy === `anon:${inc.id}`}
                        onClick={() =>
                          run({
                            key: `anon:${inc.id}`,
                            command: { action: "anonymise", targetType: "incident", targetId: inc.id },
                            success: "Anonymised",
                            detail: "Submitter and exact place removed.",
                            optimistic: () => patch(inc.id, { anonymised: true, submitter: null, location: { ...inc.location, place: undefined, precision: "suburb" } }),
                            rollback: () => undo(inc),
                          })
                        }
                      >
                        Anonymise
                      </Button>

                      <Link
                        href={`/moves/${inc.slug}`}
                        aria-label={`Open the public page for ${inc.shortCode}`}
                        className="ml-auto inline-flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider text-concrete-600 underline decoration-warning-500 decoration-2 underline-offset-2 hover:text-ink-950"
                      >
                        <ExternalIcon className="size-3.5" /> Public page
                      </Link>
                    </div>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      <Dialog open={!!redeeming} onClose={() => setRedeeming(null)} title="Mark as redeemed" size="sm">
        {redeeming && (
          <RedeemForm
            incident={redeeming}
            onSubmit={async (note) => {
              const inc = redeeming;
              const ok = await run({
                key: `redeem:${inc.id}`,
                command: { action: "mark_redeemed", targetType: "incident", targetId: inc.id, note, payload: note ? { note } : undefined },
                success: "REDEEMED",
                detail: "Humanity survives another day.",
                tone: "green",
                optimistic: () => patch(inc.id, { status: "redeemed" }),
                rollback: () => undo(inc),
              });
              if (ok) setRedeeming(null);
            }}
          />
        )}
      </Dialog>
    </>
  );
}

function RedeemForm({ incident, onSubmit }: { incident: IncidentSummary; onSubmit: (note: string) => Promise<void> }) {
  const id = React.useId();
  const [note, setNote] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  return (
    <form
      className="space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        setSaving(true);
        await onSubmit(note.trim());
        setSaving(false);
      }}
    >
      <div className="border-2 border-ink-950 bg-paper-100 p-2.5">
        <Meta>{incident.shortCode}</Meta>
        <p className="font-display text-lg uppercase leading-none">{incident.dickMove}</p>
      </div>
      <div>
        <Label htmlFor={id} hint="Shown on the nomination. Keep it kind — redemption is the whole point.">
          What got fixed?
        </Label>
        <Textarea id={id} rows={3} maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} placeholder="They came back and moved it. Humanity survives another day." />
      </div>
      <div className="flex justify-end">
        <Button type="submit" variant="redeem" disabled={saving}>
          {saving ? "Saving…" : "Mark redeemed"}
        </Button>
      </div>
    </form>
  );
}
