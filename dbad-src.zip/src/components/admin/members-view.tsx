"use client";

import * as React from "react";
import Link from "next/link";
import type { AdminActions } from "@/lib/actions/types";
import type { UserRow, Viewer } from "@/lib/data/repository";
import type { MembersProps } from "@/lib/loaders/admin";
import type { Role } from "@/lib/domain/types";
import { formatDateAU } from "@/lib/domain/time";
import { AdminHead, useModerate } from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { EmptyState } from "@/components/ui/empty-state";
import { Select } from "@/components/ui/input";
import { Avatar } from "@/components/brand/avatar";
import { SearchIcon, ShieldIcon, StarIcon } from "@/components/icons/ui";

const ROLES: Role[] = ["member", "moderator", "admin"];
const ROLE_LABEL: Record<Role, string> = { member: "Member", moderator: "Moderator", admin: "Admin" };
const ROLE_TONE: Record<Role, "concrete" | "ink" | "yellow"> = { member: "concrete", moderator: "ink", admin: "yellow" };

/**
 * Members. Behaviour is what DBAD records, so there is not much here — a handle, what
 * they've spotted, and the one lever that matters: what they're allowed to do.
 */
export function MembersView({ members, query, viewer, actions }: MembersProps & { viewer: Viewer; actions: AdminActions }) {
  const { busy, run } = useModerate(actions);
  const [rows, setRows] = React.useState(members);
  const isAdmin = viewer.role === "admin";

  const setRole = (m: UserRow, role: Role) => {
    const previous = m.role;
    void run({
      key: `role:${m.id}`,
      command: { action: "change_role", targetType: "user", targetId: m.id, payload: { role }, note: `${previous} → ${role}` },
      success: "Role updated",
      detail: `${m.handle} is now ${ROLE_LABEL[role].toLowerCase()}.`,
      optimistic: () => setRows((list) => list.map((x) => (x.id === m.id ? { ...x, role } : x))),
      rollback: () => setRows((list) => list.map((x) => (x.id === m.id ? { ...x, role: previous } : x))),
    });
  };

  return (
    <>
      <AdminHead
        kicker={`${rows.length} member${rows.length === 1 ? "" : "s"}`}
        title="Members"
        intro={
          isAdmin
            ? "Roles take effect immediately and are logged. Moderators clear the queue; admins can also hand out the keys."
            : "Read-only for moderators — only an admin can change what someone is allowed to do."
        }
      >
        <form action="/admin/members" method="get" role="search" className="flex max-w-md gap-2">
          <label className="sr-only" htmlFor="admin-member-q">
            Search members
          </label>
          <div className="relative flex-1">
            <SearchIcon className="pointer-events-none absolute left-3 top-1/2 size-5 -translate-y-1/2 text-concrete-600" />
            <input
              id="admin-member-q"
              name="q"
              defaultValue={query ?? ""}
              placeholder="Handle or display name…"
              className="w-full rounded-sm border-[3px] border-ink-950 bg-white py-2.5 pl-11 pr-3 text-base shadow-hard-sm"
            />
          </div>
          <button type="submit" className="rounded-sm border-[3px] border-ink-950 bg-ink-950 px-4 font-display uppercase text-warning-500 shadow-hard-yellow">
            Search
          </button>
        </form>
      </AdminHead>

      {rows.length === 0 ? (
        <EmptyState
          stamp="NO MEMBERS"
          title="Nobody by that name."
          body="Try part of a handle. Members are only ever found by what they chose to be called."
          action={{ href: "/admin/members", label: "Show everyone" }}
        />
      ) : (
        <ul className="border-[3px] border-ink-950 bg-paper-50 shadow-hard divide-y-2 divide-concrete-300">
          {rows.map((m) => {
            const self = m.id === viewer.id;
            return (
              <li key={m.id} className="flex flex-col gap-3 p-3 sm:p-4 lg:flex-row lg:items-center">
                <div className="flex min-w-0 flex-1 items-center gap-3">
                  <Avatar seed={m.avatarSeed} size={40} />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                      <Link href={`/u/${m.handle}`} className="font-semibold underline decoration-warning-500 decoration-2 underline-offset-2">
                        {m.handle}
                      </Link>
                      <Badge tone={ROLE_TONE[m.role]} size="sm" className="gap-1">
                        {m.role !== "member" && <ShieldIcon className="size-3.5" />}
                        {ROLE_LABEL[m.role]}
                      </Badge>
                      {self && (
                        <Badge tone="outline" size="sm">
                          You
                        </Badge>
                      )}
                    </div>
                    <p className="truncate text-sm">{m.displayName}</p>
                    <Meta className="block">
                      Member since {formatDateAU(m.memberSince)}
                      {m.homeArea ? ` · ${m.homeArea}` : ""}
                    </Meta>
                  </div>
                </div>

                <dl className="grid grid-cols-3 gap-x-3 gap-y-1 sm:grid-cols-6 lg:w-[26rem] lg:shrink-0">
                  <Stat label="Spotted" value={m.stats.spotted} />
                  <Stat label="Fair calls" value={m.stats.fairCalls} />
                  <Stat label="Redeemed" value={m.stats.redeemed} />
                  <Stat label="Overruled" value={m.stats.overruled} />
                  <Stat label="Comments" value={m.stats.comments} />
                  <Stat label="Badges" value={m.badges.length} icon />
                </dl>

                <div className="max-w-[16rem] lg:w-44 lg:max-w-none lg:shrink-0">
                  <label className="sr-only" htmlFor={`role-${m.id}`}>
                    Role for {m.handle}
                  </label>
                  <Select
                    id={`role-${m.id}`}
                    value={m.role}
                    disabled={!isAdmin || self || busy === `role:${m.id}`}
                    onChange={(e) => setRole(m, e.target.value as Role)}
                    className="py-2 text-sm"
                  >
                    {ROLES.map((r) => (
                      <option key={r} value={r}>
                        {ROLE_LABEL[r]}
                      </option>
                    ))}
                  </Select>
                  {self ? (
                    <Meta className="mt-1 block">Can&rsquo;t change your own role.</Meta>
                  ) : !isAdmin ? (
                    <Meta className="mt-1 block">Admins only.</Meta>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}

function Stat({ label, value, icon }: { label: string; value: number; icon?: boolean }) {
  return (
    <div className="border-2 border-concrete-300 bg-paper-100 px-1.5 py-1 text-center">
      <dt className="font-mono text-[10px] uppercase leading-none tracking-wider text-concrete-600">{label}</dt>
      <dd className="mt-0.5 inline-flex items-center gap-1 font-display text-lg leading-none tabular">
        {icon && <StarIcon className="size-3.5 text-warning-600" />}
        {value}
      </dd>
    </div>
  );
}
