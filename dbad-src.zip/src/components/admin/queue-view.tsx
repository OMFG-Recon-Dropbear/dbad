"use client";

import * as React from "react";
import Link from "next/link";
import type { AdminActions } from "@/lib/actions/types";
import type { Viewer } from "@/lib/data/repository";
import type { IncidentSummary } from "@/lib/domain/types";
import type { QueueProps } from "@/lib/loaders/admin";
import { AFFECTED_LABEL } from "@/lib/domain/categories";
import { occurrenceLabel, relativeTime } from "@/lib/domain/time";
import { AdminHead, PiiScan, useModerate } from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button, ButtonLink } from "@/components/ui/button";
import { Dialog } from "@/components/ui/dialog";
import { EmptyState } from "@/components/ui/empty-state";
import { Help, Label, Textarea } from "@/components/ui/input";
import { Avatar } from "@/components/brand/avatar";
import { CodePlate } from "@/components/brand/hazard";
import { EvidenceFrame } from "@/components/brand/evidence";
import { CategoryIcon } from "@/components/icons/categories";
import { MapPinIcon, StarIcon, TrashIcon } from "@/components/icons/ui";

type DialogMode = { kind: "reject" | "anonymise"; incident: IncidentSummary } | null;

/**
 * The moderation queue: one review card per pending nomination with the photos, the
 * words, the PII scan, and the five decisions a moderator actually makes.
 */
export function QueueView({ queue, viewer, actions }: QueueProps & { viewer: Viewer; actions: AdminActions }) {
  const { busy, run } = useModerate(actions);
  const [items, setItems] = React.useState(queue);
  const [dialog, setDialog] = React.useState<DialogMode>(null);

  const remove = (id: string) => setItems((list) => list.filter((i) => i.id !== id));
  const restore = (inc: IncidentSummary) => setItems((list) => (list.some((i) => i.id === inc.id) ? list : [inc, ...list]));

  return (
    <>
      <AdminHead
        kicker={`${items.length} waiting · ${viewer.handle}`}
        title="Moderation queue"
        intro="Nothing here is public yet. Check the photo for faces, plates and house numbers, check the words for names, then approve it or send it back."
      />

      {items.length === 0 ? (
        <EmptyState
          stamp="ALL CLEAR"
          title="Queue clear. Humanity is improving. Or asleep."
          body="Nothing is waiting on a moderator. Have a cup of tea before the next ute parks on a footpath."
          action={{ href: "/admin", label: "Back to dashboard" }}
        />
      ) : (
        <ul className="space-y-5">
          {items.map((inc) => (
            <li key={inc.id}>
              <QueueCard
                incident={inc}
                busy={busy}
                onApprove={() =>
                  run({
                    key: `approve:${inc.id}`,
                    command: { action: "approve", targetType: "incident", targetId: inc.id },
                    success: "Approved",
                    detail: "It's on the public site now.",
                    tone: "green",
                    optimistic: () => remove(inc.id),
                    rollback: () => restore(inc),
                  })
                }
                onFeature={() =>
                  run({
                    key: `feature:${inc.id}`,
                    command: { action: "feature_week", targetType: "incident", targetId: inc.id },
                    success: "Dick Move of the Week",
                    detail: "It still needs approving to go public.",
                  })
                }
                onRemovePhoto={(photoId) =>
                  run({
                    key: `photo:${photoId}`,
                    command: { action: "redact_photo", targetType: "photo", targetId: inc.id, payload: { photoId } },
                    success: "Photo removed",
                    detail: "The words stay, the evidence goes.",
                    optimistic: () =>
                      setItems((list) => list.map((i) => (i.id === inc.id ? { ...i, photos: i.photos.filter((p) => p.id !== photoId) } : i))),
                    rollback: () => setItems((list) => list.map((i) => (i.id === inc.id ? inc : i))),
                  })
                }
                onReject={() => setDialog({ kind: "reject", incident: inc })}
                onAnonymise={() => setDialog({ kind: "anonymise", incident: inc })}
              />
            </li>
          ))}
        </ul>
      )}

      <Dialog
        open={dialog?.kind === "reject"}
        onClose={() => setDialog(null)}
        title="Reject nomination"
        size="sm"
      >
        {dialog?.kind === "reject" && (
          <NoteForm
            intro="The submitter gets told it wasn't published, and gets your reason. Keep it short and human — most people are trying."
            label="Why it isn't going up"
            placeholder="The photo shows a face. Reshoot or blur it and we'll happily run it."
            submitLabel="Reject nomination"
            variant="alert"
            onSubmit={async (note) => {
              const inc = dialog.incident;
              const ok = await run({
                key: `reject:${inc.id}`,
                command: { action: "reject", targetType: "incident", targetId: inc.id, note },
                success: "Rejected",
                detail: "The submitter has been told why.",
                optimistic: () => remove(inc.id),
                rollback: () => restore(inc),
              });
              if (ok) setDialog(null);
            }}
          />
        )}
      </Dialog>

      <Dialog open={dialog?.kind === "anonymise"} onClose={() => setDialog(null)} title="Anonymise nomination" size="sm">
        {dialog?.kind === "anonymise" && (
          <NoteForm
            intro="Drops the submitter, drops the exact place, and keeps the suburb. Optionally rewrite the description while you're in here."
            label="Rewritten description (optional)"
            placeholder={dialog.incident.description}
            submitLabel="Anonymise"
            variant="dark"
            optional
            onSubmit={async (description) => {
              const inc = dialog.incident;
              const ok = await run({
                key: `anon:${inc.id}`,
                command: {
                  action: "anonymise",
                  targetType: "incident",
                  targetId: inc.id,
                  note: "Anonymised from the queue.",
                  ...(description ? { payload: { description } } : {}),
                },
                success: "Anonymised",
                detail: "Submitter and exact place removed.",
                optimistic: () =>
                  setItems((list) =>
                    list.map((i) =>
                      i.id === inc.id
                        ? {
                            ...i,
                            anonymised: true,
                            submitter: null,
                            description: description || i.description,
                            location: { ...i.location, place: undefined, precision: "suburb" as const },
                          }
                        : i,
                    ),
                  ),
                rollback: () => setItems((list) => list.map((i) => (i.id === inc.id ? inc : i))),
              });
              if (ok) setDialog(null);
            }}
          />
        )}
      </Dialog>
    </>
  );
}

function QueueCard({
  incident,
  busy,
  onApprove,
  onReject,
  onAnonymise,
  onFeature,
  onRemovePhoto,
}: {
  incident: IncidentSummary;
  busy: string | null;
  onApprove: () => void;
  onReject: () => void;
  onAnonymise: () => void;
  onFeature: () => void;
  onRemovePhoto: (photoId: string) => void;
}) {
  const inc = incident;
  return (
    <article className="border-[3px] border-ink-950 bg-paper-50 shadow-hard">
      {/* header */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b-[3px] border-ink-950 bg-warning-500 px-3 py-2">
        <CodePlate code={inc.shortCode} size="sm" />
        <Badge tone="ink" size="sm" className="gap-1.5">
          <CategoryIcon id={inc.categoryId} className="size-3.5" />
          {inc.category.label}
        </Badge>
        {inc.kind === "not_a_dick" && (
          <Badge tone="green" size="sm">
            Not a dick
          </Badge>
        )}
        {inc.featuredWeek && (
          <Badge tone="red" size="sm">
            Week pick
          </Badge>
        )}
        <Meta className="ml-auto text-ink-950/70">Submitted {relativeTime(inc.createdAt)}</Meta>
      </div>

      <div className="grid grid-cols-1 gap-4 p-3 sm:p-4 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]">
        {/* ---------------------------------------------------------- evidence */}
        <div className="space-y-2">
          {inc.photos.length === 0 ? (
            <EvidenceFrame categoryId={inc.categoryId} aspect="aspect-[4/3]" />
          ) : (
            inc.photos.map((p, i) => (
              <div key={p.id}>
                <EvidenceFrame
                  photo={p}
                  categoryId={inc.categoryId}
                  aspect="aspect-[4/3]"
                  sizes="(min-width: 1024px) 20rem, 100vw"
                  caption={
                    <>
                      <span>
                        Photo {i + 1}/{inc.photos.length}
                      </span>
                      <span className="ml-auto">{p.redactionCount} redaction{p.redactionCount === 1 ? "" : "s"}</span>
                    </>
                  }
                />
                <Button
                  variant="alert"
                  size="sm"
                  className="mt-1.5 w-full"
                  disabled={busy === `photo:${p.id}`}
                  aria-label={`Remove photo ${i + 1} from ${inc.shortCode}`}
                  onClick={() => onRemovePhoto(p.id)}
                >
                  <TrashIcon className="size-4" /> {busy === `photo:${p.id}` ? "Removing…" : "Remove photo"}
                </Button>
              </div>
            ))
          )}
          <p className="font-mono text-[11px] uppercase leading-snug tracking-wider text-concrete-600">
            Check for: faces · plates · house numbers · school uniforms
          </p>
        </div>

        {/* ---------------------------------------------------------- words */}
        <div className="min-w-0">
          <h3 className="font-display text-2xl normal-case leading-[0.95] tracking-tight">
            {/^["“]/.test(inc.title) ? inc.title : <>&ldquo;{inc.title}&rdquo;</>}
          </h3>

          <dl className="mt-3 space-y-2.5">
            <div>
              <dt className="font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">The dick move</dt>
              <dd className="font-display text-xl uppercase leading-none">{inc.dickMove}</dd>
            </div>
            <div>
              <dt className="font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">Why it mattered</dt>
              <dd className="text-sm leading-snug">{inc.description}</dd>
            </div>
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <div>
                <dt className="font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">Location</dt>
                <dd className="flex items-start gap-1.5 text-sm leading-snug">
                  <MapPinIcon className="mt-0.5 size-4 shrink-0 text-concrete-600" />
                  <span>
                    {inc.location.place ? `${inc.location.place}, ` : ""}
                    {inc.location.suburb}, {inc.location.state}
                    <span className="block font-mono text-[11px] uppercase tracking-wider text-concrete-600">
                      {inc.location.region} · {inc.location.precision} precision
                    </span>
                  </span>
                </dd>
              </div>
              <div>
                <dt className="font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">When</dt>
                <dd className="text-sm leading-snug">{occurrenceLabel(inc.occurredOn, inc.partOfDay)}</dd>
              </div>
            </div>
            <div>
              <dt className="font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">Affected</dt>
              <dd className="mt-1 flex flex-wrap gap-1.5">
                {inc.affected.length === 0 && <Meta>Nobody nominated</Meta>}
                {inc.affected.map((a) => (
                  <Badge key={a} tone="concrete" size="sm">
                    {AFFECTED_LABEL[a]}
                  </Badge>
                ))}
              </dd>
            </div>
            <div>
              <dt className="font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">Submitted by</dt>
              <dd className="mt-1 flex items-center gap-2 text-sm">
                {inc.submitter ? (
                  <>
                    <Avatar seed={inc.submitter.avatarSeed} size={24} />
                    <Link href={`/u/${inc.submitter.handle}`} className="font-semibold underline decoration-warning-500 decoration-2 underline-offset-2">
                      {inc.submitter.handle}
                    </Link>
                  </>
                ) : (
                  <Meta>Anonymous submission</Meta>
                )}
                {inc.socialSource && (
                  <a href={inc.socialSource.url} target="_blank" rel="noopener noreferrer" className="font-mono text-[11px] uppercase tracking-wider underline">
                    Source link
                  </a>
                )}
              </dd>
            </div>
          </dl>

          <PiiScan
            className="mt-3"
            fields={[
              { label: "Title", text: inc.title },
              { label: "Dick move", text: inc.dickMove },
              { label: "Description", text: inc.description },
            ]}
          />
        </div>
      </div>

      {/* ---------------------------------------------------------- actions */}
      <div className="flex flex-wrap items-center gap-2 border-t-[3px] border-ink-950 bg-paper-100 px-3 py-2.5">
        <Button variant="redeem" size="sm" aria-label={`Approve ${inc.shortCode}`} disabled={busy === `approve:${inc.id}`} onClick={onApprove}>
          {busy === `approve:${inc.id}` ? "Approving…" : "Approve"}
        </Button>
        <Button variant="alert" size="sm" aria-label={`Reject ${inc.shortCode}`} onClick={onReject}>
          Reject
        </Button>
        <Button variant="dark" size="sm" aria-label={`Anonymise ${inc.shortCode}`} onClick={onAnonymise}>
          Anonymise
        </Button>
        <Button variant="paper" size="sm" aria-label={`Feature ${inc.shortCode} as Dick Move of the Week`} disabled={busy === `feature:${inc.id}`} onClick={onFeature}>
          <StarIcon className="size-4" /> Feature as Dick Move of the Week
        </Button>
        <ButtonLink href={`/moves/${inc.slug}`} variant="ghost" size="sm" className="ml-auto underline" aria-label={`Preview the public page for ${inc.shortCode}`}>
          Preview page
        </ButtonLink>
      </div>
    </article>
  );
}

function NoteForm({
  intro,
  label,
  placeholder,
  submitLabel,
  variant,
  optional,
  onSubmit,
}: {
  intro: string;
  label: string;
  placeholder?: string;
  submitLabel: string;
  variant: "alert" | "dark" | "redeem" | "primary";
  optional?: boolean;
  onSubmit: (note: string) => Promise<void>;
}) {
  const id = React.useId();
  const [note, setNote] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const disabled = saving || (!optional && note.trim().length < 4);
  return (
    <form
      className="space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        if (disabled) return;
        setSaving(true);
        await onSubmit(note.trim());
        setSaving(false);
      }}
    >
      <p className="text-sm leading-snug text-ink-700">{intro}</p>
      <div>
        <Label htmlFor={id}>{label}</Label>
        <Textarea id={id} rows={4} maxLength={600} value={note} placeholder={placeholder} onChange={(e) => setNote(e.target.value)} />
        {optional && <Help>Leave it blank to keep the original wording.</Help>}
      </div>
      <div className="flex justify-end gap-2">
        <Button type="submit" variant={variant} disabled={disabled}>
          {saving ? "Saving…" : submitLabel}
        </Button>
      </div>
    </form>
  );
}
