"use client";

import * as React from "react";
import type { AdminActions } from "@/lib/actions/types";
import type { ReportWithTarget, Viewer } from "@/lib/data/repository";
import type { ReportsProps } from "@/lib/loaders/admin";
import type { ReportStatus } from "@/lib/domain/types";
import { relativeTime } from "@/lib/domain/time";
import {
  AdminHead,
  HighlightedText,
  REPORT_REASON_LABEL,
  REPORT_REASON_TONE,
  REPORT_STATUS_LABEL,
  useModerate,
} from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { LinkTabs } from "@/components/ui/tabs";
import { IncidentRow } from "@/components/incident/incident-card";
import { Avatar } from "@/components/brand/avatar";

const TABS: Array<{ value: string; label: string }> = [
  { value: "", label: "All" },
  { value: "open", label: "Open" },
  { value: "reviewing", label: "Reviewing" },
  { value: "resolved", label: "Resolved" },
  { value: "dismissed", label: "Dismissed" },
];

const STATUS_TONE: Record<ReportStatus, "red" | "yellow" | "green" | "concrete"> = {
  open: "red",
  reviewing: "yellow",
  resolved: "green",
  dismissed: "concrete",
};

/**
 * Reports from the community. Anything that identifies a real person is the first job
 * of the day; everything else can wait until after the coffee.
 */
export function ReportsView({ reports, status, viewer, actions }: ReportsProps & { viewer: Viewer; actions: AdminActions }) {
  void viewer;
  const { busy, run } = useModerate(actions);
  const [rows, setRows] = React.useState(reports);

  /** Resolving inside a filtered list quietly drops the row; in "All" it just re-badges. */
  const settle = (report: ReportWithTarget, next: ReportStatus) =>
    setRows((list) =>
      status && status !== next ? list.filter((r) => r.id !== report.id) : list.map((r) => (r.id === report.id ? { ...r, status: next } : r)),
    );
  const undo = (report: ReportWithTarget) =>
    setRows((list) => (list.some((r) => r.id === report.id) ? list.map((r) => (r.id === report.id ? report : r)) : [report, ...list]));

  return (
    <>
      <AdminHead
        kicker={`${rows.length} shown`}
        title="Reports"
        intro="Reports about identifying details or children get actioned first. Everything else: read it, act on it, or dismiss it and move on."
      >
        <LinkTabs
          size="sm"
          className="!mx-0 !px-0"
          current={status ?? ""}
          items={TABS.map((t) => ({ ...t, href: t.value ? `/admin/reports?status=${t.value}` : "/admin/reports" }))}
        />
      </AdminHead>

      {rows.length === 0 ? (
        <EmptyState
          stamp="NOTHING FLAGGED"
          title="No reports in this pile."
          body="Either the community is behaving or they've given up on us. Check the other tabs before you celebrate."
          action={{ href: "/admin/reports", label: "Show all reports" }}
        />
      ) : (
        <ul className="space-y-4">
          {rows.map((r) => {
            const settled = r.status === "resolved" || r.status === "dismissed";
            return (
              <li key={r.id} className="border-[3px] border-ink-950 bg-paper-50 shadow-hard">
                <div className="flex flex-wrap items-center gap-2 border-b-[3px] border-ink-950 bg-paper-100 px-3 py-2">
                  <Badge tone={REPORT_REASON_TONE[r.reason]} size="sm">
                    {REPORT_REASON_LABEL[r.reason]}
                  </Badge>
                  <Badge tone={STATUS_TONE[r.status]} size="sm">
                    {REPORT_STATUS_LABEL[r.status]}
                  </Badge>
                  <Meta>on a {r.targetType}</Meta>
                  <Meta className="ml-auto">{relativeTime(r.createdAt)}</Meta>
                </div>

                <div className="space-y-3 p-3 sm:p-4">
                  <div>
                    <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">What they said</p>
                    <p className="text-sm leading-snug">{r.details ?? "No detail given — just the reason."}</p>
                    <Meta className="mt-1 block">Reported by {r.reporterId ? "a member" : "someone not signed in"}</Meta>
                  </div>

                  <div>
                    <p className="mb-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-concrete-600">The content</p>
                    {r.incident ? (
                      <IncidentRow incident={r.incident} />
                    ) : r.comment ? (
                      <div className="flex gap-2.5 border-2 border-ink-950 bg-paper-100 p-2.5">
                        <Avatar seed={r.comment.author.handle} size={32} />
                        <div className="min-w-0">
                          <p className="text-sm font-semibold">{r.comment.author.handle}</p>
                          <HighlightedText text={r.comment.body} className="text-sm leading-snug" />
                          <Meta className="mt-1 block">
                            {relativeTime(r.comment.createdAt)} · currently {r.comment.status}
                          </Meta>
                        </div>
                      </div>
                    ) : (
                      <p className="border-2 border-dashed border-concrete-400 p-2.5 text-sm text-concrete-600">
                        The reported content has already gone. Nothing to action.
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 border-t-[3px] border-ink-950 bg-paper-100 px-3 py-2.5">
                  <Button
                    variant="redeem"
                    size="sm"
                    aria-label={`Resolve report: ${REPORT_REASON_LABEL[r.reason]}`}
                    disabled={settled || busy === `resolve:${r.id}`}
                    onClick={() =>
                      run({
                        key: `resolve:${r.id}`,
                        command: { action: "resolve_report", targetType: "report", targetId: r.id },
                        success: "Report resolved",
                        detail: "Logged against your handle.",
                        tone: "green",
                        optimistic: () => settle(r, "resolved"),
                        rollback: () => undo(r),
                      })
                    }
                  >
                    Resolve
                  </Button>
                  <Button
                    variant="paper"
                    size="sm"
                    aria-label={`Dismiss report: ${REPORT_REASON_LABEL[r.reason]}`}
                    disabled={settled || busy === `dismiss:${r.id}`}
                    onClick={() =>
                      run({
                        key: `dismiss:${r.id}`,
                        command: { action: "dismiss_report", targetType: "report", targetId: r.id },
                        success: "Report dismissed",
                        detail: "No action taken on the content.",
                        optimistic: () => settle(r, "dismissed"),
                        rollback: () => undo(r),
                      })
                    }
                  >
                    Dismiss
                  </Button>

                  <span className="mx-1 hidden h-6 w-0.5 bg-concrete-300 sm:block" aria-hidden />

                  {r.comment && (
                    <Button
                      variant="alert"
                      size="sm"
                      aria-label={`Hide the reported comment by ${r.comment.author.handle}`}
                      disabled={busy === `hide:${r.id}`}
                      onClick={() =>
                        run({
                          key: `hide:${r.id}`,
                          command: { action: "hide_comment", targetType: "comment", targetId: r.targetId, note: `Reported: ${REPORT_REASON_LABEL[r.reason]}` },
                          success: "Comment hidden",
                          optimistic: () =>
                            setRows((list) =>
                              list.map((x) => (x.id === r.id && x.comment ? { ...x, comment: { ...x.comment, status: "hidden" as const } } : x)),
                            ),
                          rollback: () => undo(r),
                        })
                      }
                    >
                      Hide comment
                    </Button>
                  )}

                  {r.incident && (
                    <>
                      <Button
                        variant="alert"
                        size="sm"
                        aria-label={`Remove the reported nomination ${r.incident.shortCode}`}
                        disabled={busy === `remove:${r.id}`}
                        onClick={() =>
                          run({
                            key: `remove:${r.id}`,
                            command: { action: "remove", targetType: "incident", targetId: r.targetId, note: `Reported: ${REPORT_REASON_LABEL[r.reason]}` },
                            success: "Nomination removed",
                            detail: "It's off the public site.",
                          })
                        }
                      >
                        Remove nomination
                      </Button>
                      <Button
                        variant="dark"
                        size="sm"
                        aria-label={`Anonymise the reported nomination ${r.incident.shortCode}`}
                        disabled={busy === `anon:${r.id}`}
                        onClick={() =>
                          run({
                            key: `anon:${r.id}`,
                            command: { action: "anonymise", targetType: "incident", targetId: r.targetId, note: `Reported: ${REPORT_REASON_LABEL[r.reason]}` },
                            success: "Nomination anonymised",
                            detail: "Submitter and exact place removed.",
                          })
                        }
                      >
                        Anonymise
                      </Button>
                    </>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );
}
