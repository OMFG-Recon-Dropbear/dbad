"use client";

import * as React from "react";
import type { AdminActions } from "@/lib/actions/types";
import type { Viewer } from "@/lib/data/repository";
import type { NoticeLines } from "@/lib/domain/types";
import type { NoticeTemplateMeta } from "@/lib/notice/lines";
import { NOTICE_TEMPLATES } from "@/lib/notice/lines";
import { SITE } from "@/lib/site";
import { AdminHead, useModerate } from "./admin-shell";
import { Badge, Meta } from "@/components/ui/badge";
import { Button, ButtonLink } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { NoticeCard } from "@/components/notice/notice-card";
import { InfoIcon } from "@/components/icons/ui";

/** The words every preview uses, so the five templates are compared like for like. */
const SAMPLE = {
  dickMove: "Parking across a public footpath.",
  why: "People shouldn't have to walk onto the road because you couldn't park properly.",
  location: "Batemans Bay, NSW",
  advice: "Do better next time.",
} as const;

/**
 * The five printable notice templates with a live preview each. Only the default
 * headline is editable here — the rest of a notice is written by whoever prints it.
 */
export function TemplatesView({ viewer, actions }: { viewer: Viewer; actions: AdminActions }) {
  void viewer;
  const { busy, run } = useModerate(actions);

  return (
    <>
      <AdminHead
        kicker={`${NOTICE_TEMPLATES.length} templates`}
        title="Notice templates"
        intro="What people actually print and leave under a wiper. The headline is the one line the community can't edit per-notice, so it's the one worth arguing about."
        action={
          <ButtonLink href="/notice/new" variant="dark" size="sm">
            Open the notice studio
          </ButtonLink>
        }
      />

      <p className="mb-4 flex items-start gap-2.5 border-[3px] border-ink-950 bg-warning-500 p-3 text-sm leading-snug shadow-hard-sm">
        <InfoIcon className="mt-0.5 size-5 shrink-0" />
        <span>
          <strong>Demo mode.</strong> Headline changes are written to the audit log; the shipped copy is what prints until template text is
          moved into configuration.
        </span>
      </p>

      <div className="space-y-4">
        {NOTICE_TEMPLATES.map((t) => (
          <TemplateRow
            key={t.id}
            template={t}
            busy={busy === `tpl:${t.id}`}
            onSave={(headline) =>
              run({
                key: `tpl:${t.id}`,
                command: { action: "edit_template", targetType: "template", targetId: t.id, payload: { headline }, note: `Headline: ${headline}` },
                success: "Template saved",
                detail: "Logged. Shipped copy still prints in demo mode.",
              })
            }
          />
        ))}
      </div>
    </>
  );
}

function SampleLine({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="font-mono text-[10px] uppercase tracking-[0.18em] text-concrete-600">{label}</dt>
      <dd className="text-sm leading-snug">{value}</dd>
    </div>
  );
}

function TemplateRow({ template, busy, onSave }: { template: NoticeTemplateMeta; busy: boolean; onSave: (headline: string) => Promise<boolean> }) {
  const [headline, setHeadline] = React.useState(template.headline);
  const dirty = headline.trim() !== template.headline;
  const lines: NoticeLines = { headline: headline || template.headline, ...SAMPLE };

  return (
    <form
      className="grid grid-cols-1 gap-4 border-[3px] border-ink-950 bg-paper-50 p-3 shadow-hard sm:grid-cols-[16rem_minmax(0,1fr)] sm:p-4"
      onSubmit={async (e) => {
        e.preventDefault();
        if (!dirty || busy) return;
        await onSave(headline.trim());
      }}
    >
      <div className="mx-auto w-full max-w-[16rem]">
        <div className="shadow-hard-sm">
          <NoticeCard template={template.id} lines={lines} code="DBAD-0042" qrUrl={SITE.url} linkMode="site" />
        </div>
        <Meta className="mt-1.5 block text-center">Live preview · prints A5</Meta>
      </div>

      <div className="flex min-w-0 flex-col">
        <div className="flex flex-wrap items-center gap-2">
          <h2 className="font-display text-2xl leading-none">{template.name}</h2>
          <Badge tone="concrete" size="sm">
            {template.id}
          </Badge>
        </div>
        <p className="mt-2 text-sm leading-snug text-ink-700">{template.blurb}</p>

        <div className="mt-4">
          <label htmlFor={`tpl-${template.id}`} className="mb-1.5 block font-display text-base uppercase leading-none tracking-wide">
            Default headline
          </label>
          <Input
            id={`tpl-${template.id}`}
            value={headline}
            maxLength={60}
            onChange={(e) => setHeadline(e.target.value)}
            aria-describedby={`tpl-help-${template.id}`}
          />
          <p id={`tpl-help-${template.id}`} className="mt-1.5 text-sm text-concrete-600">
            Shown in the black bar on the notice. {60 - headline.length} characters left.
          </p>
        </div>

        <dl className="mt-4 grid grid-cols-1 gap-x-4 gap-y-1.5 border-t-2 border-concrete-300 pt-3 sm:grid-cols-2">
          <SampleLine label="The dick move" value={SAMPLE.dickMove} />
          <SampleLine label="Why you're here" value={SAMPLE.why} />
          <SampleLine label="Location" value={SAMPLE.location} />
          <SampleLine label="Community advice" value={SAMPLE.advice} />
        </dl>
        <p className="mt-2 text-sm text-concrete-600">Those four lines come from the nomination, so they aren&rsquo;t editable here.</p>

        <div className="mt-auto flex items-center gap-2 pt-3">
          <Meta>{dirty ? "Unsaved changes" : "Saved"}</Meta>
          <Button type="submit" variant={dirty ? "dark" : "paper"} size="sm" className="ml-auto" disabled={!dirty || busy || headline.trim().length < 3}>
            {busy ? "Saving…" : "Save headline"}
          </Button>
        </div>
      </div>
    </form>
  );
}
