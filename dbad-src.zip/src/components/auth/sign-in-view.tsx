"use client";

import * as React from "react";
import Link from "next/link";
import { Container } from "@/components/layout/site-shell";
import { Button } from "@/components/ui/button";
import { Input, Label, Help, FieldError } from "@/components/ui/input";
import { Wordmark } from "@/components/brand/wordmark";
import { Avatar } from "@/components/brand/avatar";
import { AppleIcon, FacebookIcon, GoogleIcon, MailIcon } from "@/components/icons/ui";
import { cn } from "@/lib/utils";

export interface DemoAccount {
  id: string;
  label: string;
  blurb: string;
  handle: string;
}

export interface SignInActions {
  /** Demo mode only: sets the demo cookie. */
  demoSignIn?: (id: string, next: string) => Promise<void>;
  /** Supabase mode: sends a magic link. */
  emailSignIn?: (email: string, next: string) => Promise<{ ok: boolean; message?: string }>;
  /** Supabase mode: starts OAuth. */
  oauthSignIn?: (provider: "google" | "apple" | "facebook", next: string) => Promise<void>;
}

export function SignInView({ mode, demoAccounts = [], next = "/", actions, error }: { mode: "demo" | "supabase"; demoAccounts?: DemoAccount[]; next?: string; actions: SignInActions; error?: string }) {
  const [email, setEmail] = React.useState("");
  const [busy, setBusy] = React.useState<string | null>(null);
  const [message, setMessage] = React.useState<string | null>(null);
  const [err, setErr] = React.useState<string | null>(error ?? null);

  return (
    <Container size="md" className="py-12">
      <div className="mx-auto max-w-lg">
        <div className="text-center">
          <Wordmark className="mx-auto h-14 w-auto" />
          <h1 className="mt-6 text-4xl sm:text-5xl">Sign in.</h1>
          <p className="mt-2 text-ink-700">Nominate, vote, comment and earn badges. We want your handle, not your life story.</p>
        </div>

        {mode === "demo" ? (
          <div className="mt-8 border-[3px] border-ink-950 bg-paper-50 shadow-hard p-5 space-y-3">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600">Demo mode · pick a seat</p>
            {demoAccounts.map((a) => (
              <button
                key={a.id}
                type="button"
                disabled={busy !== null}
                onClick={async () => {
                  setBusy(a.id);
                  await actions.demoSignIn?.(a.id, next);
                }}
                className={cn("w-full flex items-center gap-4 text-left border-[3px] border-ink-950 bg-paper-100 hover:bg-warning-500 p-3 shadow-hard-sm", busy === a.id && "opacity-60")}
              >
                <Avatar seed={a.handle} size={44} />
                <span className="min-w-0">
                  <span className="block font-display uppercase text-xl leading-none">{a.label}</span>
                  <span className="block text-sm text-ink-700 mt-1">{a.blurb}</span>
                </span>
              </button>
            ))}
            <Help>Demo accounts exist because Supabase isn&rsquo;t configured. Set NEXT_PUBLIC_SUPABASE_URL and the anon key to enable real sign-in with email, Google, Apple and Facebook.</Help>
          </div>
        ) : (
          <div className="mt-8 border-[3px] border-ink-950 bg-paper-50 shadow-hard p-5 space-y-5">
            <div className="grid gap-2">
              {(
                [
                  { id: "google", label: "Continue with Google", Icon: GoogleIcon },
                  { id: "apple", label: "Continue with Apple", Icon: AppleIcon },
                  { id: "facebook", label: "Continue with Facebook", Icon: FacebookIcon },
                ] as const
              ).map((p) => (
                <Button key={p.id} variant="paper" size="lg" className="w-full justify-start" disabled={busy !== null} onClick={async () => { setBusy(p.id); await actions.oauthSignIn?.(p.id, next); setBusy(null); }}>
                  <p.Icon className="size-5" /> {p.label}
                </Button>
              ))}
            </div>
            <div className="flex items-center gap-3 font-mono text-[11px] uppercase tracking-widest text-concrete-600">
              <span className="h-px flex-1 bg-concrete-300" /> or email <span className="h-px flex-1 bg-concrete-300" />
            </div>
            <form
              className="space-y-3"
              onSubmit={async (e) => {
                e.preventDefault();
                setErr(null);
                setBusy("email");
                const res = await actions.emailSignIn?.(email, next);
                setBusy(null);
                if (res?.ok) setMessage(res.message ?? "Check your email for a sign-in link.");
                else setErr(res?.message ?? "Couldn't send the link.");
              }}
            >
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
              <Button type="submit" size="lg" className="w-full" disabled={busy !== null}>
                <MailIcon className="size-5" /> {busy === "email" ? "Sending…" : "Email me a sign-in link"}
              </Button>
              {message && <p className="text-sm font-semibold text-redeem-700">{message}</p>}
              <FieldError>{err}</FieldError>
            </form>
          </div>
        )}
        <p className="mt-6 text-center text-sm text-concrete-600">
          By signing in you agree to the{" "}
          <Link href="/standards" className="font-semibold underline decoration-warning-500 decoration-2">community standard</Link>. Call out the action, not the person.
        </p>
      </div>
    </Container>
  );
}
