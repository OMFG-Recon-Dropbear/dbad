import * as React from "react";
import { hash32 } from "@/lib/domain/utils";
import { cn } from "@/lib/utils";

const PALETTE = ["#f5c400", "#d7263d", "#3f9d57", "#2f2f2f", "#8a8a82", "#ffd21f"];

/**
 * Deterministic sticker avatar — a geometric "hazard badge" generated from the member's
 * handle. No uploads, no faces, nothing to moderate.
 */
export function Avatar({ seed, className, size = 40 }: { seed: string; className?: string; size?: number }) {
  const h = hash32(seed);
  const bg = PALETTE[h % PALETTE.length]!;
  const fg = bg === "#2f2f2f" || bg === "#d7263d" || bg === "#3f9d57" ? "#f7f3ea" : "#0f0f0f";
  const shape = (h >>> 8) % 4;
  const rot = ((h >>> 12) % 5) * 15 - 30;
  return (
    <svg viewBox="0 0 40 40" width={size} height={size} className={cn("shrink-0 border-2 border-ink-950 bg-paper-50", className)} aria-hidden>
      <rect width="40" height="40" fill={bg} />
      <g transform={`rotate(${rot} 20 20)`} fill={fg}>
        {shape === 0 && <path d="M20 6l14 26H6z" />}
        {shape === 1 && <rect x="9" y="9" width="22" height="22" />}
        {shape === 2 && <circle cx="20" cy="20" r="12" />}
        {shape === 3 && <path d="M20 5l4 11h11l-9 7 3 11-9-7-9 7 3-11-9-7h11z" />}
      </g>
      <text x="20" y="25" textAnchor="middle" fontFamily="DBAD Display, Impact, sans-serif" fontWeight="900" fontSize="14" fill={bg}>
        {seed.slice(0, 1).toUpperCase()}
      </text>
    </svg>
  );
}
