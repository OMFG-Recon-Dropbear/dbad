import * as React from "react";
import type { VoteTally } from "@/lib/domain/types";
import { summariseVotes, VERDICT_ORDER, VERDICT_SHORT } from "@/lib/domain/verdict";
import { cn } from "@/lib/utils";

const bandColour = {
  not: "bg-redeem-500",
  bit: "bg-warning-400",
  definitely: "bg-warning-600",
  absolute: "bg-alert-500",
  pending: "bg-concrete-300",
};

/**
 * The Dick-o-meter. A gauge from "Not a dick move" to "Absolute dickery" with the
 * community's needle, plus the vote distribution underneath. Playful, but honest.
 */
export function DickOMeter({ votes, compact, className, positive }: { votes: VoteTally; compact?: boolean; className?: string; positive?: boolean }) {
  const s = summariseVotes(votes);
  const needle = s.band === "pending" ? 50 : s.percent;
  const label = positive ? (s.band === "pending" ? "Verdict pending" : `${100 - s.percent}% not a dick`) : s.label;

  return (
    <div className={cn("w-full", className)} role="group" aria-label={`Dick-o-meter: ${label}, ${s.total} verdicts`}>
      <div className="flex items-baseline justify-between gap-3 mb-4">
        <span className={cn("font-display uppercase leading-none", compact ? "text-lg" : "text-2xl sm:text-3xl")}>{label}</span>
        <span className="font-mono text-xs uppercase tracking-wider text-concrete-600 tabular">
          {s.total} verdict{s.total === 1 ? "" : "s"}
        </span>
      </div>
      <div className="relative h-5 border-[3px] border-ink-950 bg-paper-100 overflow-visible">
        <div className="absolute inset-0 grid grid-cols-4">
          <div className="bg-redeem-500/80" />
          <div className="bg-warning-400/80" />
          <div className="bg-warning-600/80" />
          <div className="bg-alert-500/80" />
        </div>
        <div className="absolute inset-y-0 left-1/4 w-[3px] bg-ink-950/60" aria-hidden />
        <div className="absolute inset-y-0 left-1/2 w-[3px] bg-ink-950/60" aria-hidden />
        <div className="absolute inset-y-0 left-3/4 w-[3px] bg-ink-950/60" aria-hidden />
        {/* needle */}
        <div
          className={cn("absolute -top-2 -bottom-2 w-[5px] bg-ink-950 transition-[left] duration-500", s.band === "pending" && "opacity-40")}
          style={{ left: `calc(${needle}% - 2px)` }}
          aria-hidden
        >
          <span className="absolute -top-2 left-1/2 -translate-x-1/2 border-x-[7px] border-x-transparent border-t-[8px] border-t-ink-950" />
        </div>
      </div>
      {!compact && (
        <div className="mt-2 grid grid-cols-4 gap-1 font-mono text-[10px] sm:text-[11px] uppercase tracking-wide text-concrete-600">
          {VERDICT_ORDER.map((v) => (
            <div key={v} className={cn(v === "not" ? "text-left" : v === "absolute" ? "text-right" : "text-center")}>
              {VERDICT_SHORT[v]}
            </div>
          ))}
        </div>
      )}
      {!compact && s.total > 0 && (
        <ul className="mt-3 space-y-1.5" aria-label="Vote distribution">
          {s.distribution.map((d) => (
            <li key={d.verdict} className="flex items-center gap-2 text-sm">
              <span className="w-36 sm:w-44 shrink-0 font-semibold">{VERDICT_SHORT[d.verdict]}</span>
              <span className="flex-1 h-3 bg-concrete-200 border border-ink-950/30">
                <span className={cn("block h-full", bandColour[d.verdict])} style={{ width: `${d.percent}%` }} />
              </span>
              <span className="w-12 text-right font-mono text-xs tabular">{d.percent}%</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/** Thin one-line version for feed cards. */
export function VerdictBar({ votes, positive }: { votes: VoteTally; positive?: boolean }) {
  const s = summariseVotes(votes);
  const pct = s.band === "pending" ? 0 : s.agreePercent;
  const text = s.band === "pending" ? s.label : positive ? `${100 - s.percent}% not a dick` : `${pct}% dick move`;
  return (
    <div className="flex items-center gap-2" aria-label={`Community verdict: ${text}`}>
      <div className="h-2.5 flex-1 border-2 border-ink-950 bg-paper-100 overflow-hidden">
        <div
          className={cn("h-full", positive ? "bg-redeem-500" : s.band === "pending" ? "bg-concrete-300" : bandColour[s.band])}
          style={{ width: `${s.band === "pending" ? 100 : positive ? 100 - s.percent : s.percent}%` }}
        />
      </div>
      <span className="font-mono text-[11px] uppercase tracking-wider text-concrete-600 whitespace-nowrap">{text}</span>
    </div>
  );
}
