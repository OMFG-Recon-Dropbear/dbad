import * as React from "react";
import Image from "next/image";
import type { Photo } from "@/lib/domain/types";
import { cn } from "@/lib/utils";
import { CategoryIcon } from "@/components/icons/categories";
import type { CategoryId } from "@/lib/domain/types";

/**
 * Evidence photo frame with corner ticks and an optional mono caption strip.
 * Falls back to a big category icon on hazard yellow when a nomination has no photo,
 * so text-only dick moves still look intentional in the feed.
 */
export function EvidenceFrame({
  photo,
  categoryId,
  caption,
  priority,
  sizes = "(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw",
  className,
  aspect = "aspect-[4/3]",
  fill = true,
}: {
  photo?: Photo;
  categoryId: CategoryId;
  caption?: React.ReactNode;
  priority?: boolean;
  sizes?: string;
  className?: string;
  aspect?: string;
  fill?: boolean;
}) {
  return (
    <figure className={cn("relative bg-ink-950 border-[3px] border-ink-950", className)}>
      <div className={cn("evidence-frame relative overflow-hidden bg-ink-900 border-0", aspect)}>
        {photo ? (
          fill ? (
            <Image src={photo.url} alt={photo.alt} fill sizes={sizes} priority={priority} className="object-cover" />
          ) : (
            <Image src={photo.url} alt={photo.alt} width={photo.width} height={photo.height} sizes={sizes} priority={priority} className="h-full w-full object-cover" />
          )
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-warning-500 text-ink-950">
            <div className="absolute inset-0 opacity-[0.08] hazard" aria-hidden />
            <CategoryIcon id={categoryId} className="relative size-[38%] max-h-40" />
            <span className="absolute bottom-3 left-3 font-mono text-[11px] uppercase tracking-widest text-ink-950/80">No photo · text nomination</span>
          </div>
        )}
        {photo && photo.redactionCount > 0 && (
          <span className="absolute top-2 right-2 font-mono text-[10px] uppercase tracking-wider bg-ink-950/85 text-paper-50 px-1.5 py-1">
            {photo.redactionCount} redaction{photo.redactionCount === 1 ? "" : "s"}
          </span>
        )}
      </div>
      {caption && <figcaption className="flex items-center gap-3 bg-ink-950 text-paper-50 font-mono text-[11px] uppercase tracking-wider px-3 py-2">{caption}</figcaption>}
    </figure>
  );
}
