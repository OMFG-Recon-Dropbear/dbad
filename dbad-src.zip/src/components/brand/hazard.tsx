import * as React from "react";
import { cn } from "@/lib/utils";

/** Hazard tape divider. */
export function HazardTape({ className, thin, red }: { className?: string; thin?: boolean; red?: boolean }) {
  return <div aria-hidden className={cn(red ? "hazard-red" : thin ? "hazard-thin" : "hazard", thin ? "h-2" : "h-4", className)} />;
}

/** Section heading with a stencil label and a hazard rule. */
export function SectionHeading({
  kicker,
  title,
  action,
  className,
  dark,
}: {
  kicker?: string;
  title: React.ReactNode;
  action?: React.ReactNode;
  className?: string;
  dark?: boolean;
}) {
  return (
    <div className={cn("flex flex-wrap items-end justify-between gap-3", className)}>
      <div>
        {kicker && <p className={cn("font-mono text-xs uppercase tracking-[0.2em] mb-2", dark ? "text-warning-500" : "text-concrete-600")}>{kicker}</p>}
        <h2 className={cn("text-3xl sm:text-4xl md:text-5xl", dark ? "text-paper-50" : "text-ink-950")}>{title}</h2>
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

/** Ticket-style number plate: DBAD-0042 */
export function CodePlate({ code, className, size = "md" }: { code: string; className?: string; size?: "sm" | "md" | "lg" }) {
  return (
    <span
      className={cn(
        "inline-block font-mono font-bold tracking-wider bg-paper-50 text-ink-950 border-2 border-ink-950 leading-none rounded-xs",
        size === "sm" && "text-[11px] px-1.5 py-1",
        size === "md" && "text-sm px-2 py-1",
        size === "lg" && "text-lg px-3 py-1.5",
        className,
      )}
    >
      {code}
    </span>
  );
}
