import * as React from "react";
import { cn } from "@/lib/utils";

const tones = {
  red: "text-alert-500",
  ink: "text-ink-950",
  yellow: "text-warning-700",
  green: "text-redeem-600",
  concrete: "text-concrete-500",
  paper: "text-paper-50",
};

const sizes = {
  sm: "text-sm",
  md: "text-xl",
  lg: "text-3xl",
  xl: "text-5xl sm:text-6xl",
};

/**
 * Rubber stamp. Rotated, grungy, blends into paper. Use for verdicts and statuses:
 * REDEEMED, DICK MOVE, OVERRULED, PENDING.
 */
export function Stamp({
  children,
  tone = "red",
  size = "md",
  className,
  animate,
  flat,
  rotate,
}: {
  children: React.ReactNode;
  tone?: keyof typeof tones;
  size?: keyof typeof sizes;
  className?: string;
  animate?: boolean;
  /** No grunge mask (for dark backgrounds or print). */
  flat?: boolean;
  rotate?: number;
}) {
  return (
    <span
      className={cn(flat ? "stamp-flat" : "stamp", tones[tone], sizes[size], animate && "animate-stamp-in", className)}
      style={rotate !== undefined ? { transform: `rotate(${rotate}deg)` } : undefined}
    >
      {children}
    </span>
  );
}

/** Small status pill used on cards: REDEEMED / OVERRULED / NOT A DICK / DICK MOVE OF THE WEEK */
export function StatusStamp({ status }: { status: "redeemed" | "overruled" | "not_a_dick" | "week" | "pending" | "removed" }) {
  const map = {
    redeemed: { label: "REDEEMED", tone: "green" as const },
    overruled: { label: "OVERRULED", tone: "concrete" as const },
    not_a_dick: { label: "DEFINITELY NOT A DICK", tone: "green" as const },
    week: { label: "DICK MOVE OF THE WEEK", tone: "red" as const },
    pending: { label: "AWAITING MODERATION", tone: "concrete" as const },
    removed: { label: "REMOVED", tone: "concrete" as const },
  };
  const m = map[status];
  return (
    <Stamp tone={m.tone} size="sm" rotate={-4} flat className="!text-xs sm:!text-sm bg-paper-50/95 shadow-hard-sm">
      {m.label}
    </Stamp>
  );
}
