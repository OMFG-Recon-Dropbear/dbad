import * as React from "react";
import { WORDMARK_CUTS, WORDMARK_HEIGHT, WORDMARK_PATHS, WORDMARK_WIDTH } from "./wordmark-geometry";

let counter = 0;

/**
 * The DBAD stencil wordmark. Renders as an inline SVG so it's crisp at any size and
 * inherits `currentColor`. `id` must be unique per instance because of the mask.
 */
export function Wordmark({ className, title = "DBAD", id, style }: { className?: string; title?: string; id?: string; style?: React.CSSProperties }) {
  const reactId = React.useId();
  const maskId = `wm-${id ?? reactId.replace(/[^a-zA-Z0-9]/g, "")}-${counter++ % 1000}`;
  return (
    <svg viewBox={`0 0 ${WORDMARK_WIDTH} ${WORDMARK_HEIGHT}`} className={className} style={style} role="img" aria-label={title} focusable="false">
      <defs>
        <mask id={maskId} maskUnits="userSpaceOnUse" x="0" y="0" width={WORDMARK_WIDTH} height={WORDMARK_HEIGHT}>
          <rect width={WORDMARK_WIDTH} height={WORDMARK_HEIGHT} fill="white" />
          {WORDMARK_CUTS.map(([x, y, w, h], i) => (
            <rect key={i} x={x} y={y} width={w} height={h} fill="black" />
          ))}
        </mask>
      </defs>
      <g fill="currentColor" mask={`url(#${maskId})`}>
        {WORDMARK_PATHS.map((d, i) => (
          <path key={i} d={d} />
        ))}
      </g>
    </svg>
  );
}

/** Wordmark on a yellow plate with hazard tape — the app-icon / sticker treatment. */
export function WordmarkPlate({ className }: { className?: string }) {
  return (
    <span className={`inline-flex items-center bg-warning-500 text-ink-950 border-[3px] border-ink-950 px-2 py-1 ${className ?? ""}`}>
      <Wordmark className="h-[1em] w-auto" />
    </span>
  );
}

/** Stacked lockup: DBAD / DON'T BE A DICK. */
export function Lockup({ className, dark }: { className?: string; dark?: boolean }) {
  return (
    <div className={`flex flex-col items-start gap-1 ${className ?? ""}`}>
      <Wordmark className={`h-10 w-auto ${dark ? "text-warning-500" : "text-ink-950"}`} />
      <span className={`font-display uppercase tracking-wide text-sm leading-none ${dark ? "text-paper-50" : "text-ink-950"}`}>Don&rsquo;t be a dick.</span>
    </div>
  );
}
