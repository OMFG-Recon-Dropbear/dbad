import { Container, PageHeader } from "@/components/layout/site-shell";
import { ButtonLink } from "@/components/ui/button";
import { Wordmark } from "@/components/brand/wordmark";
import { HazardTape } from "@/components/brand/hazard";
import { SITE } from "@/lib/site";

export function AboutView() {
  return (
    <>
      <PageHeader dark kicker="Philosophy" title={<>It&rsquo;s not about ruining someone&rsquo;s day.</>} intro="It's about recognising the small choices we all make that affect everyone around us." />
      <Container size="md" className="py-12 space-y-12">
        <section className="space-y-5 text-lg leading-relaxed">
          <p>
            Sometimes people do things that are inconsiderate, selfish, ridiculous or just plain annoying. A car across a footpath. A trolley in the middle of a bay. Fish in the office microwave. None of it is a crime. All of it makes the day a little worse for everyone else.
          </p>
          <p>
            DBAD gives the community a humorous way of saying what we&rsquo;re all thinking: <strong>Don&rsquo;t be a dick.</strong>
          </p>
          <p>
            We&rsquo;re very particular about one distinction. There&rsquo;s a difference between <em>a person being a dick</em> and <em>someone doing something that was a dick move</em>. DBAD is built entirely around the second one. We call out the action. We never build a file on the person. There are no names, no plates, no faces, no addresses — the platform refuses them, moderators remove them, and the community standard is blunt about it.
          </p>
        </section>

        <section className="bg-warning-500 border-[3px] border-ink-950 shadow-hard p-6 sm:p-8">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-ink-950/70">The point</p>
          <p className="mt-3 text-4xl sm:text-5xl leading-[0.92]">We&rsquo;ve all been a dick at some point.</p>
          <p className="mt-4 text-lg leading-relaxed">
            The objective isn&rsquo;t perfection. It&rsquo;s awareness. Take the joke. Fix the problem. Move on. That&rsquo;s why every nomination can end in <strong>REDEMPTION</strong>, and why the community gets more excited about a car being moved than about the car being there in the first place.
          </p>
        </section>

        <section className="grid gap-6 sm:grid-cols-2">
          {[
            { t: "Behaviour, not people", b: "A nomination describes what happened and where, at suburb level. Nothing about who." },
            { t: "Humour, not cruelty", b: "The DBAD wording helper strips personal attacks and keeps the facts funny. Threats get you banned." },
            { t: "Redemption is the goal", b: "Fixed it? It's marked REDEEMED and celebrated. Most people do better once they know." },
            { t: "Balance", b: "NOT A DICK nominations celebrate trolley-returners and tyre-changers. Standards work both ways." },
            { t: "Right of reply", b: "Think a post is about you? Ask for removal, correction, anonymisation, context or a reply — without identifying yourself." },
            { t: "Moderated, audited", b: "Every nomination with a photo is checked before publication. Every moderator action is logged." },
          ].map((c) => (
            <div key={c.t} className="border-[3px] border-ink-950 bg-paper-100 p-5 shadow-hard-sm">
              <h3 className="text-2xl">{c.t}</h3>
              <p className="mt-2 text-ink-700 leading-snug">{c.b}</p>
            </div>
          ))}
        </section>

        <section className="text-center">
          <Wordmark className="mx-auto h-16 w-auto" />
          <p className="mt-6 text-3xl sm:text-4xl leading-[0.95]">Take the joke.<br />Fix the problem.<br />Move on.</p>
          <p className="mt-6 font-display uppercase text-2xl text-warning-700">{SITE.closing}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <ButtonLink href="/standards" variant="dark">Read the community standard</ButtonLink>
            <ButtonLink href="/nominate">Nominate a dick move</ButtonLink>
          </div>
        </section>
      </Container>
      <HazardTape thin />
    </>
  );
}
