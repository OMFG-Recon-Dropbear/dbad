"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import type { AppealAction, IncidentSummary } from "@/lib/domain/types";
import type { AppealActions } from "@/lib/actions/types";
import { Container, PageHeader } from "@/components/layout/site-shell";
import { Button } from "@/components/ui/button";
import { FieldError, Help, Input, Label, Textarea } from "@/components/ui/input";
import { Stamp } from "@/components/brand/stamp";
import { useToast } from "@/components/ui/toast";
import { cn } from "@/lib/utils";
import { IncidentRow } from "@/components/incident/incident-card";
import { ShieldIcon } from "@/components/icons/ui";

const ACTIONS: Array<{ id: AppealAction; label: string; blurb: string }> = [
  { id: "removal", label: "Remove it", blurb: "Take the nomination down." },
  { id: "correction", label: "Correct it", blurb: "Something in the description is wrong." },
  { id: "anonymisation", label: "Anonymise it", blurb: "Blur more, drop the place name, remove a detail." },
  { id: "context", label: "Add context", blurb: "There's a reason the photo doesn't show." },
  { id: "reply", label: "Right of reply", blurb: "Publish your side, without your identity." },
  { id: "redemption", label: "Mark it redeemed", blurb: "You fixed it. Say so." },
];

export function AboutYouView({ incident, code, actions, initialAction }: { incident: IncidentSummary | null; code?: string; actions: AppealActions; initialAction?: AppealAction }) {
  const toast = useToast();
  const router = useRouter();
  const [action, setAction] = React.useState<AppealAction>(initialAction ?? "removal");
  const [lookup, setLookup] = React.useState(code ?? "");
  const [message, setMessage] = React.useState("");
  const [contact, setContact] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [reference, setReference] = React.useState<string | null>(null);

  return (
    <>
      <PageHeader
        kicker="Right of reply"
        title="Is this about you?"
        intro="If you believe a nomination concerns you, you can ask for removal, a correction, anonymisation, added context, a right of reply or redemption status. You don't have to identify yourself publicly, and you don't need an account."
      />
      <Container size="lg" className="py-10 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div>
          {reference ? (
            <div className="border-[3px] border-ink-950 bg-paper-50 shadow-hard p-8 text-center">
              <Stamp tone="green" size="lg" animate flat className="bg-paper-50">Received</Stamp>
              <h2 className="mt-6 text-4xl">Thanks. A human will look at it.</h2>
              <p className="mt-3 text-ink-700">Reference <span className="font-mono font-bold">{reference}</span>. Requests about identifying details are actioned first — usually within hours. If you left a contact, we&rsquo;ll reply there.</p>
            </div>
          ) : (
            <form
              className="space-y-6"
              onSubmit={async (e) => {
                e.preventDefault();
                setError(null);
                if (!incident) return setError("Enter the DBAD code printed on the notice, or paste the nomination link.");
                if (message.trim().length < 10) return setError("Tell us a little more so we can act on it.");
                setBusy(true);
                const res = await actions.submit({ incidentId: incident.id, requestedAction: action, message: message.trim(), contact: contact.trim() || undefined });
                setBusy(false);
                if (res.ok && res.data) {
                  setReference(res.data.reference);
                  toast.push({ tone: "green", title: "Request received", body: res.message });
                } else setError(res.message ?? "Couldn't send that. Try again.");
              }}
            >
              <div className="border-[3px] border-ink-950 bg-paper-50 p-5">
                <Label htmlFor="code" hint="Printed on the notice (e.g. DBAD-0042), or in the page address.">Which nomination?</Label>
                <div className="flex gap-2">
                  <Input
                    id="code"
                    name="code"
                    value={lookup}
                    onChange={(e) => setLookup(e.target.value.toUpperCase())}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        router.push(`/about-you?code=${encodeURIComponent(lookup.trim())}`);
                      }
                    }}
                    placeholder="DBAD-0042"
                    className="font-mono uppercase"
                  />
                  <Button type="button" variant="dark" onClick={() => router.push(`/about-you?code=${encodeURIComponent(lookup.trim())}`)}>
                    Find
                  </Button>
                </div>
                {incident ? (
                  <div className="mt-3"><IncidentRow incident={incident} /></div>
                ) : code ? (
                  <FieldError>We couldn&rsquo;t find a public nomination with that code.</FieldError>
                ) : null}
              </div>

              <div className="border-[3px] border-ink-950 bg-paper-50 p-5">
                <Label>What would you like?</Label>
                <div className="grid gap-2 sm:grid-cols-2">
                  {ACTIONS.map((a) => (
                    <button
                      key={a.id}
                      type="button"
                      aria-pressed={action === a.id}
                      onClick={() => setAction(a.id)}
                      className={cn("text-left border-[3px] border-ink-950 rounded-sm p-3", action === a.id ? "bg-ink-950 text-warning-500 shadow-hard-yellow" : "bg-paper-100 hover:bg-white shadow-hard-sm")}
                    >
                      <span className="block font-display uppercase text-lg leading-none">{a.label}</span>
                      <span className={cn("block text-xs mt-1", action === a.id ? "text-paper-50/80" : "text-concrete-600")}>{a.blurb}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-[3px] border-ink-950 bg-paper-50 p-5 space-y-4">
                <div>
                  <Label htmlFor="msg" hint={action === "reply" ? "This is the text we'd publish beneath the nomination, without your identity. Keep it about what happened." : "What's wrong, or what's missing? Moderators only see this."}>
                    {action === "reply" ? "Your reply" : "Tell us more"}
                  </Label>
                  <Textarea id="msg" value={message} onChange={(e) => setMessage(e.target.value)} rows={5} maxLength={2000} />
                </div>
                <div>
                  <Label htmlFor="contact" hint="Optional. Email or phone, seen by moderators only, used to reply to you and nothing else.">Contact</Label>
                  <Input id="contact" value={contact} onChange={(e) => setContact(e.target.value)} placeholder="you@example.com" autoComplete="email" />
                </div>
                <FieldError>{error}</FieldError>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <Help className="mt-0">No account needed. Nothing here is published unless you asked for a right of reply.</Help>
                  <Button type="submit" size="lg" disabled={busy}>{busy ? "Sending…" : "Send request"}</Button>
                </div>
              </div>
            </form>
          )}
        </div>
        <aside className="space-y-4">
          <div className="bg-ink-950 text-paper-50 border-[3px] border-ink-950 p-5 shadow-hard-yellow">
            <ShieldIcon className="size-8 text-warning-500" />
            <p className="mt-3 font-display uppercase text-2xl leading-none">How this works</p>
            <ol className="mt-3 space-y-2 text-sm text-paper-50/85 list-decimal pl-4">
              <li>Your request goes to the moderation queue, visible only to moderators.</li>
              <li>Anything identifying is removed immediately, before the rest is considered.</li>
              <li>You&rsquo;re not asked to prove who you are. We act on the content, not the person.</li>
              <li>Right-of-reply text is published verbatim (minus identifying details) with a note that moderators verified the request.</li>
              <li>Redemption requests flip the nomination to REDEEMED — the community likes those best.</li>
            </ol>
          </div>
          <div className="border-[3px] border-ink-950 bg-paper-100 p-5 text-sm leading-snug">
            <p className="font-display uppercase text-lg leading-none mb-2">A note on fairness</p>
            <p>Nominations are about behaviour in public. If the description is wrong, we fix it. If the community got it wrong, we say so — publicly, with an OVERRULED stamp. We&rsquo;d rather be fair than funny.</p>
          </div>
        </aside>
      </Container>
    </>
  );
}
