import { Container, PageHeader } from "@/components/layout/site-shell";

export function PrivacyView() {
  return (
    <>
      <PageHeader kicker="Privacy" title="What we collect, and what we refuse to." intro="DBAD is built so that the platform never becomes a dossier on anyone — including the people who get nominated." />
      <Container size="md" className="py-12 space-y-10 text-lg leading-relaxed">
        <section>
          <h2 className="text-3xl mb-3">People who get nominated</h2>
          <p>We don&rsquo;t collect anything about them. Nominations describe behaviour in a public place at suburb level. Faces and number plates are blurred on the submitter&rsquo;s device before upload and checked again by moderators. Text is scanned for phone numbers, emails, addresses, plates and names before it can be published. There is no database table for &ldquo;the person&rdquo;, and there never will be.</p>
        </section>
        <section>
          <h2 className="text-3xl mb-3">Members</h2>
          <p>An email address (or the Google, Apple or Facebook account you sign in with), a handle, and your activity on DBAD: nominations, verdicts, reactions, comments and badges. Profiles show your handle, a general home area if you choose one, and contributor statistics. There are no scores for alleged offenders — gamification applies to contributors only.</p>
        </section>
        <section>
          <h2 className="text-3xl mb-3">Photos</h2>
          <p>Photos are downscaled and re-encoded on your device, which also strips embedded metadata such as GPS coordinates. Only the redacted version is uploaded. Moderators can blur further or remove a photo without deleting the nomination.</p>
        </section>
        <section>
          <h2 className="text-3xl mb-3">Location</h2>
          <p>If you use &ldquo;use my general location&rdquo;, coordinates are rounded to roughly a kilometre before they leave your device and are only used to suggest a suburb. The map shows areas, not points. Residential addresses are rejected by the platform.</p>
        </section>
        <section>
          <h2 className="text-3xl mb-3">Requests</h2>
          <p>&ldquo;Is this about you?&rdquo; requests and reports are visible to moderators only. A contact detail you provide there is used to reply to you and nothing else. Right-of-reply text is published only if you ask for it, without your identity.</p>
        </section>
        <section>
          <h2 className="text-3xl mb-3">Facebook</h2>
          <p>DBAD never scrapes Facebook. If you paste a post link, it is stored for moderators as provenance and never displayed publicly. You describe the incident yourself.</p>
        </section>
        <section>
          <h2 className="text-3xl mb-3">Fonts, analytics, third parties</h2>
          <p>Fonts are self-hosted. There is no advertising and no third-party tracking. Aggregate statistics (dick moves per week, most active areas) are computed from published nominations only.</p>
        </section>
      </Container>
    </>
  );
}
