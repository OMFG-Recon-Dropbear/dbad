import { Container, PageHeader } from "@/components/layout/site-shell";
import { ButtonLink } from "@/components/ui/button";
import { CheckIcon, XIcon } from "@/components/icons/ui";

const RULES = [
  { t: "Photograph the behaviour, not the person.", b: "Faces, plates, house numbers and anything identifying get blurred before you submit, and checked again by moderators." },
  { t: "Don't publish identifying information.", b: "Names, phone numbers, private addresses, workplace details irrelevant to the incident, personal social-media accounts, medical information, anything about children." },
  { t: "Don't trespass.", b: "If you have to enter private property to see it, you don't have a nomination." },
  { t: "Don't interfere with vehicles or property.", b: "A notice under a wiper is a notice. Anything on the paint, in the mirror or through a window is not." },
  { t: "Don't confront people for content.", b: "DBAD isn't a prank channel. Nothing here is worth an argument in a car park." },
  { t: "Don't manufacture incidents.", b: "If it wouldn't have happened without you, it didn't happen." },
  { t: "Don't use DBAD to settle personal disputes.", b: "Neighbours, exes, colleagues, that guy from the group chat — no. Moderators can tell." },
  { t: "Don't encourage harassment.", b: "No pile-ons, no 'someone should…', no tracking anyone down. Comments that head that way get removed." },
  { t: "If you're wrong, own it.", b: "The community can overrule a nomination. Accepting it earns respect; arguing it doesn't." },
  { t: "If they fix it, acknowledge it.", b: "Mark it REDEEMED. It's the whole point." },
];

const NEVER = ["Names", "Phone numbers", "Private addresses", "Irrelevant workplace details", "Personal social-media accounts", "Threats", "Defamatory accusations", "Medical information", "Anything about children", "Targeted harassment"];
const FINE = ["Public places: car parks, beaches, roads, parks, shopping centres", "Suburb or town", "What happened, factually", "Who was affected", "Humour aimed at the behaviour", "Acknowledging redemption"];

export function StandardsView() {
  return (
    <>
      <PageHeader kicker="Community standard" title={<>Call out the action.<br />Not the person.</>} intro="The rules are short because they're obvious. Breaking them gets content removed and repeat offenders removed with it." />
      <Container size="lg" className="py-12 space-y-12">
        <ol className="grid gap-4 sm:grid-cols-2">
          {RULES.map((r, i) => (
            <li key={r.t} className="relative border-[3px] border-ink-950 bg-paper-50 p-5 pt-7 shadow-hard-sm">
              <span className="absolute -top-4 left-4 bg-ink-950 text-warning-500 font-mono font-bold text-sm px-2 py-1 border-[3px] border-ink-950 leading-none">{String(i + 1).padStart(2, "0")}</span>
              <h3 className="text-2xl">{r.t}</h3>
              <p className="mt-2 text-ink-700 leading-snug">{r.b}</p>
            </li>
          ))}
        </ol>

        <section className="grid gap-6 md:grid-cols-2">
          <div className="border-[3px] border-alert-500 bg-paper-100 p-5">
            <h3 className="text-2xl text-alert-600 inline-flex items-center gap-2"><XIcon className="size-6" /> Never publish</h3>
            <ul className="mt-3 space-y-1.5">
              {NEVER.map((n) => (
                <li key={n} className="flex items-center gap-2"><span className="size-2 bg-alert-500" aria-hidden />{n}</li>
              ))}
            </ul>
          </div>
          <div className="border-[3px] border-redeem-600 bg-paper-100 p-5">
            <h3 className="text-2xl text-redeem-700 inline-flex items-center gap-2"><CheckIcon className="size-6" /> Fine</h3>
            <ul className="mt-3 space-y-1.5">
              {FINE.map((n) => (
                <li key={n} className="flex items-center gap-2"><span className="size-2 bg-redeem-500" aria-hidden />{n}</li>
              ))}
            </ul>
          </div>
        </section>

        <section className="bg-ink-950 text-paper-50 border-[3px] border-ink-950 shadow-hard-yellow p-6 sm:p-10 text-center">
          <p className="font-mono text-xs uppercase tracking-[0.25em] text-warning-500">Above all</p>
          <p className="mt-4 text-4xl sm:text-5xl md:text-6xl leading-[0.9]">
            Don&rsquo;t be a dick while telling someone else <span className="text-warning-500">not to be a dick.</span>
          </p>
        </section>

        <section className="grid gap-4 sm:grid-cols-3">
          {[
            { h: "Reporting", b: "Every nomination and comment has a report button. Identifying details and anything about children are actioned first.", href: "/feed", label: "Browse" },
            { h: "Is this about you?", b: "Ask for removal, correction, anonymisation, context, a right of reply or redemption status without identifying yourself publicly.", href: "/about-you", label: "Start a request" },
            { h: "Appeals", b: "Had a nomination removed or overruled? Reply to the moderator's note or lodge an appeal — a different moderator reviews it.", href: "/about-you?action=context", label: "Lodge an appeal" },
          ].map((c) => (
            <div key={c.h} className="border-[3px] border-ink-950 bg-paper-50 p-5 flex flex-col">
              <h3 className="text-2xl">{c.h}</h3>
              <p className="mt-2 text-ink-700 leading-snug flex-1">{c.b}</p>
              <ButtonLink href={c.href} variant="outline" size="sm" className="mt-4 self-start">{c.label}</ButtonLink>
            </div>
          ))}
        </section>
      </Container>
    </>
  );
}
