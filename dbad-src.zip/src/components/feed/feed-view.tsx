import Link from "next/link";
import type { FeedProps } from "@/lib/loaders/feed";
import { feedHref } from "@/lib/loaders/feed";
import { CATEGORIES } from "@/lib/domain/categories";
import { Container, PageHeader } from "@/components/layout/site-shell";
import { IncidentCard } from "@/components/incident/incident-card";
import { LinkTabs } from "@/components/ui/tabs";
import { ButtonLink } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { CategoryIcon } from "@/components/icons/categories";
import { ArrowRightIcon, SearchIcon } from "@/components/icons/ui";
import { cn } from "@/lib/utils";

export function FeedView({ page, filters, clusters, basePath, kind }: FeedProps) {
  const positive = kind === "not_a_dick";
  const sortTabs = [
    { value: "latest", label: "Latest", href: feedHref(basePath, filters, { sort: "latest" }) },
    { value: "top", label: positive ? "Most loved" : "Top dickery", href: feedHref(basePath, filters, { sort: "top" }) },
    ...(positive ? [] : [{ value: "redeemed", label: "Redeemed", href: feedHref(basePath, filters, { sort: "redeemed" }) }]),
  ];
  const activeFilters = [filters.categoryId, filters.state, filters.region, filters.query].filter(Boolean).length;

  return (
    <>
      <PageHeader
        kicker={positive ? "Balance" : "Spotted in the wild"}
        title={
          positive ? (
            <>
              Definitely <span className="text-redeem-600">not</span> a dick.
            </>
          ) : (
            <>
              Latest <span className="text-warning-700">dick moves</span>
            </>
          )
        }
        intro={
          positive
            ? "Trolleys returned, rubbish picked up, cars moved the second someone realised. The community standard, demonstrated."
            : "Fresh nominations from the community. Cast your verdict, have a laugh, and keep an eye out for redemption."
        }
      >
        <form action={basePath} method="get" className="flex gap-2 max-w-xl" role="search">
          {filters.categoryId && <input type="hidden" name="category" value={filters.categoryId} />}
          {filters.state && <input type="hidden" name="state" value={filters.state} />}
          <label className="sr-only" htmlFor="feed-q">Search nominations</label>
          <div className="relative flex-1">
            <SearchIcon className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 size-5 text-concrete-600" />
            <input
              id="feed-q"
              name="q"
              defaultValue={filters.query ?? ""}
              placeholder={positive ? "Search good deeds…" : "Search dick moves, suburbs, places…"}
              className="w-full bg-white border-[3px] border-ink-950 rounded-sm pl-11 pr-3 py-3 text-base shadow-hard-sm"
            />
          </div>
          <button type="submit" className="border-[3px] border-ink-950 bg-ink-950 text-warning-500 font-display uppercase px-4 rounded-sm shadow-hard-yellow">
            Search
          </button>
        </form>
      </PageHeader>

      <Container className="py-8">
        {/* Category chips */}
        <div className="flex gap-2 overflow-x-auto scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0 pb-2" role="navigation" aria-label="Categories">
          <Link
            href={feedHref(basePath, filters, { categoryId: undefined })}
            className={cn(
              "shrink-0 inline-flex items-center gap-2 border-[3px] border-ink-950 rounded-sm px-3 py-2 text-sm font-semibold leading-none",
              !filters.categoryId ? "bg-ink-950 text-warning-500 shadow-hard-yellow" : "bg-paper-50 shadow-hard-sm hover:bg-white",
            )}
          >
            All
          </Link>
          {CATEGORIES.map((c) => (
            <Link
              key={c.id}
              href={feedHref(basePath, filters, { categoryId: c.id })}
              className={cn(
                "shrink-0 inline-flex items-center gap-2 border-[3px] border-ink-950 rounded-sm px-3 py-2 text-sm font-semibold leading-none",
                filters.categoryId === c.id ? "bg-ink-950 text-warning-500 shadow-hard-yellow" : "bg-paper-50 shadow-hard-sm hover:bg-white",
              )}
            >
              <CategoryIcon id={c.id} className="size-4" />
              {c.short}
            </Link>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <LinkTabs items={sortTabs} current={filters.sort ?? "latest"} size="sm" className="!mx-0 !px-0" />
          <div className="flex items-center gap-2 text-sm text-concrete-600">
            <span className="font-mono text-xs uppercase tracking-wider">
              {page.total} {positive ? "good deed" : "nomination"}{page.total === 1 ? "" : "s"}
              {filters.region ? ` around ${filters.region}` : filters.state ? ` in ${filters.state}` : ""}
            </span>
            {activeFilters > 0 && (
              <Link href={basePath} className="font-semibold underline decoration-warning-500 decoration-2 underline-offset-2">
                Clear filters
              </Link>
            )}
          </div>
        </div>

        {/* Region chips (from map clusters) */}
        {clusters.length > 1 && (
          <div className="mt-3 flex gap-2 overflow-x-auto scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0 pb-1" aria-label="Areas">
            {clusters.slice(0, 10).map((c) => (
              <Link
                key={c.region}
                href={feedHref(basePath, filters, { region: filters.region === c.region ? undefined : c.region })}
                className={cn(
                  "shrink-0 inline-flex items-center gap-1.5 border-2 border-ink-950 rounded-xs px-2 py-1 font-mono text-[11px] uppercase tracking-wider",
                  filters.region === c.region ? "bg-warning-500" : "bg-paper-100 hover:bg-white",
                )}
              >
                {c.region} <span className="text-concrete-600">{positive ? c.notADick : c.count}</span>
              </Link>
            ))}
          </div>
        )}

        {page.items.length === 0 ? (
          <div className="mt-8">
            <EmptyState
              stamp={positive ? "NOTHING YET" : "ALL CLEAR"}
              title={positive ? "No good deeds match that." : "No dick moves match that."}
              body={positive ? "Seen someone do the right thing? Nominate it." : "Either humanity is improving or your filters are too specific. Try clearing them."}
              action={{ href: positive ? "/nominate?kind=not_a_dick" : "/nominate", label: positive ? "Nominate a not-a-dick" : "Nominate a dick move" }}
            />
          </div>
        ) : (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {page.items.map((inc, i) => (
              <IncidentCard key={inc.id} incident={inc} priority={i < 3} />
            ))}
          </div>
        )}

        {page.nextCursor && (
          <div className="mt-10 flex justify-center">
            <ButtonLink href={feedHref(basePath, filters, { cursor: page.nextCursor })} variant="dark" size="lg">
              More {positive ? "good deeds" : "dick moves"} <ArrowRightIcon className="size-5" />
            </ButtonLink>
          </div>
        )}
      </Container>
    </>
  );
}
