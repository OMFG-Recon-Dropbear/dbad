import type { FeaturedSet } from "@/lib/data/repository";
import { summariseVotes } from "@/lib/domain/verdict";
import { relativeTime } from "@/lib/domain/time";
import { Container, PageHeader } from "@/components/layout/site-shell";
import { IncidentCard, locationLabel } from "@/components/incident/incident-card";
import { EvidenceFrame } from "@/components/brand/evidence";
import { DickOMeter } from "@/components/brand/dick-o-meter";
import { SectionHeading, CodePlate } from "@/components/brand/hazard";
import { Stamp } from "@/components/brand/stamp";
import { Badge, Meta } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { CategoryIcon } from "@/components/icons/categories";
import { ArrowRightIcon, MapPinIcon } from "@/components/icons/ui";

export function WeekView({ featured }: { featured: FeaturedSet }) {
  const { week, month, greatest, mostRedeemed } = featured;
  return (
    <>
      <PageHeader
        dark
        kicker="Community pick · updated weekly"
        title={
          <>
            Dick Move <span className="text-warning-500">of the Week</span>
          </>
        }
        intro="Chosen by community verdict and a moderator's sanity check. It's an award nobody wants, for behaviour everybody recognises."
      />
      <Container className="py-10 space-y-14">
        {week ? (
          <article className="grid gap-0 lg:grid-cols-[1.3fr_1fr] bg-paper-50 border-[3px] border-ink-950 shadow-hard-lg">
            <div className="relative">
              <EvidenceFrame photo={week.photos[0]} categoryId={week.categoryId} priority className="h-full border-0 lg:border-r-[3px]" aspect="aspect-[4/3] lg:aspect-auto lg:h-full" sizes="(min-width:1024px) 60vw, 100vw" />
              <div className="absolute top-4 left-4 z-[2]">
                <Stamp tone="red" size="lg" animate>
                  This week
                </Stamp>
              </div>
            </div>
            <div className="p-5 sm:p-7 flex flex-col gap-4">
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="gap-1.5"><CategoryIcon id={week.categoryId} className="size-3.5" />{week.category.label}</Badge>
                <CodePlate code={week.shortCode} size="sm" />
              </div>
              <h2 className="text-3xl sm:text-4xl normal-case tracking-tight leading-[0.95]">&ldquo;{week.title}&rdquo;</h2>
              <p className="text-ink-700 leading-snug">{week.description}</p>
              <Meta className="inline-flex items-center gap-1"><MapPinIcon className="size-3.5" />{locationLabel(week, true)} · {relativeTime(week.createdAt)}</Meta>
              <DickOMeter votes={week.votes} />
              <div className="mt-auto pt-2 flex flex-wrap gap-3">
                <ButtonLink href={`/moves/${week.slug}`} variant="dark">
                  Open the nomination <ArrowRightIcon className="size-4" />
                </ButtonLink>
                <ButtonLink href={`/notice/new?incident=${week.id}`} variant="paper">
                  Print the notice
                </ButtonLink>
              </div>
            </div>
          </article>
        ) : (
          <EmptyState stamp="NO WINNER YET" title="This week's award is still open." body="Cast verdicts on the latest nominations and check back Monday." action={{ href: "/feed", label: "See the latest dick moves" }} />
        )}

        {month && (
          <section>
            <SectionHeading kicker="Previous winner" title="Dick Move of the Month" />
            <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_1fr] items-start">
              <IncidentCard incident={month} featured />
              <div className="bg-ink-950 text-paper-50 border-[3px] border-ink-950 p-6 shadow-hard-yellow">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-warning-500">Why it won</p>
                <p className="mt-3 text-3xl leading-[0.95]">{summariseVotes(month.votes).agreePercent}% of {summariseVotes(month.votes).total} voters called it.</p>
                <p className="mt-3 text-paper-50/85 leading-snug">{month.description}</p>
                <p className="mt-4 font-mono text-[11px] uppercase tracking-widest text-paper-50/60">Awards are about the behaviour. Nobody is named, ever.</p>
              </div>
            </div>
          </section>
        )}

        <section>
          <SectionHeading kicker="Hall of shame (behaviour only)" title="Greatest acts of dickery" action={<ButtonLink href="/feed?sort=top" variant="outline" size="sm">Full ranking <ArrowRightIcon className="size-4" /></ButtonLink>} />
          <ol className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {greatest.map((inc, i) => (
              <li key={inc.id} className="relative">
                <span className="absolute -top-3 -left-3 z-20 size-10 grid place-items-center bg-ink-950 text-warning-500 font-display text-xl border-[3px] border-warning-500">{i + 1}</span>
                <IncidentCard incident={inc} />
              </li>
            ))}
          </ol>
        </section>

        <section>
          <SectionHeading kicker="The good bit" title="Most redeemed" action={<ButtonLink href="/feed?sort=redeemed" variant="outline" size="sm">All redemptions <ArrowRightIcon className="size-4" /></ButtonLink>} />
          {mostRedeemed.length === 0 ? (
            <div className="mt-6"><EmptyState stamp="PENDING" title="No redemptions yet." body="They'll come. People are better than the internet suggests." /></div>
          ) : (
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {mostRedeemed.map((inc) => (
                <IncidentCard key={inc.id} incident={inc} />
              ))}
            </div>
          )}
        </section>
      </Container>
    </>
  );
}
