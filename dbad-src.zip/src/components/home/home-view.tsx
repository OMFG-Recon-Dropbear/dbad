import Link from "next/link";
import type { HomeProps } from "@/lib/loaders/home";
import { SITE } from "@/lib/site";
import { summariseVotes } from "@/lib/domain/verdict";
import { Container } from "@/components/layout/site-shell";
import { ButtonLink } from "@/components/ui/button";
import { IncidentCard, locationLabel } from "@/components/incident/incident-card";
import { EvidenceFrame } from "@/components/brand/evidence";
import { DickOMeter } from "@/components/brand/dick-o-meter";
import { HazardTape, SectionHeading, CodePlate } from "@/components/brand/hazard";
import { Stamp } from "@/components/brand/stamp";
import { Badge, Meta } from "@/components/ui/badge";
import { Wordmark } from "@/components/brand/wordmark";
import { NoticePreviewMini } from "@/components/notice/notice-mini";
import { ArrowRightIcon, CameraIcon, EyeIcon, MapPinIcon, MegaphoneIcon } from "@/components/icons/ui";
import { relativeTime } from "@/lib/domain/time";
import { CategoryIcon } from "@/components/icons/categories";

export function HomeView({ featured, latest, clusters, totals }: HomeProps) {
  const week = featured.week;
  const weekSummary = week ? summariseVotes(week.votes) : null;
  const topCluster = clusters[0];

  return (
    <>
      {/* ------------------------------------------------------------------ HERO */}
      <section className="concrete text-paper-50 overflow-hidden">
        <Container className="relative py-12 sm:py-16 lg:py-24">
          <div className="grid gap-10 lg:grid-cols-[1.25fr_1fr] lg:items-center">
            <div className="relative z-10">
              <p className="font-mono text-xs sm:text-sm uppercase tracking-[0.25em] text-warning-500 mb-4">Community noticeboard · Australia</p>
              <h1 className="text-[17vw] xs:text-[15vw] sm:text-7xl md:text-8xl lg:text-[7.5rem] xl:text-[8.5rem] leading-[0.86] text-paper-50">
                Don&rsquo;t
                <br />
                be a <span className="text-warning-500">dick.</span>
              </h1>
              <p className="mt-6 max-w-lg text-lg sm:text-xl text-paper-50/85 leading-snug">{SITE.subline}</p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4">
                <ButtonLink href="/nominate" size="lg" className="w-full sm:w-auto">
                  <CameraIcon className="size-6" /> Nominate a dick move
                </ButtonLink>
                <ButtonLink href="/feed" variant="outline-light" size="lg" className="w-full sm:w-auto">
                  <EyeIcon className="size-6" /> See the latest dick moves
                </ButtonLink>
              </div>
              <p className="mt-6 font-mono text-[11px] sm:text-xs uppercase tracking-widest text-paper-50/60">{SITE.alt}</p>
            </div>
            <div className="relative flex justify-center lg:justify-end">
              <div className="relative w-[260px] xs:w-[300px] sm:w-[340px] rotate-[3deg]">
                <NoticePreviewMini
                  lines={{
                    headline: "YOU HAVE BEEN DBAD'D.",
                    dickMove: "Parking across a public footpath.",
                    why: "Footpaths are for people. Your parking made everyone else work around you.",
                    location: "Batemans Bay, NSW",
                    advice: "That was a dick move. Do better.",
                  }}
                  code="DBAD-0042"
                />
                <div className="absolute -left-8 bottom-16 -rotate-12 hidden sm:block">
                  <Stamp tone="red" size="lg" flat className="bg-paper-50/95 shadow-hard">
                    Dick move
                  </Stamp>
                </div>
              </div>
            </div>
          </div>
        </Container>
        <div className="border-t border-paper-50/10 bg-ink-950/40">
          <Container className="py-3 flex flex-wrap items-center gap-x-8 gap-y-2 font-mono text-[11px] sm:text-xs uppercase tracking-widest text-paper-50/70">
            <span><strong className="text-warning-500 tabular">{totals.moves}</strong> dick moves called out</span>
            <span><strong className="text-redeem-400 tabular">{totals.redeemed}</strong> redeemed</span>
            <span><strong className="text-paper-50 tabular">{totals.notADick}</strong> definitely not dicks</span>
            <span><strong className="text-paper-50 tabular">{totals.regions}</strong> areas spotted</span>
          </Container>
        </div>
      </section>
      <HazardTape />

      {/* ------------------------------------------------------------- HOW IT WORKS */}
      <section className="bg-paper-50">
        <Container className="py-12 sm:py-16">
          <SectionHeading kicker="How it works" title="Three steps. Under a minute." />
          <ol className="mt-8 grid gap-4 sm:grid-cols-3">
            {[
              { n: "01", t: "Spot it", b: "Someone does something spectacularly inconsiderate.", Icon: EyeIcon },
              { n: "02", t: "Snap it", b: "Take a photo without creating another problem yourself. No faces, no plates, no confrontation.", Icon: CameraIcon },
              { n: "03", t: "DBAD it", b: "Tell us what happened, let the community vote, and generate a printable DBAD notice.", Icon: MegaphoneIcon },
            ].map((s) => (
              <li key={s.n} className="relative bg-paper-100 border-[3px] border-ink-950 shadow-hard p-5 pt-6">
                <span className="absolute -top-4 left-4 bg-warning-500 border-[3px] border-ink-950 font-mono font-bold text-sm px-2 py-1 leading-none">{s.n}</span>
                <s.Icon className="size-9 text-ink-950" />
                <h3 className="mt-3 text-3xl">{s.t}</h3>
                <p className="mt-2 text-ink-700 leading-snug">{s.b}</p>
              </li>
            ))}
          </ol>
        </Container>
      </section>

      {/* -------------------------------------------------------- DICK MOVE OF THE WEEK */}
      {week && weekSummary && (
        <section className="bg-ink-950 text-paper-50">
          <Container className="py-12 sm:py-16">
            <SectionHeading
              dark
              kicker="Community pick"
              title={
                <>
                  Dick Move <span className="text-warning-500">of the Week</span>
                </>
              }
              action={
                <ButtonLink href="/week" variant="outline-light" size="sm">
                  Past winners <ArrowRightIcon className="size-4" />
                </ButtonLink>
              }
            />
            <article className="mt-8 grid gap-0 lg:grid-cols-[1.3fr_1fr] bg-paper-50 text-ink-950 border-[3px] border-warning-500 shadow-hard-yellow">
              <div className="relative">
                <EvidenceFrame photo={week.photos[0]} categoryId={week.categoryId} priority className="h-full border-0 lg:border-r-[3px]" aspect="aspect-[4/3] lg:aspect-auto lg:h-full" sizes="(min-width:1024px) 60vw, 100vw" />
                <div className="absolute top-4 left-4 z-[2]">
                  <Stamp tone="red" size="lg" animate>
                    Dick move of the week
                  </Stamp>
                </div>
              </div>
              <div className="p-5 sm:p-7 flex flex-col gap-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge className="gap-1.5"><CategoryIcon id={week.categoryId} className="size-3.5" />{week.category.label}</Badge>
                  <CodePlate code={week.shortCode} size="sm" />
                </div>
                <h3 className="text-3xl sm:text-4xl normal-case tracking-tight leading-[0.95]">&ldquo;{week.title}&rdquo;</h3>
                <p className="text-ink-700 leading-snug">{week.description}</p>
                <Meta className="inline-flex items-center gap-1"><MapPinIcon className="size-3.5" />{locationLabel(week, true)} · {relativeTime(week.createdAt)}</Meta>
                <DickOMeter votes={week.votes} compact />
                <div className="mt-auto pt-2 flex flex-wrap gap-3">
                  <ButtonLink href={`/moves/${week.slug}`} variant="dark">
                    Cast your verdict <ArrowRightIcon className="size-4" />
                  </ButtonLink>
                  <ButtonLink href={`/notice/new?incident=${week.id}`} variant="paper">
                    Print the notice
                  </ButtonLink>
                </div>
              </div>
            </article>
          </Container>
        </section>
      )}

      {/* ------------------------------------------------------------- LATEST */}
      <section className="bg-paper-50">
        <Container className="py-12 sm:py-16">
          <SectionHeading
            kicker="Spotted in the wild"
            title="Latest dick moves"
            action={
              <ButtonLink href="/feed" variant="outline" size="sm">
                See all <ArrowRightIcon className="size-4" />
              </ButtonLink>
            }
          />
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {latest.slice(0, 6).map((inc, i) => (
              <IncidentCard key={inc.id} incident={inc} priority={i < 2} />
            ))}
          </div>
        </Container>
      </section>

      {/* ----------------------------------------------------------- NOT A DICK */}
      {featured.notADick.length > 0 && (
        <section className="bg-redeem-500 text-paper-50 border-y-[3px] border-ink-950">
          <Container className="py-12 sm:py-16">
            <div className="grid gap-8 lg:grid-cols-[1fr_1.4fr] lg:items-start">
              <div>
                <p className="font-mono text-xs uppercase tracking-[0.2em] mb-3 text-paper-50/80">Balance</p>
                <h2 className="text-4xl sm:text-5xl text-paper-50">
                  Definitely <span className="text-ink-950">not</span> a dick.
                </h2>
                <p className="mt-4 text-paper-50/90 leading-relaxed max-w-md">
                  DBAD isn&rsquo;t all doom. When someone returns a trolley in the rain, moves their car the second they realise, or picks up rubbish that isn&rsquo;t theirs — nominate that too. Community standards work both ways.
                </p>
                <div className="mt-6 flex flex-wrap gap-3">
                  <ButtonLink href="/nominate?kind=not_a_dick" variant="dark">
                    Nominate a not-a-dick
                  </ButtonLink>
                  <ButtonLink href="/not-a-dick" variant="paper">
                    See the good ones
                  </ButtonLink>
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {featured.notADick.slice(0, 2).map((inc) => (
                  <IncidentCard key={inc.id} incident={inc} />
                ))}
              </div>
            </div>
          </Container>
        </section>
      )}

      {/* -------------------------------------------------------- REDEMPTION + MAP */}
      <section className="bg-paper-50">
        <Container className="py-12 sm:py-16 grid gap-10 lg:grid-cols-2">
          <div>
            <SectionHeading kicker="Redemption" title="People can improve." />
            <p className="mt-4 text-ink-700 leading-relaxed max-w-lg">
              Every nomination can end well. When the situation is fixed — the car moved, the trolley returned, the mess cleaned — it gets marked <strong>REDEEMED</strong>, and the community celebrates it harder than the original dick move.
            </p>
            <ul className="mt-6 space-y-3">
              {featured.latestRedemptions.slice(0, 3).map((inc) => (
                <li key={inc.id}>
                  <Link href={`/moves/${inc.slug}`} className="group flex gap-4 items-start border-[3px] border-redeem-600 bg-paper-100 p-4 hover:bg-white">
                    <Stamp tone="green" size="sm" className="mt-1 shrink-0">Redeemed</Stamp>
                    <div className="min-w-0">
                      <p className="font-semibold leading-snug group-hover:underline decoration-redeem-500 decoration-2">{inc.dickMove}</p>
                      <p className="text-sm text-ink-700 mt-1 leading-snug">&ldquo;{inc.redemption?.note}&rdquo;</p>
                      <Meta className="mt-1 block">{locationLabel(inc)} · {inc.redemption ? relativeTime(inc.redemption.createdAt) : ""}</Meta>
                    </div>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <SectionHeading kicker="Australian Dickery Map" title="Near you." action={<ButtonLink href="/map" variant="outline" size="sm">Open the map <ArrowRightIcon className="size-4" /></ButtonLink>} />
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {clusters.slice(0, 4).map((c) => (
                <Link key={c.region} href={`/feed?region=${encodeURIComponent(c.region)}`} className="group block bg-paper-100 border-[3px] border-ink-950 shadow-hard-sm p-4 hover:bg-white">
                  <p className="font-display text-4xl leading-none tabular">{c.count}</p>
                  <p className="font-display uppercase text-lg leading-none mt-1 group-hover:underline decoration-warning-500 decoration-4">{c.region}</p>
                  <Meta className="mt-2 block">
                    {c.countThisWeek} this week · {c.redeemed} redeemed
                  </Meta>
                </Link>
              ))}
            </div>
            {topCluster && (
              <p className="mt-4 font-mono text-xs uppercase tracking-wider text-concrete-600">
                {topCluster.countThisWeek} dick moves spotted around {topCluster.region} this week.
              </p>
            )}
          </div>
        </Container>
      </section>

      {/* ------------------------------------------------------------- STANDARD */}
      <section className="bg-warning-500 border-y-[3px] border-ink-950">
        <Container className="py-12 sm:py-16 grid gap-8 lg:grid-cols-[1fr_1fr] items-center">
          <div>
            <p className="font-mono text-xs uppercase tracking-[0.2em] mb-3 text-ink-950/70">The one rule</p>
            <h2 className="text-4xl sm:text-5xl md:text-6xl">
              Call out the action.
              <br />
              Not the person.
            </h2>
            <p className="mt-4 text-ink-950/85 leading-relaxed max-w-md">
              No names, no plates, no faces, no addresses. Photograph the behaviour. If they fix it, say so. If you were wrong, own it. And above all: don&rsquo;t be a dick while telling someone else not to be a dick.
            </p>
            <div className="mt-6">
              <ButtonLink href="/standards" variant="dark">
                Read the community standard
              </ButtonLink>
            </div>
          </div>
          <div className="justify-self-center lg:justify-self-end">
            <div className="bg-ink-950 text-paper-50 p-8 border-[3px] border-ink-950 shadow-hard-lg max-w-sm -rotate-1">
              <Wordmark className="h-10 w-auto text-warning-500" />
              <p className="mt-5 font-display uppercase text-3xl leading-[0.95]">Take the joke.<br />Fix the problem.<br />Move on.</p>
              <p className="mt-5 font-mono text-[11px] uppercase tracking-widest text-paper-50/60">We&rsquo;ve all been a dick at some point.</p>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
