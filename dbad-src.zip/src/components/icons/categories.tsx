import * as React from "react";
import type { CategoryId } from "@/lib/domain/types";

type P = React.SVGProps<SVGSVGElement>;

/**
 * Category icons: heavy, stencil-ish, single colour (currentColor). Designed on a 48
 * grid so they hold up at 24px in a chip and at 160px on a photo-less card.
 */
function Base({ children, ...props }: P) {
  return (
    <svg viewBox="0 0 48 48" fill="none" stroke="currentColor" strokeWidth={4} strokeLinecap="square" strokeLinejoin="miter" aria-hidden focusable="false" {...props}>
      {children}
    </svg>
  );
}

export const ParkingIcon = (p: P) => (
  <Base {...p}>
    <rect x="6" y="6" width="36" height="36" />
    <path d="M18 36V13h9a6.5 6.5 0 0 1 0 13h-9" />
  </Base>
);

export const RoadIcon = (p: P) => (
  <Base {...p}>
    <path d="M14 6h20l8 36H6z" />
    <path d="M24 10v6M24 21v6M24 32v6" strokeDasharray="0" />
  </Base>
);

export const ShoppingIcon = (p: P) => (
  <Base {...p}>
    <path d="M4 8h6l4 20h22l4-14H13" />
    <path d="M15 28l-2 6h22" />
    <circle cx="17" cy="40" r="3" fill="currentColor" stroke="none" />
    <circle cx="33" cy="40" r="3" fill="currentColor" stroke="none" />
  </Base>
);

export const NeighbourhoodIcon = (p: P) => (
  <Base {...p}>
    <path d="M4 24L16 12l12 12M8 22v18h16V22M26 42h16V26l-8-8-4 4" />
    <path d="M13 42v-9h6v9" />
  </Base>
);

export const RubbishIcon = (p: P) => (
  <Base {...p}>
    <path d="M8 14h32M18 14V8h12v6M11 14l2 28h22l2-28M20 21v14M28 21v14" />
  </Base>
);

export const DogIcon = (p: P) => (
  <Base {...p}>
    <ellipse cx="24" cy="31" rx="9" ry="8" fill="currentColor" stroke="none" />
    <circle cx="11" cy="21" r="4.5" fill="currentColor" stroke="none" />
    <circle cx="37" cy="21" r="4.5" fill="currentColor" stroke="none" />
    <circle cx="17" cy="11" r="4.5" fill="currentColor" stroke="none" />
    <circle cx="31" cy="11" r="4.5" fill="currentColor" stroke="none" />
  </Base>
);

export const InternetIcon = (p: P) => (
  <Base {...p}>
    <path d="M6 8h36v24H24l-10 8v-8H6z" />
    <path d="M14 20h4M22 20h4M30 20h4" />
  </Base>
);

export const WorkplaceIcon = (p: P) => (
  <Base {...p}>
    <path d="M8 16h26v16a8 8 0 0 1-8 8H16a8 8 0 0 1-8-8z" />
    <path d="M34 20h4a4 4 0 0 1 0 8h-4" />
    <path d="M14 10c0-3 3-3 3-6M22 10c0-3 3-3 3-6" />
  </Base>
);

export const OtherIcon = (p: P) => (
  <Base {...p}>
    <path d="M24 4l20 36H4z" />
    <path d="M20 20c0-3 2-4 4-4s4 1 4 4-4 3-4 7" />
    <path d="M24 32v.5" strokeWidth={5} />
  </Base>
);

export const CATEGORY_ICONS: Record<CategoryId, (p: P) => React.JSX.Element> = {
  parking: ParkingIcon,
  road: RoadIcon,
  shopping: ShoppingIcon,
  neighbourhood: NeighbourhoodIcon,
  rubbish: RubbishIcon,
  dog: DogIcon,
  internet: InternetIcon,
  workplace: WorkplaceIcon,
  other: OtherIcon,
};

export function CategoryIcon({ id, ...props }: P & { id: CategoryId }) {
  const Icon = CATEGORY_ICONS[id] ?? OtherIcon;
  return <Icon {...props} />;
}
