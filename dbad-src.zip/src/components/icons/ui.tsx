import * as React from "react";

type P = React.SVGProps<SVGSVGElement>;

function I({ children, ...props }: P) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="square" strokeLinejoin="miter" aria-hidden focusable="false" {...props}>
      {children}
    </svg>
  );
}

export const XIcon = (p: P) => (
  <I {...p}>
    <path d="M5 5l14 14M19 5L5 19" />
  </I>
);
export const MenuIcon = (p: P) => (
  <I {...p}>
    <path d="M3 6h18M3 12h18M3 18h18" />
  </I>
);
export const PlusIcon = (p: P) => (
  <I {...p}>
    <path d="M12 4v16M4 12h16" />
  </I>
);
export const CameraIcon = (p: P) => (
  <I {...p}>
    <path d="M3 8h4l2-3h6l2 3h4v12H3z" />
    <circle cx="12" cy="13" r="3.5" />
  </I>
);
export const ShareIcon = (p: P) => (
  <I {...p}>
    <path d="M12 3v13M7 8l5-5 5 5M5 13v8h14v-8" />
  </I>
);
export const PrintIcon = (p: P) => (
  <I {...p}>
    <path d="M7 8V3h10v5M5 8h14v9h-3v4H8v-4H5zM8 13h8" />
  </I>
);
export const DownloadIcon = (p: P) => (
  <I {...p}>
    <path d="M12 3v12M7 10l5 5 5-5M4 20h16" />
  </I>
);
export const CopyIcon = (p: P) => (
  <I {...p}>
    <path d="M9 9h11v11H9zM5 15H4V4h11v1" />
  </I>
);
export const MapPinIcon = (p: P) => (
  <I {...p}>
    <path d="M12 22s7-7 7-12a7 7 0 1 0-14 0c0 5 7 12 7 12z" />
    <circle cx="12" cy="10" r="2.5" />
  </I>
);
export const BellIcon = (p: P) => (
  <I {...p}>
    <path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4zM10 21h4" />
  </I>
);
export const UserIcon = (p: P) => (
  <I {...p}>
    <circle cx="12" cy="8" r="4" />
    <path d="M4 21c0-4 4-6 8-6s8 2 8 6" />
  </I>
);
export const SearchIcon = (p: P) => (
  <I {...p}>
    <circle cx="10.5" cy="10.5" r="6.5" />
    <path d="M15.5 15.5L21 21" />
  </I>
);
export const ChevronLeftIcon = (p: P) => (
  <I {...p}>
    <path d="M15 5l-7 7 7 7" />
  </I>
);
export const ChevronRightIcon = (p: P) => (
  <I {...p}>
    <path d="M9 5l7 7-7 7" />
  </I>
);
export const ChevronDownIcon = (p: P) => (
  <I {...p}>
    <path d="M5 9l7 7 7-7" />
  </I>
);
export const CheckIcon = (p: P) => (
  <I {...p}>
    <path d="M4 12l5 5L20 6" />
  </I>
);
export const FlagIcon = (p: P) => (
  <I {...p}>
    <path d="M5 21V4h13l-2 4 2 4H5" />
  </I>
);
export const ArrowRightIcon = (p: P) => (
  <I {...p}>
    <path d="M4 12h16M13 5l7 7-7 7" />
  </I>
);
export const ArrowLeftIcon = (p: P) => (
  <I {...p}>
    <path d="M20 12H4M11 5l-7 7 7 7" />
  </I>
);
export const QrIcon = (p: P) => (
  <I {...p} strokeWidth={2}>
    <path d="M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM5.5 5.5h2v2h-2zM16.5 5.5h2v2h-2zM5.5 16.5h2v2h-2zM14 14h3v3h-3zM19 14h2v2h-2zM14 19h2v2h-2zM18 18h3v3h-3z" />
  </I>
);
export const WarningIcon = (p: P) => (
  <I {...p}>
    <path d="M12 3L2 21h20L12 3zM12 10v5M12 17.5v.5" />
  </I>
);
export const RedeemIcon = (p: P) => (
  <I {...p}>
    <path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5" />
    <path d="M9 12l2 2 4-4" />
  </I>
);
export const FilterIcon = (p: P) => (
  <I {...p}>
    <path d="M3 5h18l-7 8v6l-4 2v-8z" />
  </I>
);
export const UploadIcon = (p: P) => (
  <I {...p}>
    <path d="M12 16V4M7 9l5-5 5 5M4 20h16" />
  </I>
);
export const ImageIcon = (p: P) => (
  <I {...p}>
    <path d="M3 4h18v16H3zM3 16l5-5 4 4 3-3 6 6" />
    <circle cx="16" cy="9" r="1.5" />
  </I>
);
export const TrashIcon = (p: P) => (
  <I {...p}>
    <path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14M10 11v6M14 11v6" />
  </I>
);
export const EyeIcon = (p: P) => (
  <I {...p}>
    <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" />
    <circle cx="12" cy="12" r="3" />
  </I>
);
export const EyeOffIcon = (p: P) => (
  <I {...p}>
    <path d="M3 3l18 18M10 10a3 3 0 0 0 4 4M5.5 6.5C3.5 8.2 2 12 2 12s4 7 10 7c1.8 0 3.4-.5 4.8-1.2M9 5.3A10 10 0 0 1 12 5c6 0 10 7 10 7s-.8 1.4-2.3 3" />
  </I>
);
export const ShieldIcon = (p: P) => (
  <I {...p}>
    <path d="M12 2l8 3v6c0 5-3.5 9-8 11-4.5-2-8-6-8-11V5z" />
    <path d="M8.5 12l2.5 2.5 4.5-4.5" />
  </I>
);
export const StarIcon = (p: P) => (
  <I {...p}>
    <path d="M12 3l2.8 6 6.2.8-4.6 4.3 1.3 6.4L12 17.5 6.3 20.5l1.3-6.4L3 9.8 9.2 9z" />
  </I>
);
export const ClockIcon = (p: P) => (
  <I {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </I>
);
export const LinkIcon = (p: P) => (
  <I {...p}>
    <path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1.5 1.5M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1.5-1.5" />
  </I>
);
export const SparkIcon = (p: P) => (
  <I {...p}>
    <path d="M12 2l2 6 6 2-6 2-2 6-2-6-6-2 6-2zM19 15l1 3 3 1-3 1-1 3-1-3-3-1 3-1z" />
  </I>
);
export const LocateIcon = (p: P) => (
  <I {...p}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
  </I>
);
export const ExternalIcon = (p: P) => (
  <I {...p}>
    <path d="M14 4h6v6M20 4l-9 9M19 14v6H4V5h6" />
  </I>
);
export const ThumbIcon = (p: P) => (
  <I {...p}>
    <path d="M7 11v10H3V11zM7 11l4-8c2 0 3 1 3 3v4h6l-2 10H7" />
  </I>
);
export const LaughIcon = (p: P) => (
  <I {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M7 13c1 3 3 4 5 4s4-1 5-4zM9 9h.5M14.5 9h.5" />
  </I>
);
export const FacepalmIcon = (p: P) => (
  <I {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M8 15c1.5-1.5 6.5-1.5 8 0M8 9l3 1M16 9l-3 1" />
  </I>
);
export const HeartIcon = (p: P) => (
  <I {...p}>
    <path d="M12 21s-8-5.5-8-11a4.5 4.5 0 0 1 8-2.7A4.5 4.5 0 0 1 20 10c0 5.5-8 11-8 11z" />
  </I>
);
export const FacebookIcon = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden {...p}>
    <path d="M13.5 22v-8h2.7l.4-3.2h-3.1V8.8c0-.9.3-1.5 1.6-1.5h1.7V4.4c-.3 0-1.3-.1-2.5-.1-2.5 0-4.1 1.5-4.1 4.2v2.3H7.4V14h2.8v8h3.3z" />
  </svg>
);
export const GoogleIcon = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden {...p}>
    <path d="M21.6 12.2c0-.7-.1-1.3-.2-1.9H12v3.7h5.4a4.6 4.6 0 0 1-2 3v2.5h3.2c1.9-1.7 3-4.3 3-7.3z" />
    <path d="M12 22c2.7 0 5-.9 6.6-2.4l-3.2-2.5c-.9.6-2 1-3.4 1-2.6 0-4.8-1.8-5.6-4.1H3.1v2.6A10 10 0 0 0 12 22z" />
    <path d="M6.4 13.9A6 6 0 0 1 6.1 12c0-.7.1-1.3.3-1.9V7.5H3.1A10 10 0 0 0 2 12c0 1.6.4 3.1 1.1 4.5l3.3-2.6z" />
    <path d="M12 6c1.5 0 2.8.5 3.8 1.5l2.9-2.9A10 10 0 0 0 3.1 7.5l3.3 2.6C7.2 7.8 9.4 6 12 6z" />
  </svg>
);
export const AppleIcon = (p: P) => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden {...p}>
    <path d="M16.4 12.6c0-2.3 1.9-3.4 2-3.5-1.1-1.6-2.8-1.8-3.4-1.8-1.4-.1-2.8.9-3.5.9-.7 0-1.8-.8-3-.8-1.5 0-3 .9-3.8 2.3-1.6 2.8-.4 7 1.2 9.3.8 1.1 1.7 2.4 2.9 2.3 1.2 0 1.6-.8 3-.8s1.8.8 3 .7c1.3 0 2.1-1.1 2.8-2.3.9-1.3 1.3-2.6 1.3-2.6s-2.5-1-2.5-3.7zM14.1 5.8c.6-.8 1.1-1.9.9-3-.9 0-2 .6-2.7 1.4-.6.7-1.1 1.8-1 2.9 1.1.1 2.2-.5 2.8-1.3z" />
  </svg>
);
export const MailIcon = (p: P) => (
  <I {...p}>
    <path d="M3 5h18v14H3zM3 6l9 7 9-7" />
  </I>
);
export const LogoutIcon = (p: P) => (
  <I {...p}>
    <path d="M10 4H4v16h6M14 8l4 4-4 4M8 12h10" />
  </I>
);
export const GridIcon = (p: P) => (
  <I {...p}>
    <path d="M3 3h8v8H3zM13 3h8v8h-8zM3 13h8v8H3zM13 13h8v8h-8z" />
  </I>
);
export const ListIcon = (p: P) => (
  <I {...p}>
    <path d="M8 6h13M8 12h13M8 18h13M3 6h.5M3 12h.5M3 18h.5" />
  </I>
);
export const InfoIcon = (p: P) => (
  <I {...p}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 11v6M12 7.5v.5" />
  </I>
);
export const MegaphoneIcon = (p: P) => (
  <I {...p}>
    <path d="M3 10v4h3l9 5V5L6 10zM18 9a4 4 0 0 1 0 6M7 14l1 6h3l-1-6" />
  </I>
);
