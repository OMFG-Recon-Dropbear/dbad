import Link from "next/link";
import type { IncidentSummary } from "@/lib/domain/types";
import { relativeTime } from "@/lib/domain/time";
import { cn } from "@/lib/utils";
import { EvidenceFrame } from "@/components/brand/evidence";
import { VerdictBar } from "@/components/brand/dick-o-meter";
import { Badge, Meta } from "@/components/ui/badge";
import { StatusStamp } from "@/components/brand/stamp";
import { CodePlate } from "@/components/brand/hazard";
import { FacepalmIcon, HeartIcon, LaughIcon, MapPinIcon, ThumbIcon } from "@/components/icons/ui";
import { CategoryIcon } from "@/components/icons/categories";

export function locationLabel(inc: Pick<IncidentSummary, "location">, withPlace = false): string {
  const l = inc.location;
  return withPlace && l.place ? `${l.place}, ${l.suburb} ${l.state}` : `${l.suburb}, ${l.state}`;
}

/**
 * Feed card. The whole card is one link (no nested interactive elements), which keeps
 * it accessible and thumb-friendly. Reactions are shown as counts; voting happens on
 * the nomination page.
 */
export function IncidentCard({ incident, priority, featured, className }: { incident: IncidentSummary; priority?: boolean; featured?: boolean; className?: string }) {
  const positive = incident.kind === "not_a_dick";
  const stamp = positive ? "not_a_dick" : incident.status === "redeemed" ? "redeemed" : incident.status === "overruled" ? "overruled" : featured ? "week" : null;
  return (
    <article className={cn("group relative flex flex-col bg-paper-50 text-ink-950 border-[3px] border-ink-950 shadow-hard transition-transform hover:-translate-y-0.5", positive && "border-redeem-700", className)}>
      <Link href={`/moves/${incident.slug}`} className="absolute inset-0 z-10" aria-label={`${incident.title} — ${locationLabel(incident)}`} />
      <div className="relative">
        <EvidenceFrame photo={incident.photos[0]} categoryId={incident.categoryId} priority={priority} className="border-0 border-b-[3px]" />
        <div className="absolute top-3 left-3 z-[2] flex flex-wrap gap-1.5">
          <Badge tone={positive ? "green" : "yellow"} size="md" className="gap-1.5">
            <CategoryIcon id={incident.categoryId} className="size-3.5" />
            {positive ? "NOT A DICK" : incident.category.label}
          </Badge>
        </div>
        {stamp && (
          <div className="absolute -bottom-3 right-3 z-[3]">
            <StatusStamp status={stamp} />
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-3 p-4">
        <h3 className="font-display text-2xl leading-[0.95] tracking-tight normal-case group-hover:underline decoration-warning-500 decoration-4 underline-offset-2">
          {/^["“]/.test(incident.title) ? incident.title : <>&ldquo;{incident.title}&rdquo;</>}
        </h3>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <Meta className="inline-flex items-center gap-1">
            <MapPinIcon className="size-3.5" /> {locationLabel(incident)}
          </Meta>
          <Meta>{relativeTime(incident.createdAt)}</Meta>
        </div>
        <VerdictBar votes={incident.votes} positive={positive} />
        <div className="mt-auto flex items-center justify-between gap-2 pt-1">
          <ul className="flex items-center gap-3 font-mono text-xs text-concrete-600 tabular" aria-label="Community reactions">
            <li className="inline-flex items-center gap-1" title="Fair call"><ThumbIcon className="size-4" /> {incident.reactions.fair_call}</li>
            <li className="inline-flex items-center gap-1" title="Classic"><LaughIcon className="size-4" /> {incident.reactions.classic}</li>
            <li className="inline-flex items-center gap-1" title="Dick move"><FacepalmIcon className="size-4" /> {incident.reactions.dick_move}</li>
            <li className="inline-flex items-center gap-1" title="Redemption"><HeartIcon className="size-4" /> {incident.reactions.redemption}</li>
          </ul>
          <CodePlate code={incident.shortCode} size="sm" />
        </div>
      </div>
    </article>
  );
}

/** Compact horizontal row for sidebars and "related" lists. */
export function IncidentRow({ incident }: { incident: IncidentSummary }) {
  return (
    <Link href={`/moves/${incident.slug}`} className="group flex gap-3 items-center border-2 border-ink-950 bg-paper-50 p-2 hover:bg-white">
      <div className="size-16 shrink-0 overflow-hidden border-2 border-ink-950 bg-warning-500 flex items-center justify-center">
        {incident.photos[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={incident.photos[0].url} alt="" className="size-full object-cover" loading="lazy" />
        ) : (
          <CategoryIcon id={incident.categoryId} className="size-8" />
        )}
      </div>
      <div className="min-w-0">
        <p className="font-semibold leading-snug line-clamp-2 group-hover:underline decoration-warning-500 decoration-2">{incident.title}</p>
        <Meta>{locationLabel(incident)} · {relativeTime(incident.createdAt)}</Meta>
      </div>
    </Link>
  );
}
