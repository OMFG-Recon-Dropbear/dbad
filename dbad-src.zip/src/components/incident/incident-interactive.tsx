"use client";

import * as React from "react";
import Link from "next/link";
import type { IncidentDetail, ReactionKind, ReportReason, Verdict } from "@/lib/domain/types";
import type { ViewerOrNull } from "@/lib/data/repository";
import type { CommunityActions } from "@/lib/actions/types";
import { VERDICT_LABEL, VERDICT_ORDER, summariseVotes } from "@/lib/domain/verdict";
import { relativeTime } from "@/lib/domain/time";
import { validateComment, LIMITS } from "@/lib/domain/validation";
import { scanText } from "@/lib/domain/pii";
import { cn } from "@/lib/utils";
import { DickOMeter } from "@/components/brand/dick-o-meter";
import { Button } from "@/components/ui/button";
import { Chip, Textarea, Label, FieldError, Select, Help } from "@/components/ui/input";
import { Dialog } from "@/components/ui/dialog";
import { useToast } from "@/components/ui/toast";
import { Avatar } from "@/components/brand/avatar";
import { Stamp } from "@/components/brand/stamp";
import { Meta } from "@/components/ui/badge";
import { CopyIcon, FacebookIcon, FacepalmIcon, FlagIcon, HeartIcon, LaughIcon, RedeemIcon, ShareIcon, ThumbIcon } from "@/components/icons/ui";
import { SITE } from "@/lib/site";

const REACTIONS: Array<{ kind: ReactionKind; label: string; Icon: (p: React.SVGProps<SVGSVGElement>) => React.JSX.Element }> = [
  { kind: "fair_call", label: "Fair call", Icon: ThumbIcon },
  { kind: "classic", label: "Classic", Icon: LaughIcon },
  { kind: "dick_move", label: "Dick move", Icon: FacepalmIcon },
  { kind: "redemption", label: "Redemption", Icon: HeartIcon },
];

const REPORT_REASONS: Array<{ id: ReportReason; label: string }> = [
  { id: "identifies_person", label: "It identifies a person (face, plate, name, handle)" },
  { id: "private_address", label: "It shows or names a private address" },
  { id: "children", label: "It involves children" },
  { id: "harassment", label: "It's harassment or a threat" },
  { id: "defamatory", label: "It makes an accusation that isn't supported" },
  { id: "not_a_dick_move", label: "It's not actually a dick move" },
  { id: "duplicate", label: "Duplicate" },
  { id: "spam", label: "Spam" },
  { id: "other", label: "Something else" },
];

export function IncidentInteractive({
  incident,
  viewer,
  actions,
  isOwner,
  isMod,
}: {
  incident: IncidentDetail;
  viewer: ViewerOrNull;
  actions: CommunityActions;
  isOwner: boolean;
  isMod: boolean;
}) {
  const toast = useToast();
  const positive = incident.kind === "not_a_dick";
  const [votes, setVotes] = React.useState(incident.votes);
  const [viewerVote, setViewerVote] = React.useState<Verdict | undefined>(incident.viewerVote);
  const [reactions, setReactions] = React.useState(incident.reactions);
  const [mine, setMine] = React.useState<ReactionKind[]>(incident.viewerReactions ?? []);
  const [comments, setComments] = React.useState(incident.comments);
  const [pending, setPending] = React.useState<string | null>(null);
  const [reportTarget, setReportTarget] = React.useState<{ type: "incident" | "comment"; id: string } | null>(null);
  const [redeemOpen, setRedeemOpen] = React.useState(false);
  const [status, setStatus] = React.useState(incident.status);
  const [redemptionNote, setRedemptionNote] = React.useState(incident.redemption?.note);

  const signInHref = `/sign-in?next=/moves/${incident.slug}`;
  const shareUrl = `${SITE.url}/moves/${incident.slug}`;
  const summary = summariseVotes(votes);

  async function vote(v: Verdict) {
    if (!viewer) return toast.push({ tone: "ink", title: "Sign in to cast a verdict", body: "It takes ten seconds and we don't want your data." });
    if (isOwner) return toast.push({ tone: "yellow", title: "Nice try", body: "You can't vote on your own nomination." });
    const prev = viewerVote;
    const prevVotes = votes;
    setViewerVote(v);
    setVotes((t) => {
      const n = { ...t };
      if (prev) n[prev] = Math.max(0, n[prev] - 1);
      n[v] += 1;
      return n;
    });
    setPending("vote");
    const res = await actions.castVote(incident.id, v);
    setPending(null);
    if (!res.ok || !res.data) {
      setViewerVote(prev);
      setVotes(prevVotes);
      toast.push({ tone: "red", title: "Verdict not recorded", body: res.message });
    } else {
      setVotes(res.data.votes);
      setViewerVote(res.data.viewerVote);
    }
  }

  async function react(kind: ReactionKind) {
    if (!viewer) return toast.push({ tone: "ink", title: "Sign in to react", body: "Reactions need a member behind them." });
    const had = mine.includes(kind);
    setMine((m) => (had ? m.filter((k) => k !== kind) : [...m, kind]));
    setReactions((r) => ({ ...r, [kind]: Math.max(0, r[kind] + (had ? -1 : 1)) }));
    const res = await actions.toggleReaction(incident.id, kind);
    if (res.ok && res.data) {
      setReactions(res.data.reactions);
      setMine(res.data.viewerReactions);
    } else {
      setMine((m) => (had ? [...m, kind] : m.filter((k) => k !== kind)));
      setReactions((r) => ({ ...r, [kind]: Math.max(0, r[kind] + (had ? 1 : -1)) }));
      toast.push({ tone: "red", title: "Couldn't react", body: res.message });
    }
  }

  async function share() {
    const data = { title: `DBAD — ${incident.title}`, text: positive ? "Definitely not a dick." : summary.shareLine, url: shareUrl };
    try {
      if (typeof navigator !== "undefined" && "share" in navigator && navigator.canShare?.(data)) {
        await navigator.share(data);
        return;
      }
    } catch {
      /* user cancelled */
    }
    await copy();
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(shareUrl);
      toast.push({ tone: "yellow", title: "Link copied", body: shareUrl });
    } catch {
      toast.push({ tone: "ink", title: "Copy this link", body: shareUrl });
    }
  }

  return (
    <div className="space-y-8">
      {/* ------------------------------------------------------------ Verdict */}
      <section id="verdict" className="bg-paper-50 border-[3px] border-ink-950 shadow-hard p-5 sm:p-6">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="text-3xl">Community verdict</h2>
          <Meta>{positive ? "Agree it's a good move?" : "Was it, though?"}</Meta>
        </div>
        <div className="mt-4">
          <DickOMeter votes={votes} positive={positive} />
        </div>
        {status === "overruled" && (
          <p className="mt-4 flex items-center gap-3 text-sm">
            <Stamp tone="concrete" size="sm" flat>
              Overruled
            </Stamp>
            The community reckons this one wasn&rsquo;t a dick move. The submitter owned it. Respect.
          </p>
        )}
        <div className="mt-5">
          <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600 mb-2">{viewerVote ? "Your verdict (tap to change)" : "Cast your verdict"}</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {VERDICT_ORDER.map((v) => (
              <Chip
                key={v}
                active={viewerVote === v}
                disabled={pending === "vote"}
                onClick={() => vote(v)}
                className={cn("justify-center py-3 text-sm sm:text-[15px] whitespace-normal text-center leading-tight", v === "absolute" && viewerVote !== v && "hover:bg-alert-500 hover:text-paper-50")}
              >
                {VERDICT_LABEL[v]}
              </Chip>
            ))}
          </div>
          {!viewer && (
            <Help>
              <Link href={signInHref} className="font-semibold underline decoration-warning-500 decoration-2">
                Sign in
              </Link>{" "}
              to cast a verdict. Verdicts are one per member and can be changed.
            </Help>
          )}
          {isOwner && <Help>You can&rsquo;t vote on your own nomination — but you can mark it redeemed if they fix it.</Help>}
        </div>
      </section>

      {/* ------------------------------------------------------------ Reactions + share */}
      <section className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <ul className="flex flex-wrap gap-2" aria-label="Reactions">
          {REACTIONS.map(({ kind, label, Icon }) => {
            const active = mine.includes(kind);
            return (
              <li key={kind}>
                <button
                  type="button"
                  aria-pressed={active}
                  onClick={() => react(kind)}
                  className={cn(
                    "inline-flex items-center gap-2 border-[3px] border-ink-950 rounded-sm px-3 py-2 text-sm font-semibold leading-none shadow-hard-sm transition-colors",
                    active ? "bg-warning-500" : "bg-paper-50 hover:bg-white",
                  )}
                >
                  <Icon className="size-4" /> {label} <span className="font-mono text-xs tabular text-concrete-600">{reactions[kind]}</span>
                </button>
              </li>
            );
          })}
        </ul>
        <div className="flex flex-wrap gap-2">
          <Button variant="dark" size="sm" onClick={share}>
            <ShareIcon className="size-4" /> Share
          </Button>
          <Button variant="paper" size="sm" onClick={copy}>
            <CopyIcon className="size-4" /> Copy link
          </Button>
          <a
            href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 border-[3px] border-ink-950 bg-paper-50 hover:bg-white rounded-sm px-3 py-2 font-display uppercase text-sm leading-none shadow-hard"
          >
            <FacebookIcon className="size-4" /> Facebook
          </a>
        </div>
      </section>

      {/* ------------------------------------------------------------ Redemption */}
      {!positive && status !== "redeemed" && (
        <section className="border-[3px] border-redeem-600 bg-paper-100 p-5 flex flex-col sm:flex-row sm:items-center gap-4">
          <RedeemIcon className="size-10 text-redeem-600 shrink-0" />
          <div className="flex-1">
            <p className="font-display uppercase text-2xl leading-none">Has this been fixed?</p>
            <p className="mt-1 text-sm text-ink-700 leading-snug">
              If the car moved, the trolley went back or the mess got cleaned, mark it <strong>REDEEMED</strong>. DBAD rewards people who do better.
            </p>
          </div>
          {isOwner || isMod ? (
            <Button variant="redeem" onClick={() => setRedeemOpen(true)}>
              Mark redeemed
            </Button>
          ) : (
            <Meta className="shrink-0">Submitter or a moderator can confirm</Meta>
          )}
        </section>
      )}
      {status === "redeemed" && !incident.redemption && redemptionNote && (
        <section className="relative bg-redeem-500 text-paper-50 border-[3px] border-ink-950 p-6 shadow-hard animate-fade-up">
          <Stamp tone="paper" size="md" flat className="bg-redeem-700 absolute -top-4 left-5">
            Redeemed
          </Stamp>
          <p className="mt-2 font-display uppercase text-2xl leading-none">Dick move rectified.</p>
          <p className="mt-2 text-lg">&ldquo;{redemptionNote}&rdquo;</p>
        </section>
      )}

      {/* ------------------------------------------------------------ Comments */}
      <section id="comments" className="space-y-4">
        <div className="bg-ink-950 text-paper-50 border-[3px] border-ink-950 p-5 shadow-hard-yellow">
          <p className="font-display uppercase text-3xl leading-none">
            Take the piss. <span className="text-warning-500">Don&rsquo;t take it too far.</span>
          </p>
          <dl className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1 font-mono text-xs uppercase tracking-wider">
            <div><dt className="inline text-paper-50/70">Humour:</dt> <dd className="inline text-redeem-400">yes</dd></div>
            <div><dt className="inline text-paper-50/70">Criticising the behaviour:</dt> <dd className="inline text-redeem-400">yes</dd></div>
            <div><dt className="inline text-paper-50/70">Threatening people:</dt> <dd className="inline text-alert-400">no</dd></div>
            <div><dt className="inline text-paper-50/70">Identifying people:</dt> <dd className="inline text-alert-400">no</dd></div>
            <div><dt className="inline text-paper-50/70">Doxxing:</dt> <dd className="inline text-alert-400">absolutely not</dd></div>
            <div><dt className="inline text-paper-50/70">Pile-ons:</dt> <dd className="inline text-alert-400">no</dd></div>
          </dl>
        </div>

        <h2 className="text-3xl flex items-baseline gap-3">
          Comments <span className="font-mono text-sm text-concrete-600 tabular">{comments.length}</span>
        </h2>

        <ul className="space-y-3">
          {comments.length === 0 && <li className="text-concrete-600">No comments yet. Be funny. Be kind. Be first.</li>}
          {comments.map((c) => (
            <li key={c.id} className="flex gap-3 bg-paper-50 border-2 border-ink-950 p-3 sm:p-4">
              <Link href={`/u/${c.author.handle}`} className="shrink-0">
                <Avatar seed={c.author.avatarSeed} size={36} />
              </Link>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-baseline gap-x-2">
                  <Link href={`/u/${c.author.handle}`} className="font-semibold hover:underline decoration-warning-500 decoration-2">
                    {c.author.handle}
                  </Link>
                  <Meta>{relativeTime(c.createdAt)}</Meta>
                </div>
                <p className="mt-1 leading-snug">{c.body}</p>
              </div>
              <button
                type="button"
                className="self-start text-concrete-500 hover:text-alert-500"
                aria-label="Report comment"
                title="Report comment"
                onClick={() => setReportTarget({ type: "comment", id: c.id })}
              >
                <FlagIcon className="size-4" />
              </button>
            </li>
          ))}
        </ul>

        <CommentForm
          viewer={viewer}
          signInHref={signInHref}
          onSubmit={async (body) => {
            const res = await actions.addComment(incident.id, body);
            if (res.ok && res.data) {
              setComments((c) => [...c, res.data!]);
              toast.push({ tone: "yellow", title: "Posted", body: "Nice one." });
              return true;
            }
            toast.push({ tone: res.ok ? "yellow" : "red", title: res.ok ? "Held for review" : "Not posted", body: res.message });
            return res.ok;
          }}
        />

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t-2 border-concrete-300">
          <button type="button" onClick={() => setReportTarget({ type: "incident", id: incident.id })} className="inline-flex items-center gap-2 text-sm font-semibold text-concrete-600 hover:text-alert-600">
            <FlagIcon className="size-4" /> Report this nomination
          </button>
          <Link href={`/about-you?code=${incident.shortCode}`} className="text-sm font-semibold text-concrete-600 hover:text-ink-950 underline decoration-warning-500 decoration-2 underline-offset-2">
            Is this about you?
          </Link>
        </div>
      </section>

      <ReportDialog
        open={reportTarget !== null}
        onClose={() => setReportTarget(null)}
        targetLabel={reportTarget?.type === "comment" ? "this comment" : "this nomination"}
        onSubmit={async (reason, details) => {
          const target = reportTarget ?? { type: "incident" as const, id: incident.id };
          const res = await actions.reportContent({ targetType: target.type, targetId: target.id, reason, details });
          toast.push({ tone: res.ok ? "yellow" : "red", title: res.ok ? "Reported" : "Couldn't report", body: res.message });
          return res.ok;
        }}
      />

      <Dialog open={redeemOpen} onClose={() => setRedeemOpen(false)} title="Mark as redeemed" size="sm">
        <RedeemForm
          onSubmit={async (note) => {
            const res = await actions.markRedeemed(incident.id, note);
            if (res.ok) {
              setStatus("redeemed");
              setRedemptionNote(note || "Sorted. Humanity survives another day.");
              setReactions((r) => ({ ...r, redemption: r.redemption + 1 }));
              setRedeemOpen(false);
              toast.push({ tone: "green", title: "REDEEMED", body: "Humanity survives another day." });
            } else toast.push({ tone: "red", title: "Couldn't update", body: res.message });
          }}
        />
      </Dialog>
    </div>
  );
}

function CommentForm({ viewer, signInHref, onSubmit }: { viewer: ViewerOrNull; signInHref: string; onSubmit: (body: string) => Promise<boolean> }) {
  const [body, setBody] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const error = body ? validateComment(body) : null;
  const findings = body ? scanText(body).findings.filter((f) => f.severity !== "note") : [];

  if (!viewer) {
    return (
      <div className="border-[3px] border-dashed border-concrete-400 p-5 text-center">
        <p className="font-semibold">Got something funny and fair to add?</p>
        <Link href={signInHref} className="mt-2 inline-block font-display uppercase text-lg underline decoration-warning-500 decoration-4 underline-offset-2">
          Sign in to comment
        </Link>
      </div>
    );
  }
  return (
    <form
      className="border-[3px] border-ink-950 bg-paper-100 p-4 space-y-3"
      onSubmit={async (e) => {
        e.preventDefault();
        if (error || !body.trim()) return;
        setBusy(true);
        const ok = await onSubmit(body.trim());
        setBusy(false);
        if (ok) setBody("");
      }}
    >
      <Label htmlFor="comment-body" hint="Criticise the behaviour, not the person. Never identify anyone.">
        Add a comment
      </Label>
      <Textarea id="comment-body" value={body} onChange={(e) => setBody(e.target.value)} maxLength={LIMITS.comment.max} rows={3} placeholder="Funny. Fair. Short." aria-invalid={!!error} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-sm">
          <FieldError>{error}</FieldError>
          {findings.map((f) => (
            <p key={f.start} className="text-alert-600 font-semibold">
              &ldquo;{f.match}&rdquo; — {f.message}
            </p>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <Meta>{body.length}/{LIMITS.comment.max}</Meta>
          <Button type="submit" disabled={busy || !!error || !body.trim()} variant="dark" size="sm">
            {busy ? "Posting…" : "Post comment"}
          </Button>
        </div>
      </div>
    </form>
  );
}

export function ReportDialog({ open, onClose, onSubmit, targetLabel = "this nomination" }: { open: boolean; onClose: () => void; onSubmit: (reason: ReportReason, details: string) => Promise<boolean>; targetLabel?: string }) {
  const [reason, setReason] = React.useState<ReportReason>("identifies_person");
  const [details, setDetails] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  return (
    <Dialog open={open} onClose={onClose} title="Report content" size="sm">
      <form
        className="space-y-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          const ok = await onSubmit(reason, details);
          setBusy(false);
          if (ok) {
            setDetails("");
            onClose();
          }
        }}
      >
        <p className="text-sm text-ink-700">Reports about identifying details or children are actioned first. You don&rsquo;t need an account to report {targetLabel}.</p>
        <div>
          <Label htmlFor="report-reason">What&rsquo;s wrong?</Label>
          <Select id="report-reason" value={reason} onChange={(e) => setReason(e.target.value as ReportReason)}>
            {REPORT_REASONS.map((r) => (
              <option key={r.id} value={r.id}>
                {r.label}
              </option>
            ))}
          </Select>
        </div>
        <div>
          <Label htmlFor="report-details" hint="Optional. Don't include personal information here either.">
            Details
          </Label>
          <Textarea id="report-details" value={details} onChange={(e) => setDetails(e.target.value)} rows={3} maxLength={1000} />
        </div>
        <div className="flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" variant="alert" disabled={busy}>
            {busy ? "Sending…" : "Send report"}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}

function RedeemForm({ onSubmit }: { onSubmit: (note: string) => Promise<void> }) {
  const [note, setNote] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  return (
    <form
      className="space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        await onSubmit(note.trim());
        setBusy(false);
      }}
    >
      <p className="text-ink-700 leading-snug">Tell the community what got fixed. Keep it kind — redemption is the whole point.</p>
      <div>
        <Label htmlFor="redeem-note">What happened?</Label>
        <Textarea id="redeem-note" value={note} onChange={(e) => setNote(e.target.value)} rows={3} maxLength={300} placeholder="They moved the car. Humanity survives another day." />
      </div>
      <div className="flex justify-end">
        <Button type="submit" variant="redeem" disabled={busy}>
          {busy ? "Saving…" : "Mark redeemed"}
        </Button>
      </div>
    </form>
  );
}
