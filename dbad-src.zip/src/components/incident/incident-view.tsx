import Link from "next/link";
import type { IncidentPageProps } from "@/lib/loaders/incident";
import type { CommunityActions } from "@/lib/actions/types";
import { AFFECTED_LABEL } from "@/lib/domain/categories";
import { occurrenceLabel, relativeTime, stampDate } from "@/lib/domain/time";
import { Container } from "@/components/layout/site-shell";
import { EvidenceFrame } from "@/components/brand/evidence";
import { Badge, Meta } from "@/components/ui/badge";
import { CodePlate } from "@/components/brand/hazard";
import { Stamp, StatusStamp } from "@/components/brand/stamp";
import { Avatar } from "@/components/brand/avatar";
import { ButtonLink } from "@/components/ui/button";
import { CategoryIcon } from "@/components/icons/categories";
import { ArrowRightIcon, MapPinIcon, PrintIcon, ClockIcon, ExternalIcon } from "@/components/icons/ui";
import { IncidentCard, locationLabel } from "./incident-card";
import { IncidentInteractive } from "./incident-interactive";
import { buildNoticeLines } from "@/lib/notice/lines";
import { NoticePreviewMini } from "@/components/notice/notice-mini";
import { weekOf } from "@/lib/domain/utils";

export function IncidentView({ incident, related, viewer, actions }: IncidentPageProps & { actions: CommunityActions }) {
  const positive = incident.kind === "not_a_dick";
  const isWeek = incident.featuredWeek === weekOf(new Date());
  const lines = buildNoticeLines(incident);
  const isOwner = viewer?.id === incident.submitterId;
  const isMod = viewer?.role === "moderator" || viewer?.role === "admin";

  return (
    <>
      {incident.moderationStatus !== "approved" && (
        <div className="bg-concrete-200 border-b-[3px] border-ink-950">
          <Container className="py-3 flex flex-wrap items-center gap-3">
            <StatusStamp status="pending" />
            <p className="text-sm">
              This nomination is only visible to you{isMod ? " and moderators" : ""} until a moderator has checked it against the community standard.
            </p>
            {isMod && (
              <ButtonLink href="/admin/queue" size="sm" variant="dark">
                Open the queue
              </ButtonLink>
            )}
          </Container>
        </div>
      )}

      <article>
        <header className={positive ? "bg-redeem-500 text-paper-50 border-b-[3px] border-ink-950" : "bg-paper-100 border-b-[3px] border-ink-950"}>
          <Container className="py-8 sm:py-10">
            <nav aria-label="Breadcrumb" className="font-mono text-[11px] uppercase tracking-widest mb-4 opacity-80">
              <Link href={positive ? "/not-a-dick" : "/feed"} className="hover:underline">
                {positive ? "Definitely not a dick" : "Latest dick moves"}
              </Link>
              <span className="mx-2">/</span>
              <span>{incident.shortCode}</span>
            </nav>
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={positive ? "paper" : "yellow"} size="lg" className="gap-1.5">
                <CategoryIcon id={incident.categoryId} className="size-4" />
                {positive ? "DEFINITELY NOT A DICK" : incident.category.label}
              </Badge>
              <CodePlate code={incident.shortCode} />
              {incident.status === "redeemed" && <StatusStamp status="redeemed" />}
              {incident.status === "overruled" && <StatusStamp status="overruled" />}
              {isWeek && !positive && <StatusStamp status="week" />}
            </div>
            <h1 className="mt-4 text-4xl sm:text-5xl lg:text-6xl normal-case tracking-tight leading-[0.95] max-w-4xl">
              {/^["“]/.test(incident.title) ? incident.title : <>&ldquo;{incident.title}&rdquo;</>}
            </h1>
            <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2">
              <Meta className={`inline-flex items-center gap-1.5 ${positive ? "text-paper-50/90" : ""}`}>
                <MapPinIcon className="size-4" /> {locationLabel(incident, true)}
              </Meta>
              <Meta className={`inline-flex items-center gap-1.5 ${positive ? "text-paper-50/90" : ""}`}>
                <ClockIcon className="size-4" /> {occurrenceLabel(incident.occurredOn, incident.partOfDay)} · posted {relativeTime(incident.createdAt)}
              </Meta>
              {incident.submitter ? (
                <Link href={`/u/${incident.submitter.handle}`} className={`inline-flex items-center gap-2 font-mono text-xs uppercase tracking-wider hover:underline ${positive ? "text-paper-50" : "text-ink-950"}`}>
                  <Avatar seed={incident.submitter.avatarSeed} size={24} /> spotted by {incident.submitter.handle}
                </Link>
              ) : (
                <Meta className={positive ? "text-paper-50/90" : ""}>Anonymous nomination</Meta>
              )}
            </div>
          </Container>
        </header>

        <Container className="py-8 grid gap-8 lg:grid-cols-[1.4fr_1fr] lg:gap-12">
          {/* -------------------------------------------------- Main column */}
          <div className="space-y-8 min-w-0">
            {incident.photos.length > 0 ? (
              <div className="space-y-3">
                <EvidenceFrame
                  photo={incident.photos[0]}
                  categoryId={incident.categoryId}
                  priority
                  sizes="(min-width:1024px) 60vw, 100vw"
                  caption={
                    <>
                      <span>Evidence 1/{incident.photos.length}</span>
                      <span className="text-warning-500">Approx. {incident.location.suburb.toUpperCase()}</span>
                      <span className="ml-auto">{stampDate(incident.createdAt)}</span>
                    </>
                  }
                />
                {incident.photos.length > 1 && (
                  <div className="grid grid-cols-3 gap-3">
                    {incident.photos.slice(1).map((p) => (
                      <EvidenceFrame key={p.id} photo={p} categoryId={incident.categoryId} sizes="30vw" />
                    ))}
                  </div>
                )}
                <p className="font-mono text-[11px] uppercase tracking-wider text-concrete-600">
                  Faces, plates and identifying details are removed before publication. Location is approximate.
                </p>
              </div>
            ) : (
              <EvidenceFrame categoryId={incident.categoryId} caption={<span>Text nomination · no photo</span>} />
            )}

            <section className="grid gap-5 sm:grid-cols-2">
              <div className="bg-paper-100 border-[3px] border-ink-950 p-5 shadow-hard-sm">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600">{positive ? "The good move" : "The dick move"}</p>
                <p className="mt-2 font-display uppercase text-3xl leading-[0.95]">{incident.dickMove}</p>
              </div>
              <div className="bg-paper-100 border-[3px] border-ink-950 p-5 shadow-hard-sm">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600">Who was affected</p>
                <ul className="mt-2 flex flex-wrap gap-1.5">
                  {incident.affected.length === 0 && <li className="text-ink-700">Unspecified</li>}
                  {incident.affected.map((a) => (
                    <li key={a}>
                      <Badge tone="paper" size="md" className="normal-case tracking-normal font-sans font-semibold">
                        {AFFECTED_LABEL[a]}
                      </Badge>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="sm:col-span-2 bg-paper-50 border-[3px] border-ink-950 p-5 shadow-hard-sm">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600">{positive ? "What happened" : "Why it was a dick move"}</p>
                <p className="mt-2 text-lg leading-relaxed">{incident.description}</p>
                {incident.socialSource && (
                  <p className="mt-3 text-sm text-concrete-600 inline-flex items-center gap-1.5">
                    <ExternalIcon className="size-4" /> Originally shared on Facebook (link held by moderators; not scraped).
                  </p>
                )}
              </div>
            </section>

            {incident.redemption && (
              <section className="relative bg-redeem-500 text-paper-50 border-[3px] border-ink-950 p-6 shadow-hard">
                <div className="absolute -top-4 left-5">
                  <Stamp tone="paper" size="md" flat className="bg-redeem-700">
                    Redeemed
                  </Stamp>
                </div>
                <p className="mt-2 font-display uppercase text-2xl sm:text-3xl leading-[0.95]">Dick move rectified.</p>
                <p className="mt-2 text-lg leading-snug">&ldquo;{incident.redemption.note}&rdquo;</p>
                <Meta className="mt-3 block text-paper-50/80">
                  Confirmed by {incident.redemption.confirmedBy} · {relativeTime(incident.redemption.createdAt)}
                </Meta>
              </section>
            )}

            {incident.publicReplies.length > 0 && (
              <section className="bg-paper-50 border-[3px] border-dashed border-ink-950 p-5">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600">Right of reply</p>
                {incident.publicReplies.map((r) => (
                  <blockquote key={r.id} className="mt-3 border-l-[6px] border-warning-500 pl-4">
                    <p className="text-lg leading-snug">&ldquo;{r.publicReply}&rdquo;</p>
                    <Meta className="mt-1 block">Published {relativeTime(r.createdAt)} · verified by moderators, identity not disclosed</Meta>
                  </blockquote>
                ))}
              </section>
            )}

            <IncidentInteractive incident={incident} viewer={viewer} actions={actions} isOwner={isOwner} isMod={isMod} />
          </div>

          {/* -------------------------------------------------- Side column */}
          <aside className="space-y-6 lg:sticky lg:top-24 self-start">
            <div className="bg-ink-950 text-paper-50 border-[3px] border-ink-950 p-5 shadow-hard-yellow">
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-warning-500">The DBAD notice</p>
              <p className="mt-2 font-display uppercase text-2xl leading-none">Print it. Place it. Where lawful.</p>
              <p className="mt-2 text-sm text-paper-50/80 leading-snug">
                A5 or A6, five templates, with a QR that links here or just to the site. Never on private property, never on the vehicle&rsquo;s paint.
              </p>
              <div className="mt-4 mx-auto w-48">
                <NoticePreviewMini lines={lines} code={incident.shortCode} template={positive ? "friendly-reminder" : "official-warning"} />
              </div>
              <ButtonLink href={`/notice/new?incident=${incident.id}`} className="mt-5 w-full">
                <PrintIcon className="size-5" /> Generate the notice
              </ButtonLink>
            </div>

            <div className="border-[3px] border-ink-950 bg-paper-100 p-5">
              <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600">Is this about you?</p>
              <p className="mt-2 leading-snug">
                You can ask for removal, a correction, anonymisation, context, a right of reply, or redemption status — without identifying yourself publicly.
              </p>
              <ButtonLink href={`/about-you?code=${incident.shortCode}`} variant="outline" size="sm" className="mt-3">
                Start here <ArrowRightIcon className="size-4" />
              </ButtonLink>
            </div>

            {related.length > 0 && (
              <div>
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-concrete-600 mb-3">More from around here</p>
                <div className="grid gap-4">
                  {related.map((r) => (
                    <IncidentCard key={r.id} incident={r} />
                  ))}
                </div>
              </div>
            )}
          </aside>
        </Container>
      </article>
    </>
  );
}
