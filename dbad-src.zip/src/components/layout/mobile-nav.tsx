"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { CameraIcon, GridIcon, HeartIcon, MapPinIcon, UserIcon } from "@/components/icons/ui";

const items = [
  { href: "/feed", label: "Feed", Icon: GridIcon },
  { href: "/map", label: "Map", Icon: MapPinIcon },
  { href: "/nominate", label: "Nominate", Icon: CameraIcon, primary: true },
  { href: "/not-a-dick", label: "Not a dick", Icon: HeartIcon },
  { href: "/me", label: "Me", Icon: UserIcon },
];

/** Thumb-reachable bottom bar on phones. The camera button is the whole point. */
export function MobileNav() {
  const pathname = usePathname();
  if (pathname.startsWith("/nominate") || pathname.startsWith("/notice/") || pathname.startsWith("/admin")) return null;
  return (
    <nav
      className="lg:hidden fixed bottom-0 inset-x-0 z-40 bg-ink-950 text-paper-50 border-t-[3px] border-warning-500 print-hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      aria-label="Quick navigation"
    >
      <ul className="grid grid-cols-5 items-end">
        {items.map(({ href, label, Icon, primary }) => {
          const active = pathname === href || (href !== "/" && pathname.startsWith(href));
          return (
            <li key={href} className="flex justify-center">
              <Link
                href={href}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 py-2 w-full text-[10px] font-mono uppercase tracking-wider",
                  active ? "text-warning-500" : "text-paper-50/80 hover:text-warning-500",
                  primary && "-mt-5",
                )}
              >
                {primary ? (
                  <span className="flex size-14 items-center justify-center bg-warning-500 text-ink-950 border-[3px] border-ink-950 shadow-hard-sm rounded-sm">
                    <Icon className="size-7" />
                  </span>
                ) : (
                  <Icon className="size-6" />
                )}
                <span className={cn(primary && "text-warning-500 font-bold")}>{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
