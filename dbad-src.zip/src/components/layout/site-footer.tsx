import Link from "next/link";
import { FOOTER_NAV, SITE } from "@/lib/site";
import { Wordmark } from "@/components/brand/wordmark";
import { HazardTape } from "@/components/brand/hazard";

export function SiteFooter() {
  return (
    <footer className="mt-16 print-hidden">
      <HazardTape />
      <div className="concrete text-paper-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-5 py-12 grid gap-10 md:grid-cols-[1.2fr_1fr_1fr]">
          <div>
            <Wordmark className="h-12 w-auto text-warning-500" />
            <p className="mt-4 font-display uppercase text-2xl leading-none">Don&rsquo;t be a dick.</p>
            <p className="mt-3 max-w-sm text-paper-50/80 text-sm leading-relaxed">{SITE.supporting}</p>
            <p className="mt-4 font-mono text-[11px] uppercase tracking-widest text-paper-50/60">
              Call out the action. Not the person.
            </p>
          </div>
          <div>
            <h3 className="font-mono text-xs uppercase tracking-[0.2em] text-warning-500 mb-3">The board</h3>
            <ul className="space-y-2">
              <li><Link className="hover:text-warning-500" href="/feed">Latest dick moves</Link></li>
              <li><Link className="hover:text-warning-500" href="/week">Dick Move of the Week</Link></li>
              <li><Link className="hover:text-warning-500" href="/not-a-dick">Definitely not a dick</Link></li>
              <li><Link className="hover:text-warning-500" href="/map">Australian Dickery Map</Link></li>
              <li><Link className="hover:text-warning-500" href="/nominate">Nominate a dick move</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="font-mono text-xs uppercase tracking-[0.2em] text-warning-500 mb-3">The rules</h3>
            <ul className="space-y-2">
              {FOOTER_NAV.map((l) => (
                <li key={l.href}>
                  <Link className="hover:text-warning-500" href={l.href}>{l.label}</Link>
                </li>
              ))}
              <li><Link className="hover:text-warning-500" href="/sign-in">Sign in</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-paper-50/10">
          <div className="mx-auto max-w-7xl px-4 sm:px-5 py-6 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <p className="font-display uppercase text-lg sm:text-xl leading-none text-warning-500">{SITE.closing}</p>
            <p className="font-mono text-[11px] uppercase tracking-widest text-paper-50/60">
              {SITE.domain} · Made in Australia · We&rsquo;ve all been a dick at some point.
            </p>
          </div>
        </div>
      </div>
      {/* room for the mobile bottom bar */}
      <div className="h-20 lg:hidden bg-ink-900" aria-hidden />
    </footer>
  );
}
