"use client";

import * as React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ViewerOrNull } from "@/lib/data/repository";
import { NAV } from "@/lib/site";
import { cn } from "@/lib/utils";
import { Wordmark } from "@/components/brand/wordmark";
import { ButtonLink } from "@/components/ui/button";
import { Avatar } from "@/components/brand/avatar";
import { BellIcon, MenuIcon, PlusIcon, XIcon } from "@/components/icons/ui";

export function SiteHeader({ viewer, unread = 0 }: { viewer: ViewerOrNull; unread?: number }) {
  const [open, setOpen] = React.useState(false);
  const pathname = usePathname();
  React.useEffect(() => setOpen(false), [pathname]);

  return (
    <header className="sticky top-0 z-50 print-hidden">
      <div className="hazard-thin h-2" aria-hidden />
      <div className="bg-ink-950 text-paper-50 border-b-[3px] border-ink-950">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-3 sm:px-5 h-16">
          <Link href="/" className="flex items-center gap-3 shrink-0" aria-label="DBAD home">
            <Wordmark className="h-8 w-auto text-warning-500" />
            <span className="hidden md:block font-display uppercase text-sm tracking-wide leading-none text-paper-50/90">
              Don&rsquo;t be
              <br />a dick.
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-1 ml-6" aria-label="Primary">
            {NAV.map((item) => {
              const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "px-3 py-2 font-display uppercase tracking-wide text-base leading-none border-2 border-transparent hover:border-warning-500 hover:text-warning-500 transition-colors",
                    active && "text-warning-500 border-b-warning-500",
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <div className="hidden sm:block">
              <ButtonLink href="/nominate" size="sm">
                <PlusIcon className="size-4" /> Nominate a dick move
              </ButtonLink>
            </div>
            {viewer ? (
              <>
                <Link
                  href="/notifications"
                  className="relative inline-flex size-10 items-center justify-center border-2 border-paper-50/30 hover:border-warning-500 hover:text-warning-500"
                  aria-label={unread ? `${unread} unread notifications` : "Notifications"}
                >
                  <BellIcon className="size-5" />
                  {unread > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 bg-alert-500 text-paper-50 font-mono text-[11px] font-bold leading-5 text-center border-2 border-ink-950">
                      {unread > 9 ? "9+" : unread}
                    </span>
                  )}
                </Link>
                <Link href="/me" className="inline-flex items-center gap-2 hover:text-warning-500" aria-label="Your profile">
                  <Avatar seed={viewer.handle} size={36} />
                  <span className="hidden xl:inline font-semibold text-sm">{viewer.displayName}</span>
                </Link>
              </>
            ) : (
              <div className="hidden sm:block">
                <ButtonLink href="/sign-in" variant="outline-light" size="sm">
                  Sign in
                </ButtonLink>
              </div>
            )}
            <button
              type="button"
              onClick={() => setOpen((o) => !o)}
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? "Close menu" : "Open menu"}
              className="lg:hidden inline-flex size-10 items-center justify-center border-2 border-paper-50/30 hover:border-warning-500 hover:text-warning-500"
            >
              {open ? <XIcon className="size-5" /> : <MenuIcon className="size-5" />}
            </button>
          </div>
        </div>

        <div id="mobile-menu" hidden={!open} className="lg:hidden border-t-2 border-paper-50/10 bg-ink-900">
          <nav className="mx-auto max-w-7xl px-3 sm:px-5 py-3 grid gap-1" aria-label="Mobile">
            {NAV.map((item) => (
              <Link key={item.href} href={item.href} className="block px-3 py-3 font-display uppercase text-xl tracking-wide leading-none hover:text-warning-500 border-b border-paper-50/10">
                {item.label}
              </Link>
            ))}
            <div className="flex flex-wrap gap-2 pt-3">
              <ButtonLink href="/nominate" size="md" className="flex-1">
                Nominate a dick move
              </ButtonLink>
              {viewer ? (
                <ButtonLink href="/me" variant="outline-light" size="md">
                  Your profile
                </ButtonLink>
              ) : (
                <ButtonLink href="/sign-in" variant="outline-light" size="md">
                  Sign in
                </ButtonLink>
              )}
            </div>
            <Link href="/standards" className="mt-2 px-3 py-2 font-mono text-xs uppercase tracking-widest text-paper-50/70 hover:text-warning-500">
              Community standard →
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
