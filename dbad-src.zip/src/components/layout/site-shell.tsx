import * as React from "react";
import type { ViewerOrNull } from "@/lib/data/repository";
import { SiteHeader } from "./site-header";
import { SiteFooter } from "./site-footer";
import { MobileNav } from "./mobile-nav";
import { ToastProvider } from "@/components/ui/toast";

export function SiteShell({ viewer, unread, children }: { viewer: ViewerOrNull; unread?: number; children: React.ReactNode }) {
  return (
    <ToastProvider>
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[100] focus:bg-warning-500 focus:px-4 focus:py-2 focus:font-display focus:uppercase">
        Skip to content
      </a>
      <SiteHeader viewer={viewer} unread={unread} />
      <main id="main" className="min-h-[60vh]">
        {children}
      </main>
      <SiteFooter />
      <MobileNav />
    </ToastProvider>
  );
}

/** Standard page container. */
export function Container({ className = "", children, size = "xl" }: { className?: string; children: React.ReactNode; size?: "md" | "lg" | "xl" | "2xl" }) {
  const max = { md: "max-w-3xl", lg: "max-w-5xl", xl: "max-w-7xl", "2xl": "max-w-[90rem]" }[size];
  return <div className={`mx-auto w-full ${max} px-4 sm:px-5 ${className}`}>{children}</div>;
}

/** Page header block: kicker + big title + optional intro. */
export function PageHeader({ kicker, title, intro, children, dark }: { kicker?: string; title: React.ReactNode; intro?: React.ReactNode; children?: React.ReactNode; dark?: boolean }) {
  return (
    <section className={dark ? "concrete text-paper-50" : "bg-paper-100 border-b-[3px] border-ink-950"}>
      <Container className="py-8 sm:py-12">
        {kicker && <p className={`font-mono text-xs uppercase tracking-[0.2em] mb-3 ${dark ? "text-warning-500" : "text-concrete-600"}`}>{kicker}</p>}
        <h1 className={`text-4xl sm:text-5xl md:text-6xl ${dark ? "text-paper-50" : ""}`}>{title}</h1>
        {intro && <div className={`mt-4 max-w-2xl text-base sm:text-lg leading-relaxed ${dark ? "text-paper-50/85" : "text-ink-700"}`}>{intro}</div>}
        {children && <div className="mt-6">{children}</div>}
      </Container>
    </section>
  );
}
