import Link from "next/link";
import type { MapCluster } from "@/lib/domain/types";
import { getCategory } from "@/lib/domain/categories";
import { cn } from "@/lib/utils";

/**
 * A deliberately schematic Australia. The outline is simplified on purpose — DBAD
 * shows *areas*, never addresses, so a stencil-style map is more honest than a street
 * map would be. Coordinates are lat/lng pairs projected with a simple equirectangular
 * projection corrected for latitude.
 */
const MAINLAND: Array<[number, number]> = [
  [-10.7, 142.5], [-12.5, 143.5], [-14.5, 144.5], [-15.5, 145.2], [-16.9, 145.8], [-18.3, 146.3], [-19.3, 146.8], [-20.3, 148.7], [-21.1, 149.2], [-22.4, 150.6],
  [-23.4, 150.9], [-23.8, 151.3], [-24.8, 152.4], [-25.3, 153.2], [-26.5, 153.1], [-27.5, 153.1], [-28.6, 153.6], [-29.5, 153.4], [-30.3, 153.1], [-31.4, 152.9],
  [-32.2, 152.5], [-32.9, 151.8], [-33.9, 151.3], [-34.4, 150.9], [-35.1, 150.8], [-35.7, 150.2], [-36.4, 150.1], [-37.1, 149.9], [-37.5, 149.98], [-37.9, 148.0],
  [-38.6, 147.0], [-39.1, 146.4], [-38.5, 145.4], [-38.3, 144.6], [-38.85, 143.5], [-38.4, 142.5], [-38.35, 141.6], [-38.0, 140.7], [-36.8, 139.85], [-35.8, 139.3],
  [-35.6, 138.1], [-34.9, 138.5], [-34.4, 138.0], [-35.3, 137.0], [-34.2, 137.5], [-32.5, 137.8], [-33.6, 137.0], [-34.7, 135.9], [-33.7, 134.9], [-32.8, 134.2],
  [-32.1, 133.7], [-31.5, 131.1], [-31.7, 128.9], [-32.5, 125.5], [-33.9, 121.9], [-35.0, 117.9], [-34.4, 115.1], [-33.5, 115.0], [-31.95, 115.85], [-30.5, 115.1],
  [-28.8, 114.6], [-27.7, 114.1], [-26.5, 113.6], [-25.5, 113.5], [-24.0, 113.4], [-22.6, 113.7], [-21.9, 114.1], [-21.6, 115.1], [-20.7, 116.8], [-20.3, 118.6],
  [-19.5, 121.0], [-17.9, 122.2], [-16.4, 123.0], [-15.6, 124.4], [-15.0, 124.9], [-14.2, 125.9], [-13.9, 127.0], [-14.9, 128.2], [-15.0, 129.4], [-13.8, 129.9],
  [-12.45, 130.85], [-12.1, 131.6], [-11.3, 132.2], [-11.9, 134.2], [-12.0, 136.0], [-12.2, 136.8], [-13.1, 136.4], [-14.0, 135.7], [-14.7, 135.4], [-15.9, 136.5],
  [-16.5, 137.9], [-17.4, 139.6], [-17.5, 140.8], [-16.5, 141.3], [-15.2, 141.6], [-13.8, 141.5], [-12.6, 141.9], [-11.5, 142.1],
];
const TASMANIA: Array<[number, number]> = [
  [-40.7, 144.7], [-41.0, 146.0], [-41.0, 147.0], [-40.9, 147.9], [-41.5, 148.3], [-42.2, 148.3], [-42.7, 148.0], [-43.2, 147.9], [-43.6, 146.9], [-43.2, 146.0],
  [-42.2, 145.3], [-41.4, 144.8],
];

const W = 1000;
const H = 900;
const LAT_SCALE = Math.cos((27 * Math.PI) / 180);
const B = { minLat: -44.6, maxLat: -10.0, minLng: 112.5, maxLng: 154.5 };

function project(lat: number, lng: number): { x: number; y: number } {
  const lngSpan = (B.maxLng - B.minLng) * LAT_SCALE;
  const latSpan = B.maxLat - B.minLat;
  const scale = Math.min(W / lngSpan, H / latSpan);
  const ox = (W - lngSpan * scale) / 2;
  const oy = (H - latSpan * scale) / 2;
  return { x: ox + (lng - B.minLng) * LAT_SCALE * scale, y: oy + (B.maxLat - lat) * scale };
}

function toPath(points: Array<[number, number]>): string {
  return points.map(([lat, lng], i) => `${i === 0 ? "M" : "L"}${project(lat, lng).x.toFixed(1)} ${project(lat, lng).y.toFixed(1)}`).join("") + "Z";
}

/**
 * Bigger clusters get their label first; smaller ones nearby stay unlabelled so the
 * south-east corner (where most of Australia lives) doesn't turn into soup. Every cluster
 * is still clickable and listed beside the map.
 */
function placeLabels(clusters: MapCluster[], max: number) {
  const placed: Array<{ x: number; y: number; w: number; h: number }> = [];
  return [...clusters]
    .sort((a, b) => b.count - a.count)
    .map((c) => {
      const p = project(c.approxLat, c.approxLng);
      const r = 16 + Math.sqrt(c.count / max) * 40;
      const w = c.region.length * 13 + 16;
      const box = { x: p.x - w / 2, y: p.y + r + 6, w, h: 26 };
      const collides = placed.some((b) => box.x < b.x + b.w && box.x + box.w > b.x && box.y < b.y + b.h && box.y + box.h > b.y);
      const circleClash = placed.some((b) => Math.hypot(b.x + b.w / 2 - p.x, b.y - 6 - p.y) < r + 10);
      const label = !collides && !circleClash;
      if (label) placed.push(box);
      return { c, p, r, label };
    });
}

export function AustraliaMap({ clusters, activeRegion, hrefFor, className }: { clusters: MapCluster[]; activeRegion?: string; hrefFor: (c: MapCluster) => string; className?: string }) {
  const max = Math.max(1, ...clusters.map((c) => c.count));
  return (
    <div className={cn("relative bg-ink-950 border-[3px] border-ink-950 shadow-hard overflow-hidden", className)}>
      <svg viewBox={`0 0 ${W} ${H}`} className="block w-full h-auto" role="img" aria-label="Map of Australia with dick moves clustered by area">
        <defs>
          <pattern id="map-dots" width="14" height="14" patternUnits="userSpaceOnUse">
            <circle cx="7" cy="7" r="1.6" fill="#f5c400" opacity="0.35" />
          </pattern>
        </defs>
        <rect width={W} height={H} fill="#171717" />
        <g stroke="#f5c400" strokeWidth="4" strokeLinejoin="round" strokeDasharray="14 8" fill="url(#map-dots)">
          <path d={toPath(MAINLAND)} />
          <path d={toPath(TASMANIA)} />
        </g>
        <text x={W - 20} y={H - 20} textAnchor="end" fill="#8a8a82" fontFamily="IBM Plex Mono, monospace" fontSize="20" letterSpacing="3">
          APPROXIMATE AREAS ONLY · NO ADDRESSES · EVER
        </text>
        {(() => {
          const placed = placeLabels(clusters, max);
          return (
            <>
              {/* circles first (smallest on top so tiny clusters stay clickable), labels in a second pass so they never sit under a circle */}
              {[...placed].sort((a, b) => b.c.count - a.c.count).map(({ c, p, r }) => {
                const active = c.region === activeRegion;
                return (
                  <Link key={c.region} href={hrefFor(c)} aria-label={`${c.count} dick moves around ${c.region}`}>
                    <g className="cursor-pointer">
                      <circle cx={p.x} cy={p.y} r={r + 10} fill={active ? "#d7263d" : "#f5c400"} opacity="0.18" />
                      <circle cx={p.x} cy={p.y} r={r} fill={active ? "#d7263d" : "#f5c400"} stroke="#0f0f0f" strokeWidth="5" />
                      <text x={p.x} y={p.y + r * 0.32} textAnchor="middle" fill={active ? "#f7f3ea" : "#0f0f0f"} fontFamily="DBAD Display, Impact, sans-serif" fontWeight="900" fontSize={r * 0.95}>
                        {c.count}
                      </text>
                    </g>
                  </Link>
                );
              })}
              {placed
                .filter((x) => x.label)
                .map(({ c, p, r }) => (
                  <text
                    key={`${c.region}-label`}
                    x={p.x}
                    y={p.y + r + 26}
                    textAnchor="middle"
                    fill="#f7f3ea"
                    stroke="#171717"
                    strokeWidth="6"
                    paintOrder="stroke"
                    fontFamily="DBAD Display, Impact, sans-serif"
                    fontWeight="900"
                    fontSize="22"
                    letterSpacing="1"
                    style={{ pointerEvents: "none" }}
                  >
                    {c.region.toUpperCase()}
                  </text>
                ))}
            </>
          );
        })()}
      </svg>
    </div>
  );
}

export function ClusterList({ clusters, hrefFor, activeRegion }: { clusters: MapCluster[]; hrefFor: (c: MapCluster) => string; activeRegion?: string }) {
  return (
    <ul className="grid gap-2">
      {clusters.map((c) => (
        <li key={c.region}>
          <Link
            href={hrefFor(c)}
            className={cn("flex items-center gap-4 border-[3px] border-ink-950 bg-paper-50 p-3 hover:bg-white", c.region === activeRegion && "bg-warning-500")}
          >
            <span className="font-display text-3xl leading-none tabular w-14 text-right">{c.count}</span>
            <span className="min-w-0 flex-1">
              <span className="block font-display uppercase text-lg leading-none">{c.region}</span>
              <span className="block font-mono text-[11px] uppercase tracking-wider text-concrete-600 mt-1">
                {c.state} · {c.countThisWeek} this week · {c.redeemed} redeemed · mostly {getCategory(c.topCategoryId).short.toLowerCase()}
                {c.notADick ? ` · ${c.notADick} not-a-dick` : ""}
              </span>
            </span>
          </Link>
        </li>
      ))}
    </ul>
  );
}
