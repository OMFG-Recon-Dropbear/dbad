import type { IncidentSummary, MapCluster } from "@/lib/domain/types";
import { Container, PageHeader } from "@/components/layout/site-shell";
import { AustraliaMap, ClusterList } from "./australia-map";
import { IncidentCard } from "@/components/incident/incident-card";
import { SectionHeading } from "@/components/brand/hazard";
import { ButtonLink } from "@/components/ui/button";
import { ArrowRightIcon } from "@/components/icons/ui";

export interface MapProps {
  clusters: MapCluster[];
  activeRegion?: string;
  regionIncidents: IncidentSummary[];
}

export function MapView({ clusters, activeRegion, regionIncidents }: MapProps) {
  const top = clusters[0];
  const active = clusters.find((c) => c.region === activeRegion);
  const hrefFor = (c: MapCluster) => `/map?region=${encodeURIComponent(c.region)}`;
  return (
    <>
      <PageHeader
        kicker="Australian Dickery Map"
        title={
          <>
            Where the <span className="text-warning-700">dick moves</span> are.
          </>
        }
        intro={
          top
            ? `${top.countThisWeek} dick moves spotted around ${top.region} this week. Locations are approximate — suburb or public place only, never a home.`
            : "Locations are approximate — suburb or public place only, never a home."
        }
      />
      <Container className="py-8 grid gap-8 lg:grid-cols-[1.4fr_1fr]">
        <div>
          <AustraliaMap clusters={clusters} activeRegion={activeRegion} hrefFor={hrefFor} />
          <p className="mt-3 font-mono text-[11px] uppercase tracking-wider text-concrete-600">
            Precise coordinates are never stored where they could identify a home. Public businesses, roads, parks and facilities may be named.
          </p>
        </div>
        <div>
          <SectionHeading kicker="Browse by area" title="Pick a spot." />
          <div className="mt-4">
            <ClusterList clusters={clusters} hrefFor={hrefFor} activeRegion={activeRegion} />
          </div>
        </div>
      </Container>
      {active && (
        <section className="bg-paper-100 border-y-[3px] border-ink-950">
          <Container className="py-10">
            <SectionHeading
              kicker={`${active.count} dick moves · ${active.redeemed} redeemed`}
              title={`Around ${active.region}`}
              action={
                <ButtonLink href={`/feed?region=${encodeURIComponent(active.region)}`} variant="outline" size="sm">
                  All from {active.region} <ArrowRightIcon className="size-4" />
                </ButtonLink>
              }
            />
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {regionIncidents.map((inc) => (
                <IncidentCard key={inc.id} incident={inc} />
              ))}
            </div>
          </Container>
        </section>
      )}
    </>
  );
}
