"use client";

import * as React from "react";
import Link from "next/link";
import type { AffectedGroup, AustralianState, CategoryId, IncidentKind, NominationInput, PartOfDay } from "@/lib/domain/types";
import type { ViewerOrNull } from "@/lib/data/repository";
import type { NominationActions } from "@/lib/actions/types";
import type { RewriteSuggestion } from "@/lib/ai/rewrite";
import type { Region } from "@/lib/client/images";
import { applyRedactions, downscale } from "@/lib/client/images";
import { AFFECTED_GROUPS, AUSTRALIAN_STATES, CATEGORIES, PART_OF_DAY } from "@/lib/domain/categories";
import { LIMITS, isFacebookUrl, validateNomination } from "@/lib/domain/validation";
import { scanText } from "@/lib/domain/pii";
import { coarsen, nearestPlace } from "@/lib/domain/geo";
import { isoDate } from "@/lib/domain/utils";
import { buildNoticeLines } from "@/lib/notice/lines";
import { cn } from "@/lib/utils";
import { Button, ButtonLink } from "@/components/ui/button";
import { Checkbox, Chip, FieldError, Help, Input, Label, Select, Textarea } from "@/components/ui/input";
import { Badge, Meta } from "@/components/ui/badge";
import { Stamp } from "@/components/brand/stamp";
import { HazardTape } from "@/components/brand/hazard";
import { CategoryIcon } from "@/components/icons/categories";
import { ArrowLeftIcon, ArrowRightIcon, CameraIcon, CheckIcon, FacebookIcon, LocateIcon, SparkIcon, TrashIcon, UploadIcon, WarningIcon } from "@/components/icons/ui";
import { NoticeCard } from "@/components/notice/notice-card";
import { SITE } from "@/lib/site";
import { useToast } from "@/components/ui/toast";
import { RedactionEditor } from "./redaction-editor";

interface DraftPhoto {
  id: string;
  dataUrl: string;
  width: number;
  height: number;
  regions: Region[];
}

interface Draft {
  kind: IncidentKind;
  photos: DraftPhoto[];
  facebookUrl: string;
  categoryId: CategoryId | null;
  description: string;
  title: string;
  dickMove: string;
  affected: AffectedGroup[];
  suburb: string;
  state: AustralianState | "";
  place: string;
  approxLat?: number;
  approxLng?: number;
  occurredOn: string;
  partOfDay: PartOfDay;
  acceptedStandard: boolean;
  reviewedRedaction: boolean;
}

const STEPS = [
  { id: 1, label: "What happened" },
  { id: 2, label: "Where & when" },
  { id: 3, label: "Redaction check" },
  { id: 4, label: "Review" },
];

export function NominateWizard({
  viewer,
  actions,
  initialKind = "dick_move",
  initialCategory,
  requireAuthForPhotos = false,
}: {
  viewer: ViewerOrNull;
  actions: NominationActions;
  initialKind?: IncidentKind;
  initialCategory?: CategoryId;
  requireAuthForPhotos?: boolean;
}) {
  const toast = useToast();
  const [step, setStep] = React.useState(1);
  const [draft, setDraft] = React.useState<Draft>({
    kind: initialKind,
    photos: [],
    facebookUrl: "",
    categoryId: initialCategory ?? null,
    description: "",
    title: "",
    dickMove: "",
    affected: [],
    suburb: "",
    state: "",
    place: "",
    occurredOn: isoDate(new Date()),
    partOfDay: "afternoon",
    acceptedStandard: false,
    reviewedRedaction: false,
  });
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [submitting, setSubmitting] = React.useState(false);
  const [result, setResult] = React.useState<{ slug: string; shortCode: string; noticeId: string; moderationStatus: string } | null>(null);
  const positive = draft.kind === "not_a_dick";
  const patch = (p: Partial<Draft>) => setDraft((d) => ({ ...d, ...p }));

  const hasPhotos = draft.photos.length > 0;
  const visibleSteps = hasPhotos ? STEPS : STEPS.filter((s) => s.id !== 3);

  function validateStep(n: number): boolean {
    const e: Record<string, string> = {};
    if (n === 1) {
      if (!draft.categoryId) e.categoryId = "Pick a category.";
      if (draft.description.trim().length < LIMITS.description.min) e.description = positive ? "Tell us what they did — one or two sentences." : "Tell us what made it a dick move — one or two factual sentences.";
      if (draft.dickMove.trim().length < LIMITS.dickMove.min) e.dickMove = positive ? "Sum up the good move in a few words." : "Sum up the dick move in a few words.";
      if (draft.title.trim().length < LIMITS.title.min) e.title = "Give it a one-liner (or let DBAD suggest one).";
      if (draft.facebookUrl && !isFacebookUrl(draft.facebookUrl)) e.facebookUrl = "That doesn't look like a Facebook post link.";
      for (const [k, v] of Object.entries({ description: draft.description, title: draft.title, dickMove: draft.dickMove })) {
        const s = scanText(v);
        if (s.blocked) e[k] = "That reads as a threat. DBAD never threatens people.";
        else if (s.findings.some((f) => f.severity === "block")) e[k] = "Remove the identifying details flagged below.";
      }
      if (requireAuthForPhotos && !viewer && hasPhotos) e.photos = "Sign in to publish photos, or remove them to post a text-only nomination.";
    }
    if (n === 2) {
      if (draft.suburb.trim().length < LIMITS.suburb.min) e.suburb = "Suburb or town, please.";
      if (!draft.state) e.state = "Pick a state or territory.";
      if (/\b\d{1,5}[A-Za-z]?\s+[A-Z][a-z]+\s+(?:St|Street|Rd|Road|Ave|Avenue|Dr|Drive|Cres|Crescent|Ct|Court|Pl|Place|Cl|Close)\b/.test(`${draft.suburb} ${draft.place}`)) {
        e.place = "That looks like a street address. Public places only — 'Coles car park' is fine, '14 Smith St' is not.";
      }
    }
    if (n === 3 && hasPhotos && !draft.reviewedRedaction) e.reviewedRedaction = "Please confirm you've checked every photo.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function next() {
    if (!validateStep(step)) return;
    const idx = visibleSteps.findIndex((s) => s.id === step);
    const nxt = visibleSteps[idx + 1];
    if (nxt) {
      setStep(nxt.id);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }
  function back() {
    const idx = visibleSteps.findIndex((s) => s.id === step);
    const prev = visibleSteps[idx - 1];
    if (prev) setStep(prev.id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function submit() {
    if (!draft.acceptedStandard) {
      setErrors({ acceptedStandard: "You need to agree to the community standard." });
      return;
    }
    setSubmitting(true);
    try {
      const photos = await Promise.all(
        draft.photos.map(async (p) => ({
          src: p.regions.length ? await applyRedactions(p.dataUrl, p.regions) : p.dataUrl,
          width: p.width,
          height: p.height,
          alt: `${draft.dickMove || "Evidence photo"} — ${draft.suburb}`,
          redactionCount: p.regions.length,
        })),
      );
      const input: NominationInput = {
        kind: draft.kind,
        categoryId: draft.categoryId!,
        dickMove: draft.dickMove.trim(),
        title: draft.title.trim(),
        description: draft.description.trim(),
        affected: draft.affected,
        location: { suburb: draft.suburb.trim(), state: draft.state as AustralianState, place: draft.place.trim() || undefined, approxLat: draft.approxLat, approxLng: draft.approxLng },
        occurredOn: draft.occurredOn,
        partOfDay: draft.partOfDay,
        photos,
        facebookUrl: draft.facebookUrl.trim() || undefined,
        acceptedStandard: draft.acceptedStandard,
        reviewedRedaction: hasPhotos ? draft.reviewedRedaction : true,
      };
      const local = validateNomination(input);
      if (!local.ok) {
        setErrors(local.fieldErrors ?? {});
        toast.push({ tone: "red", title: "A couple of things need fixing", body: Object.values(local.fieldErrors ?? {})[0] });
        setSubmitting(false);
        return;
      }
      const res = await actions.submit(input);
      if (!res.ok || !res.data) {
        setErrors(res.fieldErrors ?? {});
        toast.push({ tone: "red", title: "Not submitted", body: res.message ?? Object.values(res.fieldErrors ?? {})[0] });
        setSubmitting(false);
        return;
      }
      setResult(res.data);
      window.scrollTo({ top: 0 });
    } catch (err) {
      toast.push({ tone: "red", title: "Something went sideways", body: err instanceof Error ? err.message : "Try again." });
    } finally {
      setSubmitting(false);
    }
  }

  if (result) return <SuccessView result={result} draft={draft} />;

  return (
    <div className="pb-28">
      {/* progress */}
      <div className="bg-ink-950 text-paper-50 border-b-[3px] border-ink-950">
        <div className="mx-auto max-w-3xl px-4 sm:px-5 py-4">
          <div className="flex items-center justify-between gap-3">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-warning-500">
              {positive ? "Nominate a not-a-dick" : "Nominate a dick move"} · step {visibleSteps.findIndex((s) => s.id === step) + 1} of {visibleSteps.length}
            </p>
            <button
              type="button"
              onClick={() => patch({ kind: positive ? "dick_move" : "not_a_dick" })}
              className="font-mono text-[11px] uppercase tracking-wider underline decoration-warning-500 decoration-2 underline-offset-2 hover:text-warning-500"
            >
              Switch to {positive ? "dick move" : "not a dick"}
            </button>
          </div>
          <ol className="mt-3 grid gap-1" style={{ gridTemplateColumns: `repeat(${visibleSteps.length}, minmax(0, 1fr))` }}>
            {visibleSteps.map((s, i) => {
              const done = visibleSteps.findIndex((x) => x.id === step) > i;
              const active = s.id === step;
              return (
                <li key={s.id} className="min-w-0">
                  <div className={cn("h-2", active ? "hazard-thin" : done ? "bg-warning-500" : "bg-paper-50/20")} />
                  <p className={cn("mt-1.5 font-display uppercase text-xs sm:text-sm leading-none truncate", active ? "text-warning-500" : done ? "text-paper-50" : "text-paper-50/50")}>{s.label}</p>
                </li>
              );
            })}
          </ol>
        </div>
      </div>

      <div className="mx-auto max-w-3xl px-4 sm:px-5 py-6 sm:py-8">
        {step === 1 && <StepWhat draft={draft} patch={patch} errors={errors} viewer={viewer} actions={actions} requireAuthForPhotos={requireAuthForPhotos} />}
        {step === 2 && <StepWhere draft={draft} patch={patch} errors={errors} />}
        {step === 3 && <StepRedact draft={draft} patch={patch} errors={errors} />}
        {step === 4 && <StepReview draft={draft} patch={patch} errors={errors} viewer={viewer} />}
      </div>

      {/* sticky action bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 bg-paper-50 border-t-[3px] border-ink-950 print-hidden" style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
        <div className="mx-auto max-w-3xl px-4 sm:px-5 py-3 flex items-center gap-3">
          {step > 1 ? (
            <Button variant="paper" onClick={back}>
              <ArrowLeftIcon className="size-5" /> Back
            </Button>
          ) : (
            <ButtonLink href="/" variant="ghost">
              Cancel
            </ButtonLink>
          )}
          <div className="flex-1" />
          {step < 4 ? (
            <Button size="lg" onClick={next}>
              Continue <ArrowRightIcon className="size-5" />
            </Button>
          ) : (
            <Button size="lg" variant={positive ? "redeem" : "primary"} onClick={submit} disabled={submitting}>
              {submitting ? "Submitting…" : positive ? "Nominate the legend" : "DBAD it"}
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step 1 — what happened
// ---------------------------------------------------------------------------
function StepWhat({
  draft,
  patch,
  errors,
  viewer,
  actions,
  requireAuthForPhotos,
}: {
  draft: Draft;
  patch: (p: Partial<Draft>) => void;
  errors: Record<string, string>;
  viewer: ViewerOrNull;
  actions: NominationActions;
  requireAuthForPhotos: boolean;
}) {
  const toast = useToast();
  const positive = draft.kind === "not_a_dick";
  const [suggestions, setSuggestions] = React.useState<RewriteSuggestion[] | null>(null);
  const [suggesting, setSuggesting] = React.useState(false);
  const [removed, setRemoved] = React.useState<string[]>([]);
  const [processing, setProcessing] = React.useState(false);
  const fileRef = React.useRef<HTMLInputElement>(null);
  const cameraRef = React.useRef<HTMLInputElement>(null);
  const descScan = scanText(draft.description);
  const showAdvanced = draft.title.length > 0 || draft.dickMove.length > 0;

  async function addFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    const room = LIMITS.photos - draft.photos.length;
    const list = Array.from(files).slice(0, room);
    if (list.length < files.length) toast.push({ tone: "yellow", title: `Up to ${LIMITS.photos} photos`, body: "The behaviour, not a documentary." });
    setProcessing(true);
    const out: DraftPhoto[] = [];
    for (const f of list) {
      try {
        const d = await downscale(f);
        out.push({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, dataUrl: d.dataUrl, width: d.width, height: d.height, regions: [] });
      } catch (err) {
        toast.push({ tone: "red", title: "Couldn't read a photo", body: err instanceof Error ? err.message : undefined });
      }
    }
    setProcessing(false);
    patch({ photos: [...draft.photos, ...out] });
  }

  async function suggest() {
    if (draft.description.trim().length < 8 || !draft.categoryId) {
      toast.push({ tone: "ink", title: "Write a sentence first", body: "Even an angry one. DBAD will tidy it up." });
      return;
    }
    setSuggesting(true);
    try {
      const res = await actions.suggest({ text: draft.description, categoryId: draft.categoryId, affected: draft.affected, kind: draft.kind });
      setSuggestions(res.suggestions);
      setRemoved(res.removed);
    } finally {
      setSuggesting(false);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl sm:text-5xl">{positive ? "Who did the right thing?" : "What happened?"}</h1>
        <p className="mt-2 text-ink-700">
          {positive ? "Trolleys returned, rubbish picked up, cars moved. Call out the good stuff too." : "Photo first, words second. Keep it factual — DBAD will help make it funny."}
        </p>
      </div>

      {/* Photos */}
      <section>
        <Label hint={positive ? "Optional. Photograph the deed, not the person." : "Optional but recommended. Photograph the behaviour, never the person. No faces, no plates — you'll get a redaction step next."}>Photos</Label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {draft.photos.map((p) => (
            <div key={p.id} className="relative aspect-[4/3] border-[3px] border-ink-950 bg-ink-950 overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.dataUrl} alt="" className="size-full object-cover" />
              <button
                type="button"
                aria-label="Remove photo"
                onClick={() => patch({ photos: draft.photos.filter((x) => x.id !== p.id) })}
                className="absolute top-1.5 right-1.5 size-8 grid place-items-center bg-paper-50 border-2 border-ink-950 hover:bg-alert-500 hover:text-paper-50"
              >
                <TrashIcon className="size-4" />
              </button>
            </div>
          ))}
          {draft.photos.length < LIMITS.photos && (
            <>
              <button
                type="button"
                onClick={() => cameraRef.current?.click()}
                disabled={processing}
                className="aspect-[4/3] border-[3px] border-dashed border-ink-950 bg-warning-500 hover:bg-warning-400 flex flex-col items-center justify-center gap-1 font-display uppercase text-lg leading-none"
              >
                <CameraIcon className="size-8" /> {processing ? "Processing…" : "Take photo"}
              </button>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={processing}
                className="aspect-[4/3] border-[3px] border-dashed border-ink-950 bg-paper-100 hover:bg-white flex flex-col items-center justify-center gap-1 font-display uppercase text-lg leading-none"
              >
                <UploadIcon className="size-8" /> Upload
              </button>
            </>
          )}
        </div>
        <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="sr-only" onChange={(e) => addFiles(e.target.files)} />
        <input ref={fileRef} type="file" accept="image/*" multiple className="sr-only" onChange={(e) => addFiles(e.target.files)} />
        <FieldError>{errors.photos}</FieldError>
        {requireAuthForPhotos && !viewer && draft.photos.length > 0 && (
          <Help>
            <Link href="/sign-in?next=/nominate" className="font-semibold underline decoration-warning-500 decoration-2">
              Sign in
            </Link>{" "}
            to publish photos. Text-only nominations can be anonymous.
          </Help>
        )}
      </section>

      {/* Facebook */}
      <section>
        <Label htmlFor="fb" hint="Optional. Paste the public post you saw it in. We don't scrape Facebook — you still describe it here.">
          <span className="inline-flex items-center gap-2">
            <FacebookIcon className="size-4" /> Submit from Facebook
          </span>
        </Label>
        <Input id="fb" inputMode="url" placeholder="https://www.facebook.com/groups/…/posts/…" value={draft.facebookUrl} onChange={(e) => patch({ facebookUrl: e.target.value })} aria-invalid={!!errors.facebookUrl} />
        <FieldError>{errors.facebookUrl}</FieldError>
      </section>

      {/* Category */}
      <section>
        <Label hint={positive ? "Which area of life did they improve?" : "Pick the closest. 'Other dickery' exists for a reason."}>Category</Label>
        <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 gap-2">
          {CATEGORIES.map((c) => {
            const active = draft.categoryId === c.id;
            return (
              <button
                key={c.id}
                type="button"
                aria-pressed={active}
                onClick={() => patch({ categoryId: c.id })}
                className={cn(
                  "text-left border-[3px] border-ink-950 rounded-sm p-3 flex gap-3 items-start transition-colors",
                  active ? "bg-ink-950 text-warning-500 shadow-hard-yellow" : "bg-paper-50 hover:bg-white shadow-hard-sm",
                )}
              >
                <CategoryIcon id={c.id} className="size-8 shrink-0" />
                <span className="min-w-0">
                  <span className="block font-display uppercase text-lg leading-none">{positive ? c.short : c.label}</span>
                  <span className={cn("block text-xs mt-1 leading-snug", active ? "text-paper-50/80" : "text-concrete-600")}>{c.blurb}</span>
                </span>
              </button>
            );
          })}
        </div>
        <FieldError>{errors.categoryId}</FieldError>
        {draft.categoryId && CATEGORIES.find((c) => c.id === draft.categoryId)?.caution && (
          <p className="mt-2 inline-flex items-start gap-2 text-sm font-semibold bg-warning-500 border-2 border-ink-950 px-3 py-2">
            <WarningIcon className="size-4 shrink-0 mt-0.5" /> {CATEGORIES.find((c) => c.id === draft.categoryId)?.caution}
          </p>
        )}
      </section>

      {/* Description + AI */}
      <section>
        <Label htmlFor="desc" hint={positive ? "One or two sentences about what they did." : "Short and factual. Example: “Parked completely across the footpath despite several available spaces nearby.”"}>
          {positive ? "What did they do?" : "What made this a dick move?"}
        </Label>
        <Textarea
          id="desc"
          value={draft.description}
          onChange={(e) => patch({ description: e.target.value })}
          rows={4}
          maxLength={LIMITS.description.max}
          placeholder={positive ? "Returned three stray trolleys in the rain and didn't even work there." : "Angry is fine. We'll help you make it funny and fair."}
          aria-invalid={!!errors.description}
        />
        <div className="mt-1 flex items-center justify-between">
          <FieldError>{errors.description}</FieldError>
          <Meta>{draft.description.length}/{LIMITS.description.max}</Meta>
        </div>
        {descScan.findings.filter((f) => f.severity !== "note").map((f) => (
          <p key={`${f.kind}-${f.start}`} className={cn("mt-1 text-sm font-semibold", f.severity === "block" ? "text-alert-600" : "text-warning-800")}>
            &ldquo;{f.match}&rdquo; — {f.message}
          </p>
        ))}

        <div className="mt-4 bg-ink-950 text-paper-50 border-[3px] border-ink-950 p-4 shadow-hard-yellow">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-display uppercase text-xl leading-none">
                <SparkIcon className="inline size-5 mr-1 text-warning-500" /> DBAD wording helper
              </p>
              <p className="text-sm text-paper-50/80 mt-1">Turns angry into funny-but-fair. Removes personal attacks, keeps the facts.</p>
            </div>
            <Button variant="primary" size="sm" onClick={suggest} disabled={suggesting}>
              {suggesting ? "Thinking…" : suggestions ? "Try again" : "Make it funny"}
            </Button>
          </div>
          {removed.length > 0 && (
            <p className="mt-3 font-mono text-[11px] uppercase tracking-wider text-paper-50/70">
              Removed: {Array.from(new Set(removed)).join(", ")}. The behaviour stays, the abuse goes.
            </p>
          )}
          {suggestions && (
            <ul className="mt-4 grid gap-3">
              {suggestions.map((s, i) => (
                <li key={i} className="bg-paper-50 text-ink-950 border-2 border-ink-950 p-3 sm:p-4 flex flex-col sm:flex-row sm:items-start gap-3">
                  <div className="flex-1 min-w-0">
                    <Badge tone="concrete" size="sm">
                      {s.tone}
                    </Badge>
                    <p className="mt-2 font-display text-xl leading-none normal-case">&ldquo;{s.title}&rdquo;</p>
                    <p className="mt-1.5 text-sm leading-snug">{s.description}</p>
                  </div>
                  <Button
                    size="sm"
                    variant="dark"
                    className="shrink-0"
                    onClick={() => {
                      patch({ title: s.title, dickMove: s.dickMove, description: s.description });
                      toast.push({ tone: "yellow", title: "Wording applied", body: "Tweak anything you like below." });
                    }}
                  >
                    <CheckIcon className="size-4" /> Use this
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {/* Headline + dick move */}
      <section className="grid gap-5 sm:grid-cols-2">
        <div>
          <Label htmlFor="dm" hint={positive ? "e.g. “Returning other people's trolleys.”" : "Plain statement. e.g. “Blocking the footpath.”"}>
            {positive ? "The good move" : "The dick move"}
          </Label>
          <Input id="dm" value={draft.dickMove} onChange={(e) => patch({ dickMove: e.target.value })} maxLength={LIMITS.dickMove.max} aria-invalid={!!errors.dickMove} placeholder={positive ? "Returning other people's trolleys." : "Blocking the footpath."} />
          <FieldError>{errors.dickMove}</FieldError>
        </div>
        <div>
          <Label htmlFor="title" hint="The card headline. Funny helps.">
            One-liner
          </Label>
          <Input id="title" value={draft.title} onChange={(e) => patch({ title: e.target.value })} maxLength={LIMITS.title.max} aria-invalid={!!errors.title} placeholder={positive ? "Faith in humanity: restored, briefly." : "Apparently the footpath is now a parking space."} />
          <FieldError>{errors.title}</FieldError>
        </div>
        {!showAdvanced && !suggestions && <Help className="sm:col-span-2 -mt-2">Tip: hit “Make it funny” and DBAD fills these in for you.</Help>}
      </section>

      {/* Affected */}
      <section>
        <Label hint="Optional. Pick any that apply.">Who was affected?</Label>
        <div className="flex flex-wrap gap-2">
          {AFFECTED_GROUPS.map((g) => {
            const active = draft.affected.includes(g.id);
            return (
              <Chip key={g.id} active={active} onClick={() => patch({ affected: active ? draft.affected.filter((a) => a !== g.id) : [...draft.affected, g.id] })} className="whitespace-normal text-left">
                {g.label}
              </Chip>
            );
          })}
        </div>
      </section>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step 2 — where & when
// ---------------------------------------------------------------------------
function StepWhere({ draft, patch, errors }: { draft: Draft; patch: (p: Partial<Draft>) => void; errors: Record<string, string> }) {
  const toast = useToast();
  const [locating, setLocating] = React.useState(false);
  const [suggestion, setSuggestion] = React.useState<string | null>(null);

  function locate() {
    if (!("geolocation" in navigator)) return toast.push({ tone: "ink", title: "No location available", body: "Type the suburb instead." });
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        const c = coarsen(pos.coords.latitude, pos.coords.longitude);
        const near = nearestPlace(c.lat, c.lng);
        if (!near) return toast.push({ tone: "yellow", title: "Outside Australia?", body: "DBAD is Australian for now. Type the suburb." });
        patch({ approxLat: c.lat, approxLng: c.lng, suburb: draft.suburb || near.place.name, state: draft.state || near.place.state });
        setSuggestion(`Near ${near.place.name}, ${near.place.state} (about ${Math.max(1, Math.round(near.km))} km). Coordinates rounded to ~1 km — we never store anything precise.`);
      },
      () => {
        setLocating(false);
        toast.push({ tone: "ink", title: "Couldn't get your location", body: "No worries — type the suburb." });
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 },
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl sm:text-5xl">Where &amp; when?</h1>
        <p className="mt-2 text-ink-700">Suburb or town is enough. Add the public place if it&rsquo;s clearly public. Never a home address.</p>
      </div>

      <section className="grid gap-5 sm:grid-cols-[1fr_140px]">
        <div>
          <Label htmlFor="suburb">Suburb or town</Label>
          <Input id="suburb" value={draft.suburb} onChange={(e) => patch({ suburb: e.target.value })} placeholder="Batemans Bay" aria-invalid={!!errors.suburb} autoComplete="off" />
          <FieldError>{errors.suburb}</FieldError>
        </div>
        <div>
          <Label htmlFor="state">State</Label>
          <Select id="state" value={draft.state} onChange={(e) => patch({ state: e.target.value as AustralianState })} aria-invalid={!!errors.state}>
            <option value="">—</option>
            {AUSTRALIAN_STATES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
          <FieldError>{errors.state}</FieldError>
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="place" hint="Optional. A car park, beach, road, shopping centre or park. Not a house.">
            Public place
          </Label>
          <Input id="place" value={draft.place} onChange={(e) => patch({ place: e.target.value })} placeholder="Bunnings car park" aria-invalid={!!errors.place} />
          <FieldError>{errors.place}</FieldError>
        </div>
        <div className="sm:col-span-2 flex flex-wrap items-center gap-3">
          <Button variant="paper" size="sm" onClick={locate} disabled={locating}>
            <LocateIcon className="size-4" /> {locating ? "Locating…" : "Use my general location"}
          </Button>
          {suggestion && <Meta className="normal-case tracking-normal">{suggestion}</Meta>}
          {draft.approxLat != null && (
            <button type="button" className="font-mono text-[11px] uppercase tracking-wider underline" onClick={() => patch({ approxLat: undefined, approxLng: undefined })}>
              Remove map pin
            </button>
          )}
        </div>
      </section>

      <section className="grid gap-5 sm:grid-cols-2">
        <div>
          <Label htmlFor="date" hint="Day only. We don't publish exact times.">
            When
          </Label>
          <Input id="date" type="date" value={draft.occurredOn} max={isoDate(new Date())} onChange={(e) => patch({ occurredOn: e.target.value })} />
        </div>
        <div>
          <Label>Roughly what time?</Label>
          <div className="flex flex-wrap gap-2">
            {PART_OF_DAY.map((p) => (
              <Chip key={p.id} active={draft.partOfDay === p.id} onClick={() => patch({ partOfDay: p.id })}>
                {p.label}
              </Chip>
            ))}
          </div>
        </div>
      </section>

      <div className="border-[3px] border-ink-950 bg-warning-500 p-4 flex gap-3">
        <WarningIcon className="size-6 shrink-0" />
        <p className="text-sm font-semibold leading-snug">
          Locations are shown at suburb level on the map. A public business, road, park or facility can be named. A residential address is never accepted — the platform refuses it.
        </p>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step 3 — redaction review
// ---------------------------------------------------------------------------
function StepRedact({ draft, patch, errors }: { draft: Draft; patch: (p: Partial<Draft>) => void; errors: Record<string, string> }) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl sm:text-5xl">Redaction check</h1>
        <p className="mt-2 text-ink-700">
          Drag over faces, number plates, house numbers and anything that identifies a person. The photo can show the behaviour without identifying anyone.
        </p>
      </div>
      <div className="bg-ink-950 text-paper-50 p-4 border-[3px] border-ink-950 shadow-hard-yellow">
        <p className="font-display uppercase text-2xl leading-none">Call out the action. Not the person.</p>
        <p className="mt-1 text-sm text-paper-50/80">Blurring happens on your device before anything is uploaded. Moderators check again before publication.</p>
      </div>
      {draft.photos.map((p, i) => (
        <div key={p.id} className="space-y-2">
          <Meta>Photo {i + 1} of {draft.photos.length}</Meta>
          <RedactionEditor src={p.dataUrl} regions={p.regions} onChange={(regions) => patch({ photos: draft.photos.map((x) => (x.id === p.id ? { ...x, regions } : x)) })} />
        </div>
      ))}
      <div className="border-[3px] border-ink-950 bg-paper-100 p-4">
        <Checkbox
          checked={draft.reviewedRedaction}
          onChange={(e) => patch({ reviewedRedaction: e.target.checked })}
          label="I've checked every photo for faces, plates, house numbers and anything else identifying."
          description="If a moderator finds something you missed, they'll blur or remove the photo rather than delete your nomination."
        />
        <FieldError>{errors.reviewedRedaction}</FieldError>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Step 4 — review
// ---------------------------------------------------------------------------
function StepReview({ draft, patch, errors, viewer }: { draft: Draft; patch: (p: Partial<Draft>) => void; errors: Record<string, string>; viewer: ViewerOrNull }) {
  const positive = draft.kind === "not_a_dick";
  const lines = buildNoticeLines({
    id: "draft",
    kind: draft.kind,
    categoryId: draft.categoryId ?? "other",
    dickMove: draft.dickMove || (positive ? "Being a decent human." : "Dick move."),
    description: draft.description,
    location: { id: "draft", suburb: draft.suburb || "Somewhere", state: (draft.state || "NSW") as AustralianState, place: draft.place || undefined, precision: draft.place ? "place" : "suburb", region: "" },
    advice: undefined,
  });
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-4xl sm:text-5xl">Review</h1>
        <p className="mt-2 text-ink-700">Last look. {positive ? "Then we celebrate them." : "Then the community casts its verdict and you get a printable notice."}</p>
      </div>
      <div className="grid gap-6 md:grid-cols-[1fr_260px]">
        <div className="space-y-4">
          <div className="border-[3px] border-ink-950 bg-paper-50 p-5 shadow-hard-sm">
            <div className="flex flex-wrap gap-2">
              <Badge tone={positive ? "green" : "yellow"} className="gap-1.5">
                {draft.categoryId && <CategoryIcon id={draft.categoryId} className="size-3.5" />}
                {positive ? "NOT A DICK" : CATEGORIES.find((c) => c.id === draft.categoryId)?.label}
              </Badge>
              {draft.photos.length > 0 && (
                <Badge tone="concrete">
                  {draft.photos.length} photo{draft.photos.length === 1 ? "" : "s"} · {draft.photos.reduce((a, p) => a + p.regions.length, 0)} redactions
                </Badge>
              )}
            </div>
            <p className="mt-3 font-display text-3xl leading-[0.95] normal-case">&ldquo;{draft.title}&rdquo;</p>
            <p className="mt-2 font-display uppercase text-xl">{draft.dickMove}</p>
            <p className="mt-2 leading-snug">{draft.description}</p>
            <Meta className="mt-3 block">
              {draft.place ? `${draft.place}, ` : ""}
              {draft.suburb}, {draft.state} · {draft.occurredOn} · {draft.partOfDay}
            </Meta>
            {draft.photos.length > 0 && (
              <div className="mt-3 grid grid-cols-4 gap-2">
                {draft.photos.map((p) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={p.id} src={p.dataUrl} alt="" className="aspect-[4/3] object-cover border-2 border-ink-950" />
                ))}
              </div>
            )}
          </div>

          <div className="border-[3px] border-ink-950 bg-paper-100 p-4 space-y-3">
            <p className="font-display uppercase text-xl leading-none">The community standard</p>
            <ul className="text-sm space-y-1 text-ink-700">
              <li>Photograph the behaviour, not the person.</li>
              <li>No identifying information. No private addresses.</li>
              <li>Don&rsquo;t trespass, interfere with property or confront people for content.</li>
              <li>Don&rsquo;t manufacture incidents or settle personal disputes.</li>
              <li>If you&rsquo;re wrong, own it. If they fix it, acknowledge it.</li>
            </ul>
            <Checkbox checked={draft.acceptedStandard} onChange={(e) => patch({ acceptedStandard: e.target.checked })} label="I agree. I'm calling out the action, not the person." />
            <FieldError>{errors.acceptedStandard}</FieldError>
            {!viewer && <Help>You&rsquo;re nominating anonymously. Sign in first if you want it on your profile (and the badges that come with it).</Help>}
          </div>
        </div>
        <div>
          <Meta className="block mb-2">Your notice (preview)</Meta>
          <div className="shadow-hard">
            <NoticeCard template={positive ? "friendly-reminder" : "official-warning"} lines={lines} qrUrl={SITE.url} />
          </div>
          <Help>Pick from five templates after you submit.</Help>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Success
// ---------------------------------------------------------------------------
function SuccessView({ result, draft }: { result: { slug: string; shortCode: string; noticeId: string; moderationStatus: string }; draft: Draft }) {
  const positive = draft.kind === "not_a_dick";
  const pending = result.moderationStatus === "pending";
  return (
    <div className="mx-auto max-w-2xl px-4 sm:px-5 py-12 text-center">
      <Stamp tone={positive ? "green" : "red"} size="xl" animate flat className="bg-paper-50">
        {positive ? "Not a dick" : "DBAD'd"}
      </Stamp>
      <h1 className="mt-8 text-5xl sm:text-6xl">{positive ? "Legend nominated." : "You've DBAD'd it."}</h1>
      <p className="mt-3 text-lg text-ink-700">
        {pending
          ? "A moderator will give it a quick once-over against the community standard before it goes live — usually within a few hours. Your notice is ready now."
          : "It's live. The community will cast its verdict; you'll be notified when it's reached."}
      </p>
      <p className="mt-4 font-mono text-sm uppercase tracking-widest">Reference {result.shortCode}</p>
      <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
        <ButtonLink href={`/notice/${result.noticeId}`} size="lg">
          {positive ? "Print the good notice" : "Print the DBAD notice"}
        </ButtonLink>
        <ButtonLink href={`/moves/${result.slug}`} variant="dark" size="lg">
          View nomination
        </ButtonLink>
      </div>
      <HazardTape className="mt-12" thin />
      <p className="mt-6 text-sm text-concrete-600">
        Place the notice appropriately, where lawful. Never on private property, never on someone&rsquo;s paintwork, never in a way that starts a confrontation. Don&rsquo;t be a dick while telling someone else not to be a dick.
      </p>
    </div>
  );
}
