"use client";

import * as React from "react";
import type { Region } from "@/lib/client/images";
import { detectFaces, faceDetectionAvailable, fileToImage, pixelate } from "@/lib/client/images";
import { Button } from "@/components/ui/button";
import { Badge, Meta } from "@/components/ui/badge";
import { EyeOffIcon, SparkIcon, TrashIcon } from "@/components/icons/ui";

/**
 * Touch-friendly redaction canvas. Drag to draw a box; it pixelates immediately.
 * Auto-detect uses the browser's FaceDetector when present. The parent keeps the
 * region list so the final export happens once, at submit time.
 */
export function RedactionEditor({
  src,
  regions,
  onChange,
}: {
  src: string;
  regions: Region[];
  onChange: (regions: Region[]) => void;
}) {
  const canvasRef = React.useRef<HTMLCanvasElement>(null);
  const imgRef = React.useRef<HTMLImageElement | null>(null);
  const [draft, setDraft] = React.useState<Region | null>(null);
  const [detecting, setDetecting] = React.useState(false);
  const [ready, setReady] = React.useState(false);
  const canDetect = faceDetectionAvailable();

  // Load the source once.
  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      const blob = await (await fetch(src)).blob();
      const img = await fileToImage(blob);
      if (cancelled) return;
      imgRef.current = img;
      const c = canvasRef.current;
      if (c) {
        c.width = img.naturalWidth;
        c.height = img.naturalHeight;
      }
      setReady(true);
    })();
    return () => {
      cancelled = true;
    };
  }, [src]);

  // Redraw whenever regions or the draft change.
  React.useEffect(() => {
    const c = canvasRef.current;
    const img = imgRef.current;
    if (!c || !img || !ready) return;
    const ctx = c.getContext("2d")!;
    ctx.clearRect(0, 0, c.width, c.height);
    ctx.drawImage(img, 0, 0);
    for (const r of regions) pixelate(ctx, r);
    for (const r of [...regions, ...(draft ? [draft] : [])]) {
      ctx.save();
      ctx.strokeStyle = r.kind === "face" ? "#d7263d" : "#f5c400";
      ctx.lineWidth = Math.max(3, c.width / 300);
      ctx.setLineDash(r === draft ? [12, 8] : []);
      ctx.strokeRect(r.x, r.y, r.w, r.h);
      ctx.restore();
    }
  }, [regions, draft, ready]);

  const toCanvas = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const c = canvasRef.current!;
    const rect = c.getBoundingClientRect();
    return { x: ((e.clientX - rect.left) / rect.width) * c.width, y: ((e.clientY - rect.top) / rect.height) * c.height };
  };
  const start = React.useRef<{ x: number; y: number } | null>(null);
  // Mirror of `draft` for the pointer-up handler: pointermove updates are continuous-priority and
  // may not have committed when pointerup fires, so read the ref rather than the state closure.
  const draftRef = React.useRef<Region | null>(null);

  return (
    <div className="space-y-3">
      <div className="relative border-[3px] border-ink-950 bg-ink-950 select-none touch-none">
        <canvas
          ref={canvasRef}
          className="block w-full h-auto cursor-crosshair"
          aria-label="Photo. Drag to blur an area."
          onPointerDown={(e) => {
            e.currentTarget.setPointerCapture(e.pointerId);
            start.current = toCanvas(e);
            draftRef.current = { ...start.current, w: 0, h: 0, kind: "manual" };
            setDraft(draftRef.current);
          }}
          onPointerMove={(e) => {
            if (!start.current) return;
            const p = toCanvas(e);
            draftRef.current = { x: Math.min(p.x, start.current.x), y: Math.min(p.y, start.current.y), w: Math.abs(p.x - start.current.x), h: Math.abs(p.y - start.current.y), kind: "manual" };
            setDraft(draftRef.current);
          }}
          onPointerUp={() => {
            const d = draftRef.current;
            if (d && d.w > 8 && d.h > 8) onChange([...regions, d]);
            draftRef.current = null;
            setDraft(null);
            start.current = null;
          }}
          onPointerCancel={() => {
            draftRef.current = null;
            setDraft(null);
            start.current = null;
          }}
        />
        {!ready && <div className="absolute inset-0 flex items-center justify-center text-paper-50 font-mono text-xs uppercase tracking-widest">Loading photo…</div>}
        <div className="absolute top-2 left-2 flex gap-1.5 pointer-events-none">
          <Badge tone="ink" size="sm">
            <EyeOffIcon className="size-3" /> Drag to blur
          </Badge>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button
          size="sm"
          variant="paper"
          disabled={!canDetect || detecting || !ready}
          title={canDetect ? "Uses your browser's on-device face detector" : "Automatic face detection isn't available in this browser — draw the boxes by hand"}
          onClick={async () => {
            if (!imgRef.current) return;
            setDetecting(true);
            const found = await detectFaces(imgRef.current);
            setDetecting(false);
            if (found.length === 0) return;
            onChange([...regions, ...found]);
          }}
        >
          <SparkIcon className="size-4" /> {detecting ? "Looking…" : "Auto-detect faces"}
        </Button>
        <Button size="sm" variant="ghost" disabled={regions.length === 0} onClick={() => onChange(regions.slice(0, -1))}>
          Undo
        </Button>
        <Button size="sm" variant="ghost" disabled={regions.length === 0} onClick={() => onChange([])}>
          <TrashIcon className="size-4" /> Clear
        </Button>
        <Meta className="ml-auto">
          {regions.length} redaction{regions.length === 1 ? "" : "s"}
          {!canDetect && " · auto-detect unavailable here, draw by hand"}
        </Meta>
      </div>
    </div>
  );
}
