import * as React from "react";
import type { NoticeLines, NoticeTemplateId } from "@/lib/domain/types";
import { encodeQr, qrPath } from "@/lib/domain/qr";
import { SITE } from "@/lib/site";
import { fitMono, isLongDomain } from "@/lib/notice/fit";
import { cn } from "@/lib/utils";
import { Wordmark } from "@/components/brand/wordmark";

export interface NoticeCardProps {
  template: NoticeTemplateId;
  lines: NoticeLines;
  /** Short code printed on the notice: DBAD-0042 (optional for standalone notices). */
  code?: string;
  /** Full URL the QR code points to. */
  qrUrl: string;
  /** Whether the QR links to this incident or just the site. Changes the caption. */
  linkMode?: "site" | "incident";
  className?: string;
  /** Adds an id for print targeting. */
  id?: string;
}

/**
 * The printable DBAD notice.
 *
 * Every template is laid out with container-query units (cqw) inside a fixed A-series
 * aspect ratio, so the exact same markup renders as a 300px preview, a full-width phone
 * card, or an A5 sheet — nothing reflows, nothing wraps differently.
 */
export function NoticeCard({ template, lines, code, qrUrl, linkMode = "site", className, id }: NoticeCardProps) {
  const Template = TEMPLATES[template] ?? OfficialWarning;
  return (
    <div
      id={id}
      className={cn("notice-root relative w-full select-text", className)}
      style={{ containerType: "inline-size", aspectRatio: "1 / 1.4142" }}
      data-template={template}
    >
      <Template lines={lines} code={code} qrUrl={qrUrl} linkMode={linkMode} />
    </div>
  );
}

// ---------------------------------------------------------------------------
// Shared bits
// ---------------------------------------------------------------------------

function Qr({ url, className, dark = "#0f0f0f", light = "#ffffff" }: { url: string; className?: string; dark?: string; light?: string }) {
  const q = encodeQr(url, "M");
  const dim = q.size + 4;
  return (
    <svg viewBox={`0 0 ${dim} ${dim}`} className={className} shapeRendering="crispEdges" role="img" aria-label={`QR code linking to ${url}`}>
      <rect width={dim} height={dim} fill={light} />
      <path d={qrPath(q, 2)} fill={dark} />
    </svg>
  );
}

const cq = (n: number) => `${n}cqw`;

/**
 * The deployed hostname decides how much room the footer's right column takes. A long
 * hostname is set smaller (never wrapped — a URL broken mid-word is useless on paper) and
 * the QR caption drops a notch so both fit beside a 22cqw QR code.
 */
const LONG_DOMAIN = isLongDomain(SITE.domain);
/** Domain size in cqw, capped so the domain never exceeds `maxW` cqw. */
const domainCq = (base: number, maxW: number) => cq(fitMono(SITE.domain, base, maxW));

function Label({ children, className, style }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <p className={cn("font-mono font-semibold uppercase leading-none", className)} style={{ fontSize: cq(2.6), letterSpacing: "0.18em", ...style }}>
      {children}
    </p>
  );
}

type TProps = Pick<NoticeCardProps, "lines" | "code" | "qrUrl" | "linkMode">;

function QrBlock({ qrUrl, linkMode, dark, light, textClass }: { qrUrl: string; linkMode: "site" | "incident"; dark?: string; light?: string; textClass?: string }) {
  return (
    <div className="flex items-end min-w-0" style={{ gap: cq(3) }}>
      <div className={cn("shrink-0 border-[0.6cqw] bg-white", textClass?.includes("paper") ? "border-paper-50" : "border-ink-950")} style={{ width: cq(22), height: cq(22) }}>
        <Qr url={qrUrl} dark={dark} light={light} className="block size-full" />
      </div>
      <div className={cn("leading-tight min-w-0", textClass)} style={{ fontSize: cq(LONG_DOMAIN ? 2.6 : 2.9) }}>
        <p className="font-display uppercase" style={{ fontSize: cq(LONG_DOMAIN ? 3.7 : 4.2), lineHeight: 0.95 }}>
          Wondering why
          <br />
          you got this?
        </p>
        <p className="font-semibold" style={{ marginTop: cq(1.2) }}>
          Scan me. {linkMode === "incident" ? "See the community verdict." : "Learn the one rule."}
        </p>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 1. Official Warning — the council parking notice with a sense of humour
// ---------------------------------------------------------------------------
function OfficialWarning({ lines, code, qrUrl, linkMode = "site" }: TProps) {
  return (
    <div className="absolute inset-0 flex flex-col bg-[#fbf8f1] text-ink-950 border-[0.9cqw] border-ink-950 overflow-hidden">
      <div className="hazard shrink-0" style={{ height: cq(4.5) }} aria-hidden />
      <div className="flex items-center justify-between border-b-[0.7cqw] border-ink-950" style={{ padding: `${cq(3)} ${cq(5)}` }}>
        <Wordmark className="w-auto" style={{ height: cq(9) }} />
        <div className="text-right">
          <p className="font-display uppercase leading-none" style={{ fontSize: cq(4.4) }}>Official warning</p>
          <p className="font-mono font-semibold leading-none" style={{ fontSize: cq(2.6), marginTop: cq(1), letterSpacing: "0.12em" }}>
            {code ?? "NO. PENDING"}
          </p>
        </div>
      </div>

      <div className="relative flex-1 flex flex-col" style={{ padding: `${cq(4)} ${cq(5)} ${cq(3)}` }}>
        <h2 className="font-display uppercase leading-[0.88] tracking-tight" style={{ fontSize: cq(15.5) }}>
          Don&rsquo;t
          <br />
          be a dick.
        </h2>
        <p className="font-display uppercase leading-none bg-ink-950 text-warning-500 self-start" style={{ fontSize: cq(4.6), padding: `${cq(1.4)} ${cq(2)}`, marginTop: cq(2.5) }}>
          {lines.headline}
        </p>

        <div style={{ marginTop: cq(4), display: "grid", gap: cq(3.2) }}>
          <div>
            <Label className="text-concrete-600">The dick move</Label>
            <p className="font-display uppercase leading-[0.95]" style={{ fontSize: cq(6.4), marginTop: cq(1.2) }}>{lines.dickMove}</p>
          </div>
          <div>
            <Label className="text-concrete-600">Why you&rsquo;re here</Label>
            <p className="font-sans font-medium leading-snug" style={{ fontSize: cq(3.6), marginTop: cq(1.2) }}>{lines.why}</p>
          </div>
          <div className="grid grid-cols-2" style={{ gap: cq(3) }}>
            <div>
              <Label className="text-concrete-600">Location</Label>
              <p className="font-mono font-bold uppercase leading-tight" style={{ fontSize: cq(3.2), marginTop: cq(1.2) }}>{lines.location}</p>
            </div>
            <div>
              <Label className="text-concrete-600">Community advice</Label>
              <p className="font-sans font-semibold leading-snug" style={{ fontSize: cq(3.3), marginTop: cq(1.2) }}>{lines.advice}</p>
            </div>
          </div>
        </div>

        <div className="absolute text-center" style={{ right: cq(6), top: cq(3), transform: "rotate(-12deg)" }}>
          <span className="stamp-flat text-alert-500" style={{ fontSize: cq(5), opacity: 0.92, borderWidth: cq(0.7), transform: "none" }}>
            Verdict:
            <br />
            dick move
          </span>
        </div>

        <div className="mt-auto flex items-end justify-between border-t-[0.5cqw] border-dashed border-ink-950" style={{ paddingTop: cq(3), gap: cq(3) }}>
          <QrBlock qrUrl={qrUrl} linkMode={linkMode} />
          <div className="text-right shrink-0">
            <p className="font-display uppercase leading-none" style={{ fontSize: cq(4.2) }}>DBAD</p>
            <p className="font-mono font-semibold leading-none" style={{ fontSize: domainCq(2.6, 30), marginTop: cq(1) }}>{SITE.domain}</p>
          </div>
        </div>
      </div>
      <div className="hazard shrink-0" style={{ height: cq(4.5) }} aria-hidden />
    </div>
  );
}

// ---------------------------------------------------------------------------
// 2. Friendly Reminder — soft, warm, still a notice
// ---------------------------------------------------------------------------
function FriendlyReminder({ lines, code, qrUrl, linkMode = "site" }: TProps) {
  return (
    <div className="absolute inset-0 flex flex-col bg-paper-100 text-ink-950 border-[0.9cqw] border-ink-950 overflow-hidden grain">
      <div className="flex items-center justify-between bg-warning-500 border-b-[0.7cqw] border-ink-950" style={{ padding: `${cq(3)} ${cq(5)}` }}>
        <Wordmark className="w-auto" style={{ height: cq(8) }} />
        <p className="font-mono font-semibold leading-none" style={{ fontSize: cq(2.6), letterSpacing: "0.12em" }}>{code ?? "FRIENDLY"}</p>
      </div>
      <div className="flex-1 flex flex-col" style={{ padding: `${cq(5)} ${cq(6)} ${cq(3.5)}` }}>
        <p className="font-mono font-semibold uppercase text-redeem-700" style={{ fontSize: cq(2.8), letterSpacing: "0.2em" }}>A gentle word from the community</p>
        <h2 className="font-display uppercase leading-[0.9]" style={{ fontSize: cq(12), marginTop: cq(2) }}>{lines.headline}</h2>
        <div className="border-[0.5cqw] border-dashed border-ink-950" style={{ marginTop: cq(4), padding: cq(3.5) }}>
          <Label className="text-concrete-600">What happened</Label>
          <p className="font-display uppercase leading-[0.95]" style={{ fontSize: cq(5.6), marginTop: cq(1) }}>{lines.dickMove}</p>
          <p className="font-sans leading-snug" style={{ fontSize: cq(3.5), marginTop: cq(2.4) }}>{lines.why}</p>
        </div>
        <div className="grid grid-cols-2" style={{ gap: cq(3), marginTop: cq(3.5) }}>
          <div>
            <Label className="text-concrete-600">Where</Label>
            <p className="font-mono font-bold uppercase leading-tight" style={{ fontSize: cq(3.1), marginTop: cq(1) }}>{lines.location}</p>
          </div>
          <div>
            <Label className="text-concrete-600">Our advice</Label>
            <p className="font-sans font-semibold leading-snug" style={{ fontSize: cq(3.3), marginTop: cq(1) }}>{lines.advice}</p>
          </div>
        </div>
        <p className="font-display uppercase leading-none" style={{ fontSize: cq(5.6), marginTop: cq(4) }}>
          No hard feelings. <span className="text-redeem-700">Just fix it.</span>
        </p>
        <div className="mt-auto flex items-end justify-between border-t-[0.5cqw] border-ink-950" style={{ paddingTop: cq(3), gap: cq(3) }}>
          <QrBlock qrUrl={qrUrl} linkMode={linkMode} />
          <div className="text-right shrink-0">
            <p className="font-display uppercase leading-none" style={{ fontSize: cq(4) }}>Don&rsquo;t be a dick.</p>
            <p className="font-mono font-semibold leading-none" style={{ fontSize: domainCq(2.6, 30), marginTop: cq(1) }}>{SITE.domain}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 3. Maximum Dickery — black card, red tape, no mercy (still no names)
// ---------------------------------------------------------------------------
function MaximumDickery({ lines, code, qrUrl, linkMode = "site" }: TProps) {
  return (
    <div className="absolute inset-0 flex flex-col bg-ink-950 text-paper-50 border-[0.9cqw] border-alert-500 overflow-hidden">
      <div className="hazard-red shrink-0" style={{ height: cq(5) }} aria-hidden />
      <div className="flex-1 flex flex-col" style={{ padding: `${cq(4)} ${cq(5)} ${cq(3)}` }}>
        <div className="flex items-center justify-between">
          <Wordmark className="w-auto text-alert-500" style={{ height: cq(8.5) }} />
          <p className="font-mono font-bold leading-none text-alert-400" style={{ fontSize: cq(2.7), letterSpacing: "0.14em" }}>{code ?? "MAXIMUM"}</p>
        </div>
        <p className="font-mono font-semibold uppercase text-paper-50/70" style={{ fontSize: cq(2.7), letterSpacing: "0.22em", marginTop: cq(4) }}>Community alert level</p>
        <h2 className="font-display uppercase leading-[0.86] text-alert-500 tracking-tight" style={{ fontSize: cq(17) }}>
          Absolute
          <br />
          dickery.
        </h2>
        <p className="font-display uppercase leading-none bg-paper-50 text-ink-950 self-start" style={{ fontSize: cq(4.4), padding: `${cq(1.3)} ${cq(2)}`, marginTop: cq(2.5) }}>
          {lines.headline}
        </p>
        <div style={{ marginTop: cq(4), display: "grid", gap: cq(3) }}>
          <div>
            <Label className="text-alert-400">The offence against decency</Label>
            <p className="font-display uppercase leading-[0.95]" style={{ fontSize: cq(6.2), marginTop: cq(1.2) }}>{lines.dickMove}</p>
          </div>
          <div>
            <Label className="text-alert-400">Why the whole community noticed</Label>
            <p className="font-sans font-medium leading-snug text-paper-50/90" style={{ fontSize: cq(3.5), marginTop: cq(1.2) }}>{lines.why}</p>
          </div>
          <div className="grid grid-cols-2" style={{ gap: cq(3) }}>
            <div>
              <Label className="text-alert-400">Scene</Label>
              <p className="font-mono font-bold uppercase leading-tight" style={{ fontSize: cq(3.1), marginTop: cq(1.2) }}>{lines.location}</p>
            </div>
            <div>
              <Label className="text-alert-400">Required action</Label>
              <p className="font-sans font-semibold leading-snug" style={{ fontSize: cq(3.3), marginTop: cq(1.2) }}>{lines.advice}</p>
            </div>
          </div>
        </div>
        <div className="mt-auto flex items-end justify-between border-t-[0.5cqw] border-alert-500/60" style={{ paddingTop: cq(3), gap: cq(3) }}>
          <QrBlock qrUrl={qrUrl} linkMode={linkMode} textClass="text-paper-50" />
          <div className="text-right shrink-0">
            <p className="font-display uppercase leading-none text-alert-500" style={{ fontSize: cq(4.2) }}>Don&rsquo;t be a dick.</p>
            <p className="font-mono font-semibold leading-none text-paper-50/70" style={{ fontSize: domainCq(2.6, 30), marginTop: cq(1) }}>{SITE.domain}</p>
          </div>
        </div>
      </div>
      <div className="hazard-red shrink-0" style={{ height: cq(5) }} aria-hidden />
    </div>
  );
}

// ---------------------------------------------------------------------------
// 4. Australian Public Service Announcement — straight-faced warning-label style
// ---------------------------------------------------------------------------
function PublicService({ lines, code, qrUrl, linkMode = "site" }: TProps) {
  return (
    <div className="absolute inset-0 flex flex-col bg-white text-ink-950 border-[0.9cqw] border-ink-950 overflow-hidden">
      <div className="bg-ink-950 text-paper-50 flex items-center justify-between" style={{ padding: `${cq(3)} ${cq(5)}` }}>
        <p className="font-display uppercase leading-none" style={{ fontSize: cq(5.2) }}>Public service announcement</p>
        <svg viewBox="0 0 48 48" className="shrink-0 text-warning-500" style={{ width: cq(9), height: cq(9) }} aria-hidden>
          <path d="M24 4l20 36H4z" fill="currentColor" />
          <path d="M24 18v11M24 33v2" stroke="#0f0f0f" strokeWidth="4.5" strokeLinecap="square" />
        </svg>
      </div>
      <div className="flex-1 flex flex-col" style={{ padding: `${cq(5)} ${cq(6)} ${cq(3.5)}` }}>
        <p className="font-mono font-semibold uppercase" style={{ fontSize: cq(2.7), letterSpacing: "0.2em" }}>Notice to the person responsible for:</p>
        <h2 className="font-display uppercase leading-[0.92] border-b-[0.7cqw] border-ink-950" style={{ fontSize: cq(9.5), marginTop: cq(2), paddingBottom: cq(2.5) }}>
          {lines.dickMove}
        </h2>
        <ol className="font-sans" style={{ marginTop: cq(3.5), fontSize: cq(3.5), lineHeight: 1.3, display: "grid", gap: cq(2.2) }}>
          <li className="flex" style={{ gap: cq(2.5) }}>
            <span className="font-mono font-bold shrink-0">1.</span>
            <span><strong>What happened.</strong> {lines.why}</span>
          </li>
          <li className="flex" style={{ gap: cq(2.5) }}>
            <span className="font-mono font-bold shrink-0">2.</span>
            <span><strong>Where.</strong> {lines.location}.</span>
          </li>
          <li className="flex" style={{ gap: cq(2.5) }}>
            <span className="font-mono font-bold shrink-0">3.</span>
            <span><strong>What to do about it.</strong> {lines.advice}</span>
          </li>
          <li className="flex" style={{ gap: cq(2.5) }}>
            <span className="font-mono font-bold shrink-0">4.</span>
            <span><strong>Verdict.</strong> That was a dick move.</span>
          </li>
        </ol>
        <div className="bg-warning-500 border-[0.6cqw] border-ink-950 self-start" style={{ marginTop: cq(4), padding: `${cq(1.6)} ${cq(2.4)}` }}>
          <p className="font-display uppercase leading-none" style={{ fontSize: cq(7.5) }}>Don&rsquo;t be a dick.</p>
        </div>
        <div className="mt-auto flex items-end justify-between" style={{ paddingTop: cq(3), gap: cq(3) }}>
          <QrBlock qrUrl={qrUrl} linkMode={linkMode} />
          <div className="text-right shrink-0">
            <p className="font-mono font-semibold leading-tight" style={{ fontSize: cq(2.2) }}>
              Authorised by the
              <br />
              DBAD community.
              {code && (
                <>
                  <br />
                  {code}
                </>
              )}
            </p>
            <p className="font-mono font-semibold leading-none" style={{ fontSize: domainCq(2.4, 30), marginTop: cq(1) }}>{SITE.domain}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// 5. Minimal — four words
// ---------------------------------------------------------------------------
function Minimal({ lines, code, qrUrl }: TProps) {
  return (
    <div className="absolute inset-0 flex flex-col bg-white text-ink-950 border-[1.2cqw] border-ink-950 overflow-hidden" style={{ padding: `${cq(7)} ${cq(7)} ${cq(5)}` }}>
      <h2 className="font-display uppercase leading-[0.86] tracking-tight" style={{ fontSize: cq(22) }}>
        Don&rsquo;t
        <br />
        be a
        <br />
        dick.
      </h2>
      <p className="font-display uppercase leading-[0.95] text-concrete-600" style={{ fontSize: cq(5), marginTop: cq(5) }}>{lines.dickMove}</p>
      <div className="mt-auto flex items-end justify-between" style={{ gap: cq(3) }}>
        <div>
          <Wordmark className="w-auto" style={{ height: cq(7) }} />
          <p className="font-mono font-semibold leading-tight" style={{ fontSize: domainCq(2.6, 56), marginTop: cq(1.6), letterSpacing: "0.1em" }}>
            {SITE.domain}
            {code && (LONG_DOMAIN ? <br /> : " · ")}
            {code}
          </p>
        </div>
        <div className="shrink-0 border-[0.6cqw] border-ink-950" style={{ width: cq(20), height: cq(20) }}>
          <Qr url={qrUrl} className="block size-full" />
        </div>
      </div>
    </div>
  );
}

const TEMPLATES: Record<NoticeTemplateId, (p: TProps) => React.JSX.Element> = {
  "official-warning": OfficialWarning,
  "friendly-reminder": FriendlyReminder,
  "maximum-dickery": MaximumDickery,
  "public-service": PublicService,
  minimal: Minimal,
};
