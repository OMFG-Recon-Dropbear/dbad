import type { NoticeLines, NoticeTemplateId } from "@/lib/domain/types";
import { SITE } from "@/lib/site";
import { NoticeCard } from "./notice-card";

/** Small, non-interactive notice preview used on the homepage and in cards. */
export function NoticePreviewMini({ lines, code, template = "official-warning", className }: { lines: NoticeLines; code?: string; template?: NoticeTemplateId; className?: string }) {
  return (
    <div className={`shadow-hard-lg ${className ?? ""}`}>
      <NoticeCard template={template} lines={lines} code={code} qrUrl={SITE.url} linkMode="site" />
    </div>
  );
}
