"use client";

import * as React from "react";
import Link from "next/link";
import type { NoticeLines, NoticeLinkMode, NoticeTemplateId, PrintableNotice } from "@/lib/domain/types";
import type { NoticeStudioProps } from "@/lib/loaders/notice";
import type { NoticeActions } from "@/lib/actions/types";
import { NOTICE_TEMPLATES } from "@/lib/notice/lines";
import { SITE } from "@/lib/site";
import { cn } from "@/lib/utils";
import { NoticeCard } from "./notice-card";
import { Button, ButtonLink } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { Meta } from "@/components/ui/badge";
import { useToast } from "@/components/ui/toast";
import { CopyIcon, DownloadIcon, PrintIcon, ShareIcon, QrIcon, ArrowLeftIcon, WarningIcon } from "@/components/icons/ui";

type Size = "a5" | "a6";

/**
 * The DBAD notice generator. Preview on the left, controls on the right, four actions:
 * PRINT NOTICE, DOWNLOAD PDF, SHARE, COPY LINK. Edits are saved (debounced) so the PDF
 * route and the shareable link render exactly what's on screen.
 */
export function NoticeStudio({ notice: initial, incident, actions }: NoticeStudioProps & { actions: NoticeActions }) {
  const toast = useToast();
  const [notice, setNotice] = React.useState<PrintableNotice>(initial);
  const [size, setSize] = React.useState<Size>("a5");
  const [saving, setSaving] = React.useState(false);
  const saveTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const incidentUrl = incident ? `${SITE.url}/d/${incident.shortCode}` : SITE.url;
  const qrUrl = notice.linkMode === "incident" && incident ? incidentUrl : SITE.url;
  const noticeUrl = `${SITE.url}/notice/${notice.id}`;
  const pdfUrl = `/api/notices/${notice.id}/pdf?size=${size}`;

  function update(patch: Partial<Pick<PrintableNotice, "template" | "linkMode" | "lines">>) {
    setNotice((n) => ({ ...n, ...patch }));
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      setSaving(true);
      const merged = { ...notice, ...patch };
      await actions.update(notice.id, { template: merged.template, linkMode: merged.linkMode, lines: merged.lines });
      setSaving(false);
    }, 500);
  }

  function setLine<K extends keyof NoticeLines>(key: K, value: string) {
    update({ lines: { ...notice.lines, [key]: value } });
  }

  async function share() {
    const data = { title: "DBAD notice", text: `${notice.lines.headline} ${notice.lines.dickMove}`, url: noticeUrl };
    try {
      if ("share" in navigator && navigator.canShare?.(data)) {
        await navigator.share(data);
        return;
      }
    } catch {
      /* cancelled */
    }
    copy();
  }
  async function copy() {
    try {
      await navigator.clipboard.writeText(noticeUrl);
      toast.push({ tone: "yellow", title: "Link copied", body: noticeUrl });
    } catch {
      toast.push({ tone: "ink", title: "Copy this link", body: noticeUrl });
    }
  }

  const pageCss = size === "a5" ? "148mm 210mm" : "105mm 148mm";

  return (
    <div className="bg-concrete-200 print:bg-white min-h-screen">
      <style>{`@media print { @page { size: ${pageCss}; margin: 0; } .notice-print-wrap { width: ${size === "a5" ? "148mm" : "105mm"} !important; } }`}</style>
      <div className="mx-auto max-w-7xl px-4 sm:px-5 py-6 grid gap-8 lg:grid-cols-[minmax(0,1.1fr)_420px]">
        {/* ------------------------------------------------ preview */}
        <div className="print-area">
          <div className="print-hidden flex flex-wrap items-center justify-between gap-3 mb-4">
            <Link href={incident ? `/moves/${incident.slug}` : "/"} className="inline-flex items-center gap-2 font-mono text-xs uppercase tracking-widest hover:underline">
              <ArrowLeftIcon className="size-4" /> {incident ? `Back to ${incident.shortCode}` : "Back"}
            </Link>
            <Meta>{saving ? "Saving…" : "Saved"}</Meta>
          </div>
          <div className="flex justify-center">
            <div className={cn("notice-print-wrap w-full", size === "a5" ? "max-w-[520px]" : "max-w-[380px]")}>
              <div className="shadow-hard-lg print:shadow-none">
                <NoticeCard id="dbad-notice" template={notice.template} lines={notice.lines} code={incident?.shortCode} qrUrl={qrUrl} linkMode={notice.linkMode} />
              </div>
            </div>
          </div>
          <p className="print-hidden mt-4 text-center font-mono text-[11px] uppercase tracking-widest text-concrete-600">
            Preview · prints at {size.toUpperCase()} · QR links to {notice.linkMode === "incident" && incident ? "this nomination" : SITE.domain}
          </p>
        </div>

        {/* ------------------------------------------------ controls */}
        <aside className="print-hidden space-y-6">
          <div className="bg-paper-50 border-[3px] border-ink-950 shadow-hard p-5">
            <h1 className="text-3xl">Your DBAD notice</h1>
            <p className="mt-1 text-sm text-ink-700">Pick a template, tweak the words, print or download. Place it where lawful — never on private property or paintwork.</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <Button onClick={() => window.print()} size="md">
                <PrintIcon className="size-5" /> Print notice
              </Button>
              <ButtonLink href={pdfUrl} variant="dark" size="md" target="_blank" rel="noopener">
                <DownloadIcon className="size-5" /> Download PDF
              </ButtonLink>
              <Button onClick={share} variant="paper" size="md">
                <ShareIcon className="size-5" /> Share
              </Button>
              <Button onClick={copy} variant="paper" size="md">
                <CopyIcon className="size-5" /> Copy link
              </Button>
            </div>
            <div className="mt-4 flex items-center gap-2">
              <Meta>Size</Meta>
              {(["a5", "a6"] as Size[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  aria-pressed={size === s}
                  onClick={() => setSize(s)}
                  className={cn("border-2 border-ink-950 px-3 py-1 font-mono text-xs uppercase tracking-wider", size === s ? "bg-ink-950 text-warning-500" : "bg-paper-100 hover:bg-white")}
                >
                  {s.toUpperCase()}
                </button>
              ))}
              <Meta className="ml-auto">A6 = two per A5 sheet</Meta>
            </div>
          </div>

          <div className="bg-paper-50 border-[3px] border-ink-950 p-5">
            <Label>Template</Label>
            <div className="grid gap-2">
              {NOTICE_TEMPLATES.map((t) => {
                const active = notice.template === t.id;
                return (
                  <button
                    key={t.id}
                    type="button"
                    aria-pressed={active}
                    onClick={() => update({ template: t.id as NoticeTemplateId, lines: { ...notice.lines, headline: notice.lines.headline === NOTICE_TEMPLATES.find((x) => x.id === notice.template)?.headline ? t.headline : notice.lines.headline } })}
                    className={cn("text-left border-[3px] border-ink-950 rounded-sm p-3 flex items-center gap-3", active ? "bg-ink-950 text-warning-500 shadow-hard-yellow" : "bg-paper-100 hover:bg-white shadow-hard-sm")}
                  >
                    <TemplateSwatch id={t.id} />
                    <span className="min-w-0">
                      <span className="block font-display uppercase text-lg leading-none">{t.name}</span>
                      <span className={cn("block text-xs mt-1 leading-snug", active ? "text-paper-50/80" : "text-concrete-600")}>{t.blurb}</span>
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="bg-paper-50 border-[3px] border-ink-950 p-5">
            <Label hint="Where the QR code sends people.">
              <span className="inline-flex items-center gap-2">
                <QrIcon className="size-4" /> QR code
              </span>
            </Label>
            <div className="grid grid-cols-2 gap-2">
              {(
                [
                  { id: "site", label: "The DBAD site", blurb: "Just dontbeadick.com.au. Nothing about this incident." },
                  { id: "incident", label: "This nomination", blurb: incident ? "The community verdict and redemption page." : "Needs a nomination." },
                ] as Array<{ id: NoticeLinkMode; label: string; blurb: string }>
              ).map((o) => (
                <button
                  key={o.id}
                  type="button"
                  disabled={o.id === "incident" && !incident}
                  aria-pressed={notice.linkMode === o.id}
                  onClick={() => update({ linkMode: o.id })}
                  className={cn(
                    "text-left border-[3px] border-ink-950 rounded-sm p-3 disabled:opacity-40",
                    notice.linkMode === o.id ? "bg-warning-500 shadow-hard-sm" : "bg-paper-100 hover:bg-white",
                  )}
                >
                  <span className="block font-display uppercase leading-none">{o.label}</span>
                  <span className="block text-xs mt-1 text-ink-700 leading-snug">{o.blurb}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-paper-50 border-[3px] border-ink-950 p-5 space-y-4">
            <Label hint="Say what happened, not who did it. Personal details are stripped automatically.">Words</Label>
            <div>
              <Meta>Headline</Meta>
              <Input value={notice.lines.headline} maxLength={60} onChange={(e) => setLine("headline", e.target.value)} className="mt-1" />
            </div>
            <div>
              <Meta>The dick move</Meta>
              <Input value={notice.lines.dickMove} maxLength={90} onChange={(e) => setLine("dickMove", e.target.value)} className="mt-1" />
            </div>
            <div>
              <Meta>Why you&rsquo;re here</Meta>
              <Textarea value={notice.lines.why} maxLength={220} rows={3} onChange={(e) => setLine("why", e.target.value)} className="mt-1 min-h-0" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Meta>Location</Meta>
                <Input value={notice.lines.location} maxLength={80} onChange={(e) => setLine("location", e.target.value)} className="mt-1" />
              </div>
              <div>
                <Meta>Community advice</Meta>
                <Input value={notice.lines.advice} maxLength={140} onChange={(e) => setLine("advice", e.target.value)} className="mt-1" />
              </div>
            </div>
          </div>

          <div className="border-[3px] border-ink-950 bg-warning-500 p-4 flex gap-3 text-sm font-semibold leading-snug">
            <WarningIcon className="size-6 shrink-0" />
            <p>
              Place it appropriately, where lawful: under a wiper is generally fine, on the paint is not; a noticeboard is fine, someone&rsquo;s front door is not. Never confront anyone to deliver it. Don&rsquo;t be a dick while telling someone else not to be a dick.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}

function TemplateSwatch({ id }: { id: NoticeTemplateId }) {
  const map: Record<NoticeTemplateId, string> = {
    "official-warning": "bg-[#fbf8f1] border-ink-950 [background-image:repeating-linear-gradient(-45deg,#0f0f0f_0_3px,#f5c400_3px_6px)]",
    "friendly-reminder": "bg-warning-500 border-ink-950",
    "maximum-dickery": "bg-ink-950 border-alert-500",
    "public-service": "bg-white border-ink-950",
    minimal: "bg-white border-ink-950",
  };
  return <span aria-hidden className={cn("size-10 shrink-0 border-[3px] rounded-xs", map[id])} />;
}
