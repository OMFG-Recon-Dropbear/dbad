import * as React from "react";
import { SITE } from "@/lib/site";

/**
 * Open Graph card rendered by next/og (satori). Satori supports a flexbox subset with
 * inline styles only — no Tailwind classes here. Fonts are the same TTF subsets the PDF
 * uses, read from public/pdf-fonts.
 */
export async function ogFonts(): Promise<Array<{ name: string; data: ArrayBuffer; weight: 400 | 600 | 900; style: "normal" }>> {
  const fs = await import("node:fs/promises");
  const path = await import("node:path");
  const dir = path.join(process.cwd(), "public", "pdf-fonts");
  const read = async (f: string) => {
    const buf = await fs.readFile(path.join(dir, f));
    return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer;
  };
  return [
    { name: "DBAD Display", data: await read("DBADDisplay-Black.ttf"), weight: 900, style: "normal" },
    { name: "Public Sans", data: await read("PublicSans-SemiBold.ttf"), weight: 600, style: "normal" },
    { name: "IBM Plex Mono", data: await read("IBMPlexMono-SemiBold.ttf"), weight: 600, style: "normal" },
  ];
}

const MIME: Record<string, string> = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp" };

/**
 * Resolve a photo URL for satori. Site-relative photos (seed illustrations, anything under
 * /public) are inlined as data URIs so rendering never depends on the site being reachable
 * from inside its own container; remote photos (Supabase Storage) are passed through.
 */
export async function ogPhoto(url: string | undefined, absoluteUrl: (path: string) => string): Promise<string | undefined> {
  if (!url) return undefined;
  if (!url.startsWith("/")) return url;
  try {
    const fs = await import("node:fs/promises");
    const path = await import("node:path");
    const clean = url.split("?")[0] ?? url;
    const file = path.join(process.cwd(), "public", ...clean.split("/").filter(Boolean));
    const mime = MIME[path.extname(file).toLowerCase()];
    if (!mime) return absoluteUrl(url);
    const buf = await fs.readFile(file);
    return `data:${mime};base64,${buf.toString("base64")}`;
  } catch {
    return absoluteUrl(url);
  }
}

const HAZARD = "repeating-linear-gradient(-45deg, #0f0f0f 0 18px, #f5c400 18px 36px)";

export function OgCard({
  kicker,
  title,
  sub,
  verdict,
  location,
  positive,
  photoUrl,
}: {
  kicker: string;
  title: string;
  sub: string;
  verdict: string;
  location: string;
  positive?: boolean;
  photoUrl?: string;
}) {
  const accent = positive ? "#3f9d57" : "#f5c400";
  return (
    <div style={{ width: 1200, height: 630, display: "flex", flexDirection: "column", background: "#171717", color: "#f7f3ea", fontFamily: "Public Sans" }}>
      <div style={{ height: 22, backgroundImage: HAZARD, display: "flex" }} />
      <div style={{ display: "flex", flex: 1 }}>
        <div style={{ display: "flex", flexDirection: "column", flex: 1, padding: "44px 56px 40px 56px", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
            <div style={{ display: "flex", fontFamily: "DBAD Display", fontSize: 58, color: accent, letterSpacing: -1 }}>DBAD</div>
            <div style={{ display: "flex", fontFamily: "IBM Plex Mono", fontSize: 18, letterSpacing: 3, color: "#a9a9a1", textTransform: "uppercase", whiteSpace: "nowrap", overflow: "hidden" }}>{kicker}</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
            <div style={{ display: "flex", fontFamily: "DBAD Display", fontSize: title.length > 40 ? 64 : 84, lineHeight: 0.92, textTransform: "uppercase", color: "#f7f3ea" }}>{title}</div>
            <div style={{ display: "flex", fontSize: 30, lineHeight: 1.2, color: "#dcdcd4", maxWidth: 700 }}>&ldquo;{sub}&rdquo;</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {verdict && (
              <div style={{ display: "flex", alignSelf: "flex-start", background: accent, color: "#0f0f0f", fontFamily: "DBAD Display", fontSize: 30, padding: "10px 18px", textTransform: "uppercase" }}>{verdict}</div>
            )}
            <div style={{ display: "flex", justifyContent: "space-between", gap: 24, fontFamily: "IBM Plex Mono", fontSize: 18, letterSpacing: 2, color: "#a9a9a1", textTransform: "uppercase", whiteSpace: "nowrap" }}>
              <span style={{ display: "flex" }}>{location}</span>
              <span style={{ display: "flex" }}>{SITE.domain}</span>
            </div>
          </div>
        </div>
        {photoUrl && (
          <div style={{ display: "flex", width: 420, position: "relative", borderLeft: "6px solid #0f0f0f" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={photoUrl} alt="" width={420} height={608} style={{ objectFit: "cover", width: 420, height: 608 }} />
            <div style={{ position: "absolute", left: 18, top: 18, display: "flex", background: "#0f0f0f", color: "#f5c400", fontFamily: "IBM Plex Mono", fontSize: 16, letterSpacing: 3, padding: "8px 12px" }}>EVIDENCE · REDACTED</div>
          </div>
        )}
      </div>
    </div>
  );
}
