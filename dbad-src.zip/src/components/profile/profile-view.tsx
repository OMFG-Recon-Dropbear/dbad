import type { ProfilePage, ViewerOrNull } from "@/lib/data/repository";
import type { Notification } from "@/lib/domain/types";
import { BADGES } from "@/lib/domain/badges";
import { formatDateAU, relativeTime } from "@/lib/domain/time";
import { Container } from "@/components/layout/site-shell";
import { Avatar } from "@/components/brand/avatar";
import { IncidentCard } from "@/components/incident/incident-card";
import { SectionHeading } from "@/components/brand/hazard";
import { Badge, Meta } from "@/components/ui/badge";
import { ButtonLink } from "@/components/ui/button";
import { EmptyState } from "@/components/ui/empty-state";
import { cn } from "@/lib/utils";
import { StarIcon } from "@/components/icons/ui";
import Link from "next/link";

export function ProfileView({ page, viewer, isSelf, signOutAction }: { page: ProfilePage; viewer: ViewerOrNull; isSelf: boolean; signOutAction?: () => Promise<void> }) {
  const { profile, stats, badges, recent } = page;
  const earned = new Set(badges.map((b) => b.badgeId));
  void viewer;
  return (
    <>
      <section className="concrete text-paper-50 border-b-[3px] border-ink-950">
        <Container className="py-10 flex flex-col sm:flex-row sm:items-end gap-6">
          <Avatar seed={profile.avatarSeed} size={96} className="border-[3px]" />
          <div className="flex-1 min-w-0">
            <p className="font-mono text-xs uppercase tracking-[0.2em] text-warning-500">DBAD member since {formatDateAU(profile.memberSince, { year: "numeric", month: "short" })}</p>
            <h1 className="mt-2 text-4xl sm:text-5xl text-paper-50 normal-case">{profile.displayName}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-3">
              <Meta className="text-paper-50/80">@{profile.handle}</Meta>
              {profile.homeArea && <Meta className="text-paper-50/80">{profile.homeArea}</Meta>}
              {profile.role !== "member" && <Badge tone="yellow" size="sm">{profile.role}</Badge>}
            </div>
            {profile.bio && <p className="mt-3 text-paper-50/85 max-w-xl">{profile.bio}</p>}
          </div>
          {isSelf && (
            <div className="flex gap-2">
              <ButtonLink href="/notifications" variant="outline-light" size="sm">Notifications</ButtonLink>
              {signOutAction && (
                <form action={signOutAction}>
                  <button type="submit" className="inline-flex items-center border-[3px] border-paper-50 text-paper-50 font-display uppercase text-sm px-3 py-2 rounded-sm hover:bg-paper-50 hover:text-ink-950">Sign out</button>
                </form>
              )}
            </div>
          )}
        </Container>
      </section>

      <Container className="py-10 space-y-12">
        <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { n: stats.spotted, l: "Dick moves spotted" },
            { n: stats.fairCalls, l: "Fair calls" },
            { n: stats.redeemed, l: "Redeemed" },
            { n: stats.overruled, l: "Overruled" },
            { n: stats.notADick, l: "Not-a-dicks" },
            { n: stats.comments, l: "Comments" },
          ].map((s) => (
            <div key={s.l} className="border-[3px] border-ink-950 bg-paper-50 p-4 shadow-hard-sm">
              <p className="font-display text-4xl leading-none tabular">{s.n}</p>
              <p className="mt-1 font-mono text-[11px] uppercase tracking-wider text-concrete-600">{s.l}</p>
            </div>
          ))}
        </section>

        <section>
          <SectionHeading kicker="Contributor badges" title="Reputation" />
          <p className="mt-2 text-ink-700 max-w-2xl">Badges are for contributors and community activity only. DBAD never scores the people who get photographed.</p>
          <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {BADGES.map((b) => {
              const has = earned.has(b.id);
              const when = badges.find((x) => x.badgeId === b.id)?.awardedAt;
              return (
                <li key={b.id} className={cn("border-[3px] p-4 flex gap-3", has ? "border-ink-950 bg-warning-500 shadow-hard-sm" : "border-dashed border-concrete-400 bg-paper-100 text-concrete-600")}>
                  <StarIcon className={cn("size-8 shrink-0", has ? "text-ink-950" : "text-concrete-400")} />
                  <div>
                    <p className="font-display uppercase text-xl leading-none">{b.name}</p>
                    <p className="mt-1 text-sm leading-snug">{b.blurb}</p>
                    <Meta className={cn("mt-1 block", has ? "text-ink-950/70" : "")}>{has && when ? `Earned ${relativeTime(when)}` : b.rule}</Meta>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        <section>
          <SectionHeading kicker="Spotted in the wild" title={isSelf ? "Your nominations" : `Spotted by ${profile.handle}`} />
          {recent.length === 0 ? (
            <div className="mt-6"><EmptyState stamp="QUIET" title="Nothing nominated yet." body={isSelf ? "Seen a dick move? You know what to do." : "This member is keeping their powder dry."} action={isSelf ? { href: "/nominate", label: "Nominate a dick move" } : undefined} /></div>
          ) : (
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {recent.map((inc) => (
                <IncidentCard key={inc.id} incident={inc} />
              ))}
            </div>
          )}
        </section>
      </Container>
    </>
  );
}

export function NotificationsView({ notifications }: { notifications: Notification[] }) {
  return (
    <Container size="md" className="py-10">
      <SectionHeading kicker="Notifications" title="What's happened." />
      {notifications.length === 0 ? (
        <div className="mt-6"><EmptyState stamp="ALL QUIET" title="Nothing yet." body="Verdicts, redemptions, comments and badges show up here." /></div>
      ) : (
        <ul className="mt-6 space-y-2">
          {notifications.map((n) => (
            <li key={n.id}>
              <Link href={n.href ?? "/me"} className={cn("block border-[3px] border-ink-950 p-4 hover:bg-white", n.readAt ? "bg-paper-100" : "bg-paper-50 shadow-hard-sm")}>
                <div className="flex items-baseline justify-between gap-3">
                  <p className="font-display uppercase text-lg leading-none">{n.title}</p>
                  <Meta>{relativeTime(n.createdAt)}</Meta>
                </div>
                <p className="mt-1 text-sm text-ink-700">{n.body}</p>
                {!n.readAt && <Badge tone="yellow" size="sm" className="mt-2">New</Badge>}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </Container>
  );
}
