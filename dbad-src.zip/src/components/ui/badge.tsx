import * as React from "react";
import { cn, variants } from "@/lib/utils";

export const badgeVariants = variants(
  "inline-flex items-center gap-1 font-display uppercase tracking-wide leading-none border-2 border-ink-950 whitespace-nowrap",
  {
    variants: {
      tone: {
        yellow: "bg-warning-500 text-ink-950",
        ink: "bg-ink-950 text-paper-50",
        paper: "bg-paper-50 text-ink-950",
        red: "bg-alert-500 text-paper-50",
        green: "bg-redeem-500 text-paper-50",
        concrete: "bg-concrete-200 text-ink-950",
        outline: "bg-transparent text-ink-950",
        "outline-light": "bg-transparent text-paper-50 border-paper-50",
      },
      size: {
        sm: "text-[11px] px-1.5 py-1 rounded-xs",
        md: "text-xs px-2 py-1 rounded-xs",
        lg: "text-sm px-2.5 py-1.5 rounded-sm",
      },
    },
    defaultVariants: { tone: "yellow", size: "md" },
  },
);

type Tone = NonNullable<Parameters<typeof badgeVariants>[0]>["tone"];
type Size = NonNullable<Parameters<typeof badgeVariants>[0]>["size"];

export function Badge({ className, tone, size, ...props }: React.HTMLAttributes<HTMLSpanElement> & { tone?: Tone; size?: Size }) {
  return <span className={badgeVariants({ tone, size, className })} {...props} />;
}

/** Tiny mono metadata label, e.g. "BATEMANS BAY, NSW · 24 MIN AGO" */
export function Meta({ className, ...props }: React.HTMLAttributes<HTMLSpanElement>) {
  return <span className={cn("font-mono text-[11px] sm:text-xs uppercase tracking-wider text-concrete-600", className)} {...props} />;
}
