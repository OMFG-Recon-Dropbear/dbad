import * as React from "react";
import Link from "next/link";
import { cn, variants } from "@/lib/utils";

export const buttonVariants = variants(
  "inline-flex items-center justify-center gap-2 font-display uppercase tracking-wide leading-none border-[3px] border-ink-950 select-none transition-[transform,box-shadow,background-color] duration-100 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap",
  {
    variants: {
      variant: {
        primary: "bg-warning-500 text-ink-950 shadow-hard hover:bg-warning-400",
        dark: "bg-ink-950 text-warning-500 shadow-hard-yellow hover:bg-ink-800",
        paper: "bg-paper-50 text-ink-950 shadow-hard hover:bg-white",
        alert: "bg-alert-500 text-paper-50 border-ink-950 shadow-hard hover:bg-alert-400",
        redeem: "bg-redeem-500 text-paper-50 shadow-hard hover:bg-redeem-400",
        ghost: "bg-transparent border-transparent text-ink-950 hover:bg-ink-950/5 shadow-none",
        outline: "bg-transparent text-ink-950 shadow-none hover:bg-ink-950 hover:text-warning-500",
        "outline-light": "bg-transparent text-paper-50 border-paper-50 shadow-none hover:bg-paper-50 hover:text-ink-950",
      },
      size: {
        sm: "text-sm px-3 py-2 rounded-sm",
        md: "text-base px-4 py-3 rounded-sm",
        lg: "text-lg xs:text-xl px-6 py-4 rounded-sm",
        xl: "text-xl xs:text-2xl px-7 py-5 rounded-md",
        icon: "size-11 rounded-sm px-0 py-0",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

type Variant = NonNullable<Parameters<typeof buttonVariants>[0]>["variant"];
type Size = NonNullable<Parameters<typeof buttonVariants>[0]>["size"];

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function Button({ className, variant, size, type = "button", ...props }, ref) {
  return <button ref={ref} type={type} className={buttonVariants({ variant, size, className })} {...props} />;
});

export interface ButtonLinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  href: string;
  variant?: Variant;
  size?: Size;
  prefetch?: boolean;
}

export function ButtonLink({ href, className, variant, size, children, prefetch, ...props }: ButtonLinkProps) {
  const external = /^https?:\/\//.test(href);
  if (external) {
    return (
      <a href={href} className={buttonVariants({ variant, size, className })} target="_blank" rel="noopener noreferrer" {...props}>
        {children}
      </a>
    );
  }
  return (
    <Link href={href} prefetch={prefetch} className={buttonVariants({ variant, size, className })} {...props}>
      {children}
    </Link>
  );
}

export function IconButton({ className, label, children, ...props }: ButtonProps & { label: string }) {
  return (
    <Button variant="paper" size="icon" aria-label={label} title={label} className={cn("shadow-hard-sm", className)} {...props}>
      {children}
    </Button>
  );
}
