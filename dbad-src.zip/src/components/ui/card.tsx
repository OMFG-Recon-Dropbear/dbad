import * as React from "react";
import { cn } from "@/lib/utils";

/** Sticker-like card: hard border, offset shadow, paper background. */
export function Card({ className, children, as: Tag = "div", ...props }: React.HTMLAttributes<HTMLElement> & { as?: "div" | "article" | "section" | "li" }) {
  return (
    <Tag className={cn("relative bg-paper-50 border-[3px] border-ink-950 shadow-hard", className)} {...props}>
      {children}
    </Tag>
  );
}

export function CardHeader({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-4 pt-4 pb-2 sm:px-5", className)} {...props} />;
}

export function CardTitle({ className, ...props }: React.HTMLAttributes<HTMLHeadingElement>) {
  return <h3 className={cn("font-display text-2xl leading-none", className)} {...props} />;
}

export function CardContent({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-4 pb-4 sm:px-5", className)} {...props} />;
}

export function CardFooter({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("px-4 pb-4 sm:px-5 flex items-center gap-3", className)} {...props} />;
}

/** A card with a torn bottom edge — for community "paper" content. */
export function TornCard({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn("relative", className)}>
      <div className="absolute inset-0 translate-x-1 translate-y-1 bg-ink-950 torn-bottom" aria-hidden />
      <div className="relative bg-paper-100 torn-bottom grain">{children}</div>
    </div>
  );
}
