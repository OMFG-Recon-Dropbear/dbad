"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { IconButton } from "./button";
import { XIcon } from "@/components/icons/ui";

/**
 * Native <dialog>-based modal. No portal library needed; the browser handles focus
 * trapping, Escape, and the top layer.
 */
export function Dialog({
  open,
  onClose,
  title,
  children,
  className,
  size = "md",
}: {
  open: boolean;
  onClose: () => void;
  title: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const ref = React.useRef<HTMLDialogElement>(null);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (open && !el.open) el.showModal();
    if (!open && el.open) el.close();
  }, [open]);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const handleClose = () => onClose();
    el.addEventListener("close", handleClose);
    return () => el.removeEventListener("close", handleClose);
  }, [onClose]);

  return (
    <dialog
      ref={ref}
      aria-label={typeof title === "string" ? title : undefined}
      onClick={(e) => {
        if (e.target === ref.current) onClose();
      }}
      className={cn(
        "m-auto w-[calc(100vw-1.5rem)] bg-paper-50 text-ink-950 border-[3px] border-ink-950 shadow-hard-lg p-0 backdrop:bg-ink-950/70 backdrop:backdrop-blur-[2px] open:animate-fade-up",
        size === "sm" && "max-w-md",
        size === "md" && "max-w-xl",
        size === "lg" && "max-w-3xl",
        className,
      )}
    >
      <div className="flex items-start justify-between gap-4 border-b-[3px] border-ink-950 bg-warning-500 px-4 py-3 sm:px-5">
        <h2 className="font-display text-2xl leading-none pt-1">{title}</h2>
        <IconButton label="Close" onClick={onClose} className="-mr-1">
          <XIcon className="size-5" />
        </IconButton>
      </div>
      <div className="p-4 sm:p-5">{children}</div>
    </dialog>
  );
}
