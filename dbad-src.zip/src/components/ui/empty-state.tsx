import * as React from "react";
import { Stamp } from "@/components/brand/stamp";
import { ButtonLink } from "./button";

export function EmptyState({
  stamp = "NOTHING HERE",
  title,
  body,
  action,
}: {
  stamp?: string;
  title: string;
  body?: string;
  action?: { href: string; label: string };
}) {
  return (
    <div className="border-[3px] border-dashed border-concrete-400 bg-paper-100 px-6 py-12 text-center">
      <Stamp tone="concrete" size="lg">
        {stamp}
      </Stamp>
      <h3 className="mt-5 text-3xl">{title}</h3>
      {body && <p className="mx-auto mt-2 max-w-md text-concrete-600">{body}</p>}
      {action && (
        <div className="mt-6">
          <ButtonLink href={action.href}>{action.label}</ButtonLink>
        </div>
      )}
    </div>
  );
}

export function ErrorState({ title = "Something went sideways.", body, retryHref }: { title?: string; body?: string; retryHref?: string }) {
  return (
    <div className="border-[3px] border-alert-500 bg-paper-100 px-6 py-12 text-center">
      <Stamp tone="red" size="lg">
        ERROR
      </Stamp>
      <h3 className="mt-5 text-3xl">{title}</h3>
      <p className="mx-auto mt-2 max-w-md text-concrete-600">{body ?? "Not your fault. Probably ours. Try again in a moment."}</p>
      {retryHref && (
        <div className="mt-6">
          <ButtonLink href={retryHref} variant="dark">
            Try again
          </ButtonLink>
        </div>
      )}
    </div>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`animate-pulse bg-concrete-200 ${className}`} aria-hidden />;
}
