import * as React from "react";
import { cn } from "@/lib/utils";

const base =
  "w-full bg-white text-ink-950 placeholder:text-concrete-500 border-[3px] border-ink-950 rounded-sm px-3 py-3 text-base leading-tight shadow-hard-sm focus:outline-none focus-visible:ring-0 disabled:opacity-60 aria-[invalid=true]:border-alert-500";

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(function Input({ className, ...props }, ref) {
  return <input ref={ref} className={cn(base, className)} {...props} />;
});

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(function Textarea({ className, ...props }, ref) {
  return <textarea ref={ref} className={cn(base, "min-h-28 resize-y", className)} {...props} />;
});

export const Select = React.forwardRef<HTMLSelectElement, React.SelectHTMLAttributes<HTMLSelectElement>>(function Select({ className, children, ...props }, ref) {
  return (
    <div className="relative">
      <select ref={ref} className={cn(base, "appearance-none pr-10", className)} {...props}>
        {children}
      </select>
      <svg aria-hidden viewBox="0 0 20 20" className="pointer-events-none absolute right-3 top-1/2 size-5 -translate-y-1/2 fill-ink-950">
        <path d="M5 7l5 6 5-6z" />
      </svg>
    </div>
  );
});

export function Label({ className, hint, children, ...props }: React.LabelHTMLAttributes<HTMLLabelElement> & { hint?: string }) {
  return (
    <label className={cn("block font-display uppercase tracking-wide text-lg leading-none mb-2", className)} {...props}>
      {children}
      {hint && <span className="block font-sans normal-case tracking-normal text-sm text-concrete-600 mt-1 font-normal">{hint}</span>}
    </label>
  );
}

export function FieldError({ children, id }: { children?: React.ReactNode; id?: string }) {
  if (!children) return null;
  return (
    <p id={id} role="alert" className="mt-2 text-sm font-semibold text-alert-600">
      {children}
    </p>
  );
}

export function Help({ children, className }: { children: React.ReactNode; className?: string }) {
  return <p className={cn("mt-2 text-sm text-concrete-600", className)}>{children}</p>;
}

/** Checkbox styled like a stamp box. */
export function Checkbox({ className, label, description, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label: React.ReactNode; description?: React.ReactNode }) {
  return (
    <label className={cn("flex gap-3 items-start cursor-pointer", className)}>
      <span className="relative mt-0.5 shrink-0">
        <input type="checkbox" className="peer sr-only" {...props} />
        <span className="block size-6 border-[3px] border-ink-950 bg-white rounded-xs peer-focus-visible:outline peer-focus-visible:outline-3 peer-focus-visible:outline-warning-500 peer-checked:bg-warning-500" />
        <svg aria-hidden viewBox="0 0 24 24" className="absolute inset-0 m-auto size-4 opacity-0 peer-checked:opacity-100 fill-none stroke-ink-950 stroke-[4]">
          <path d="M4 12l5 5L20 6" strokeLinecap="square" strokeLinejoin="miter" />
        </svg>
      </span>
      <span className="text-base leading-snug">
        <span className="font-semibold">{label}</span>
        {description && <span className="block text-sm text-concrete-600 mt-0.5">{description}</span>}
      </span>
    </label>
  );
}

/** Chip-style toggle used for categories, affected groups, verdicts. */
export function Chip({ active, className, children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      className={cn(
        "inline-flex items-center gap-2 border-[3px] border-ink-950 rounded-sm px-3 py-2 text-sm sm:text-base font-semibold leading-none transition-colors whitespace-nowrap",
        active ? "bg-ink-950 text-warning-500 shadow-hard-yellow" : "bg-paper-50 text-ink-950 hover:bg-white shadow-hard-sm",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}
