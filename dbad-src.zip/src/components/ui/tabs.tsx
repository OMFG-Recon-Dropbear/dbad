import * as React from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";

/**
 * Link-based tabs (URL is the state, so the feed filters are shareable and work
 * without JavaScript).
 */
export function LinkTabs({
  items,
  current,
  className,
  size = "md",
}: {
  items: Array<{ href: string; label: string; value: string; count?: number }>;
  current: string;
  className?: string;
  size?: "sm" | "md";
}) {
  return (
    <nav className={cn("flex gap-2 overflow-x-auto scrollbar-none -mx-4 px-4 sm:mx-0 sm:px-0 pb-1", className)} aria-label="Filter">
      {items.map((it) => {
        const active = it.value === current;
        return (
          <Link
            key={it.value}
            href={it.href}
            aria-current={active ? "page" : undefined}
            className={cn(
              "inline-flex items-center gap-2 border-[3px] border-ink-950 rounded-sm font-semibold leading-none whitespace-nowrap transition-colors",
              size === "sm" ? "px-2.5 py-1.5 text-sm" : "px-3 py-2 text-sm sm:text-base",
              active ? "bg-ink-950 text-warning-500 shadow-hard-yellow" : "bg-paper-50 hover:bg-white shadow-hard-sm",
            )}
          >
            {it.label}
            {typeof it.count === "number" && <span className={cn("font-mono text-xs", active ? "text-paper-50/80" : "text-concrete-600")}>{it.count}</span>}
          </Link>
        );
      })}
    </nav>
  );
}
