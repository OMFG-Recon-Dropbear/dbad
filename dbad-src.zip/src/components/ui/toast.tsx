"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

type Toast = { id: number; title: string; body?: string; tone: "yellow" | "green" | "red" | "ink" };
type Ctx = { push: (t: Omit<Toast, "id">) => void };

const ToastContext = React.createContext<Ctx>({ push: () => {} });

export function useToast() {
  return React.useContext(ToastContext);
}

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = React.useState<Toast[]>([]);
  const push = React.useCallback((t: Omit<Toast, "id">) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 4200);
  }, []);
  const value = React.useMemo(() => ({ push }), [push]);
  return (
    <ToastContext.Provider value={value}>
      {children}
      <div aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-20 sm:bottom-6 z-[100] flex flex-col items-center gap-2 px-3 print-hidden">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={cn(
              "pointer-events-auto w-full max-w-sm border-[3px] border-ink-950 shadow-hard px-4 py-3 animate-fade-up",
              t.tone === "yellow" && "bg-warning-500 text-ink-950",
              t.tone === "green" && "bg-redeem-500 text-paper-50",
              t.tone === "red" && "bg-alert-500 text-paper-50",
              t.tone === "ink" && "bg-ink-950 text-paper-50",
            )}
          >
            <p className="font-display uppercase text-lg leading-none">{t.title}</p>
            {t.body && <p className="text-sm mt-1 leading-snug">{t.body}</p>}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
