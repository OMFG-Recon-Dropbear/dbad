import type { ActionResult, IncidentDetail, NominationInput, PrintableNotice, ReactionKind, ReactionTally, Verdict, VoteTally } from "@/lib/domain/types";
import type { AppealInput, CreateNoticeInput, ModerationCommand, ReportInput } from "@/lib/data/repository";
import type { RewriteInput, RewriteResult } from "@/lib/ai/rewrite";

/**
 * Action contracts shared by the Next.js Server Actions and the preview harness. Client
 * components receive one of these objects as a prop and never import server code.
 */
export interface CommunityActions {
  castVote(incidentId: string, verdict: Verdict): Promise<ActionResult<{ votes: VoteTally; viewerVote: Verdict }>>;
  toggleReaction(incidentId: string, kind: ReactionKind): Promise<ActionResult<{ reactions: ReactionTally; viewerReactions: ReactionKind[] }>>;
  addComment(incidentId: string, body: string): Promise<ActionResult<IncidentDetail["comments"][number]>>;
  reportContent(input: ReportInput): Promise<ActionResult>;
  markRedeemed(incidentId: string, note: string): Promise<ActionResult>;
}

export interface NominationActions {
  submit(input: NominationInput): Promise<ActionResult<{ id: string; slug: string; shortCode: string; noticeId: string; moderationStatus: string }>>;
  suggest(input: RewriteInput): Promise<RewriteResult>;
}

export interface NoticeActions {
  update(id: string, patch: Partial<CreateNoticeInput>): Promise<PrintableNotice | null>;
  create(input: CreateNoticeInput): Promise<PrintableNotice>;
}

export interface AppealActions {
  submit(input: AppealInput): Promise<ActionResult<{ reference: string }>>;
}

export interface AdminActions {
  moderate(command: ModerationCommand): Promise<ActionResult>;
}
