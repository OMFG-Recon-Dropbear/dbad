import type { AffectedGroup, CategoryId } from "@/lib/domain/types";
import { AFFECTED_LABEL } from "@/lib/domain/categories";
import { scanText, softenText } from "@/lib/domain/pii";
import { hash32, joinWithAnd } from "@/lib/domain/utils";

/**
 * The DBAD wording helper.
 *
 * Takes an angry description and returns humorous, factual DBAD wording that targets
 * the behaviour rather than the person. Two implementations:
 *
 *  - `localRewrite`   deterministic, dependency-free, always available. Strips personal
 *                     attacks and profanity, then builds wording from what the text
 *                     says actually happened.
 *  - `anthropicRewrite` uses the Anthropic Messages API when ANTHROPIC_API_KEY is set,
 *                     with a strict system prompt and the local result as a fallback.
 */

export interface RewriteInput {
  text: string;
  categoryId: CategoryId;
  affected?: AffectedGroup[];
  kind?: "dick_move" | "not_a_dick";
}

export interface RewriteSuggestion {
  /** Card one-liner, ≤ 90 chars. */
  title: string;
  /** Plain statement of the dick move, ≤ 60 chars. */
  dickMove: string;
  /** Factual description with a bit of humour, ≤ 240 chars. */
  description: string;
  tone: "dry" | "cheeky" | "factual";
}

export interface RewriteResult {
  suggestions: RewriteSuggestion[];
  removed: string[];
  provider: "local" | "anthropic";
}

interface Pattern {
  id: string;
  test: RegExp;
  categories?: CategoryId[];
  dickMove: string;
  titles: string[];
  descriptions: string[];
}

/**
 * Behaviour patterns. `{affected}` and `{where}` are filled in. Written in an Australian
 * voice, aimed squarely at the action.
 */
const PATTERNS: Pattern[] = [
  {
    id: "footpath",
    test: /\b(foot ?path|pavement|sidewalk|walkway)s?\b.*\b(park|block|across|over)|\b(park|block)\w*\b.*\b(foot ?path|pavement|sidewalk|walkway)s?\b|\b(across|over)\b.*\b(foot ?path|pavement|sidewalk|walkway)s?\b/i,
    dickMove: "Blocking the footpath.",
    titles: [
      "Apparently the footpath is now a parking space.",
      "The footpath was needed for a very important parking manoeuvre.",
      "Footpaths are for people. This car disagreed.",
    ],
    descriptions: [
      "Apparently the entire footpath was required for this parking manoeuvre. {affected} were forced onto the road. Strong Dick Move.",
      "Parked across the whole footpath, sending {affected} out onto the road to get around it. There was space nearby. There is always space nearby.",
      "A vehicle took up the footpath end to end. {affected} had to detour into traffic. Footpaths are for people.",
    ],
  },
  {
    id: "disabled_bay",
    test: /\b(disabled|accessible|wheelchair|handicap)\b.*\b(park\w*|bay|spot|space)|\b(park\w*|bay|spot|space)\b.*\b(disabled|accessible|wheelchair|handicap)\b/i,
    categories: ["parking", "shopping", "other"],
    dickMove: "Parking in an accessible bay without a permit.",
    titles: [
      "'Just two minutes' in the accessible bay. Classic.",
      "The accessible bay: not a two-minute drop zone.",
      "A permit is a permit. A hazard light isn't.",
    ],
    descriptions: [
      "Parked in an accessible bay with no permit while {affected} circled the car park. Those bays exist for a reason, and 'I'll only be a minute' isn't it.",
      "No permit, accessible bay, hazard lights on as if that's a legal instrument. {affected} did the extra lap.",
    ],
  },
  {
    id: "two_bays",
    test: /\b(two|2|double|both)\b.*\b(spaces?|spots?|bays?)|\bacross the line|\bover the line\b/i,
    categories: ["parking", "shopping", "other"],
    dickMove: "Taking two parking bays.",
    titles: [
      "One car. Two bays. Zero self-awareness.",
      "Parked like the lines were a suggestion.",
      "This car needed personal space.",
    ],
    descriptions: [
      "Parked across two bays in a car park where {affected} were hunting for one. The lines are painted for a reason, and it isn't decoration.",
      "One vehicle, two spaces, and a car park full of people circling. A masterclass in not looking down.",
    ],
  },
  {
    id: "driveway",
    test: /\bdriveway\b/i,
    dickMove: "Blocking a driveway.",
    titles: ["The driveway is not a visitor bay.", "Somebody's driveway, somebody else's parking spot."],
    descriptions: [
      "Parked across a driveway so nobody could get in or out. {affected} waited. The car did not care.",
    ],
  },
  {
    id: "trolley",
    test: /\btrolle?y|trolleys|shopping cart\b/i,
    dickMove: "Abandoning a trolley.",
    titles: [
      "The trolley bay was right there.",
      "A trolley, alone in the wild, twenty metres from home.",
      "This trolley has been released into its natural habitat.",
    ],
    descriptions: [
      "A trolley left in a parking bay {where}, a short stroll from the trolley return. {affected} got to play dodgems with it. Return the trolley. It takes eleven seconds.",
      "Abandoned mid-car-park like it had done something wrong. The trolley bay was within sight. {affected} moved it so they could park.",
    ],
  },
  {
    id: "dog_poo",
    test: /\b(poo|poop|crap|turd|mess|business|droppings|bag)\b.*\bdog|\bdog\b.*\b(poo|poop|crap|turd|mess|business|droppings|bag)\b|\bdidn'?t pick (it )?up\b/i,
    categories: ["dog", "neighbourhood", "rubbish", "other"],
    dickMove: "Not picking up after the dog.",
    titles: [
      "The dog did its job. The human didn't do theirs.",
      "A bag was carried. A bag was not used.",
      "The footpath received an unsolicited gift.",
    ],
    descriptions: [
      "Dog did what dogs do; the owner watched, then walked off. {affected} found it the hard way. The dog is blameless. The person holding the lead is not.",
      "Poo left on a shared path with a bin metres away. To be clear: the dog is a good dog. This is a human problem.",
    ],
  },
  {
    id: "dog_offlead",
    test: /\b(off[- ]?lead|off[- ]?leash|no lead|no leash|unleashed)\b/i,
    categories: ["dog", "neighbourhood", "other"],
    dickMove: "Off-lead where dogs must be leashed.",
    titles: ["'He's friendly!' is not a leash.", "Off-lead in an on-lead area, with confidence."],
    descriptions: [
      "Dog off-lead in a clearly signed on-lead area, bounding at {affected} while the owner shouted 'he's friendly'. Lovely dog. The lead is for everyone else's sake.",
    ],
  },
  {
    id: "litter",
    test: /\b(litter|rubbish|trash|garbage|dump(ed|ing)?|left (their|his|her|the) (mess|rubbish)|bottles?|cans?|wrappers?|butts?|cigarette)\b/i,
    categories: ["rubbish", "neighbourhood", "other"],
    dickMove: "Leaving rubbish behind.",
    titles: [
      "The bin was three metres away. Three.",
      "A picnic's worth of rubbish, left for the wind to sort.",
      "Nature: beautiful. This: not.",
    ],
    descriptions: [
      "Rubbish left {where} with a bin in plain sight. {affected} cleaned up after strangers, again. Take it with you. It's not heavy.",
      "An entire evening's worth of packaging left for someone else to deal with. The bin was right there. It's always right there.",
    ],
  },
  {
    id: "tailgate",
    test: /\b(tailgat\w*|up my (arse|ass|bumper)|right behind me|inches? from)\b/i,
    categories: ["road", "other"],
    dickMove: "Tailgating.",
    titles: ["Close enough to read the odometer.", "The two-second gap was treated as a challenge."],
    descriptions: [
      "Sat a car-length off the bumper for kilometres despite an overtaking lane. {affected} got a lesson in mirror-checking. Back off; nobody is arriving sooner.",
    ],
  },
  {
    id: "phone_driving",
    test: /\b(on (the|their|his|her) phone|texting|scrolling)\b.*\b(driv|wheel|car|traffic)|\b(driv|wheel)\b.*\b(phone|texting|scrolling)\b/i,
    categories: ["road", "other"],
    dickMove: "Using a phone while driving.",
    titles: ["The road was optional. The phone was not.", "Multitasking at 60 km/h."],
    descriptions: [
      "Phone in hand, eyes down, drifting across lanes while {affected} gave a wide berth. Whatever it was, it could have waited.",
    ],
  },
  {
    id: "merge",
    test: /\b(merge|merging|cut (me|us) off|cut in|pushed in|indicat|indicator|didn'?t signal)\b/i,
    categories: ["road", "other"],
    dickMove: "Cutting in without indicating.",
    titles: ["Indicators: fitted as standard, apparently optional.", "The merge lane was treated as a personal express lane."],
    descriptions: [
      "Cut across two lanes without an indicator and forced {affected} to brake hard. The little stalk on the steering column does a thing. Try it.",
    ],
  },
  {
    id: "queue",
    test: /\b(queue|line|pushed in|jumped the|skipped the|express lane|item)\b/i,
    categories: ["shopping", "other", "neighbourhood"],
    dickMove: "Jumping the queue.",
    titles: ["The queue was for other people.", "Fourteen items. Eight-item lane. Bold."],
    descriptions: [
      "Skipped a queue of {affected} as if it were a suggestion. Queues are the one thing Australians do properly. Respect the queue.",
    ],
  },
  {
    id: "aisle",
    test: /\b(aisle|blocked the aisle|middle of the aisle|left (the|their) trolley in)\b/i,
    categories: ["shopping", "other"],
    dickMove: "Blocking the aisle.",
    titles: ["The aisle became a private lounge room.", "A trolley parked diagonally. In the aisle. For the vibes."],
    descriptions: [
      "Trolley parked diagonally across the aisle while its owner browsed, and {affected} waited or reversed. A trolley is 60 centimetres wide. So is the gap it left.",
    ],
  },
  {
    id: "noise",
    test: /\b(noise|loud|music|blast|speaker|party|leaf ?blower|mower|revving)\b/i,
    categories: ["neighbourhood", "other"],
    dickMove: "Unreasonable noise in a shared space.",
    titles: ["The whole park got to enjoy the playlist.", "A speaker, at full volume, for everybody's benefit."],
    descriptions: [
      "A speaker at full volume in a shared public space, treating {affected} to somebody else's playlist. Headphones exist and they're brilliant.",
    ],
  },
  {
    id: "microwave",
    test: /\b(microwave|fish|reheat|lunch|fridge|stole|took my)\b/i,
    categories: ["workplace", "other"],
    dickMove: "Microwaving fish in the office.",
    titles: ["Fish. In the office microwave. At 12:02.", "The kitchen has entered a new era."],
    descriptions: [
      "Reheated fish in the shared microwave and left the door open so the whole floor could join in. {affected} still smell it. Some meals are for home.",
    ],
  },
  {
    id: "reply_all",
    test: /\b(reply[- ]?all|cc'?d everyone|emailed the whole)\b/i,
    categories: ["workplace", "other"],
    dickMove: "Replying-all to the whole company.",
    titles: ["Reply-all. Four hundred people. 'Thanks.'", "The email that launched a thousand notifications."],
    descriptions: [
      "Replied-all to an all-staff email to say 'thanks', triggering a cascade of 'please remove me' replies. {affected} lost an afternoon. The button is right next to the good button.",
    ],
  },
  {
    id: "marketplace",
    test: /\b(marketplace|no[- ]?show|didn'?t show|haggl|lowball|is this still available|free to a good home)\b/i,
    categories: ["internet", "other"],
    dickMove: "Marketplace no-show.",
    titles: ["'Is this still available?' Yes. Then silence.", "Confirmed pickup. Didn't pick up. Didn't message."],
    descriptions: [
      "Arranged a pickup, confirmed twice, then vanished without a word. {affected} waited an hour. Just send the message. It's one message.",
    ],
  },
  {
    id: "shortcut_parking_generic",
    test: /\bpark(ed|ing)?\b/i,
    categories: ["parking", "shopping", "neighbourhood", "other"],
    dickMove: "Inconsiderate parking.",
    titles: ["A parking decision was made. It was the wrong one.", "Where lines and logic were both ignored."],
    descriptions: [
      "Parked in a way that made everyone else work around it. {affected} had to improvise. There were better options and they were not far away.",
    ],
  },
];

const GENERIC: Record<CategoryId, Omit<Pattern, "test" | "id" | "categories">> = {
  parking: {
    dickMove: "Inconsiderate parking.",
    titles: ["A parking decision was made. It was the wrong one."],
    descriptions: ["Parked in a way that made {affected} work around it. There were better options, and they were not far away."],
  },
  road: {
    dickMove: "Inconsiderate driving.",
    titles: ["The road rules were treated as a rough guide."],
    descriptions: ["Drove in a way that put {affected} on edge and made everyone else compensate. Nobody gets there faster. Everybody gets there angrier."],
  },
  shopping: {
    dickMove: "Shopping-centre dickery.",
    titles: ["The shops were treated as a personal obstacle course for everyone else."],
    descriptions: ["Made a routine trip harder for {affected} through pure inattention. A moment of looking around would have fixed it."],
  },
  neighbourhood: {
    dickMove: "Community-space stupidity.",
    titles: ["A shared space, treated as a private one."],
    descriptions: ["Used a shared community space as if nobody else existed. {affected} noticed. They always notice."],
  },
  rubbish: {
    dickMove: "Leaving rubbish behind.",
    titles: ["The bin was right there."],
    descriptions: ["Left rubbish for {affected} to deal with when a bin was in plain sight. Take it with you."],
  },
  dog: {
    dickMove: "Irresponsible dog ownership.",
    titles: ["Good dog. Questionable human."],
    descriptions: ["The dog behaved like a dog. The owner behaved like the rules didn't apply. {affected} had to deal with the result. The dog remains innocent."],
  },
  internet: {
    dickMove: "Online dickery.",
    titles: ["Posted publicly, regretted communally."],
    descriptions: ["A public post that made things harder for {affected} for no good reason. The internet remembers, but DBAD forgives if it's fixed."],
  },
  workplace: {
    dickMove: "Workplace dick move.",
    titles: ["The office kitchen has seen things."],
    descriptions: ["A small workplace choice that cost {affected} their patience. No confidential details, just a plea for basic consideration."],
  },
  other: {
    dickMove: "General dickery.",
    titles: ["Humanity found a new one."],
    descriptions: ["Something spectacularly inconsiderate that made life harder for {affected}. We didn't have a category for it. We do now."],
  },
};

const POSITIVE: Record<string, { titles: string[]; descriptions: string[]; dickMove: string }> = {
  default: {
    dickMove: "Being a decent human.",
    titles: ["Definitely not a dick.", "Faith in humanity: restored, briefly.", "Spotted: someone doing the right thing for no reward."],
    descriptions: [
      "Went out of their way to help {affected} when nobody was watching and nothing was in it for them. Definitely not a dick.",
      "Fixed a problem that wasn't theirs and walked off without a word. This is the standard. Definitely not a dick.",
    ],
  },
};

function pick<T>(items: T[], seed: number, offset = 0): T {
  return items[(seed + offset) % items.length]!;
}

function affectedPhrase(affected?: AffectedGroup[]): { phrase: string; singular: boolean } {
  if (!affected || affected.length === 0 || affected.includes("everyone")) return { phrase: "Everyone else", singular: true };
  if (affected.includes("probably_nobody")) return { phrase: "Nobody in particular", singular: true };
  const labels = affected.slice(0, 3).map((a) => AFFECTED_LABEL[a].toLowerCase());
  const s = joinWithAnd(labels);
  return { phrase: s.charAt(0).toUpperCase() + s.slice(1), singular: false };
}

function extractWhere(text: string): string {
  const m = text.match(/\b(?:at|in|outside|near|behind|opposite)\s+(?:the\s+)?([A-Z][\w'&-]*(?:\s+[A-Z][\w'&-]*){0,3})/);
  if (!m) return "";
  return `at ${m[1]}`;
}

export function localRewrite(input: RewriteInput): RewriteResult {
  const { text: softened, removed } = softenText(input.text);
  const scan = scanText(softened);
  const base = scan.cleaned || softened;
  const seed = hash32(input.text + input.categoryId);
  const { phrase: affected, singular } = affectedPhrase(input.affected);
  const where = extractWhere(input.text);

  const fill = (s: string) =>
    s
      .replace(/(^|[.!?]\s+)\{affected\}/g, (_m, pre: string) => `${pre}${affected}`)
      .replace(/\{affected\}/g, affected.charAt(0).toLowerCase() + affected.slice(1))
      // "Everyone else were" → "Everyone else was": templates are written for plural groups.
      .replace(new RegExp(`(${affected}) were\\b`, "gi"), singular ? "$1 was" : "$1 were")
      .replace(" {where}", where ? ` ${where}` : "")
      .replace("{where}", where)
      .replace(/\s{2,}/g, " ")
      .trim();

  if (input.kind === "not_a_dick") {
    const p = POSITIVE.default!;
    return {
      provider: "local",
      removed,
      suggestions: [
        { tone: "cheeky", title: pick(p.titles, seed), dickMove: p.dickMove, description: fill(pick(p.descriptions, seed)) },
        { tone: "dry", title: pick(p.titles, seed, 1), dickMove: p.dickMove, description: fill(pick(p.descriptions, seed, 1)) },
        { tone: "factual", title: "Definitely not a dick.", dickMove: p.dickMove, description: base.slice(0, 240) },
      ],
    };
  }

  const matched = PATTERNS.find(
    (p) => p.test.test(input.text) && (!p.categories || p.categories.includes(input.categoryId)),
  );
  const src = matched ?? GENERIC[input.categoryId];

  const dry: RewriteSuggestion = {
    tone: "dry",
    title: pick(src.titles, seed),
    dickMove: src.dickMove,
    description: fill(pick(src.descriptions, seed)),
  };
  const cheeky: RewriteSuggestion = {
    tone: "cheeky",
    title: pick(src.titles, seed, 1),
    dickMove: src.dickMove,
    description: fill(pick(src.descriptions, seed, 1)),
  };
  // The factual option keeps the user's own words, minus the attacks and PII. Sentences that
  // lost their meaning in the clean-up (masked details, dangling "because he's a") are dropped.
  const kept = base
    .split(/(?<=[.!?])\s+/)
    .map((x) => x.trim())
    .filter((x) => x.length > 12 && !x.includes("[") && !/\b(?:a|an|the|his|her|their|because|so|and|but|is|was|he's|she's|they're)\W*$/i.test(x))
    .map((x) => x.replace(/\s+([,.!?;:])/g, "$1").replace(/[,;:]$/, "."));
  const factualText = kept.join(" ");
  const factualBody = factualText
    ? factualText.charAt(0).toUpperCase() + factualText.slice(1).replace(/[.!?]*$/, "") + ". Dick move."
    : fill(pick(src.descriptions, seed, 2));
  const factual: RewriteSuggestion = {
    tone: "factual",
    title: src.dickMove.replace(/\.$/, ""),
    dickMove: src.dickMove,
    description: factualBody.slice(0, 240),
  };

  // De-duplicate identical suggestions (small pattern lists can collide).
  const seen = new Set<string>();
  const suggestions = [dry, cheeky, factual].filter((s) => {
    const key = s.title + s.description;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return { provider: "local", removed, suggestions };
}

const SYSTEM_PROMPT = `You write copy for DBAD (Don't Be A Dick), an Australian community site that calls out inconsiderate BEHAVIOUR with humour. Rules you never break:
- Target the action, never the person. No insults, no speculation about who they are, no "type of person" language.
- Remove and never repeat identifying details: names, number plates, phone numbers, addresses, workplaces, social handles, descriptions of children.
- Keep it factual and short. Australian English. Dry, self-aware humour; no cruelty, no threats, no swearing beyond the word "dick".
- If the text is about a dog, the dog is never the dick. The owner is responsible.
- Output strictly as JSON: {"suggestions":[{"tone":"dry|cheeky|factual","title":"<=90 chars one-liner","dickMove":"<=60 chars plain statement ending with a full stop","description":"<=240 chars"}]} with exactly three suggestions.`;

export async function anthropicRewrite(input: RewriteInput, apiKey: string, model = "claude-sonnet-4-5"): Promise<RewriteResult> {
  const local = localRewrite(input);
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model,
        max_tokens: 600,
        system: SYSTEM_PROMPT,
        messages: [
          {
            role: "user",
            content: `Category: ${input.categoryId}\nKind: ${input.kind ?? "dick_move"}\nAffected: ${(input.affected ?? []).join(", ") || "unspecified"}\nSubmitter wrote: """${input.text.slice(0, 1200)}"""`,
          },
        ],
      }),
      signal: AbortSignal.timeout(12_000),
    });
    if (!res.ok) return local;
    const json = (await res.json()) as { content?: Array<{ type: string; text?: string }> };
    const text = json.content?.find((c) => c.type === "text")?.text ?? "";
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start < 0 || end < 0) return local;
    const parsed = JSON.parse(text.slice(start, end + 1)) as { suggestions?: RewriteSuggestion[] };
    const suggestions = (parsed.suggestions ?? [])
      .filter((s) => s && typeof s.title === "string" && typeof s.description === "string")
      .map((s) => ({
        tone: (["dry", "cheeky", "factual"].includes(s.tone) ? s.tone : "dry") as RewriteSuggestion["tone"],
        title: s.title.slice(0, 90),
        dickMove: (s.dickMove || local.suggestions[0]?.dickMove || "Dick move.").slice(0, 60),
        // Belt and braces: never let PII through even from the model.
        description: scanText(s.description).cleaned.slice(0, 240),
      }));
    if (suggestions.length === 0) return local;
    return { suggestions, removed: local.removed, provider: "anthropic" };
  } catch {
    return local;
  }
}

export async function rewrite(input: RewriteInput): Promise<RewriteResult> {
  const key = process.env.ANTHROPIC_API_KEY;
  if (key) return anthropicRewrite(input, key, process.env.DBAD_AI_MODEL || "claude-sonnet-4-5");
  return localRewrite(input);
}
