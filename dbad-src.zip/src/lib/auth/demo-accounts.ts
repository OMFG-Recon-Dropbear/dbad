/** Demo accounts offered on the sign-in page when Supabase isn't configured. Safe for client bundles. */
export const DEMO_ACCOUNTS = [
  { id: "u_jen", label: "Member", blurb: "Jen — South Coast spotter with a Fair Dinkum badge." },
  { id: "u_sarah", label: "Moderator", blurb: "Sarah — keeps the noticeboard tidy." },
  { id: "u_hq", label: "Admin", blurb: "DBAD HQ — full dashboard access." },
] as const;
