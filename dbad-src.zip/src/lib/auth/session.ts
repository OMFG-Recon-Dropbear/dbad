import "server-only";
import { cookies } from "next/headers";
import { cache } from "react";
import type { ViewerOrNull } from "@/lib/data/repository";
import { isSupabaseConfigured } from "@/lib/data";
import { PROFILES } from "@/lib/data/demo/seed";

export const DEMO_COOKIE = "dbad_demo_user";

/** The current member, resolved once per request. */
export const getViewer = cache(async (): Promise<ViewerOrNull> => {
  const store = await cookies();
  if (!isSupabaseConfigured()) {
    const id = store.get(DEMO_COOKIE)?.value;
    if (!id) return null;
    const p = PROFILES.find((x) => x.id === id);
    return p ? { id: p.id, handle: p.handle, displayName: p.displayName, role: p.role } : null;
  }
  const { createSupabaseServerClient } = await import("@/lib/supabase/server");
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;
  const { data: profile } = await supabase.from("profiles").select("id, handle, display_name, role").eq("id", user.id).maybeSingle();
  if (!profile) {
    // Profile row is created by a DB trigger on sign-up; fall back to a minimal viewer.
    return { id: user.id, handle: user.email?.split("@")[0] ?? "member", displayName: "Member", role: "member" };
  }
  return { id: profile.id, handle: profile.handle, displayName: profile.display_name, role: profile.role };
});

export { DEMO_ACCOUNTS } from "./demo-accounts";
