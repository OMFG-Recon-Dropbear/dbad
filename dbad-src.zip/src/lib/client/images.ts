/**
 * Browser-side image helpers for the nomination flow. Everything happens on the
 * device: downscaling (so uploads are fast on mobile data) and pixelation (so the
 * redacted image, not the original, is what leaves the phone).
 */

export interface Region {
  x: number;
  y: number;
  w: number;
  h: number;
  /** face | plate | manual */
  kind: "face" | "plate" | "manual";
}

export const MAX_DIMENSION = 1600;
export const JPEG_QUALITY = 0.82;

export async function fileToImage(file: File | Blob): Promise<HTMLImageElement> {
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = "async";
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("That file doesn't look like an image."));
      img.src = url;
    });
    return img;
  } finally {
    // Revoke after decode; the image keeps its bitmap.
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
}

/** Downscale to MAX_DIMENSION on the long edge. Also strips EXIF (incl. GPS) by re-encoding. */
export async function downscale(file: File | Blob, maxDim = MAX_DIMENSION): Promise<{ dataUrl: string; width: number; height: number }> {
  const img = await fileToImage(file);
  const scale = Math.min(1, maxDim / Math.max(img.naturalWidth, img.naturalHeight));
  const width = Math.max(1, Math.round(img.naturalWidth * scale));
  const height = Math.max(1, Math.round(img.naturalHeight * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas unavailable");
  ctx.drawImage(img, 0, 0, width, height);
  return { dataUrl: canvas.toDataURL("image/jpeg", JPEG_QUALITY), width, height };
}

/** Pixelate a rectangle in place. Block size scales with the region so plates are unreadable. */
export function pixelate(ctx: CanvasRenderingContext2D, r: Region) {
  const x = Math.max(0, Math.floor(r.x));
  const y = Math.max(0, Math.floor(r.y));
  const w = Math.min(ctx.canvas.width - x, Math.ceil(r.w));
  const h = Math.min(ctx.canvas.height - y, Math.ceil(r.h));
  if (w <= 0 || h <= 0) return;
  const block = Math.max(10, Math.round(Math.max(w, h) / 6));
  const cols = Math.max(1, Math.floor(w / block));
  const rows = Math.max(1, Math.floor(h / block));
  const tmp = document.createElement("canvas");
  tmp.width = cols;
  tmp.height = rows;
  const tctx = tmp.getContext("2d")!;
  tctx.imageSmoothingEnabled = true;
  tctx.drawImage(ctx.canvas, x, y, w, h, 0, 0, cols, rows);
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(tmp, 0, 0, cols, rows, x, y, w, h);
  ctx.imageSmoothingEnabled = true;
}

/** Renders the source image with all regions pixelated and returns a JPEG data URL. */
export async function applyRedactions(dataUrl: string, regions: Region[]): Promise<string> {
  const img = await fileToImage(await (await fetch(dataUrl)).blob());
  const canvas = document.createElement("canvas");
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  const ctx = canvas.getContext("2d")!;
  ctx.drawImage(img, 0, 0);
  for (const r of regions) pixelate(ctx, r);
  return canvas.toDataURL("image/jpeg", JPEG_QUALITY);
}

interface DetectedFace {
  boundingBox: { x: number; y: number; width: number; height: number };
}
interface FaceDetectorLike {
  detect(source: HTMLImageElement | HTMLCanvasElement): Promise<DetectedFace[]>;
}

/**
 * Progressive enhancement: Chrome's Shape Detection API where available. Returns
 * regions padded generously. Never the only line of defence — the manual review step
 * is mandatory.
 */
export async function detectFaces(img: HTMLImageElement | HTMLCanvasElement): Promise<Region[]> {
  const w = window as unknown as { FaceDetector?: new (opts?: { fastMode?: boolean; maxDetectedFaces?: number }) => FaceDetectorLike };
  if (!w.FaceDetector) return [];
  try {
    const det = new w.FaceDetector({ fastMode: false, maxDetectedFaces: 12 });
    const faces = await det.detect(img);
    return faces.map((f) => {
      const pad = Math.max(f.boundingBox.width, f.boundingBox.height) * 0.35;
      return { kind: "face" as const, x: f.boundingBox.x - pad, y: f.boundingBox.y - pad, w: f.boundingBox.width + pad * 2, h: f.boundingBox.height + pad * 2 };
    });
  } catch {
    return [];
  }
}

export function faceDetectionAvailable(): boolean {
  return typeof window !== "undefined" && "FaceDetector" in window;
}
