import type {
  ActionResult,
  AdminStats,
  Appeal,
  Category,
  Comment,
  FeedFilters,
  FeedPage,
  Incident,
  IncidentDetail,
  IncidentSummary,
  MapCluster,
  ModerationAction,
  NominationInput,
  Notification,
  Photo,
  PrintableNotice,
  Profile,
  ProfileStats,
  ReactionKind,
  ReactionTally,
  Report,
  UserBadge,
  Verdict,
  VoteTally,
} from "@/lib/domain/types";
import { CATEGORIES, getCategory } from "@/lib/domain/categories";
import { evaluateBadges } from "@/lib/domain/badges";
import { applyVote, dickeryRank, summariseVotes, totalVotes, MIN_VOTES_FOR_VERDICT } from "@/lib/domain/verdict";
import { scanText } from "@/lib/domain/pii";
import { randomId, shortCodeFromSequence, slugify, weekOf } from "@/lib/domain/utils";
import { validateNomination } from "@/lib/domain/validation";
import { buildNoticeLines } from "@/lib/notice/lines";
import type {
  AppealInput,
  AppealWithIncident,
  AuditEntry,
  CreateNoticeInput,
  FeaturedSet,
  ModerationCommand,
  ProfilePage,
  Repository,
  ReportInput,
  ReportWithTarget,
  UserRow,
  Viewer,
  ViewerOrNull,
} from "../repository";
import * as seed from "./seed";

/**
 * In-memory implementation used when Supabase isn't configured (and by the design
 * preview harness in the browser). State lives for the life of the process, so the
 * demo behaves like a real site during a session: votes stick, comments appear,
 * nominations land in the moderation queue.
 */
interface Store {
  incidents: Incident[];
  profiles: Profile[];
  comments: Comment[];
  reports: Report[];
  appeals: Appeal[];
  audit: ModerationAction[];
  notifications: Notification[];
  notices: PrintableNotice[];
  userBadges: Record<string, UserBadge[]>;
  votes: Map<string, Verdict>; // key `${incidentId}:${userId}`
  reactions: Map<string, Set<ReactionKind>>;
  sequence: number;
}

function clone<T>(v: T): T {
  return typeof structuredClone === "function" ? structuredClone(v) : (JSON.parse(JSON.stringify(v)) as T);
}

function createStore(): Store {
  return {
    incidents: clone(seed.INCIDENTS),
    profiles: clone(seed.PROFILES),
    comments: clone(seed.COMMENTS),
    reports: clone(seed.REPORTS),
    appeals: clone(seed.APPEALS),
    audit: clone(seed.AUDIT),
    notifications: clone(seed.NOTIFICATIONS),
    notices: clone(seed.NOTICES),
    userBadges: clone(seed.USER_BADGES),
    votes: new Map(),
    reactions: new Map(),
    sequence: seed.NEXT_SEQUENCE,
  };
}

const globalStore = globalThis as unknown as { __dbadDemoStore?: Store };

export class DemoRepository implements Repository {
  private store: Store;

  constructor(store?: Store) {
    if (store) this.store = store;
    else {
      if (!globalStore.__dbadDemoStore) globalStore.__dbadDemoStore = createStore();
      this.store = globalStore.__dbadDemoStore;
    }
  }

  /** Fresh, isolated store (tests / harness resets). */
  static isolated(): DemoRepository {
    return new DemoRepository(createStore());
  }

  // ---- helpers -----------------------------------------------------------
  private profile(id: string | null | undefined): Profile | undefined {
    if (!id) return undefined;
    return this.store.profiles.find((p) => p.id === id);
  }

  private summarise(inc: Incident): IncidentSummary {
    const p = inc.anonymised ? undefined : this.profile(inc.submitterId);
    return {
      ...clone(inc),
      category: getCategory(inc.categoryId),
      submitter: p ? { handle: p.handle, displayName: p.displayName, avatarSeed: p.avatarSeed } : null,
    };
  }

  private detail(inc: Incident, viewer?: ViewerOrNull): IncidentDetail {
    const comments = this.store.comments
      .filter((c) => c.incidentId === inc.id && c.status === "visible")
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
      .map((c) => {
        const a = this.profile(c.authorId);
        return { ...clone(c), author: { handle: a?.handle ?? "member", displayName: a?.displayName ?? "Member", avatarSeed: a?.avatarSeed ?? "member" } };
      });
    const publicReplies = this.store.appeals
      .filter((a) => a.incidentId === inc.id && a.status === "actioned" && a.publicReply)
      .map((a) => ({ id: a.id, publicReply: a.publicReply, createdAt: a.createdAt }));
    return {
      ...this.summarise(inc),
      comments,
      publicReplies,
      viewerVote: viewer ? this.store.votes.get(`${inc.id}:${viewer.id}`) : undefined,
      viewerReactions: viewer ? Array.from(this.store.reactions.get(`${inc.id}:${viewer.id}`) ?? []) : undefined,
    };
  }

  private publicIncidents(): Incident[] {
    return this.store.incidents.filter((i) => i.moderationStatus === "approved");
  }

  private stats(userId: string): ProfileStats {
    const mine = this.store.incidents.filter((i) => i.submitterId === userId && i.moderationStatus === "approved");
    let fairCalls = 0;
    let overruled = 0;
    for (const i of mine) {
      if (i.kind !== "dick_move") continue;
      const s = summariseVotes(i.votes);
      if (s.band === "pending") continue;
      if (s.band === "not" || i.status === "overruled") overruled++;
      else fairCalls++;
    }
    return {
      spotted: mine.filter((i) => i.kind === "dick_move").length,
      fairCalls,
      redeemed: mine.filter((i) => i.status === "redeemed").length,
      overruled,
      notADick: mine.filter((i) => i.kind === "not_a_dick").length,
      comments: this.store.comments.filter((c) => c.authorId === userId && c.status === "visible").length,
    };
  }

  private log(actor: Viewer, cmd: ModerationCommand) {
    this.store.audit.unshift({
      id: randomId("ma"),
      actorId: actor.id,
      action: cmd.action,
      targetType: cmd.targetType,
      targetId: cmd.targetId,
      note: cmd.note,
      createdAt: new Date().toISOString(),
    });
  }

  private notify(userId: string | null | undefined, n: Omit<Notification, "id" | "userId" | "createdAt">) {
    if (!userId) return;
    this.store.notifications.unshift({ id: randomId("n"), userId, createdAt: new Date().toISOString(), ...n });
  }

  private refreshBadges(userId: string) {
    const earned = evaluateBadges(this.stats(userId));
    const have = this.store.userBadges[userId] ?? [];
    for (const b of earned) {
      if (!have.some((h) => h.badgeId === b)) {
        have.push({ badgeId: b, awardedAt: new Date().toISOString() });
        this.notify(userId, { kind: "badge", title: `Badge earned: ${b.replace(/_/g, " ").toUpperCase()}`, body: "Check your profile.", href: "/me" });
      }
    }
    this.store.userBadges[userId] = have;
  }

  // ---- categories --------------------------------------------------------
  async listCategories(): Promise<Category[]> {
    return CATEGORIES;
  }

  // ---- incidents ---------------------------------------------------------
  async listIncidents(filters: FeedFilters, viewer?: ViewerOrNull): Promise<FeedPage> {
    void viewer;
    let items = this.publicIncidents();
    if (filters.kind) items = items.filter((i) => i.kind === filters.kind);
    if (filters.categoryId) items = items.filter((i) => i.categoryId === filters.categoryId);
    if (filters.state) items = items.filter((i) => i.location.state === filters.state);
    if (filters.region) items = items.filter((i) => i.location.region === filters.region);
    if (filters.status) items = items.filter((i) => i.status === filters.status);
    if (filters.query) {
      const q = filters.query.toLowerCase();
      items = items.filter((i) =>
        [i.title, i.dickMove, i.description, i.location.suburb, i.location.place ?? "", i.location.state].join(" ").toLowerCase().includes(q),
      );
    }
    const sort = filters.sort ?? "latest";
    if (sort === "latest") items.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (sort === "top") items.sort((a, b) => dickeryRank(b.votes) - dickeryRank(a.votes));
    if (sort === "redeemed") {
      items = items.filter((i) => i.status === "redeemed").sort((a, b) => (b.redemption?.createdAt ?? "").localeCompare(a.redemption?.createdAt ?? ""));
    }
    const limit = filters.limit ?? 12;
    const start = filters.cursor ? Number(filters.cursor) || 0 : 0;
    const page = items.slice(start, start + limit);
    return {
      items: page.map((i) => this.summarise(i)),
      nextCursor: start + limit < items.length ? String(start + limit) : undefined,
      total: items.length,
    };
  }

  async getIncidentBySlug(slug: string, viewer?: ViewerOrNull): Promise<IncidentDetail | null> {
    const inc = this.store.incidents.find((i) => i.slug === slug);
    if (!inc) return null;
    if (inc.moderationStatus !== "approved") {
      const canSee = viewer && (viewer.role !== "member" || viewer.id === inc.submitterId);
      if (!canSee) return null;
    }
    return this.detail(inc, viewer);
  }

  async getIncidentByCode(code: string): Promise<IncidentSummary | null> {
    const inc = this.publicIncidents().find((i) => i.shortCode.toLowerCase() === code.toLowerCase());
    return inc ? this.summarise(inc) : null;
  }

  async getIncidentById(id: string, viewer?: ViewerOrNull): Promise<IncidentDetail | null> {
    const inc = this.store.incidents.find((i) => i.id === id);
    if (!inc) return null;
    if (inc.moderationStatus !== "approved") {
      const canSee = viewer && (viewer.role !== "member" || viewer.id === inc.submitterId);
      if (!canSee) return null;
    }
    return this.detail(inc, viewer);
  }

  async getFeatured(): Promise<FeaturedSet> {
    const pub = this.publicIncidents();
    const thisWeek = weekOf(new Date());
    const week = pub.find((i) => i.featuredWeek === thisWeek && i.kind === "dick_move") ?? null;
    const month = pub.filter((i) => i.featuredWeek && i.featuredWeek !== thisWeek && i.kind === "dick_move").sort((a, b) => dickeryRank(b.votes) - dickeryRank(a.votes))[0] ?? null;
    const greatest = pub
      .filter((i) => i.kind === "dick_move" && totalVotes(i.votes) >= MIN_VOTES_FOR_VERDICT)
      .sort((a, b) => dickeryRank(b.votes) - dickeryRank(a.votes))
      .slice(0, 6);
    const mostRedeemed = pub.filter((i) => i.status === "redeemed").sort((a, b) => b.reactions.redemption - a.reactions.redemption).slice(0, 6);
    const latestRedemptions = pub.filter((i) => i.status === "redeemed").sort((a, b) => (b.redemption?.createdAt ?? "").localeCompare(a.redemption?.createdAt ?? "")).slice(0, 4);
    const notADick = pub.filter((i) => i.kind === "not_a_dick").sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 6);
    return {
      week: week ? this.summarise(week) : null,
      month: month ? this.summarise(month) : null,
      greatest: greatest.map((i) => this.summarise(i)),
      mostRedeemed: mostRedeemed.map((i) => this.summarise(i)),
      latestRedemptions: latestRedemptions.map((i) => this.summarise(i)),
      notADick: notADick.map((i) => this.summarise(i)),
    };
  }

  async listRelated(incidentId: string, limit = 3): Promise<IncidentSummary[]> {
    const inc = this.store.incidents.find((i) => i.id === incidentId);
    if (!inc) return [];
    return this.publicIncidents()
      .filter((i) => i.id !== incidentId && (i.categoryId === inc.categoryId || i.location.region === inc.location.region))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, limit)
      .map((i) => this.summarise(i));
  }

  async createIncident(input: NominationInput, viewer: ViewerOrNull) {
    const validation = validateNomination(input);
    if (!validation.ok) return validation;
    const seq = this.store.sequence++;
    const shortCode = shortCodeFromSequence(seq);
    const id = randomId("inc");
    const photos: Photo[] = input.photos.map((p, idx) => ({
      id: `${id}_p${idx}`,
      url: p.src,
      width: p.width,
      height: p.height,
      alt: p.alt || `Evidence photo ${idx + 1}`,
      redacted: true,
      redactionCount: p.redactionCount,
    }));
    const region = guessRegion(input.location.suburb, input.location.state);
    const inc: Incident = {
      id,
      shortCode,
      slug: `${slugify(input.dickMove.replace(/\.$/, ""))}-${slugify(input.location.suburb)}-${String(seq).padStart(4, "0")}`,
      kind: input.kind,
      categoryId: input.categoryId,
      title: scanText(input.title).cleaned,
      dickMove: scanText(input.dickMove).cleaned,
      description: scanText(input.description).cleaned,
      affected: input.affected,
      location: {
        id: randomId("loc"),
        suburb: input.location.suburb.trim(),
        state: input.location.state,
        place: input.location.place?.trim() || undefined,
        approxLat: input.location.approxLat,
        approxLng: input.location.approxLng,
        precision: input.location.place ? "place" : "suburb",
        region,
      },
      occurredOn: input.occurredOn,
      partOfDay: input.partOfDay,
      createdAt: new Date().toISOString(),
      submitterId: viewer?.id ?? null,
      photos,
      socialSource: input.facebookUrl ? { platform: "facebook", url: input.facebookUrl, retrievedVia: "manual" } : undefined,
      status: "open",
      // Positive nominations and photo-less posts go straight up; photos wait for a moderator's once-over.
      moderationStatus: input.kind === "not_a_dick" || photos.length === 0 ? "approved" : "pending",
      anonymised: !viewer,
      votes: { not: 0, bit: 0, definitely: 0, absolute: 0 },
      reactions: { fair_call: 0, classic: 0, dick_move: 0, redemption: 0 },
      commentCount: 0,
      advice: undefined,
    };
    this.store.incidents.unshift(inc);
    const notice = await this.createNotice(
      { incidentId: id, template: input.kind === "not_a_dick" ? "friendly-reminder" : "official-warning", linkMode: "site", lines: buildNoticeLines(inc) },
      viewer,
    );
    if (viewer) this.refreshBadges(viewer.id);
    return { ok: true, data: { id, slug: inc.slug, shortCode, noticeId: notice.id, moderationStatus: inc.moderationStatus } };
  }

  // ---- community ---------------------------------------------------------
  async castVote(incidentId: string, verdict: Verdict, viewer: ViewerOrNull): Promise<ActionResult<{ votes: VoteTally; viewerVote: Verdict }>> {
    if (!viewer) return { ok: false, message: "Sign in to cast a verdict." };
    const inc = this.store.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, message: "That nomination has gone." };
    if (inc.submitterId === viewer.id) return { ok: false, message: "You can't vote on your own nomination. Nice try." };
    const key = `${incidentId}:${viewer.id}`;
    const prev = this.store.votes.get(key);
    if (prev === verdict) return { ok: true, data: { votes: inc.votes, viewerVote: verdict } };
    inc.votes = applyVote(inc.votes, verdict, prev);
    this.store.votes.set(key, verdict);
    const summary = summariseVotes(inc.votes);
    if (summary.total === MIN_VOTES_FOR_VERDICT && !prev) {
      this.notify(inc.submitterId, { kind: "verdict_reached", title: "Community verdict reached", body: `${inc.dickMove} — ${summary.shareLine.replace("Community verdict: ", "")}`, href: `/moves/${inc.slug}` });
    }
    return { ok: true, data: { votes: inc.votes, viewerVote: verdict } };
  }

  async toggleReaction(incidentId: string, kind: ReactionKind, viewer: ViewerOrNull): Promise<ActionResult<{ reactions: ReactionTally; viewerReactions: ReactionKind[] }>> {
    if (!viewer) return { ok: false, message: "Sign in to react." };
    const inc = this.store.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, message: "That nomination has gone." };
    const key = `${incidentId}:${viewer.id}`;
    const set = this.store.reactions.get(key) ?? new Set<ReactionKind>();
    if (set.has(kind)) {
      set.delete(kind);
      inc.reactions[kind] = Math.max(0, inc.reactions[kind] - 1);
    } else {
      set.add(kind);
      inc.reactions[kind] += 1;
    }
    this.store.reactions.set(key, set);
    return { ok: true, data: { reactions: inc.reactions, viewerReactions: Array.from(set) } };
  }

  async addComment(incidentId: string, body: string, viewer: ViewerOrNull): Promise<ActionResult<IncidentDetail["comments"][number]>> {
    if (!viewer) return { ok: false, message: "Sign in to comment." };
    const inc = this.store.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, message: "That nomination has gone." };
    const trimmed = body.trim();
    if (trimmed.length < 2) return { ok: false, message: "Say something. Anything. Well — almost anything." };
    if (trimmed.length > 600) return { ok: false, message: "Keep it under 600 characters. Brevity is the soul of taking the piss." };
    const scan = scanText(trimmed);
    if (scan.blocked) return { ok: false, message: "That crosses the line. Take the piss, don't take it too far." };
    const hasIdentifying = scan.findings.some((f) => ["phone", "email", "personal_profile_url", "social_handle", "named_person", "street_address", "rego"].includes(f.kind));
    const c: Comment = {
      id: randomId("c"),
      incidentId,
      authorId: viewer.id,
      body: scan.cleaned,
      createdAt: new Date().toISOString(),
      status: hasIdentifying ? "hidden" : "visible",
    };
    this.store.comments.push(c);
    if (hasIdentifying) {
      this.store.reports.push({ id: randomId("rep"), targetType: "comment", targetId: c.id, reason: "identifies_person", details: "Auto-held: comment contained identifying details.", status: "open", createdAt: c.createdAt });
      return { ok: false, message: "That comment looked like it identified someone, so it's been held for a moderator. Describe the behaviour, not the person." };
    }
    inc.commentCount += 1;
    if (inc.submitterId && inc.submitterId !== viewer.id) {
      this.notify(inc.submitterId, { kind: "comment", title: "New comment", body: `${viewer.handle}: "${c.body.slice(0, 80)}"`, href: `/moves/${inc.slug}#comments` });
    }
    this.refreshBadges(viewer.id);
    return { ok: true, data: { ...c, author: { handle: viewer.handle, displayName: viewer.displayName, avatarSeed: viewer.handle } } };
  }

  async reportContent(input: ReportInput, viewer: ViewerOrNull): Promise<ActionResult> {
    const exists = input.targetType === "incident" ? this.store.incidents.some((i) => i.id === input.targetId) : this.store.comments.some((c) => c.id === input.targetId);
    if (!exists) return { ok: false, message: "We couldn't find that content." };
    this.store.reports.push({
      id: randomId("rep"),
      targetType: input.targetType,
      targetId: input.targetId,
      reason: input.reason,
      details: input.details?.slice(0, 1000),
      reporterId: viewer?.id,
      status: "open",
      createdAt: new Date().toISOString(),
    });
    return { ok: true, message: "Thanks. A moderator will take a look. If it identifies someone, it comes down fast." };
  }

  async submitAppeal(input: AppealInput): Promise<ActionResult<{ reference: string }>> {
    const inc = this.store.incidents.find((i) => i.id === input.incidentId);
    if (!inc) return { ok: false, message: "We couldn't find that nomination." };
    if (input.message.trim().length < 10) return { ok: false, message: "Tell us a little more so we can act on it." };
    const id = randomId("app");
    this.store.appeals.push({
      id,
      incidentId: input.incidentId,
      requestedAction: input.requestedAction,
      message: input.message.slice(0, 2000),
      contact: input.contact?.slice(0, 200),
      status: "open",
      createdAt: new Date().toISOString(),
    });
    return { ok: true, data: { reference: id.slice(-8).toUpperCase() }, message: "Received. A human will review it, usually within a day." };
  }

  async markRedeemed(incidentId: string, note: string, viewer: ViewerOrNull): Promise<ActionResult> {
    if (!viewer) return { ok: false, message: "Sign in first." };
    const inc = this.store.incidents.find((i) => i.id === incidentId);
    if (!inc) return { ok: false, message: "That nomination has gone." };
    const allowed = inc.submitterId === viewer.id || viewer.role !== "member";
    if (!allowed) return { ok: false, message: "Only the submitter or a moderator can mark this redeemed." };
    inc.status = "redeemed";
    inc.redemption = {
      id: randomId("red"),
      incidentId,
      note: scanText(note).cleaned.slice(0, 300) || "Sorted. Humanity survives another day.",
      confirmedBy: inc.submitterId === viewer.id ? "submitter" : "moderator",
      createdAt: new Date().toISOString(),
    };
    inc.reactions.redemption += 1;
    if (inc.submitterId) this.refreshBadges(inc.submitterId);
    return { ok: true, message: "REDEEMED. Humanity survives another day." };
  }

  // ---- notices -----------------------------------------------------------
  async getNotice(id: string): Promise<PrintableNotice | null> {
    return this.store.notices.find((n) => n.id === id) ?? null;
  }

  async createNotice(input: CreateNoticeInput, viewer: ViewerOrNull): Promise<PrintableNotice> {
    const notice: PrintableNotice = {
      id: randomId("not"),
      incidentId: input.incidentId,
      template: input.template,
      linkMode: input.linkMode,
      lines: {
        headline: scanText(input.lines.headline).cleaned.slice(0, 60),
        dickMove: scanText(input.lines.dickMove).cleaned.slice(0, 90),
        why: scanText(input.lines.why).cleaned.slice(0, 220),
        location: scanText(input.lines.location).cleaned.slice(0, 80),
        advice: scanText(input.lines.advice).cleaned.slice(0, 140),
      },
      createdAt: new Date().toISOString(),
      createdBy: viewer?.id,
    };
    this.store.notices.push(notice);
    return notice;
  }

  async updateNotice(id: string, patch: Partial<CreateNoticeInput>, viewer: ViewerOrNull): Promise<PrintableNotice | null> {
    const n = this.store.notices.find((x) => x.id === id);
    if (!n) return null;
    if (n.createdBy && viewer && n.createdBy !== viewer.id && viewer.role === "member") return n;
    if (patch.template) n.template = patch.template;
    if (patch.linkMode) n.linkMode = patch.linkMode;
    if (patch.lines) {
      n.lines = {
        headline: scanText(patch.lines.headline ?? n.lines.headline).cleaned.slice(0, 60),
        dickMove: scanText(patch.lines.dickMove ?? n.lines.dickMove).cleaned.slice(0, 90),
        why: scanText(patch.lines.why ?? n.lines.why).cleaned.slice(0, 220),
        location: scanText(patch.lines.location ?? n.lines.location).cleaned.slice(0, 80),
        advice: scanText(patch.lines.advice ?? n.lines.advice).cleaned.slice(0, 140),
      };
    }
    return n;
  }

  // ---- map ---------------------------------------------------------------
  async getMapClusters(): Promise<MapCluster[]> {
    const weekAgo = Date.now() - 7 * 86_400_000;
    const groups = new Map<string, Incident[]>();
    for (const i of this.publicIncidents()) {
      const key = i.location.region;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(i);
    }
    const clusters: MapCluster[] = [];
    for (const [region, items] of groups) {
      const withCoords = items.filter((i) => i.location.approxLat != null);
      const lat = withCoords.reduce((a, i) => a + (i.location.approxLat ?? 0), 0) / Math.max(1, withCoords.length);
      const lng = withCoords.reduce((a, i) => a + (i.location.approxLng ?? 0), 0) / Math.max(1, withCoords.length);
      const cats = new Map<string, number>();
      for (const i of items) cats.set(i.categoryId, (cats.get(i.categoryId) ?? 0) + 1);
      const top = Array.from(cats.entries()).sort((a, b) => b[1] - a[1])[0]![0] as MapCluster["topCategoryId"];
      clusters.push({
        region,
        state: items[0]!.location.state,
        approxLat: lat,
        approxLng: lng,
        count: items.filter((i) => i.kind === "dick_move").length,
        countThisWeek: items.filter((i) => i.kind === "dick_move" && new Date(i.createdAt).getTime() > weekAgo).length,
        redeemed: items.filter((i) => i.status === "redeemed").length,
        notADick: items.filter((i) => i.kind === "not_a_dick").length,
        topCategoryId: top,
      });
    }
    return clusters.sort((a, b) => b.count - a.count);
  }

  // ---- members -----------------------------------------------------------
  private profilePage(p: Profile): ProfilePage {
    const recent = this.publicIncidents()
      .filter((i) => i.submitterId === p.id && !i.anonymised)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, 6)
      .map((i) => this.summarise(i));
    return { profile: clone(p), stats: this.stats(p.id), badges: clone(this.store.userBadges[p.id] ?? []), recent };
  }

  async getProfileByHandle(handle: string): Promise<ProfilePage | null> {
    const p = this.store.profiles.find((x) => x.handle.toLowerCase() === handle.toLowerCase());
    return p ? this.profilePage(p) : null;
  }

  async getProfileById(id: string): Promise<ProfilePage | null> {
    const p = this.profile(id);
    return p ? this.profilePage(p) : null;
  }

  async listNotifications(viewer: Viewer): Promise<Notification[]> {
    return this.store.notifications.filter((n) => n.userId === viewer.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  async markNotificationsRead(viewer: Viewer): Promise<void> {
    const now = new Date().toISOString();
    for (const n of this.store.notifications) if (n.userId === viewer.id && !n.readAt) n.readAt = now;
  }

  // ---- admin -------------------------------------------------------------
  async getAdminStats(): Promise<AdminStats> {
    const now = Date.now();
    const dayAgo = now - 86_400_000;
    const weekAgo = now - 7 * 86_400_000;
    const all = this.store.incidents;
    const pub = this.publicIncidents();
    const areas = new Map<string, number>();
    const cats = new Map<string, number>();
    for (const i of pub) {
      if (i.kind !== "dick_move") continue;
      areas.set(i.location.region, (areas.get(i.location.region) ?? 0) + 1);
      cats.set(i.categoryId, (cats.get(i.categoryId) ?? 0) + 1);
    }
    return {
      dickMovesToday: all.filter((i) => i.kind === "dick_move" && new Date(i.createdAt).getTime() > dayAgo).length,
      dickMovesThisWeek: all.filter((i) => i.kind === "dick_move" && new Date(i.createdAt).getTime() > weekAgo).length,
      redemptions: all.filter((i) => i.status === "redeemed").length,
      pendingModeration: all.filter((i) => i.moderationStatus === "pending").length,
      reportedContent: this.store.reports.filter((r) => r.status === "open" || r.status === "reviewing").length,
      openAppeals: this.store.appeals.filter((a) => a.status === "open" || a.status === "in_review").length,
      mostActiveAreas: Array.from(areas.entries()).map(([region, count]) => ({ region, count })).sort((a, b) => b.count - a.count).slice(0, 6),
      mostCommonCategories: Array.from(cats.entries()).map(([categoryId, count]) => ({ categoryId: categoryId as AdminStats["mostCommonCategories"][number]["categoryId"], count })).sort((a, b) => b.count - a.count),
      membersTotal: this.store.profiles.length,
      notADickThisWeek: all.filter((i) => i.kind === "not_a_dick" && new Date(i.createdAt).getTime() > weekAgo).length,
    };
  }

  async listModerationQueue(): Promise<IncidentSummary[]> {
    return this.store.incidents.filter((i) => i.moderationStatus === "pending").sort((a, b) => a.createdAt.localeCompare(b.createdAt)).map((i) => this.summarise(i));
  }

  async listReports(status?: Report["status"]): Promise<ReportWithTarget[]> {
    return this.store.reports
      .filter((r) => !status || r.status === status)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .map((r) => {
        const out: ReportWithTarget = { ...clone(r) };
        if (r.targetType === "incident") {
          const inc = this.store.incidents.find((i) => i.id === r.targetId);
          if (inc) out.incident = this.summarise(inc);
        } else {
          const c = this.store.comments.find((x) => x.id === r.targetId);
          if (c) {
            const a = this.profile(c.authorId);
            out.comment = { ...clone(c), author: { handle: a?.handle ?? "member", displayName: a?.displayName ?? "Member" } };
          }
        }
        return out;
      });
  }

  async listAppeals(status?: Appeal["status"]): Promise<AppealWithIncident[]> {
    return this.store.appeals
      .filter((a) => !status || a.status === status)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .flatMap((a) => {
        const inc = this.store.incidents.find((i) => i.id === a.incidentId);
        return inc ? [{ ...clone(a), incident: this.summarise(inc) }] : [];
      });
  }

  async listAllComments(opts: { status?: Comment["status"]; limit?: number } = {}) {
    return this.store.comments
      .filter((c) => !opts.status || c.status === opts.status)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, opts.limit ?? 50)
      .map((c) => {
        const a = this.profile(c.authorId);
        const inc = this.store.incidents.find((i) => i.id === c.incidentId);
        return { ...clone(c), author: { handle: a?.handle ?? "member", displayName: a?.displayName ?? "Member" }, incident: { slug: inc?.slug ?? "", title: inc?.title ?? "" } };
      });
  }

  async listUsers(query?: string): Promise<UserRow[]> {
    const q = query?.toLowerCase();
    return this.store.profiles
      .filter((p) => !q || p.handle.toLowerCase().includes(q) || p.displayName.toLowerCase().includes(q))
      .map((p) => ({ ...clone(p), stats: this.stats(p.id), badges: clone(this.store.userBadges[p.id] ?? []) }));
  }

  async listAuditLog(limit = 50): Promise<AuditEntry[]> {
    return this.store.audit.slice(0, limit).map((a) => {
      const p = this.profile(a.actorId);
      return { ...clone(a), actor: { handle: p?.handle ?? "system", displayName: p?.displayName ?? "System" } };
    });
  }

  async listAllIncidentsAdmin(opts: { status?: string; query?: string; limit?: number } = {}): Promise<IncidentSummary[]> {
    const q = opts.query?.toLowerCase();
    return this.store.incidents
      .filter((i) => !opts.status || i.moderationStatus === opts.status || i.status === opts.status)
      .filter((i) => !q || [i.title, i.shortCode, i.location.suburb, i.dickMove].join(" ").toLowerCase().includes(q))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .slice(0, opts.limit ?? 100)
      .map((i) => this.summarise(i));
  }

  async moderate(cmd: ModerationCommand, actor: Viewer): Promise<ActionResult> {
    if (actor.role === "member") return { ok: false, message: "Moderators only." };
    const now = new Date().toISOString();
    const inc = cmd.targetType === "incident" || cmd.targetType === "photo" ? this.store.incidents.find((i) => i.id === cmd.targetId) : undefined;

    switch (cmd.action) {
      case "approve": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.moderationStatus = "approved";
        this.notify(inc.submitterId, { kind: "moderation", title: "Nomination approved", body: `${inc.dickMove} is live.`, href: `/moves/${inc.slug}` });
        if (inc.submitterId) this.refreshBadges(inc.submitterId);
        break;
      }
      case "reject": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.moderationStatus = "rejected";
        this.notify(inc.submitterId, { kind: "moderation", title: "Nomination not published", body: cmd.note ?? "It didn't meet the community standard.", href: "/standards" });
        break;
      }
      case "remove": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.moderationStatus = "removed";
        break;
      }
      case "restore": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.moderationStatus = "approved";
        break;
      }
      case "anonymise": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.anonymised = true;
        inc.submitterId = null;
        inc.location = { ...inc.location, place: undefined, precision: "suburb" };
        if (cmd.payload?.description) inc.description = scanText(cmd.payload.description).cleaned;
        break;
      }
      case "redact_photo": {
        if (!inc) return { ok: false, message: "Incident not found." };
        const photoId = cmd.payload?.photoId;
        inc.photos = inc.photos.filter((p) => p.id !== photoId);
        break;
      }
      case "mark_redeemed": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.status = "redeemed";
        inc.redemption = { id: randomId("red"), incidentId: inc.id, note: cmd.payload?.note || "Sorted. Humanity survives another day.", confirmedBy: "moderator", createdAt: now };
        this.notify(inc.submitterId, { kind: "redeemed", title: "REDEEMED", body: inc.redemption.note, href: `/moves/${inc.slug}` });
        if (inc.submitterId) this.refreshBadges(inc.submitterId);
        break;
      }
      case "mark_overruled": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.status = "overruled";
        this.notify(inc.submitterId, { kind: "moderation", title: "Overruled", body: "The community reckons this one wasn't a dick move. Owning it earns respect.", href: `/moves/${inc.slug}` });
        break;
      }
      case "feature_week": {
        if (!inc) return { ok: false, message: "Incident not found." };
        const week = cmd.payload?.week || weekOf(new Date());
        for (const other of this.store.incidents) if (other.featuredWeek === week) other.featuredWeek = undefined;
        inc.featuredWeek = week;
        this.notify(inc.submitterId, { kind: "featured", title: "Dick Move of the Week", body: `${inc.dickMove} is this week's Dick Move of the Week.`, href: "/week" });
        break;
      }
      case "unfeature": {
        if (!inc) return { ok: false, message: "Incident not found." };
        inc.featuredWeek = undefined;
        break;
      }
      case "hide_comment":
      case "restore_comment": {
        const c = this.store.comments.find((x) => x.id === cmd.targetId);
        if (!c) return { ok: false, message: "Comment not found." };
        const parent = this.store.incidents.find((i) => i.id === c.incidentId);
        const wasVisible = c.status === "visible";
        c.status = cmd.action === "hide_comment" ? "hidden" : "visible";
        if (parent) parent.commentCount = Math.max(0, parent.commentCount + (cmd.action === "hide_comment" ? (wasVisible ? -1 : 0) : wasVisible ? 0 : 1));
        break;
      }
      case "resolve_report":
      case "dismiss_report": {
        const r = this.store.reports.find((x) => x.id === cmd.targetId);
        if (!r) return { ok: false, message: "Report not found." };
        r.status = cmd.action === "resolve_report" ? "resolved" : "dismissed";
        r.resolvedAt = now;
        r.resolvedBy = actor.id;
        break;
      }
      case "action_appeal":
      case "decline_appeal": {
        const a = this.store.appeals.find((x) => x.id === cmd.targetId);
        if (!a) return { ok: false, message: "Appeal not found." };
        a.status = cmd.action === "action_appeal" ? "actioned" : "declined";
        a.updatedAt = now;
        if (cmd.payload?.publicReply) a.publicReply = scanText(cmd.payload.publicReply).cleaned.slice(0, 600);
        break;
      }
      case "publish_reply": {
        const a = this.store.appeals.find((x) => x.id === cmd.targetId);
        if (!a) return { ok: false, message: "Appeal not found." };
        a.publicReply = scanText(cmd.payload?.publicReply ?? "").cleaned.slice(0, 600);
        a.status = "actioned";
        a.updatedAt = now;
        break;
      }
      case "change_role": {
        if (actor.role !== "admin") return { ok: false, message: "Admins only." };
        const p = this.profile(cmd.targetId);
        if (!p) return { ok: false, message: "Member not found." };
        const role = cmd.payload?.role;
        if (role !== "member" && role !== "moderator" && role !== "admin") return { ok: false, message: "Unknown role." };
        p.role = role;
        break;
      }
      case "edit_category":
      case "edit_template":
        // Copy edits are configuration in Supabase mode; the demo store keeps the shipped copy.
        break;
      default:
        return { ok: false, message: `Unknown action ${cmd.action satisfies never}` };
    }
    this.log(actor, cmd);
    return { ok: true };
  }
}

/** Very rough region guess for new nominations so map clustering has something to hold. */
export function guessRegion(suburb: string, state: string): string {
  const s = suburb.toLowerCase();
  const table: Array<[RegExp, string]> = [
    [/batemans|batehaven|surf beach|moruya|broulee|narooma|ulladulla|mollymook|milton|tuross|malua|catalina|long beach|maloneys|lilli pilli|denhams|mossy|tomakin|rosedale|clyde/, "South Coast NSW"],
    [/nowra|bomaderry|huskisson|vincentia|berry|kangaroo valley|sussex inlet|culburra|shoalhaven/, "Shoalhaven"],
    [/merimbula|bega|eden|tathra|pambula|bermagui/, "Sapphire Coast"],
    [/canberra|civic|fyshwick|woden|gungahlin|tuggeranong|belconnen|barton|kingston|braddon|dickson|queanbeyan|jerrabomberra|googong|parkes|yarralumla|manuka|phillip|weston|kambah|casey|harrison|bruce/, "Canberra"],
    [/goulburn|marulan|yass|crookwell|bungendore/, "Southern Tablelands"],
    [/wollongong|shellharbour|kiama|dapto|thirroul|corrimal|fairy meadow|figtree/, "Illawarra"],
    [/newcastle|maitland|lake macquarie|charlestown|merewether|hamilton|kotara|cessnock/, "Hunter"],
    [/gosford|bateau|erina|terrigal|wyong|tuggerah|woy woy|the entrance/, "Central Coast"],
    [/sydney|parramatta|bondi|manly|penrith|liverpool|chatswood|newtown|surry|cbd|blacktown|hornsby|cronulla|marrickville/, "Greater Sydney"],
    [/melbourne|fitzroy|richmond|st kilda|brunswick|footscray|carlton|dandenong|geelong|prahran|collingwood/, "Melbourne"],
    [/brisbane|west end|south bank|fortitude|toowong|chermside|logan|ipswich|gold coast|surfers/, "Brisbane"],
    [/perth|fremantle|joondalup|scarborough|subiaco|rockingham|mandurah/, "Perth"],
    [/adelaide|glenelg|norwood|prospect|unley|port adelaide/, "Adelaide"],
    [/hobart|launceston|sandy bay|kingston tas|glenorchy/, "Hobart"],
    [/darwin|palmerston|casuarina|nightcliff/, "Darwin"],
  ];
  for (const [re, region] of table) if (re.test(s)) return region;
  const byState: Record<string, string> = { NSW: "Regional NSW", VIC: "Regional VIC", QLD: "Regional QLD", WA: "Regional WA", SA: "Regional SA", TAS: "Tasmania", ACT: "Canberra", NT: "Northern Territory" };
  return byState[state] ?? "Australia";
}
