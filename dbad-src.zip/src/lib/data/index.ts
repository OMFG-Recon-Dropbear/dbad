import "server-only";
import type { Repository } from "./repository";
import { DemoRepository } from "./demo/demo-repository";

/**
 * Picks the data source for this request.
 *
 * Supabase when configured (and not forced into demo mode); otherwise the in-memory
 * demo store. Server components, route handlers and server actions call this — never
 * a concrete implementation.
 */
export function isSupabaseConfigured(): boolean {
  if (process.env.DBAD_DATA_MODE === "demo") return false;
  return Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
}

export function dataMode(): "supabase" | "demo" {
  return isSupabaseConfigured() ? "supabase" : "demo";
}

export async function getRepository(): Promise<Repository> {
  if (isSupabaseConfigured()) {
    const { createSupabaseServerClient } = await import("@/lib/supabase/server");
    const { SupabaseRepository } = await import("./supabase/supabase-repository");
    const client = await createSupabaseServerClient();
    return new SupabaseRepository(client);
  }
  return new DemoRepository();
}
