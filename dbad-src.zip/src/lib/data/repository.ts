import type {
  ActionResult,
  AdminStats,
  Appeal,
  AppealAction,
  Category,
  Comment,
  FeedFilters,
  FeedPage,
  IncidentDetail,
  IncidentSummary,
  MapCluster,
  ModerationAction,
  ModerationActionKind,
  NominationInput,
  NoticeLines,
  NoticeLinkMode,
  NoticeTemplateId,
  Notification,
  PrintableNotice,
  Profile,
  ProfileStats,
  ReactionKind,
  ReactionTally,
  Report,
  ReportReason,
  Role,
  UserBadge,
  Verdict,
  VoteTally,
} from "@/lib/domain/types";

/** The signed-in member as seen by the data layer. `null` when anonymous. */
export interface Viewer {
  id: string;
  handle: string;
  displayName: string;
  role: Role;
}

export type ViewerOrNull = Viewer | null;

export interface ProfilePage {
  profile: Profile;
  stats: ProfileStats;
  badges: UserBadge[];
  recent: IncidentSummary[];
}

export interface FeaturedSet {
  week: IncidentSummary | null;
  month: IncidentSummary | null;
  greatest: IncidentSummary[];
  mostRedeemed: IncidentSummary[];
  latestRedemptions: IncidentSummary[];
  notADick: IncidentSummary[];
}

export interface ModerationCommand {
  action: ModerationActionKind;
  targetType: ModerationAction["targetType"];
  targetId: string;
  note?: string;
  /** Action-specific payload: public reply text, new role, redemption note, week date. */
  payload?: Record<string, string>;
}

export interface ReportWithTarget extends Report {
  incident?: IncidentSummary;
  comment?: Comment & { author: Pick<Profile, "handle" | "displayName"> };
}

export interface AppealWithIncident extends Appeal {
  incident: IncidentSummary;
}

export interface AuditEntry extends ModerationAction {
  actor: Pick<Profile, "handle" | "displayName">;
}

export interface UserRow extends Profile {
  stats: ProfileStats;
  badges: UserBadge[];
}

export interface CreateNoticeInput {
  incidentId?: string;
  template: NoticeTemplateId;
  linkMode: NoticeLinkMode;
  lines: NoticeLines;
}

export interface ReportInput {
  targetType: Report["targetType"];
  targetId: string;
  reason: ReportReason;
  details?: string;
}

export interface AppealInput {
  incidentId: string;
  requestedAction: AppealAction;
  message: string;
  contact?: string;
}

/**
 * Every read and write the application performs. Implemented by the in-memory demo
 * store and by the Supabase store. Pages, actions and the preview harness only ever
 * talk to this interface.
 */
export interface Repository {
  // ---- categories --------------------------------------------------------
  listCategories(): Promise<Category[]>;

  // ---- incidents ---------------------------------------------------------
  listIncidents(filters: FeedFilters, viewer?: ViewerOrNull): Promise<FeedPage>;
  getIncidentBySlug(slug: string, viewer?: ViewerOrNull): Promise<IncidentDetail | null>;
  getIncidentByCode(code: string): Promise<IncidentSummary | null>;
  getIncidentById(id: string, viewer?: ViewerOrNull): Promise<IncidentDetail | null>;
  getFeatured(): Promise<FeaturedSet>;
  createIncident(
    input: NominationInput,
    viewer: ViewerOrNull,
  ): Promise<ActionResult<{ id: string; slug: string; shortCode: string; noticeId: string; moderationStatus: string }>>;
  listRelated(incidentId: string, limit?: number): Promise<IncidentSummary[]>;

  // ---- community ---------------------------------------------------------
  castVote(incidentId: string, verdict: Verdict, viewer: ViewerOrNull): Promise<ActionResult<{ votes: VoteTally; viewerVote: Verdict }>>;
  toggleReaction(incidentId: string, kind: ReactionKind, viewer: ViewerOrNull): Promise<ActionResult<{ reactions: ReactionTally; viewerReactions: ReactionKind[] }>>;
  addComment(incidentId: string, body: string, viewer: ViewerOrNull): Promise<ActionResult<IncidentDetail["comments"][number]>>;
  reportContent(input: ReportInput, viewer: ViewerOrNull): Promise<ActionResult>;
  submitAppeal(input: AppealInput): Promise<ActionResult<{ reference: string }>>;
  markRedeemed(incidentId: string, note: string, viewer: ViewerOrNull): Promise<ActionResult>;

  // ---- notices -----------------------------------------------------------
  getNotice(id: string): Promise<PrintableNotice | null>;
  createNotice(input: CreateNoticeInput, viewer: ViewerOrNull): Promise<PrintableNotice>;
  updateNotice(id: string, patch: Partial<CreateNoticeInput>, viewer: ViewerOrNull): Promise<PrintableNotice | null>;

  // ---- map ---------------------------------------------------------------
  getMapClusters(): Promise<MapCluster[]>;

  // ---- members -----------------------------------------------------------
  getProfileByHandle(handle: string): Promise<ProfilePage | null>;
  getProfileById(id: string): Promise<ProfilePage | null>;
  listNotifications(viewer: Viewer): Promise<Notification[]>;
  markNotificationsRead(viewer: Viewer): Promise<void>;

  // ---- admin / moderation ------------------------------------------------
  getAdminStats(): Promise<AdminStats>;
  listModerationQueue(): Promise<IncidentSummary[]>;
  listReports(status?: Report["status"]): Promise<ReportWithTarget[]>;
  listAppeals(status?: Appeal["status"]): Promise<AppealWithIncident[]>;
  listAllComments(opts?: { status?: Comment["status"]; limit?: number }): Promise<Array<Comment & { author: Pick<Profile, "handle" | "displayName">; incident: Pick<IncidentSummary, "slug" | "title"> }>>;
  listUsers(query?: string): Promise<UserRow[]>;
  listAuditLog(limit?: number): Promise<AuditEntry[]>;
  listAllIncidentsAdmin(opts?: { status?: string; query?: string; limit?: number }): Promise<IncidentSummary[]>;
  moderate(command: ModerationCommand, actor: Viewer): Promise<ActionResult>;
}

export function requireRole(viewer: ViewerOrNull, roles: Role[]): viewer is Viewer {
  return !!viewer && roles.includes(viewer.role);
}

export function isModerator(viewer: ViewerOrNull): viewer is Viewer {
  return requireRole(viewer, ["moderator", "admin"]);
}
