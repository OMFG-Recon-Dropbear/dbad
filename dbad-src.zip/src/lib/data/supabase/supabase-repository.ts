import type { SupabaseClient } from "@supabase/supabase-js";
import type {
  ActionResult,
  AdminStats,
  Appeal,
  AustralianState,
  Category,
  CategoryId,
  Comment,
  FeedFilters,
  FeedPage,
  Incident,
  IncidentDetail,
  IncidentSummary,
  Location,
  MapCluster,
  ModerationAction,
  NominationInput,
  Notification,
  Photo,
  PrintableNotice,
  Profile,
  ProfileStats,
  ReactionKind,
  ReactionTally,
  Report,
  UserBadge,
  Verdict,
  VoteTally,
} from "@/lib/domain/types";
import { CATEGORY_MAP, getCategory } from "@/lib/domain/categories";
import { scanText } from "@/lib/domain/pii";
import { validateNomination } from "@/lib/domain/validation";
import { randomId, weekOf } from "@/lib/domain/utils";
import { MIN_VOTES_FOR_VERDICT } from "@/lib/domain/verdict";
import type { Database } from "@/lib/supabase/database.types";
import type {
  AppealInput,
  AppealWithIncident,
  AuditEntry,
  CreateNoticeInput,
  FeaturedSet,
  ModerationCommand,
  ProfilePage,
  Repository,
  ReportInput,
  ReportWithTarget,
  UserRow,
  Viewer,
  ViewerOrNull,
} from "../repository";

/**
 * Supabase implementation of the Repository.
 *
 * Reads go through typed selects with embedded resources; every write goes
 * through an RPC in supabase/migrations/0003_functions.sql, which authorises the
 * caller, scrubs the text and writes the audit trail. The repository never
 * writes to incidents, votes, reactions or moderation_actions directly, so the
 * rules hold whether the call arrives from this class or from anywhere else.
 */

// ---------------------------------------------------------------------------
// Row shapes
// ---------------------------------------------------------------------------
type Tables = Database["public"]["Tables"];
type IncidentRow = Tables["incidents"]["Row"];
type LocationRow = Tables["locations"]["Row"];
type CategoryRow = Tables["categories"]["Row"];
type PhotoRow = Tables["incident_photos"]["Row"];
type ProfileRow = Tables["profiles"]["Row"];
type RedemptionRow = Tables["redemptions"]["Row"];
type SocialRow = Tables["social_sources"]["Row"];
type CommentRow = Tables["comments"]["Row"];
type ReportRow = Tables["reports"]["Row"];
type AppealRow = Tables["appeals"]["Row"];
type NotificationRow = Tables["notifications"]["Row"];
type NoticeRow = Tables["printable_notices"]["Row"];
type AuditRow = Tables["moderation_actions"]["Row"];
type MemberStatsRow = Database["public"]["Views"]["member_stats"]["Row"];

type Author = Pick<ProfileRow, "id" | "handle" | "display_name" | "avatar_seed">;

interface IncidentJoined extends IncidentRow {
  location: LocationRow | LocationRow[] | null;
  category: CategoryRow | CategoryRow[] | null;
  photos: PhotoRow[] | null;
  social: SocialRow | SocialRow[] | null;
  redemption: RedemptionRow | RedemptionRow[] | null;
  submitter: Author | Author[] | null;
}

type CommentJoined = CommentRow & { author: Author | Author[] | null };

/**
 * supabase-js derives result types from the select string at the type level.
 * Our selects use aliases and nested embeds that the inference cannot always
 * narrow (and the shape of a to-one embed depends on PostgREST's relationship
 * detection), so results are asserted to the row shapes declared above. These
 * two helpers are the only casts in the file.
 */
function rows<T>(data: unknown): T[] {
  return (data ?? []) as T[];
}
function maybeRow<T>(data: unknown): T | null {
  return (data ?? null) as T | null;
}

/** PostgREST returns a to-one embed as an object, but as an array if it cannot prove uniqueness. */
function one<T>(value: T | T[] | null | undefined): T | null {
  if (Array.isArray(value)) return value[0] ?? null;
  return value ?? null;
}

interface PostgrestFailure {
  message: string;
}

function unwrap(result: { data: unknown; error: PostgrestFailure | null }, what: string): unknown {
  if (result.error) throw new Error(`DBAD: ${what} — ${result.error.message}`);
  if (result.data === null || result.data === undefined) throw new Error(`DBAD: ${what} — no data returned`);
  return result.data;
}

// ---------------------------------------------------------------------------
// RPC payload shapes (all RPCs answer with an ActionResult-shaped object)
// ---------------------------------------------------------------------------
interface RpcResult {
  ok: boolean;
  message?: string;
  fieldErrors?: Record<string, string>;
  [key: string]: unknown;
}

function asResult(data: unknown): RpcResult {
  if (data && typeof data === "object" && !Array.isArray(data)) return data as RpcResult;
  return { ok: false, message: "That didn't work. Try again." };
}

// ---------------------------------------------------------------------------
// Select strings
// ---------------------------------------------------------------------------
/**
 * One literal select for every incident read, so supabase-js can infer the shape
 * and PostgREST returns the same payload everywhere. `state` and `region` are
 * denormalised onto incidents, so the feed filters without an inner join.
 */
const INCIDENT_SELECT =
  "id, seq, short_code, slug, kind, category_id, title, dick_move, description, affected, location_id, occurred_on, part_of_day, state, region, submitter_id, status, moderation_status, anonymised, featured_week, advice, redeemed_at, votes_not, votes_bit, votes_definitely, votes_absolute, react_fair_call, react_classic, react_dick_move, react_redemption, comment_count, votes_total, dickery_rank, created_at, updated_at, location:locations(id, suburb, state, place, approx_lat, approx_lng, precision, region), category:categories(id, label, short, blurb, caution, accent), photos:incident_photos(id, url, width, height, alt, redacted, redaction_count, sort_order), social:social_sources(platform, url, retrieved_via, note), redemption:redemptions(id, incident_id, note, confirmed_by, created_at), submitter:profiles(id, handle, display_name, avatar_seed)";

const COMMENT_SELECT =
  "id, incident_id, author_id, body, status, parent_id, created_at, author:profiles(id, handle, display_name, avatar_seed)";

const COMMENT_WITH_INCIDENT_SELECT =
  "id, incident_id, author_id, body, status, parent_id, created_at, author:profiles(id, handle, display_name, avatar_seed), incident:incidents(slug, title)";

type ModerationStatusValue = Database["public"]["Enums"]["moderation_status"];
type IncidentStatusValue = Database["public"]["Enums"]["incident_status"];

const MODERATION_STATUSES: ModerationStatusValue[] = ["pending", "approved", "rejected", "removed"];
const LIFECYCLE_STATUSES: IncidentStatusValue[] = ["open", "redeemed", "overruled"];

/** The admin filter box is one input over two lifecycles; work out which it means. */
function asModerationStatus(value: string): ModerationStatusValue | undefined {
  return MODERATION_STATUSES.find((s) => s === value);
}
function asIncidentStatus(value: string): IncidentStatusValue | undefined {
  return LIFECYCLE_STATUSES.find((s) => s === value);
}

/** PostgREST `or=` filters are comma separated, so a raw query string cannot go in verbatim. */
function safeFilterTerm(input: string): string {
  return input.replace(/[,()*%\\"']/g, " ").trim();
}

// ---------------------------------------------------------------------------
// Row -> domain mapping
// ---------------------------------------------------------------------------
function toCategory(row: CategoryRow | null, id: string): Category {
  if (!row) return getCategory(id as CategoryId);
  return {
    id: row.id as CategoryId,
    label: row.label,
    short: row.short,
    blurb: row.blurb,
    caution: row.caution ?? undefined,
    accent: row.accent,
  };
}

function toLocation(row: LocationRow | null): Location {
  if (!row) {
    // Every incident has a location (NOT NULL, ON DELETE RESTRICT); this only
    // happens if a caller selects an incident without the embed.
    return { id: "", suburb: "Australia", state: "NSW", precision: "suburb", region: "Australia" };
  }
  return {
    id: row.id,
    suburb: row.suburb,
    state: row.state,
    place: row.place ?? undefined,
    approxLat: row.approx_lat ?? undefined,
    approxLng: row.approx_lng ?? undefined,
    precision: row.precision,
    region: row.region,
  };
}

function toPhoto(row: PhotoRow): Photo {
  return {
    id: row.id,
    url: row.url,
    width: row.width,
    height: row.height,
    alt: row.alt,
    redacted: row.redacted,
    redactionCount: row.redaction_count,
  };
}

function toIncident(row: IncidentJoined): Incident {
  const redemption = one(row.redemption);
  const social = one(row.social);
  const photos = (row.photos ?? []).slice().sort((a, b) => a.sort_order - b.sort_order);
  return {
    id: row.id,
    shortCode: row.short_code ?? `DBAD-${String(row.seq).padStart(4, "0")}`,
    slug: row.slug,
    kind: row.kind,
    categoryId: row.category_id as CategoryId,
    title: row.title,
    dickMove: row.dick_move,
    description: row.description,
    affected: row.affected as Incident["affected"],
    location: toLocation(one(row.location)),
    occurredOn: row.occurred_on,
    partOfDay: row.part_of_day,
    createdAt: row.created_at,
    submitterId: row.submitter_id,
    photos: photos.map(toPhoto),
    socialSource: social
      ? { platform: social.platform, url: social.url, retrievedVia: social.retrieved_via, note: social.note ?? undefined }
      : undefined,
    status: row.status,
    moderationStatus: row.moderation_status,
    anonymised: row.anonymised,
    featuredWeek: row.featured_week ?? undefined,
    votes: {
      not: row.votes_not,
      bit: row.votes_bit,
      definitely: row.votes_definitely,
      absolute: row.votes_absolute,
    },
    reactions: {
      fair_call: row.react_fair_call,
      classic: row.react_classic,
      dick_move: row.react_dick_move,
      redemption: row.react_redemption,
    },
    commentCount: row.comment_count,
    redemption: redemption
      ? {
          id: redemption.id,
          incidentId: redemption.incident_id,
          note: redemption.note,
          confirmedBy: redemption.confirmed_by,
          createdAt: redemption.created_at,
        }
      : undefined,
    advice: row.advice ?? undefined,
  };
}

function toSummary(row: IncidentJoined): IncidentSummary {
  const submitter = one(row.submitter);
  return {
    ...toIncident(row),
    category: toCategory(one(row.category), row.category_id),
    // An anonymised nomination has no submitter left to show, by construction.
    submitter:
      submitter && !row.anonymised
        ? { handle: submitter.handle, displayName: submitter.display_name, avatarSeed: submitter.avatar_seed }
        : null,
  };
}

function toComment(row: CommentJoined): IncidentDetail["comments"][number] {
  const author = one(row.author);
  return {
    id: row.id,
    incidentId: row.incident_id,
    authorId: row.author_id,
    body: row.body,
    createdAt: row.created_at,
    status: row.status,
    parentId: row.parent_id ?? undefined,
    author: {
      handle: author?.handle ?? "member",
      displayName: author?.display_name ?? "Member",
      avatarSeed: author?.avatar_seed ?? "member",
    },
  };
}

function toProfile(row: ProfileRow): Profile {
  return {
    id: row.id,
    handle: row.handle,
    displayName: row.display_name,
    avatarSeed: row.avatar_seed,
    role: row.role,
    memberSince: row.member_since,
    bio: row.bio ?? undefined,
    homeArea: row.home_area ?? undefined,
  };
}

function toStats(row: MemberStatsRow | null): ProfileStats {
  return {
    spotted: row?.spotted ?? 0,
    fairCalls: row?.fair_calls ?? 0,
    redeemed: row?.redeemed ?? 0,
    overruled: row?.overruled ?? 0,
    notADick: row?.not_a_dick ?? 0,
    comments: row?.comments ?? 0,
  };
}

function toNotice(row: NoticeRow): PrintableNotice {
  return {
    id: row.id,
    incidentId: row.incident_id ?? undefined,
    template: row.template,
    linkMode: row.link_mode,
    lines: {
      headline: row.headline,
      dickMove: row.dick_move,
      why: row.why,
      location: row.location,
      advice: row.advice,
    },
    createdAt: row.created_at,
    createdBy: row.created_by ?? undefined,
  };
}

function toReport(row: ReportRow): Report {
  return {
    id: row.id,
    targetType: row.target_type,
    targetId: row.target_id,
    reason: row.reason,
    details: row.details ?? undefined,
    reporterId: row.reporter_id ?? undefined,
    status: row.status,
    createdAt: row.created_at,
    resolvedAt: row.resolved_at ?? undefined,
    resolvedBy: row.resolved_by ?? undefined,
  };
}

function toAppeal(row: AppealRow): Appeal {
  return {
    id: row.id,
    incidentId: row.incident_id,
    requestedAction: row.requested_action,
    message: row.message,
    contact: row.contact ?? undefined,
    status: row.status,
    publicReply: row.public_reply ?? undefined,
    createdAt: row.created_at,
    updatedAt: row.updated_at ?? undefined,
  };
}

function toNotification(row: NotificationRow): Notification {
  return {
    id: row.id,
    userId: row.user_id,
    kind: row.kind,
    title: row.title,
    body: row.body,
    href: row.href ?? undefined,
    createdAt: row.created_at,
    readAt: row.read_at ?? undefined,
  };
}

function toAuditAction(row: AuditRow): ModerationAction {
  return {
    id: row.id,
    actorId: row.actor_id,
    action: row.action,
    targetType: row.target_type,
    targetId: row.target_id,
    note: row.note ?? undefined,
    createdAt: row.created_at,
  };
}

// ---------------------------------------------------------------------------
// Photo uploads
// ---------------------------------------------------------------------------
const PHOTO_BUCKET = "incident-photos";
const DATA_URL = /^data:(image\/[a-z0-9.+-]+);base64,(.+)$/i;
const EXTENSION_FOR: Record<string, string> = {
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "image/png": "png",
  "image/webp": "webp",
  "image/avif": "avif",
};

interface DecodedImage {
  bytes: Uint8Array;
  contentType: string;
  extension: string;
}

function decodeDataUrl(src: string): DecodedImage | null {
  const match = DATA_URL.exec(src);
  if (!match) return null;
  const contentType = (match[1] ?? "image/jpeg").toLowerCase();
  const base64 = match[2] ?? "";
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return { bytes, contentType, extension: EXTENSION_FOR[contentType] ?? "jpg" };
}

/**
 * Declared as a type alias, not an interface: only type aliases get the implicit
 * index signature that lets them be passed as a `Json` RPC argument.
 */
type NominationPhotoPayload = {
  url: string;
  storagePath?: string;
  width: number;
  height: number;
  alt: string;
  redactionCount: number;
};

export class SupabaseRepository implements Repository {
  constructor(private readonly db: SupabaseClient<Database>) {}

  // ---- categories --------------------------------------------------------
  async listCategories(): Promise<Category[]> {
    const res = await this.db
      .from("categories")
      .select("id, label, short, blurb, caution, accent")
      .order("sort_order", { ascending: true });
    return rows<CategoryRow>(unwrap(res, "listCategories")).map((row) => toCategory(row, row.id));
  }

  // ---- incidents ---------------------------------------------------------
  async listIncidents(filters: FeedFilters, viewer?: ViewerOrNull): Promise<FeedPage> {
    void viewer; // visibility is decided by RLS, not by the caller
    const sort = filters.sort ?? "latest";
    const limit = filters.limit ?? 12;
    const start = filters.cursor ? Number(filters.cursor) || 0 : 0;

    let q = this.db
      .from("incidents")
      .select(INCIDENT_SELECT, { count: "exact" })
      .eq("moderation_status", "approved");

    if (filters.kind) q = q.eq("kind", filters.kind);
    if (filters.categoryId) q = q.eq("category_id", filters.categoryId);
    if (filters.status) q = q.eq("status", filters.status);
    if (filters.state) q = q.eq("state", filters.state);
    if (filters.region) q = q.eq("region", filters.region);
    if (filters.query) q = q.textSearch("search", filters.query, { type: "websearch", config: "english" });

    if (sort === "top") q = q.order("dickery_rank", { ascending: false }).order("created_at", { ascending: false });
    else if (sort === "redeemed") q = q.eq("status", "redeemed").order("redeemed_at", { ascending: false, nullsFirst: false });
    else q = q.order("created_at", { ascending: false });

    const res = await q.range(start, start + limit - 1);
    if (res.error) throw new Error(`DBAD: listIncidents — ${res.error.message}`);
    const total = res.count ?? 0;
    return {
      items: rows<IncidentJoined>(res.data).map(toSummary),
      nextCursor: start + limit < total ? String(start + limit) : undefined,
      total,
    };
  }

  private async detail(row: IncidentJoined, viewer?: ViewerOrNull): Promise<IncidentDetail> {
    const [commentsRes, repliesRes, voteRes, reactionRes] = await Promise.all([
      this.db
        .from("comments")
        .select(COMMENT_SELECT)
        .eq("incident_id", row.id)
        .eq("status", "visible")
        .order("created_at", { ascending: true }),
      this.db
        .from("appeal_replies")
        .select("id, public_reply, created_at")
        .eq("incident_id", row.id)
        .order("created_at", { ascending: true }),
      viewer
        ? this.db.from("votes").select("verdict").eq("incident_id", row.id).eq("user_id", viewer.id).maybeSingle()
        : Promise.resolve({ data: null, error: null }),
      viewer
        ? this.db.from("reactions").select("kind").eq("incident_id", row.id).eq("user_id", viewer.id)
        : Promise.resolve({ data: null, error: null }),
    ]);

    const viewerVote = maybeRow<{ verdict: Verdict }>(voteRes.data)?.verdict;
    return {
      ...toSummary(row),
      comments: rows<CommentJoined>(commentsRes.data).map(toComment),
      publicReplies: rows<{ id: string | null; public_reply: string | null; created_at: string | null }>(
        repliesRes.data,
      ).map((r) => ({ id: r.id ?? "", publicReply: r.public_reply ?? undefined, createdAt: r.created_at ?? "" })),
      viewerVote: viewer ? viewerVote : undefined,
      viewerReactions: viewer ? rows<{ kind: ReactionKind }>(reactionRes.data).map((r) => r.kind) : undefined,
    };
  }

  async getIncidentBySlug(slug: string, viewer?: ViewerOrNull): Promise<IncidentDetail | null> {
    const res = await this.db.from("incidents").select(INCIDENT_SELECT).eq("slug", slug).maybeSingle();
    if (res.error) throw new Error(`DBAD: getIncidentBySlug — ${res.error.message}`);
    const row = maybeRow<IncidentJoined>(res.data);
    return row ? this.detail(row, viewer) : null;
  }

  async getIncidentById(id: string, viewer?: ViewerOrNull): Promise<IncidentDetail | null> {
    const res = await this.db.from("incidents").select(INCIDENT_SELECT).eq("id", id).maybeSingle();
    if (res.error) throw new Error(`DBAD: getIncidentById — ${res.error.message}`);
    const row = maybeRow<IncidentJoined>(res.data);
    return row ? this.detail(row, viewer) : null;
  }

  async getIncidentByCode(code: string): Promise<IncidentSummary | null> {
    const res = await this.db
      .from("incidents")
      .select(INCIDENT_SELECT)
      .eq("moderation_status", "approved")
      .eq("short_code", code.trim().toUpperCase())
      .maybeSingle();
    if (res.error) throw new Error(`DBAD: getIncidentByCode — ${res.error.message}`);
    const row = maybeRow<IncidentJoined>(res.data);
    return row ? toSummary(row) : null;
  }

  async getFeatured(): Promise<FeaturedSet> {
    const thisWeek = weekOf(new Date());
    const approved = () => this.db.from("incidents").select(INCIDENT_SELECT).eq("moderation_status", "approved");

    const [week, month, greatest, mostRedeemed, latestRedemptions, notADick] = await Promise.all([
      approved().eq("kind", "dick_move").eq("featured_week", thisWeek).limit(1),
      approved()
        .eq("kind", "dick_move")
        .not("featured_week", "is", null)
        .neq("featured_week", thisWeek)
        .order("dickery_rank", { ascending: false })
        .limit(1),
      approved()
        .eq("kind", "dick_move")
        .gte("votes_total", MIN_VOTES_FOR_VERDICT)
        .order("dickery_rank", { ascending: false })
        .limit(6),
      approved().eq("status", "redeemed").order("react_redemption", { ascending: false }).limit(6),
      approved().eq("status", "redeemed").order("redeemed_at", { ascending: false, nullsFirst: false }).limit(4),
      approved().eq("kind", "not_a_dick").order("created_at", { ascending: false }).limit(6),
    ]);

    const list = (res: { data: unknown }) => rows<IncidentJoined>(res.data).map(toSummary);
    return {
      week: list(week)[0] ?? null,
      month: list(month)[0] ?? null,
      greatest: list(greatest),
      mostRedeemed: list(mostRedeemed),
      latestRedemptions: list(latestRedemptions),
      notADick: list(notADick),
    };
  }

  async listRelated(incidentId: string, limit = 3): Promise<IncidentSummary[]> {
    const seedRes = await this.db.from("incidents").select("id, category_id, region").eq("id", incidentId).maybeSingle();
    const seed = maybeRow<{ category_id: string; region: string }>(seedRes.data);
    if (!seed) return [];
    const region = seed.region;

    const [byCategory, byRegion] = await Promise.all([
      this.db
        .from("incidents")
        .select(INCIDENT_SELECT)
        .eq("moderation_status", "approved")
        .eq("category_id", seed.category_id)
        .neq("id", incidentId)
        .order("created_at", { ascending: false })
        .limit(limit + 1),
      region
        ? this.db
            .from("incidents")
            .select(INCIDENT_SELECT)
            .eq("moderation_status", "approved")
            .eq("region", region)
            .neq("id", incidentId)
            .order("created_at", { ascending: false })
            .limit(limit + 1)
        : Promise.resolve({ data: null, error: null }),
    ]);

    const seen = new Set<string>();
    const merged: IncidentSummary[] = [];
    for (const row of [...rows<IncidentJoined>(byCategory.data), ...rows<IncidentJoined>(byRegion.data)]) {
      if (seen.has(row.id)) continue;
      seen.add(row.id);
      merged.push(toSummary(row));
    }
    merged.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    return merged.slice(0, limit);
  }

  /** Uploads any data: URL photos to Storage and returns what submit_nomination expects. */
  private async preparePhotos(
    input: NominationInput,
    viewer: ViewerOrNull,
  ): Promise<{ ok: true; photos: NominationPhotoPayload[] } | { ok: false; message: string }> {
    const out: NominationPhotoPayload[] = [];
    for (const [index, photo] of input.photos.entries()) {
      const base = {
        width: photo.width,
        height: photo.height,
        alt: photo.alt || `Evidence photo ${index + 1}`,
        redactionCount: photo.redactionCount,
      };
      const decoded = decodeDataUrl(photo.src);
      if (!decoded) {
        // Already a URL or a storage path — nothing to upload.
        out.push({ ...base, url: photo.src });
        continue;
      }
      if (!viewer) {
        return {
          ok: false,
          message:
            "Photos need an account — the storage bucket only accepts uploads from a signed-in member. Sign in, or post this one without a photo.",
        };
      }
      const path = `${viewer.id}/${randomId()}.${decoded.extension}`;
      const upload = await this.db.storage
        .from(PHOTO_BUCKET)
        .upload(path, decoded.bytes, { contentType: decoded.contentType, upsert: false });
      if (upload.error) {
        return { ok: false, message: `That photo didn't upload: ${upload.error.message}` };
      }
      const { data: pub } = this.db.storage.from(PHOTO_BUCKET).getPublicUrl(path);
      out.push({ ...base, url: pub.publicUrl, storagePath: path });
    }
    return { ok: true, photos: out };
  }

  async createIncident(
    input: NominationInput,
    viewer: ViewerOrNull,
  ): Promise<
    ActionResult<{ id: string; slug: string; shortCode: string; noticeId: string; moderationStatus: string }>
  > {
    const validation = validateNomination(input);
    if (!validation.ok) return validation;

    const prepared = await this.preparePhotos(input, viewer);
    if (!prepared.ok) return { ok: false, message: prepared.message, fieldErrors: { photos: prepared.message } };

    const res = await this.db.rpc("submit_nomination", {
      payload: {
        kind: input.kind,
        categoryId: input.categoryId,
        dickMove: input.dickMove,
        title: input.title,
        description: input.description,
        affected: input.affected,
        location: {
          suburb: input.location.suburb,
          state: input.location.state,
          place: input.location.place ?? null,
          approxLat: input.location.approxLat ?? null,
          approxLng: input.location.approxLng ?? null,
        },
        occurredOn: input.occurredOn,
        partOfDay: input.partOfDay,
        photos: prepared.photos,
        facebookUrl: input.facebookUrl ?? null,
        acceptedStandard: input.acceptedStandard,
        reviewedRedaction: input.reviewedRedaction,
      },
    });
    if (res.error) return { ok: false, message: res.error.message };

    const payload = asResult(res.data);
    if (!payload.ok) {
      return {
        ok: false,
        message: payload.message ?? "A couple of things need fixing.",
        fieldErrors: payload.fieldErrors,
      };
    }
    return {
      ok: true,
      data: {
        id: String(payload.id ?? ""),
        slug: String(payload.slug ?? ""),
        shortCode: String(payload.short_code ?? ""),
        noticeId: String(payload.notice_id ?? ""),
        moderationStatus: String(payload.moderation_status ?? "pending"),
      },
    };
  }

  // ---- community ---------------------------------------------------------
  async castVote(
    incidentId: string,
    verdict: Verdict,
    viewer: ViewerOrNull,
  ): Promise<ActionResult<{ votes: VoteTally; viewerVote: Verdict }>> {
    if (!viewer) return { ok: false, message: "Sign in to cast a verdict." };
    const res = await this.db.rpc("cast_vote", { incident: incidentId, verdict });
    if (res.error) return { ok: false, message: res.error.message };
    const payload = asResult(res.data);
    if (!payload.ok) return { ok: false, message: payload.message };
    return {
      ok: true,
      data: { votes: payload.votes as VoteTally, viewerVote: (payload.viewerVote as Verdict) ?? verdict },
    };
  }

  async toggleReaction(
    incidentId: string,
    kind: ReactionKind,
    viewer: ViewerOrNull,
  ): Promise<ActionResult<{ reactions: ReactionTally; viewerReactions: ReactionKind[] }>> {
    if (!viewer) return { ok: false, message: "Sign in to react." };
    const res = await this.db.rpc("toggle_reaction", { incident: incidentId, kind });
    if (res.error) return { ok: false, message: res.error.message };
    const payload = asResult(res.data);
    if (!payload.ok) return { ok: false, message: payload.message };
    return {
      ok: true,
      data: {
        reactions: payload.reactions as ReactionTally,
        viewerReactions: (payload.viewerReactions as ReactionKind[]) ?? [],
      },
    };
  }

  async addComment(
    incidentId: string,
    body: string,
    viewer: ViewerOrNull,
  ): Promise<ActionResult<IncidentDetail["comments"][number]>> {
    if (!viewer) return { ok: false, message: "Sign in to comment." };
    const res = await this.db.rpc("add_comment", { incident: incidentId, body });
    if (res.error) return { ok: false, message: res.error.message };
    const payload = asResult(res.data);
    // A comment that looked like it identified someone is held, and the RPC
    // answers with the reason — same as the demo store.
    if (!payload.ok) return { ok: false, message: payload.message };

    const c = payload.comment as {
      id: string;
      incidentId: string;
      authorId: string;
      body: string;
      createdAt: string;
      status: Comment["status"];
      parentId: string | null;
      author: { handle: string; displayName: string; avatarSeed: string };
    };
    return {
      ok: true,
      data: {
        id: c.id,
        incidentId: c.incidentId,
        authorId: c.authorId,
        body: c.body,
        createdAt: c.createdAt,
        status: c.status,
        parentId: c.parentId ?? undefined,
        author: c.author,
      },
    };
  }

  async reportContent(input: ReportInput, viewer: ViewerOrNull): Promise<ActionResult> {
    void viewer; // the RPC reads auth.uid() itself
    const res = await this.db.rpc("report_content", {
      payload: {
        targetType: input.targetType,
        targetId: input.targetId,
        reason: input.reason,
        details: input.details ?? null,
      },
    });
    if (res.error) return { ok: false, message: res.error.message };
    const payload = asResult(res.data);
    return { ok: payload.ok, message: payload.message };
  }

  async submitAppeal(input: AppealInput): Promise<ActionResult<{ reference: string }>> {
    const res = await this.db.rpc("submit_appeal", {
      payload: {
        incidentId: input.incidentId,
        requestedAction: input.requestedAction,
        message: input.message,
        contact: input.contact ?? null,
      },
    });
    if (res.error) return { ok: false, message: res.error.message };
    const payload = asResult(res.data);
    if (!payload.ok) return { ok: false, message: payload.message };
    return { ok: true, message: payload.message, data: { reference: String(payload.reference ?? "") } };
  }

  async markRedeemed(incidentId: string, note: string, viewer: ViewerOrNull): Promise<ActionResult> {
    if (!viewer) return { ok: false, message: "Sign in first." };
    const res = await this.db.rpc("mark_redeemed", { incident: incidentId, note });
    if (res.error) return { ok: false, message: res.error.message };
    const payload = asResult(res.data);
    return { ok: payload.ok, message: payload.message };
  }

  // ---- notices -----------------------------------------------------------
  async getNotice(id: string): Promise<PrintableNotice | null> {
    const res = await this.db.from("printable_notices").select("*").eq("id", id).maybeSingle();
    if (res.error) throw new Error(`DBAD: getNotice — ${res.error.message}`);
    const row = maybeRow<NoticeRow>(res.data);
    return row ? toNotice(row) : null;
  }

  async createNotice(input: CreateNoticeInput, viewer: ViewerOrNull): Promise<PrintableNotice> {
    const res = await this.db
      .from("printable_notices")
      .insert({
        incident_id: input.incidentId ?? null,
        template: input.template,
        link_mode: input.linkMode,
        headline: clean(input.lines.headline, 60),
        dick_move: clean(input.lines.dickMove, 90),
        why: clean(input.lines.why, 220),
        location: clean(input.lines.location, 80),
        advice: clean(input.lines.advice, 140),
        created_by: viewer?.id ?? null,
      })
      .select("*")
      .single();
    const row = maybeRow<NoticeRow>(unwrap(res, "createNotice"));
    if (!row) throw new Error("DBAD: createNotice — no row returned");
    return toNotice(row);
  }

  async updateNotice(
    id: string,
    patch: Partial<CreateNoticeInput>,
    viewer: ViewerOrNull,
  ): Promise<PrintableNotice | null> {
    const current = await this.getNotice(id);
    if (!current) return null;
    // The RLS policy allows the creator, a moderator, or anyone at all for an
    // anonymous notice; this mirrors the demo's "no edit, no error" behaviour.
    if (current.createdBy && viewer && current.createdBy !== viewer.id && viewer.role === "member") return current;

    const lines = patch.lines;
    const res = await this.db
      .from("printable_notices")
      .update({
        ...(patch.template ? { template: patch.template } : {}),
        ...(patch.linkMode ? { link_mode: patch.linkMode } : {}),
        ...(lines
          ? {
              headline: clean(lines.headline ?? current.lines.headline, 60),
              dick_move: clean(lines.dickMove ?? current.lines.dickMove, 90),
              why: clean(lines.why ?? current.lines.why, 220),
              location: clean(lines.location ?? current.lines.location, 80),
              advice: clean(lines.advice ?? current.lines.advice, 140),
            }
          : {}),
      })
      .eq("id", id)
      .select("*")
      .maybeSingle();
    if (res.error) throw new Error(`DBAD: updateNotice — ${res.error.message}`);
    const row = maybeRow<NoticeRow>(res.data);
    return row ? toNotice(row) : current;
  }

  // ---- map ---------------------------------------------------------------
  async getMapClusters(): Promise<MapCluster[]> {
    const res = await this.db.rpc("map_clusters");
    if (res.error) throw new Error(`DBAD: getMapClusters — ${res.error.message}`);
    return rows<{
      region: string;
      state: AustralianState;
      approx_lat: number;
      approx_lng: number;
      count: number;
      count_this_week: number;
      redeemed: number;
      not_a_dick: number;
      top_category_id: string;
    }>(res.data).map((c) => ({
      region: c.region,
      state: c.state,
      approxLat: Number(c.approx_lat),
      approxLng: Number(c.approx_lng),
      count: c.count,
      countThisWeek: c.count_this_week,
      redeemed: c.redeemed,
      notADick: c.not_a_dick,
      topCategoryId: (c.top_category_id in CATEGORY_MAP ? c.top_category_id : "other") as CategoryId,
    }));
  }

  // ---- members -----------------------------------------------------------
  private async profilePage(row: ProfileRow): Promise<ProfilePage> {
    const [statsRes, badgeRes, recentRes] = await Promise.all([
      this.db.from("member_stats").select("*").eq("user_id", row.id).maybeSingle(),
      this.db.from("user_badges").select("badge_id, awarded_at").eq("user_id", row.id).order("awarded_at"),
      this.db
        .from("incidents")
        .select(INCIDENT_SELECT)
        .eq("moderation_status", "approved")
        .eq("submitter_id", row.id)
        .eq("anonymised", false)
        .order("created_at", { ascending: false })
        .limit(6),
    ]);

    return {
      profile: toProfile(row),
      stats: toStats(maybeRow<MemberStatsRow>(statsRes.data)),
      badges: rows<{ badge_id: string; awarded_at: string }>(badgeRes.data).map(
        (b): UserBadge => ({ badgeId: b.badge_id as UserBadge["badgeId"], awardedAt: b.awarded_at }),
      ),
      recent: rows<IncidentJoined>(recentRes.data).map(toSummary),
    };
  }

  async getProfileByHandle(handle: string): Promise<ProfilePage | null> {
    // handle is citext, so this comparison is case-insensitive in the database.
    const res = await this.db.from("profiles").select("*").eq("handle", handle).maybeSingle();
    if (res.error) throw new Error(`DBAD: getProfileByHandle — ${res.error.message}`);
    const row = maybeRow<ProfileRow>(res.data);
    return row ? this.profilePage(row) : null;
  }

  async getProfileById(id: string): Promise<ProfilePage | null> {
    const res = await this.db.from("profiles").select("*").eq("id", id).maybeSingle();
    if (res.error) throw new Error(`DBAD: getProfileById — ${res.error.message}`);
    const row = maybeRow<ProfileRow>(res.data);
    return row ? this.profilePage(row) : null;
  }

  async listNotifications(viewer: Viewer): Promise<Notification[]> {
    const res = await this.db
      .from("notifications")
      .select("*")
      .eq("user_id", viewer.id)
      .order("created_at", { ascending: false });
    if (res.error) throw new Error(`DBAD: listNotifications — ${res.error.message}`);
    return rows<NotificationRow>(res.data).map(toNotification);
  }

  async markNotificationsRead(viewer: Viewer): Promise<void> {
    await this.db
      .from("notifications")
      .update({ read_at: new Date().toISOString() })
      .eq("user_id", viewer.id)
      .is("read_at", null);
  }

  // ---- admin / moderation ------------------------------------------------
  async getAdminStats(): Promise<AdminStats> {
    const res = await this.db.rpc("admin_stats");
    if (res.error) throw new Error(`DBAD: getAdminStats — ${res.error.message}`);
    const payload = asResult(res.data);
    const num = (key: string) => Number(payload[key] ?? 0);
    return {
      dickMovesToday: num("dickMovesToday"),
      dickMovesThisWeek: num("dickMovesThisWeek"),
      redemptions: num("redemptions"),
      pendingModeration: num("pendingModeration"),
      reportedContent: num("reportedContent"),
      openAppeals: num("openAppeals"),
      mostActiveAreas: (payload.mostActiveAreas as AdminStats["mostActiveAreas"]) ?? [],
      mostCommonCategories: (payload.mostCommonCategories as AdminStats["mostCommonCategories"]) ?? [],
      membersTotal: num("membersTotal"),
      notADickThisWeek: num("notADickThisWeek"),
    };
  }

  async listModerationQueue(): Promise<IncidentSummary[]> {
    const res = await this.db
      .from("incidents")
      .select(INCIDENT_SELECT)
      .eq("moderation_status", "pending")
      .order("created_at", { ascending: true });
    if (res.error) throw new Error(`DBAD: listModerationQueue — ${res.error.message}`);
    return rows<IncidentJoined>(res.data).map(toSummary);
  }

  async listReports(status?: Report["status"]): Promise<ReportWithTarget[]> {
    let q = this.db.from("reports").select("*").order("created_at", { ascending: false });
    if (status) q = q.eq("status", status);
    const res = await q;
    if (res.error) throw new Error(`DBAD: listReports — ${res.error.message}`);
    const reports = rows<ReportRow>(res.data);

    const incidentIds = reports.filter((r) => r.target_type === "incident").map((r) => r.target_id);
    const commentIds = reports.filter((r) => r.target_type === "comment").map((r) => r.target_id);

    const [incidentsRes, commentsRes] = await Promise.all([
      incidentIds.length
        ? this.db.from("incidents").select(INCIDENT_SELECT).in("id", incidentIds)
        : Promise.resolve({ data: null, error: null }),
      commentIds.length
        ? this.db.from("comments").select(COMMENT_SELECT).in("id", commentIds)
        : Promise.resolve({ data: null, error: null }),
    ]);

    const byIncident = new Map(rows<IncidentJoined>(incidentsRes.data).map((i) => [i.id, toSummary(i)] as const));
    const byComment = new Map(rows<CommentJoined>(commentsRes.data).map((c) => [c.id, toComment(c)] as const));

    return reports.map((r) => {
      const out: ReportWithTarget = toReport(r);
      if (r.target_type === "incident") {
        const incident = byIncident.get(r.target_id);
        if (incident) out.incident = incident;
      } else {
        const comment = byComment.get(r.target_id);
        if (comment) out.comment = comment;
      }
      return out;
    });
  }

  async listAppeals(status?: Appeal["status"]): Promise<AppealWithIncident[]> {
    let q = this.db.from("appeals").select("*").order("created_at", { ascending: false });
    if (status) q = q.eq("status", status);
    const res = await q;
    if (res.error) throw new Error(`DBAD: listAppeals — ${res.error.message}`);
    const appeals = rows<AppealRow>(res.data);
    if (!appeals.length) return [];

    const incidentsRes = await this.db
      .from("incidents")
      .select(INCIDENT_SELECT)
      .in("id", appeals.map((a) => a.incident_id));
    const byId = new Map(rows<IncidentJoined>(incidentsRes.data).map((i) => [i.id, toSummary(i)] as const));

    return appeals.flatMap((a) => {
      const incident = byId.get(a.incident_id);
      return incident ? [{ ...toAppeal(a), incident }] : [];
    });
  }

  async listAllComments(
    opts: { status?: Comment["status"]; limit?: number } = {},
  ): Promise<
    Array<Comment & { author: Pick<Profile, "handle" | "displayName">; incident: Pick<IncidentSummary, "slug" | "title"> }>
  > {
    let q = this.db
      .from("comments")
      .select(COMMENT_WITH_INCIDENT_SELECT)
      .order("created_at", { ascending: false })
      .limit(opts.limit ?? 50);
    if (opts.status) q = q.eq("status", opts.status);
    const res = await q;
    if (res.error) throw new Error(`DBAD: listAllComments — ${res.error.message}`);

    type Joined = CommentJoined & { incident: { slug: string; title: string } | { slug: string; title: string }[] | null };
    return rows<Joined>(res.data).map((row) => {
      const mapped = toComment(row);
      const incident = one(row.incident);
      return {
        id: mapped.id,
        incidentId: mapped.incidentId,
        authorId: mapped.authorId,
        body: mapped.body,
        createdAt: mapped.createdAt,
        status: mapped.status,
        parentId: mapped.parentId,
        author: { handle: mapped.author.handle, displayName: mapped.author.displayName },
        incident: { slug: incident?.slug ?? "", title: incident?.title ?? "" },
      };
    });
  }

  async listUsers(query?: string): Promise<UserRow[]> {
    let q = this.db.from("profiles").select("*").order("member_since", { ascending: true });
    const term = query ? safeFilterTerm(query) : "";
    if (term) q = q.or(`handle.ilike.%${term}%,display_name.ilike.%${term}%`);
    const res = await q;
    if (res.error) throw new Error(`DBAD: listUsers — ${res.error.message}`);
    const profiles = rows<ProfileRow>(res.data);
    if (!profiles.length) return [];

    const ids = profiles.map((p) => p.id);
    const [statsRes, badgeRes] = await Promise.all([
      this.db.from("member_stats").select("*").in("user_id", ids),
      this.db.from("user_badges").select("user_id, badge_id, awarded_at").in("user_id", ids),
    ]);

    const statsById = new Map(
      rows<MemberStatsRow>(statsRes.data).map((s) => [s.user_id ?? "", s] as const),
    );
    const badgesById = new Map<string, UserBadge[]>();
    for (const b of rows<{ user_id: string; badge_id: string; awarded_at: string }>(badgeRes.data)) {
      const list = badgesById.get(b.user_id) ?? [];
      list.push({ badgeId: b.badge_id as UserBadge["badgeId"], awardedAt: b.awarded_at });
      badgesById.set(b.user_id, list);
    }

    return profiles.map((p) => ({
      ...toProfile(p),
      stats: toStats(statsById.get(p.id) ?? null),
      badges: badgesById.get(p.id) ?? [],
    }));
  }

  async listAuditLog(limit = 50): Promise<AuditEntry[]> {
    const res = await this.db
      .from("moderation_actions")
      .select("*, actor:profiles(handle, display_name)")
      .order("created_at", { ascending: false })
      .limit(limit);
    if (res.error) throw new Error(`DBAD: listAuditLog — ${res.error.message}`);
    type Joined = AuditRow & {
      actor: Pick<ProfileRow, "handle" | "display_name"> | Pick<ProfileRow, "handle" | "display_name">[] | null;
    };
    return rows<Joined>(res.data).map((row) => {
      const actor = one(row.actor);
      return {
        ...toAuditAction(row),
        actor: { handle: actor?.handle ?? "system", displayName: actor?.display_name ?? "System" },
      };
    });
  }

  async listAllIncidentsAdmin(
    opts: { status?: string; query?: string; limit?: number } = {},
  ): Promise<IncidentSummary[]> {
    let q = this.db
      .from("incidents")
      .select(INCIDENT_SELECT)
      .order("created_at", { ascending: false })
      .limit(opts.limit ?? 100);

    const moderationStatus = opts.status ? asModerationStatus(opts.status) : undefined;
    const lifecycleStatus = opts.status ? asIncidentStatus(opts.status) : undefined;
    if (moderationStatus) q = q.eq("moderation_status", moderationStatus);
    else if (lifecycleStatus) q = q.eq("status", lifecycleStatus);

    const term = opts.query ? safeFilterTerm(opts.query) : "";
    if (term) {
      q = q.or(
        [
          `title.ilike.%${term}%`,
          `dick_move.ilike.%${term}%`,
          `short_code.ilike.%${term}%`,
          `location_label.ilike.%${term}%`,
        ].join(","),
      );
    }

    const res = await q;
    if (res.error) throw new Error(`DBAD: listAllIncidentsAdmin — ${res.error.message}`);
    return rows<IncidentJoined>(res.data).map(toSummary);
  }

  async moderate(command: ModerationCommand, actor: Viewer): Promise<ActionResult> {
    if (actor.role === "member") return { ok: false, message: "Moderators only." };
    const res = await this.db.rpc("moderate", {
      command: {
        action: command.action,
        targetType: command.targetType,
        targetId: command.targetId,
        note: command.note ?? null,
        payload: command.payload ?? {},
      },
    });
    if (res.error) return { ok: false, message: res.error.message };
    const payload = asResult(res.data);
    return { ok: payload.ok, message: payload.message };
  }
}

/** Notice copy is public and printable, so it gets the same scrub as everything else. */
function clean(value: string, max: number): string {
  return scanText(value ?? "").cleaned.slice(0, max);
}
