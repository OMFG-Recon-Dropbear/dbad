import type { Badge, BadgeId, ProfileStats } from "./types";

export const BADGES: Badge[] = [
  {
    id: "first_call",
    name: "FIRST CALL",
    blurb: "Made your first nomination. Welcome to the noticeboard.",
    rule: "1 approved nomination",
  },
  {
    id: "eagle_eye",
    name: "EAGLE EYE",
    blurb: "Spotted 10 verified Dick Moves.",
    rule: "10 approved nominations",
  },
  {
    id: "fair_dinkum",
    name: "FAIR DINKUM",
    blurb: "90% of your nominations agreed with by the community.",
    rule: "At least 5 verdicts reached and 90% agreed",
  },
  {
    id: "redemption_arc",
    name: "REDEMPTION ARC",
    blurb: "Helped resolve five incidents. Humanity thanks you.",
    rule: "5 nominations marked Redeemed",
  },
  {
    id: "not_actually_a_karen",
    name: "NOT ACTUALLY A KAREN",
    blurb: "Had five nominations validated by moderators.",
    rule: "5 nominations approved by a moderator",
  },
  {
    id: "local_legend",
    name: "LOCAL LEGEND",
    blurb: "Positive contributor to the DBAD community.",
    rule: "3 Not-A-Dick nominations and 10 comments that stayed up",
  },
];

export const BADGE_MAP: Record<BadgeId, Badge> = Object.fromEntries(BADGES.map((b) => [b.id, b])) as Record<
  BadgeId,
  Badge
>;

/** Pure rule evaluation — used by the demo store and mirrored by SQL in Supabase. */
export function evaluateBadges(stats: ProfileStats): BadgeId[] {
  const earned: BadgeId[] = [];
  if (stats.spotted >= 1) earned.push("first_call");
  if (stats.spotted >= 10) earned.push("eagle_eye");
  const decided = stats.fairCalls + stats.overruled;
  if (decided >= 5 && stats.fairCalls / decided >= 0.9) earned.push("fair_dinkum");
  if (stats.redeemed >= 5) earned.push("redemption_arc");
  if (stats.spotted >= 5) earned.push("not_actually_a_karen");
  if (stats.notADick >= 3 && stats.comments >= 10) earned.push("local_legend");
  return earned;
}
