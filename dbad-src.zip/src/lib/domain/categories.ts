import type { AffectedGroup, Category, CategoryId, PartOfDay } from "./types";

export const CATEGORIES: Category[] = [
  {
    id: "parking",
    label: "PARKING DICK",
    short: "Parking",
    blurb: "Blocking footpaths, disabled bays, driveways, or taking up two spaces because you couldn't be bothered.",
    accent: "warning",
  },
  {
    id: "road",
    label: "ROAD DICK",
    short: "Road",
    blurb: "Dangerous or inconsiderate road behaviour. Tailgating, phone-driving, the lot.",
    caution: "Never film while driving. Passengers and dashcams only.",
    accent: "alert",
  },
  {
    id: "shopping",
    label: "SHOPPING DICK",
    short: "Shopping",
    blurb: "Trolleys abandoned in the wild, aisles blockaded, fourteen items in the eight-item lane.",
    accent: "warning",
  },
  {
    id: "neighbourhood",
    label: "NEIGHBOURHOOD DICK",
    short: "Neighbourhood",
    blurb: "Community-space stupidity. Playgrounds, parks, shared driveways, bins.",
    caution: "Public spaces only. Nothing about someone's home or who lives there.",
    accent: "concrete",
  },
  {
    id: "rubbish",
    label: "RUBBISH DICK",
    short: "Rubbish",
    blurb: "Littering, dumping, and leaving a picnic's worth of mess for someone else.",
    accent: "warning",
  },
  {
    id: "dog",
    label: "DOG DICK",
    short: "Dog",
    blurb: "Owners who don't pick up, don't leash where they must, or think 'he's friendly' is a plan.",
    caution: "The dog is never the dick. The human holding (or not holding) the lead is.",
    accent: "concrete",
  },
  {
    id: "internet",
    label: "INTERNET DICK",
    short: "Internet",
    blurb: "Community examples that started online — public group posts, marketplace madness.",
    caution: "No screenshots of names, profiles or private messages.",
    accent: "concrete",
  },
  {
    id: "workplace",
    label: "WORKPLACE DICK MOVE",
    short: "Workplace",
    blurb: "Light-hearted office annoyances. The microwave fish. The reply-all.",
    caution: "Nothing confidential, nothing that identifies a colleague or employer.",
    accent: "concrete",
  },
  {
    id: "other",
    label: "OTHER DICKERY",
    short: "Other",
    blurb: "For everything we failed to anticipate. Humanity is inventive.",
    accent: "warning",
  },
];

export const CATEGORY_MAP: Record<CategoryId, Category> = Object.fromEntries(
  CATEGORIES.map((c) => [c.id, c]),
) as Record<CategoryId, Category>;

export function getCategory(id: CategoryId): Category {
  return CATEGORY_MAP[id] ?? CATEGORY_MAP.other;
}

export const AFFECTED_GROUPS: Array<{ id: AffectedGroup; label: string }> = [
  { id: "pedestrians", label: "Pedestrians" },
  { id: "wheelchair_users", label: "Wheelchair users" },
  { id: "parents_prams", label: "Parents with prams" },
  { id: "cyclists", label: "Cyclists" },
  { id: "neighbours", label: "Neighbours" },
  { id: "motorists", label: "Motorists" },
  { id: "local_businesses", label: "Local businesses" },
  { id: "the_community", label: "The community" },
  { id: "everyone", label: "Everyone" },
  { id: "probably_nobody", label: "Probably nobody, but it was still ridiculous" },
];

export const AFFECTED_LABEL: Record<AffectedGroup, string> = Object.fromEntries(
  AFFECTED_GROUPS.map((g) => [g.id, g.label]),
) as Record<AffectedGroup, string>;

export const PART_OF_DAY: Array<{ id: PartOfDay; label: string }> = [
  { id: "morning", label: "Morning" },
  { id: "midday", label: "Midday" },
  { id: "afternoon", label: "Afternoon" },
  { id: "evening", label: "Evening" },
  { id: "night", label: "Night" },
  { id: "unknown", label: "Not sure" },
];

export const PART_OF_DAY_LABEL: Record<PartOfDay, string> = Object.fromEntries(
  PART_OF_DAY.map((p) => [p.id, p.label]),
) as Record<PartOfDay, string>;

export const AUSTRALIAN_STATES = ["NSW", "VIC", "QLD", "WA", "SA", "TAS", "ACT", "NT"] as const;
