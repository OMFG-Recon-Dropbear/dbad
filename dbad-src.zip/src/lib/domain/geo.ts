import type { AustralianState } from "./types";

/**
 * Coarse Australian place index used to suggest a general area from device
 * coordinates without calling a third-party geocoder. Centroids only — the platform
 * never stores or displays anything more precise than a suburb/town.
 */
export interface Place {
  name: string;
  state: AustralianState;
  lat: number;
  lng: number;
  region: string;
}

export const PLACES: Place[] = [
  { name: "Sydney CBD", state: "NSW", lat: -33.868, lng: 151.209, region: "Greater Sydney" },
  { name: "Parramatta", state: "NSW", lat: -33.815, lng: 151.001, region: "Greater Sydney" },
  { name: "Penrith", state: "NSW", lat: -33.751, lng: 150.694, region: "Greater Sydney" },
  { name: "Bondi", state: "NSW", lat: -33.891, lng: 151.277, region: "Greater Sydney" },
  { name: "Manly", state: "NSW", lat: -33.797, lng: 151.288, region: "Greater Sydney" },
  { name: "Liverpool", state: "NSW", lat: -33.92, lng: 150.923, region: "Greater Sydney" },
  { name: "Cronulla", state: "NSW", lat: -34.058, lng: 151.153, region: "Greater Sydney" },
  { name: "Hornsby", state: "NSW", lat: -33.703, lng: 151.099, region: "Greater Sydney" },
  { name: "Newcastle", state: "NSW", lat: -32.927, lng: 151.78, region: "Hunter" },
  { name: "Maitland", state: "NSW", lat: -32.733, lng: 151.557, region: "Hunter" },
  { name: "Gosford", state: "NSW", lat: -33.426, lng: 151.342, region: "Central Coast" },
  { name: "Bateau Bay", state: "NSW", lat: -33.383, lng: 151.474, region: "Central Coast" },
  { name: "Wollongong", state: "NSW", lat: -34.425, lng: 150.893, region: "Illawarra" },
  { name: "Shellharbour", state: "NSW", lat: -34.58, lng: 150.87, region: "Illawarra" },
  { name: "Kiama", state: "NSW", lat: -34.671, lng: 150.854, region: "Illawarra" },
  { name: "Nowra", state: "NSW", lat: -34.876, lng: 150.601, region: "Shoalhaven" },
  { name: "Huskisson", state: "NSW", lat: -35.037, lng: 150.67, region: "Shoalhaven" },
  { name: "Ulladulla", state: "NSW", lat: -35.359, lng: 150.473, region: "South Coast NSW" },
  { name: "Mollymook", state: "NSW", lat: -35.33, lng: 150.472, region: "South Coast NSW" },
  { name: "Batemans Bay", state: "NSW", lat: -35.708, lng: 150.175, region: "South Coast NSW" },
  { name: "Batehaven", state: "NSW", lat: -35.735, lng: 150.205, region: "South Coast NSW" },
  { name: "Broulee", state: "NSW", lat: -35.855, lng: 150.175, region: "South Coast NSW" },
  { name: "Moruya", state: "NSW", lat: -35.912, lng: 150.081, region: "South Coast NSW" },
  { name: "Narooma", state: "NSW", lat: -36.219, lng: 150.132, region: "South Coast NSW" },
  { name: "Bermagui", state: "NSW", lat: -36.42, lng: 150.06, region: "Sapphire Coast" },
  { name: "Bega", state: "NSW", lat: -36.674, lng: 149.842, region: "Sapphire Coast" },
  { name: "Merimbula", state: "NSW", lat: -36.891, lng: 149.905, region: "Sapphire Coast" },
  { name: "Eden", state: "NSW", lat: -37.063, lng: 149.905, region: "Sapphire Coast" },
  { name: "Goulburn", state: "NSW", lat: -34.755, lng: 149.72, region: "Southern Tablelands" },
  { name: "Yass", state: "NSW", lat: -34.84, lng: 148.911, region: "Southern Tablelands" },
  { name: "Queanbeyan", state: "NSW", lat: -35.353, lng: 149.232, region: "Canberra" },
  { name: "Bungendore", state: "NSW", lat: -35.255, lng: 149.442, region: "Canberra" },
  { name: "Canberra Civic", state: "ACT", lat: -35.281, lng: 149.128, region: "Canberra" },
  { name: "Belconnen", state: "ACT", lat: -35.238, lng: 149.066, region: "Canberra" },
  { name: "Gungahlin", state: "ACT", lat: -35.185, lng: 149.133, region: "Canberra" },
  { name: "Woden", state: "ACT", lat: -35.345, lng: 149.087, region: "Canberra" },
  { name: "Tuggeranong", state: "ACT", lat: -35.414, lng: 149.067, region: "Canberra" },
  { name: "Fyshwick", state: "ACT", lat: -35.328, lng: 149.169, region: "Canberra" },
  { name: "Kingston", state: "ACT", lat: -35.314, lng: 149.145, region: "Canberra" },
  { name: "Dickson", state: "ACT", lat: -35.25, lng: 149.14, region: "Canberra" },
  { name: "Weston Creek", state: "ACT", lat: -35.34, lng: 149.05, region: "Canberra" },
  { name: "Albury", state: "NSW", lat: -36.081, lng: 146.916, region: "Riverina" },
  { name: "Wagga Wagga", state: "NSW", lat: -35.115, lng: 147.37, region: "Riverina" },
  { name: "Dubbo", state: "NSW", lat: -32.243, lng: 148.605, region: "Central West NSW" },
  { name: "Orange", state: "NSW", lat: -33.284, lng: 149.1, region: "Central West NSW" },
  { name: "Bathurst", state: "NSW", lat: -33.42, lng: 149.578, region: "Central West NSW" },
  { name: "Tamworth", state: "NSW", lat: -31.09, lng: 150.929, region: "New England" },
  { name: "Armidale", state: "NSW", lat: -30.512, lng: 151.669, region: "New England" },
  { name: "Port Macquarie", state: "NSW", lat: -31.431, lng: 152.909, region: "Mid North Coast" },
  { name: "Coffs Harbour", state: "NSW", lat: -30.296, lng: 153.114, region: "Mid North Coast" },
  { name: "Byron Bay", state: "NSW", lat: -28.644, lng: 153.612, region: "Northern Rivers" },
  { name: "Lismore", state: "NSW", lat: -28.81, lng: 153.277, region: "Northern Rivers" },
  { name: "Melbourne CBD", state: "VIC", lat: -37.814, lng: 144.963, region: "Melbourne" },
  { name: "Fitzroy", state: "VIC", lat: -37.798, lng: 144.978, region: "Melbourne" },
  { name: "St Kilda", state: "VIC", lat: -37.868, lng: 144.981, region: "Melbourne" },
  { name: "Footscray", state: "VIC", lat: -37.8, lng: 144.9, region: "Melbourne" },
  { name: "Dandenong", state: "VIC", lat: -37.988, lng: 145.215, region: "Melbourne" },
  { name: "Frankston", state: "VIC", lat: -38.144, lng: 145.123, region: "Melbourne" },
  { name: "Geelong", state: "VIC", lat: -38.15, lng: 144.36, region: "Geelong" },
  { name: "Ballarat", state: "VIC", lat: -37.562, lng: 143.85, region: "Regional VIC" },
  { name: "Bendigo", state: "VIC", lat: -36.757, lng: 144.28, region: "Regional VIC" },
  { name: "Shepparton", state: "VIC", lat: -36.38, lng: 145.4, region: "Regional VIC" },
  { name: "Wodonga", state: "VIC", lat: -36.122, lng: 146.888, region: "Regional VIC" },
  { name: "Brisbane CBD", state: "QLD", lat: -27.47, lng: 153.026, region: "Brisbane" },
  { name: "West End", state: "QLD", lat: -27.48, lng: 153.01, region: "Brisbane" },
  { name: "Chermside", state: "QLD", lat: -27.385, lng: 153.032, region: "Brisbane" },
  { name: "Logan", state: "QLD", lat: -27.639, lng: 153.109, region: "Brisbane" },
  { name: "Ipswich", state: "QLD", lat: -27.615, lng: 152.76, region: "Brisbane" },
  { name: "Surfers Paradise", state: "QLD", lat: -28.003, lng: 153.43, region: "Gold Coast" },
  { name: "Southport", state: "QLD", lat: -27.967, lng: 153.4, region: "Gold Coast" },
  { name: "Maroochydore", state: "QLD", lat: -26.65, lng: 153.09, region: "Sunshine Coast" },
  { name: "Noosa", state: "QLD", lat: -26.393, lng: 153.09, region: "Sunshine Coast" },
  { name: "Toowoomba", state: "QLD", lat: -27.56, lng: 151.954, region: "Regional QLD" },
  { name: "Rockhampton", state: "QLD", lat: -23.378, lng: 150.51, region: "Regional QLD" },
  { name: "Mackay", state: "QLD", lat: -21.144, lng: 149.187, region: "Regional QLD" },
  { name: "Townsville", state: "QLD", lat: -19.259, lng: 146.817, region: "Regional QLD" },
  { name: "Cairns", state: "QLD", lat: -16.92, lng: 145.771, region: "Regional QLD" },
  { name: "Perth CBD", state: "WA", lat: -31.953, lng: 115.857, region: "Perth" },
  { name: "Fremantle", state: "WA", lat: -32.056, lng: 115.747, region: "Perth" },
  { name: "Joondalup", state: "WA", lat: -31.745, lng: 115.766, region: "Perth" },
  { name: "Rockingham", state: "WA", lat: -32.277, lng: 115.729, region: "Perth" },
  { name: "Mandurah", state: "WA", lat: -32.529, lng: 115.723, region: "Perth" },
  { name: "Bunbury", state: "WA", lat: -33.327, lng: 115.641, region: "Regional WA" },
  { name: "Geraldton", state: "WA", lat: -28.778, lng: 114.615, region: "Regional WA" },
  { name: "Broome", state: "WA", lat: -17.955, lng: 122.239, region: "Regional WA" },
  { name: "Adelaide CBD", state: "SA", lat: -34.929, lng: 138.601, region: "Adelaide" },
  { name: "Glenelg", state: "SA", lat: -34.98, lng: 138.515, region: "Adelaide" },
  { name: "Port Adelaide", state: "SA", lat: -34.847, lng: 138.503, region: "Adelaide" },
  { name: "Mount Barker", state: "SA", lat: -35.067, lng: 138.859, region: "Adelaide" },
  { name: "Mount Gambier", state: "SA", lat: -37.829, lng: 140.782, region: "Regional SA" },
  { name: "Hobart", state: "TAS", lat: -42.882, lng: 147.327, region: "Hobart" },
  { name: "Launceston", state: "TAS", lat: -41.434, lng: 147.138, region: "Tasmania" },
  { name: "Devonport", state: "TAS", lat: -41.18, lng: 146.35, region: "Tasmania" },
  { name: "Darwin City", state: "NT", lat: -12.463, lng: 130.842, region: "Darwin" },
  { name: "Palmerston", state: "NT", lat: -12.486, lng: 130.983, region: "Darwin" },
  { name: "Alice Springs", state: "NT", lat: -23.698, lng: 133.881, region: "Northern Territory" },
];

function haversineKm(aLat: number, aLng: number, bLat: number, bLng: number): number {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLng = ((bLng - aLng) * Math.PI) / 180;
  const s = Math.sin(dLat / 2) ** 2 + Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

/** Nearest known place plus the distance, so the UI can say "near Batemans Bay (about 4 km)". */
export function nearestPlace(lat: number, lng: number): { place: Place; km: number } | null {
  if (lat < -44 || lat > -10 || lng < 112 || lng > 154) return null;
  let best: { place: Place; km: number } | null = null;
  for (const p of PLACES) {
    const km = haversineKm(lat, lng, p.lat, p.lng);
    if (!best || km < best.km) best = { place: p, km };
  }
  return best;
}

/** Coarsen coordinates to roughly a kilometre so nothing precise is ever stored. */
export function coarsen(lat: number, lng: number): { lat: number; lng: number } {
  return { lat: Math.round(lat * 100) / 100, lng: Math.round(lng * 100) / 100 };
}

/** Simple equirectangular projection tuned for mainland Australia + Tasmania. */
export const AU_BOUNDS = { minLat: -44.5, maxLat: -9.5, minLng: 112, maxLng: 154.5 };

export function projectAU(lat: number, lng: number, width: number, height: number): { x: number; y: number } {
  const x = ((lng - AU_BOUNDS.minLng) / (AU_BOUNDS.maxLng - AU_BOUNDS.minLng)) * width;
  const y = ((AU_BOUNDS.maxLat - lat) / (AU_BOUNDS.maxLat - AU_BOUNDS.minLat)) * height;
  return { x, y };
}
