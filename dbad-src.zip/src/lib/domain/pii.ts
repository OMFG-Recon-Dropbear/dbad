/**
 * Text PII and safety scanning.
 *
 * Runs client-side in the wizard (instant feedback) and server-side on submission
 * (authoritative). Rule of the platform: CALL OUT THE ACTION, NOT THE PERSON.
 */

export type FindingKind =
  | "phone"
  | "email"
  | "rego"
  | "street_address"
  | "social_handle"
  | "personal_profile_url"
  | "named_person"
  | "threat"
  | "child";

export type FindingSeverity = "block" | "warn" | "note";

export interface Finding {
  kind: FindingKind;
  severity: FindingSeverity;
  match: string;
  start: number;
  end: number;
  message: string;
}

export interface ScanResult {
  findings: Finding[];
  /** True if anything with severity "block" was found. */
  blocked: boolean;
  /** Text with masked matches for anything that can be auto-removed. */
  cleaned: string;
}

const PHONE = /(?:\+?61[ -]?|\(0\d\)[ -]?|0)(?:[23478](?:[ -]?\d){8}|1[38]00(?:[ -]?\d){6}|13(?:[ -]?\d){4})\b/g;
const EMAIL = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
// Australian registration plates are wildly varied. This catches the common shapes:
// ABC 123, ABC-12D, 1AB 2CD, 123 ABC, YAB 12C, S123 ABC. Requires a letter+digit mix.
const REGO =
  /\b(?:[A-Z]{2,3}[ -]?\d{2,3}[ -]?[A-Z]{0,2}|\d{3}[ -]?[A-Z]{3}|\d[A-Z]{2}[ -]?\d[A-Z]{2}|[A-Z]\d{3}[ -]?[A-Z]{3})\b/g;
const STREET =
  /\b\d{1,5}[A-Za-z]?(?:\/\d{1,4})?\s+(?:[A-Z][A-Za-z'-]+\s){1,3}(?:Street|St|Road|Rd|Avenue|Ave|Drive|Dr|Crescent|Cres|Court|Ct|Place|Pl|Lane|Ln|Way|Parade|Pde|Close|Cl|Boulevard|Blvd|Circuit|Cct|Terrace|Tce|Highway|Hwy|Grove|Gr|Esplanade|Esp|Loop|Rise|Walk|Track)\b\.?/g;
const HANDLE = /(^|[\s(])@[A-Za-z0-9_.]{3,30}\b/g;
const PROFILE_URL =
  /https?:\/\/(?:www\.|m\.)?(?:facebook\.com|fb\.com|instagram\.com|tiktok\.com|linkedin\.com\/in|x\.com|twitter\.com)\/[A-Za-z0-9_.-]{2,}(?!\/(?:posts|groups|share|videos|photo|reel)\b)/gi;
const NAMED =
  /\b(?:his|her|their) name is\s+[A-Z][a-z]+|\bnamed\s+[A-Z][a-z]+\b|\b(?:Mr|Mrs|Ms|Miss|Dr)\.?\s+[A-Z][a-z]{2,}\b/g;
const THREAT =
  /\b(?:i(?:'ll| will| am going to| wanna| want to)\s+(?:kill|bash|smash|punch|hurt|find|get|stab|run over)|(?:kill|bash|smash|punch|stab)\s+(?:him|her|them|you|the (?:prick|bastard|idiot|c\S+))|you(?:'re| are) dead|watch your back|i know where you live|burn (?:his|her|their|your) (?:car|house))\b/gi;
const CHILD = /\b(?:kid|kids|child|children|toddler|baby|school ?boy|school ?girl|student|teenager|teen)s?\b/gi;

interface Rule {
  kind: FindingKind;
  severity: FindingSeverity;
  regex: RegExp;
  message: string;
  mask?: string;
  /** Extra filter to reduce false positives. */
  accept?: (m: string, context: string) => boolean;
}

const RULES: Rule[] = [
  {
    kind: "threat",
    severity: "block",
    regex: THREAT,
    message: "That reads as a threat. DBAD calls out behaviour — it never threatens people.",
  },
  {
    kind: "phone",
    severity: "block",
    regex: PHONE,
    message: "Phone numbers are never published. Removed.",
    mask: "[phone removed]",
  },
  {
    kind: "email",
    severity: "block",
    regex: EMAIL,
    message: "Email addresses are never published. Removed.",
    mask: "[email removed]",
  },
  {
    kind: "personal_profile_url",
    severity: "block",
    regex: PROFILE_URL,
    message: "Links to personal profiles identify people. Removed.",
    mask: "[profile link removed]",
  },
  {
    kind: "social_handle",
    severity: "warn",
    regex: HANDLE,
    message: "Looks like a social-media handle. Don't identify people.",
    mask: "[handle removed]",
  },
  {
    kind: "street_address",
    severity: "warn",
    regex: STREET,
    message: "Looks like a street address. Public places are fine; residential addresses are not. Use the suburb instead.",
    mask: "[address removed]",
  },
  {
    kind: "rego",
    severity: "warn",
    regex: REGO,
    message: "Looks like a registration plate. Plates identify people — blur them in photos and leave them out of the text.",
    mask: "[rego removed]",
    accept: (m) => /[A-Z]/.test(m) && /\d/.test(m) && !/^(?:DBAD|COVID|ABN|GST|A\d{3})/i.test(m),
  },
  {
    kind: "named_person",
    severity: "warn",
    regex: NAMED,
    message: "Naming people isn't the DBAD way. Describe the behaviour instead.",
    mask: "[name removed]",
  },
  {
    kind: "child",
    severity: "note",
    regex: CHILD,
    message: "Mentions of children are fine when they were the ones affected — never publish anything that identifies a child.",
  },
];

export function scanText(input: string): ScanResult {
  const text = input ?? "";
  const findings: Finding[] = [];
  let cleaned = text;

  for (const rule of RULES) {
    rule.regex.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = rule.regex.exec(text)) !== null) {
      const match = m[0];
      if (rule.accept && !rule.accept(match, text)) continue;
      // Handles capture a leading space/paren — trim for display.
      const trimmed = match.trim();
      const start = m.index + (match.length - match.trimStart().length);
      findings.push({
        kind: rule.kind,
        severity: rule.severity,
        match: trimmed,
        start,
        end: start + trimmed.length,
        message: rule.message,
      });
      if (rule.mask) cleaned = cleaned.replace(trimmed, rule.mask);
      if (m.index === rule.regex.lastIndex) rule.regex.lastIndex++;
    }
  }

  // Dedupe overlapping findings (keep the most severe).
  const rank: Record<FindingSeverity, number> = { block: 3, warn: 2, note: 1 };
  findings.sort((a, b) => a.start - b.start || rank[b.severity] - rank[a.severity]);
  const merged: Finding[] = [];
  for (const f of findings) {
    const last = merged[merged.length - 1];
    if (last && f.start < last.end) continue;
    merged.push(f);
  }

  return {
    findings: merged,
    blocked: merged.some((f) => f.severity === "block" && f.kind === "threat"),
    cleaned: cleaned.replace(/\s{2,}/g, " ").trim(),
  };
}

/** Words that attack the person rather than the behaviour. Removed by the rewriter. */
export const PERSONAL_ATTACKS = [
  "idiot",
  "idiots",
  "moron",
  "morons",
  "prick",
  "pricks",
  "arsehole",
  "arseholes",
  "asshole",
  "assholes",
  "wanker",
  "wankers",
  "bastard",
  "bastards",
  "dickhead",
  "dickheads",
  "cunt",
  "cunts",
  "scum",
  "scumbag",
  "loser",
  "losers",
  "bogan",
  "bogans",
  "retard",
  "retarded",
  "psycho",
  "karen",
  "boomer",
  "fat",
  "ugly",
  "stupid",
  "dumb",
  "brain-dead",
  "braindead",
  "selfish",
  "entitled",
  "lazy",
  "trash",
  "scrote",
  "tosser",
  "muppet",
  "drongo",
  "galah",
];

export const PROFANITY = [
  "fuck",
  "fucking",
  "fucked",
  "fucker",
  "fuckin",
  "shit",
  "shitty",
  "bullshit",
  "bloody",
  "damn",
  "crap",
  "piss",
  "pissed",
  "bitch",
  "bitches",
  "goddamn",
  "friggin",
  "frigging",
  "effing",
];

const attackSet = new Set(PERSONAL_ATTACKS);
const profanitySet = new Set(PROFANITY);

/** Strips profanity and personal attacks while keeping the description of the behaviour. */
export function softenText(input: string): { text: string; removed: string[] } {
  const removed: string[] = [];
  const words = input.split(/(\s+)/);
  const out = words
    .map((w) => {
      if (/^\s+$/.test(w)) return w;
      const core = w.toLowerCase().replace(/^[^a-z]+|[^a-z]+$/g, "");
      if (attackSet.has(core) || profanitySet.has(core)) {
        removed.push(core);
        return "";
      }
      return w;
    })
    .join("")
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([,.!?;:])/g, "$1")
    .trim();
  return { text: out, removed };
}
