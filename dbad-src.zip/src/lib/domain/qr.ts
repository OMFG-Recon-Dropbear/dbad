/**
 * Dependency-free QR Code encoder (ISO/IEC 18004, model 2), byte mode, versions 1–10.
 *
 * Why hand-rolled: DBAD prints a QR on every notice and renders them in Open Graph
 * images, route handlers and the browser. One small, audited module with zero
 * dependencies beats pulling a library into three runtimes. Verified against
 * OpenCV's decoder by tools/qa/qr-verify.sh.
 */

export type EcLevel = "L" | "M" | "Q" | "H";

export interface QrMatrix {
  size: number;
  /** modules[row][col] === true means dark */
  modules: boolean[][];
  version: number;
  ecLevel: EcLevel;
  mask: number;
}

// [version][ecLevel] = { ec: codewords per block, groups: [[blocks, dataCodewords], ...] }
type BlockSpec = { ec: number; groups: Array<[number, number]> };
const EC_INDEX: Record<EcLevel, number> = { L: 0, M: 1, Q: 2, H: 3 };
const SPECS: BlockSpec[][] = [
  [], // version 0 placeholder
  [{ ec: 7, groups: [[1, 19]] }, { ec: 10, groups: [[1, 16]] }, { ec: 13, groups: [[1, 13]] }, { ec: 17, groups: [[1, 9]] }],
  [{ ec: 10, groups: [[1, 34]] }, { ec: 16, groups: [[1, 28]] }, { ec: 22, groups: [[1, 22]] }, { ec: 28, groups: [[1, 16]] }],
  [{ ec: 15, groups: [[1, 55]] }, { ec: 26, groups: [[1, 44]] }, { ec: 18, groups: [[2, 17]] }, { ec: 22, groups: [[2, 13]] }],
  [{ ec: 20, groups: [[1, 80]] }, { ec: 18, groups: [[2, 32]] }, { ec: 26, groups: [[2, 24]] }, { ec: 16, groups: [[4, 9]] }],
  [
    { ec: 26, groups: [[1, 108]] },
    { ec: 24, groups: [[2, 43]] },
    { ec: 18, groups: [[2, 15], [2, 16]] },
    { ec: 22, groups: [[2, 11], [2, 12]] },
  ],
  [{ ec: 18, groups: [[2, 68]] }, { ec: 16, groups: [[4, 27]] }, { ec: 24, groups: [[4, 19]] }, { ec: 28, groups: [[4, 15]] }],
  [
    { ec: 20, groups: [[2, 78]] },
    { ec: 18, groups: [[4, 31]] },
    { ec: 18, groups: [[2, 14], [4, 15]] },
    { ec: 26, groups: [[4, 13], [1, 14]] },
  ],
  [
    { ec: 24, groups: [[2, 97]] },
    { ec: 22, groups: [[2, 38], [2, 39]] },
    { ec: 22, groups: [[4, 18], [2, 19]] },
    { ec: 26, groups: [[4, 14], [2, 15]] },
  ],
  [
    { ec: 30, groups: [[2, 116]] },
    { ec: 22, groups: [[3, 36], [2, 37]] },
    { ec: 20, groups: [[4, 16], [4, 17]] },
    { ec: 24, groups: [[4, 12], [4, 13]] },
  ],
  [
    { ec: 18, groups: [[2, 68], [2, 69]] },
    { ec: 26, groups: [[4, 43], [1, 44]] },
    { ec: 24, groups: [[6, 19], [2, 20]] },
    { ec: 28, groups: [[6, 15], [2, 16]] },
  ],
];

const ALIGNMENT: number[][] = [
  [],
  [],
  [6, 18],
  [6, 22],
  [6, 26],
  [6, 30],
  [6, 34],
  [6, 22, 38],
  [6, 24, 42],
  [6, 26, 46],
  [6, 28, 50],
];

// ---- GF(256) arithmetic ----------------------------------------------------
const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    EXP[i] = x;
    LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255]!;
})();

function gfMul(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return EXP[LOG[a]! + LOG[b]!]!;
}

function rsGenerator(degree: number): Uint8Array {
  let poly = new Uint8Array([1]);
  for (let i = 0; i < degree; i++) {
    const next = new Uint8Array(poly.length + 1);
    for (let j = 0; j < poly.length; j++) {
      next[j] = (next[j] ?? 0) ^ poly[j]!;
      next[j + 1] = (next[j + 1] ?? 0) ^ gfMul(poly[j]!, EXP[i]!);
    }
    poly = next;
  }
  return poly;
}

function rsEncode(data: Uint8Array, ecCount: number): Uint8Array {
  const gen = rsGenerator(ecCount);
  const out = new Uint8Array(data.length + ecCount);
  out.set(data);
  for (let i = 0; i < data.length; i++) {
    const coef = out[i]!;
    if (coef === 0) continue;
    for (let j = 1; j < gen.length; j++) {
      out[i + j] = (out[i + j] ?? 0) ^ gfMul(gen[j]!, coef);
    }
  }
  return out.slice(data.length);
}

// ---- Bit buffer ------------------------------------------------------------
class BitBuffer {
  bits: number[] = [];
  put(value: number, length: number) {
    for (let i = length - 1; i >= 0; i--) this.bits.push((value >>> i) & 1);
  }
  get length() {
    return this.bits.length;
  }
}

function dataCapacity(version: number, ec: EcLevel): number {
  const spec = SPECS[version]![EC_INDEX[ec]]!;
  return spec.groups.reduce((acc, [blocks, cw]) => acc + blocks * cw, 0);
}

function chooseVersion(byteLength: number, ec: EcLevel): number {
  for (let v = 1; v <= 10; v++) {
    const ccBits = v <= 9 ? 8 : 16;
    const needed = 4 + ccBits + byteLength * 8;
    if (needed <= dataCapacity(v, ec) * 8) return v;
  }
  throw new Error("QR payload too long for versions 1–10 (max ~271 bytes at level M)");
}

function encodeToBytes(text: string, ec: EcLevel): { version: number; codewords: Uint8Array } {
  const bytes = new TextEncoder().encode(text);
  const version = chooseVersion(bytes.length, ec);
  const capacity = dataCapacity(version, ec);
  const bb = new BitBuffer();
  bb.put(0b0100, 4);
  bb.put(bytes.length, version <= 9 ? 8 : 16);
  for (const b of bytes) bb.put(b, 8);
  // terminator
  const maxBits = capacity * 8;
  bb.put(0, Math.min(4, maxBits - bb.length));
  while (bb.length % 8 !== 0) bb.bits.push(0);
  const pads = [0xec, 0x11];
  for (let i = 0; bb.length < maxBits; i++) bb.put(pads[i % 2]!, 8);
  const data = new Uint8Array(capacity);
  for (let i = 0; i < capacity; i++) {
    let v = 0;
    for (let b = 0; b < 8; b++) v = (v << 1) | bb.bits[i * 8 + b]!;
    data[i] = v;
  }

  // Split into blocks, compute EC, interleave.
  const spec = SPECS[version]![EC_INDEX[ec]]!;
  const blocks: Uint8Array[] = [];
  const ecBlocks: Uint8Array[] = [];
  let offset = 0;
  for (const [count, cw] of spec.groups) {
    for (let i = 0; i < count; i++) {
      const block = data.slice(offset, offset + cw);
      offset += cw;
      blocks.push(block);
      ecBlocks.push(rsEncode(block, spec.ec));
    }
  }
  const maxLen = Math.max(...blocks.map((b) => b.length));
  const out: number[] = [];
  for (let i = 0; i < maxLen; i++) {
    for (const b of blocks) if (i < b.length) out.push(b[i]!);
  }
  for (let i = 0; i < spec.ec; i++) {
    for (const e of ecBlocks) out.push(e[i]!);
  }
  return { version, codewords: new Uint8Array(out) };
}

// ---- Matrix ----------------------------------------------------------------
function makeMatrix(size: number): { grid: (boolean | null)[][]; fn: boolean[][] } {
  const grid: (boolean | null)[][] = [];
  const fn: boolean[][] = [];
  for (let r = 0; r < size; r++) {
    grid.push(new Array<boolean | null>(size).fill(null));
    fn.push(new Array<boolean>(size).fill(false));
  }
  return { grid, fn };
}

function setFn(m: ReturnType<typeof makeMatrix>, r: number, c: number, dark: boolean) {
  if (r < 0 || c < 0 || r >= m.grid.length || c >= m.grid.length) return;
  m.grid[r]![c] = dark;
  m.fn[r]![c] = true;
}

function drawFinder(m: ReturnType<typeof makeMatrix>, row: number, col: number) {
  for (let r = -1; r <= 7; r++) {
    for (let c = -1; c <= 7; c++) {
      const rr = row + r;
      const cc = col + c;
      if (rr < 0 || cc < 0 || rr >= m.grid.length || cc >= m.grid.length) continue;
      const outer = r === -1 || r === 7 || c === -1 || c === 7;
      const ring = r === 0 || r === 6 || c === 0 || c === 6;
      const core = r >= 2 && r <= 4 && c >= 2 && c <= 4;
      setFn(m, rr, cc, !outer && (ring || core));
    }
  }
}

function drawAlignment(m: ReturnType<typeof makeMatrix>, row: number, col: number) {
  for (let r = -2; r <= 2; r++) {
    for (let c = -2; c <= 2; c++) {
      const dark = Math.max(Math.abs(r), Math.abs(c)) !== 1;
      setFn(m, row + r, col + c, dark);
    }
  }
}

function bch(value: number, poly: number, bits: number): number {
  // returns value shifted with BCH remainder appended
  const degree = 31 - Math.clz32(poly);
  let v = value << (degree);
  for (let i = bits - 1; i >= degree; i--) {
    if ((v >>> i) & 1) v ^= poly << (i - degree);
  }
  return (value << degree) | v;
}

function formatBits(ec: EcLevel, mask: number): number {
  const ecBits: Record<EcLevel, number> = { L: 1, M: 0, Q: 3, H: 2 };
  const data = (ecBits[ec] << 3) | mask;
  return bch(data, 0x537, 15) ^ 0x5412;
}

function versionBits(version: number): number {
  return bch(version, 0x1f25, 18);
}

function drawFunctionPatterns(m: ReturnType<typeof makeMatrix>, version: number) {
  const size = m.grid.length;
  drawFinder(m, 0, 0);
  drawFinder(m, 0, size - 7);
  drawFinder(m, size - 7, 0);
  // timing
  for (let i = 8; i < size - 8; i++) {
    setFn(m, 6, i, i % 2 === 0);
    setFn(m, i, 6, i % 2 === 0);
  }
  // alignment
  const pos = ALIGNMENT[version] ?? [];
  for (const r of pos) {
    for (const c of pos) {
      const nearFinder =
        (r === 6 && c === 6) || (r === 6 && c === size - 7) || (r === size - 7 && c === 6);
      if (nearFinder) continue;
      drawAlignment(m, r, c);
    }
  }
  // dark module
  setFn(m, size - 8, 8, true);
  // reserve format areas
  for (let i = 0; i < 9; i++) {
    if (!m.fn[8]![i]) setFn(m, 8, i, false);
    if (!m.fn[i]![8]) setFn(m, i, 8, false);
  }
  for (let i = size - 8; i < size; i++) {
    setFn(m, 8, i, false);
    setFn(m, i, 8, false);
  }
  // reserve version areas
  if (version >= 7) {
    for (let i = 0; i < 6; i++) {
      for (let j = 0; j < 3; j++) {
        setFn(m, i, size - 11 + j, false);
        setFn(m, size - 11 + j, i, false);
      }
    }
  }
}

function drawFormat(m: ReturnType<typeof makeMatrix>, ec: EcLevel, mask: number) {
  const size = m.grid.length;
  const bits = formatBits(ec, mask);
  for (let i = 0; i < 15; i++) {
    const dark = ((bits >>> i) & 1) === 1;
    // around top-left finder
    if (i < 6) m.grid[i]![8] = dark;
    else if (i < 8) m.grid[i + 1]![8] = dark;
    else if (i === 8) m.grid[8]![7] = dark;
    else m.grid[8]![14 - i] = dark;
    // second copy
    if (i < 8) m.grid[8]![size - 1 - i] = dark;
    else m.grid[size - 15 + i]![8] = dark;
  }
  m.grid[size - 8]![8] = true; // dark module always dark
}

function drawVersion(m: ReturnType<typeof makeMatrix>, version: number) {
  if (version < 7) return;
  const size = m.grid.length;
  const bits = versionBits(version);
  for (let i = 0; i < 18; i++) {
    const dark = ((bits >>> i) & 1) === 1;
    const a = Math.floor(i / 3);
    const b = (i % 3) + size - 11;
    m.grid[a]![b] = dark;
    m.grid[b]![a] = dark;
  }
}

function placeData(m: ReturnType<typeof makeMatrix>, codewords: Uint8Array) {
  const size = m.grid.length;
  let bitIndex = 0;
  const totalBits = codewords.length * 8;
  let upward = true;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) {
      const row = upward ? size - 1 - vert : vert;
      for (let j = 0; j < 2; j++) {
        const col = right - j;
        if (m.fn[row]![col]) continue;
        let dark = false;
        if (bitIndex < totalBits) {
          dark = ((codewords[bitIndex >>> 3]! >>> (7 - (bitIndex & 7))) & 1) === 1;
          bitIndex++;
        }
        m.grid[row]![col] = dark;
      }
    }
    upward = !upward;
  }
}

function maskBit(mask: number, r: number, c: number): boolean {
  switch (mask) {
    case 0:
      return (r + c) % 2 === 0;
    case 1:
      return r % 2 === 0;
    case 2:
      return c % 3 === 0;
    case 3:
      return (r + c) % 3 === 0;
    case 4:
      return (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0;
    case 5:
      return ((r * c) % 2) + ((r * c) % 3) === 0;
    case 6:
      return (((r * c) % 2) + ((r * c) % 3)) % 2 === 0;
    default:
      return (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
  }
}

function applyMask(m: ReturnType<typeof makeMatrix>, mask: number): boolean[][] {
  const size = m.grid.length;
  const out: boolean[][] = [];
  for (let r = 0; r < size; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < size; c++) {
      const v = m.grid[r]![c] ?? false;
      row.push(m.fn[r]![c] ? v : v !== maskBit(mask, r, c));
    }
    out.push(row);
  }
  return out;
}

function penalty(modules: boolean[][]): number {
  const size = modules.length;
  let score = 0;
  // Rule 1: runs of 5+
  for (let r = 0; r < size; r++) {
    let runColor = modules[r]![0]!;
    let run = 1;
    for (let c = 1; c < size; c++) {
      if (modules[r]![c] === runColor) {
        run++;
        if (run === 5) score += 3;
        else if (run > 5) score += 1;
      } else {
        runColor = modules[r]![c]!;
        run = 1;
      }
    }
  }
  for (let c = 0; c < size; c++) {
    let runColor = modules[0]![c]!;
    let run = 1;
    for (let r = 1; r < size; r++) {
      if (modules[r]![c] === runColor) {
        run++;
        if (run === 5) score += 3;
        else if (run > 5) score += 1;
      } else {
        runColor = modules[r]![c]!;
        run = 1;
      }
    }
  }
  // Rule 2: 2x2 blocks
  for (let r = 0; r < size - 1; r++) {
    for (let c = 0; c < size - 1; c++) {
      const v = modules[r]![c];
      if (v === modules[r]![c + 1] && v === modules[r + 1]![c] && v === modules[r + 1]![c + 1]) score += 3;
    }
  }
  // Rule 3: finder-like patterns
  const pat1 = [true, false, true, true, true, false, true, false, false, false, false];
  const pat2 = [false, false, false, false, true, false, true, true, true, false, true];
  const matches = (get: (i: number) => boolean | undefined, start: number) => {
    let a = true;
    let b = true;
    for (let k = 0; k < 11; k++) {
      const v = get(start + k);
      if (v !== pat1[k]) a = false;
      if (v !== pat2[k]) b = false;
      if (!a && !b) return false;
    }
    return a || b;
  };
  for (let r = 0; r < size; r++) {
    for (let c = 0; c <= size - 11; c++) {
      if (matches((i) => modules[r]![i], c)) score += 40;
      if (matches((i) => modules[i]![r], c)) score += 40;
    }
  }
  // Rule 4: dark proportion
  let dark = 0;
  for (const row of modules) for (const v of row) if (v) dark++;
  const percent = (dark * 100) / (size * size);
  const k = Math.floor(Math.abs(percent - 50) / 5);
  score += k * 10;
  return score;
}

export function encodeQr(text: string, ecLevel: EcLevel = "M"): QrMatrix {
  const { version, codewords } = encodeToBytes(text, ecLevel);
  const size = version * 4 + 17;
  const m = makeMatrix(size);
  drawFunctionPatterns(m, version);
  placeData(m, codewords);
  let best: { mask: number; modules: boolean[][]; score: number } | null = null;
  for (let mask = 0; mask < 8; mask++) {
    drawFormat(m, ecLevel, mask);
    drawVersion(m, version);
    const modules = applyMask(m, mask);
    const score = penalty(modules);
    if (!best || score < best.score) best = { mask, modules, score };
  }
  return { size, modules: best!.modules, version, ecLevel, mask: best!.mask };
}

export interface QrSvgOptions {
  /** Size of the SVG in CSS px (viewBox stays in modules). */
  size?: number;
  /** Quiet zone in modules. Spec minimum is 4. */
  margin?: number;
  dark?: string;
  light?: string | "none";
  ecLevel?: EcLevel;
  /** Round the module corners slightly for a friendlier look. */
  rounded?: boolean;
}

/** Path data (in module units, origin includes margin) for all dark modules. */
export function qrPath(q: QrMatrix, margin = 4): string {
  const parts: string[] = [];
  for (let r = 0; r < q.size; r++) {
    let c = 0;
    while (c < q.size) {
      if (!q.modules[r]![c]) {
        c++;
        continue;
      }
      let run = 1;
      while (c + run < q.size && q.modules[r]![c + run]) run++;
      parts.push(`M${c + margin} ${r + margin}h${run}v1h-${run}z`);
      c += run;
    }
  }
  return parts.join("");
}

export function qrSvg(text: string, opts: QrSvgOptions = {}): string {
  const { size = 160, margin = 4, dark = "#0f0f0f", light = "#ffffff", ecLevel = "M" } = opts;
  const q = encodeQr(text, ecLevel);
  const dim = q.size + margin * 2;
  const bg = light === "none" ? "" : `<rect width="${dim}" height="${dim}" fill="${light}"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${dim} ${dim}" shape-rendering="crispEdges" role="img" aria-label="QR code">${bg}<path d="${qrPath(q, margin)}" fill="${dark}"/></svg>`;
}

/** Bitmap rectangles for renderers that can't use paths (pdf-lib). Module units. */
export function qrRects(q: QrMatrix): Array<{ x: number; y: number; w: number }> {
  const out: Array<{ x: number; y: number; w: number }> = [];
  for (let r = 0; r < q.size; r++) {
    let c = 0;
    while (c < q.size) {
      if (!q.modules[r]![c]) {
        c++;
        continue;
      }
      let run = 1;
      while (c + run < q.size && q.modules[r]![c + run]) run++;
      out.push({ x: c, y: r, w: run });
      c += run;
    }
  }
  return out;
}
