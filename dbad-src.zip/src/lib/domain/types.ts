/**
 * DBAD domain types.
 *
 * These mirror the PostgreSQL schema in /supabase/migrations but are written for the
 * application: camelCase, denormalised where the UI needs it, and independent of any
 * data source so the same components work against Supabase or the in-memory demo store.
 *
 * Guiding rule baked into the model: we record BEHAVIOUR, not PEOPLE. There is no
 * entity for "the person who did the dick move" and there never will be.
 */

export type AustralianState = "NSW" | "VIC" | "QLD" | "WA" | "SA" | "TAS" | "ACT" | "NT";

export type Role = "member" | "moderator" | "admin";

export type IncidentKind = "dick_move" | "not_a_dick";

/** Lifecycle of the behaviour itself. */
export type IncidentStatus = "open" | "redeemed" | "overruled";

/** Lifecycle of the post on the platform. Only `approved` is public. */
export type ModerationStatus = "pending" | "approved" | "rejected" | "removed";

export type Verdict = "not" | "bit" | "definitely" | "absolute";

export type ReactionKind = "fair_call" | "classic" | "dick_move" | "redemption";

export type CategoryId =
  | "parking"
  | "road"
  | "shopping"
  | "neighbourhood"
  | "rubbish"
  | "dog"
  | "internet"
  | "workplace"
  | "other";

export type AffectedGroup =
  | "pedestrians"
  | "wheelchair_users"
  | "parents_prams"
  | "cyclists"
  | "neighbours"
  | "motorists"
  | "local_businesses"
  | "the_community"
  | "everyone"
  | "probably_nobody";

export type PartOfDay = "morning" | "midday" | "afternoon" | "evening" | "night" | "unknown";

export type NoticeTemplateId =
  | "official-warning"
  | "friendly-reminder"
  | "maximum-dickery"
  | "public-service"
  | "minimal";

export type NoticeLinkMode = "site" | "incident";

export type ReportReason =
  | "identifies_person"
  | "private_address"
  | "harassment"
  | "defamatory"
  | "children"
  | "not_a_dick_move"
  | "duplicate"
  | "spam"
  | "other";

export type AppealAction =
  | "removal"
  | "correction"
  | "anonymisation"
  | "context"
  | "reply"
  | "redemption";

export type AppealStatus = "open" | "in_review" | "actioned" | "declined";

export type ReportStatus = "open" | "reviewing" | "resolved" | "dismissed";

export type ModerationActionKind =
  | "approve"
  | "reject"
  | "remove"
  | "restore"
  | "anonymise"
  | "redact_photo"
  | "mark_redeemed"
  | "mark_overruled"
  | "feature_week"
  | "unfeature"
  | "hide_comment"
  | "restore_comment"
  | "resolve_report"
  | "dismiss_report"
  | "action_appeal"
  | "decline_appeal"
  | "publish_reply"
  | "change_role"
  | "edit_category"
  | "edit_template";

export type BadgeId =
  | "eagle_eye"
  | "fair_dinkum"
  | "redemption_arc"
  | "not_actually_a_karen"
  | "local_legend"
  | "first_call";

export type NotificationKind =
  | "verdict_reached"
  | "featured"
  | "redeemed"
  | "comment"
  | "badge"
  | "moderation"
  | "appeal_update";

export interface Profile {
  id: string;
  handle: string;
  displayName: string;
  /** Deterministic seed for the generated sticker avatar. */
  avatarSeed: string;
  role: Role;
  memberSince: string; // ISO date
  bio?: string;
  homeArea?: string; // e.g. "South Coast, NSW" — chosen by the member, never precise
}

export interface ProfileStats {
  spotted: number; // approved nominations
  fairCalls: number; // nominations where the community verdict agreed
  redeemed: number; // nominations that ended in redemption
  overruled: number; // nominations the community rejected
  notADick: number; // positive nominations
  comments: number;
}

export interface Badge {
  id: BadgeId;
  name: string;
  blurb: string;
  rule: string;
}

export interface UserBadge {
  badgeId: BadgeId;
  awardedAt: string;
}

export interface Category {
  id: CategoryId;
  /** Loud label: "PARKING DICK" */
  label: string;
  /** Short label for chips: "Parking" */
  short: string;
  blurb: string;
  /** Optional guard-rail copy shown in the wizard. */
  caution?: string;
  /** Tailwind colour token used for accents (bg-*, text-*). */
  accent: "warning" | "alert" | "concrete" | "redeem";
}

export interface Location {
  id: string;
  /** Suburb or town. Required. */
  suburb: string;
  state: AustralianState;
  /** Public place when clearly public (a car park, beach, road, shopping centre). */
  place?: string;
  /**
   * Approximate coordinates snapped to the suburb/town centroid. Never a residential
   * address. Precision is recorded so the map can be honest about it.
   */
  approxLat?: number;
  approxLng?: number;
  precision: "suburb" | "place";
  /** Region used for clustering: "Canberra", "South Coast NSW", "Greater Sydney". */
  region: string;
}

export interface Photo {
  id: string;
  url: string;
  width: number;
  height: number;
  alt: string;
  /** Whether the image has passed redaction review. Unreviewed photos never go public. */
  redacted: boolean;
  redactionCount: number;
}

export interface SocialSource {
  platform: "facebook";
  url: string;
  /** How the content got here. DBAD never scrapes Facebook. */
  retrievedVia: "manual" | "oembed";
  note?: string;
}

export interface VoteTally {
  not: number;
  bit: number;
  definitely: number;
  absolute: number;
}

export interface ReactionTally {
  fair_call: number;
  classic: number;
  dick_move: number;
  redemption: number;
}

export interface Redemption {
  id: string;
  incidentId: string;
  note: string;
  confirmedBy: "submitter" | "moderator" | "community";
  createdAt: string;
}

export interface Incident {
  id: string;
  /** Human short code, printed on notices: DBAD-0042 */
  shortCode: string;
  slug: string;
  kind: IncidentKind;
  categoryId: CategoryId;
  /** The one-liner shown on cards. Humour lives here. */
  title: string;
  /** The dick move, stated plainly: "Blocking the footpath." */
  dickMove: string;
  /** Why it mattered, factual and short. */
  description: string;
  affected: AffectedGroup[];
  location: Location;
  occurredOn: string; // ISO date (day precision only — no exact timestamps for privacy)
  partOfDay: PartOfDay;
  createdAt: string; // ISO datetime
  submitterId: string | null; // null once anonymised
  photos: Photo[];
  socialSource?: SocialSource;
  status: IncidentStatus;
  moderationStatus: ModerationStatus;
  anonymised: boolean;
  featuredWeek?: string; // ISO Monday date when Dick Move of the Week
  votes: VoteTally;
  reactions: ReactionTally;
  commentCount: number;
  redemption?: Redemption;
  /** Stored community advice line for notices. */
  advice?: string;
}

export interface Comment {
  id: string;
  incidentId: string;
  authorId: string;
  body: string;
  createdAt: string;
  status: "visible" | "hidden" | "removed";
  parentId?: string;
}

export interface Report {
  id: string;
  targetType: "incident" | "comment";
  targetId: string;
  reason: ReportReason;
  details?: string;
  reporterId?: string;
  status: ReportStatus;
  createdAt: string;
  resolvedAt?: string;
  resolvedBy?: string;
}

export interface Appeal {
  id: string;
  incidentId: string;
  requestedAction: AppealAction;
  message: string;
  /** Private contact for follow-up. Never shown publicly. */
  contact?: string;
  status: AppealStatus;
  /** Optional right-of-reply text published beneath the nomination. */
  publicReply?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface ModerationAction {
  id: string;
  actorId: string;
  action: ModerationActionKind;
  targetType: "incident" | "comment" | "report" | "appeal" | "user" | "category" | "template" | "photo";
  targetId: string;
  note?: string;
  createdAt: string;
}

export interface NoticeLines {
  headline: string; // "YOU HAVE BEEN DBAD'D."
  dickMove: string; // "Parking across a public footpath."
  why: string; // "People shouldn't have to walk onto the road because you couldn't park properly."
  location: string; // "Batemans Bay, NSW"
  advice: string; // "Do better next time."
}

export interface PrintableNotice {
  id: string;
  incidentId?: string;
  template: NoticeTemplateId;
  linkMode: NoticeLinkMode;
  lines: NoticeLines;
  createdAt: string;
  createdBy?: string;
}

export interface Notification {
  id: string;
  userId: string;
  kind: NotificationKind;
  title: string;
  body: string;
  href?: string;
  createdAt: string;
  readAt?: string;
}

/** Shape used by feed cards and lists — the incident plus what the UI needs beside it. */
export interface IncidentSummary extends Incident {
  category: Category;
  submitter?: Pick<Profile, "handle" | "displayName" | "avatarSeed"> | null;
}

export interface IncidentDetail extends IncidentSummary {
  comments: Array<Comment & { author: Pick<Profile, "handle" | "displayName" | "avatarSeed"> }>;
  publicReplies: Array<Pick<Appeal, "id" | "publicReply" | "createdAt">>;
  viewerVote?: Verdict;
  viewerReactions?: ReactionKind[];
}

export interface FeedFilters {
  kind?: IncidentKind;
  categoryId?: CategoryId;
  state?: AustralianState;
  region?: string;
  status?: IncidentStatus;
  sort?: "latest" | "top" | "redeemed";
  query?: string;
  limit?: number;
  cursor?: string;
}

export interface FeedPage {
  items: IncidentSummary[];
  nextCursor?: string;
  total: number;
}

export interface MapCluster {
  region: string;
  state: AustralianState;
  approxLat: number;
  approxLng: number;
  count: number;
  countThisWeek: number;
  redeemed: number;
  notADick: number;
  topCategoryId: CategoryId;
}

export interface AdminStats {
  dickMovesToday: number;
  dickMovesThisWeek: number;
  redemptions: number;
  pendingModeration: number;
  reportedContent: number;
  openAppeals: number;
  mostActiveAreas: Array<{ region: string; count: number }>;
  mostCommonCategories: Array<{ categoryId: CategoryId; count: number }>;
  membersTotal: number;
  notADickThisWeek: number;
}

/** Everything the nomination wizard sends to the server. */
export interface NominationInput {
  kind: IncidentKind;
  categoryId: CategoryId;
  dickMove: string;
  title: string;
  description: string;
  affected: AffectedGroup[];
  location: {
    suburb: string;
    state: AustralianState;
    place?: string;
    approxLat?: number;
    approxLng?: number;
  };
  occurredOn: string;
  partOfDay: PartOfDay;
  photos: Array<{
    /** data: URL (demo) or storage path (supabase). Already redacted & downscaled client-side. */
    src: string;
    width: number;
    height: number;
    alt: string;
    redactionCount: number;
  }>;
  facebookUrl?: string;
  /** Submitter confirms the community standard. */
  acceptedStandard: boolean;
  /** Submitter confirms they reviewed the redaction step. */
  reviewedRedaction: boolean;
}

export interface ActionResult<T = undefined> {
  ok: boolean;
  message?: string;
  data?: T;
  fieldErrors?: Record<string, string>;
}
