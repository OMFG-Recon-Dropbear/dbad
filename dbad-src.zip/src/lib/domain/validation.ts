import { AUSTRALIAN_STATES, CATEGORY_MAP, AFFECTED_LABEL, PART_OF_DAY_LABEL } from "./categories";
import { scanText } from "./pii";
import type { ActionResult, NominationInput } from "./types";

/**
 * Hand-rolled validation (no schema library) so the same rules run in the browser,
 * in Server Actions and in the preview harness with zero dependencies.
 */

export const LIMITS = {
  dickMove: { min: 4, max: 90 },
  title: { min: 4, max: 120 },
  description: { min: 12, max: 600 },
  suburb: { min: 2, max: 60 },
  place: { max: 80 },
  photos: 4,
  comment: { min: 2, max: 600 },
};

const FACEBOOK_URL = /^https?:\/\/(?:www\.|m\.|web\.)?(?:facebook\.com|fb\.com|fb\.watch)\/.+/i;

export function isFacebookUrl(url: string): boolean {
  return FACEBOOK_URL.test(url.trim());
}

export function validateNomination(input: NominationInput): ActionResult<never> {
  const errors: Record<string, string> = {};

  if (!input || typeof input !== "object") return { ok: false, message: "Nothing received." };
  if (input.kind !== "dick_move" && input.kind !== "not_a_dick") errors.kind = "Pick a kind of nomination.";
  if (!CATEGORY_MAP[input.categoryId]) errors.categoryId = "Pick a category.";

  const dickMove = (input.dickMove ?? "").trim();
  if (dickMove.length < LIMITS.dickMove.min) errors.dickMove = "Say what the dick move was, in a few words.";
  else if (dickMove.length > LIMITS.dickMove.max) errors.dickMove = `Keep it under ${LIMITS.dickMove.max} characters.`;

  const title = (input.title ?? "").trim();
  if (title.length < LIMITS.title.min) errors.title = "Give it a one-liner.";
  else if (title.length > LIMITS.title.max) errors.title = `Keep it under ${LIMITS.title.max} characters.`;

  const description = (input.description ?? "").trim();
  if (description.length < LIMITS.description.min) errors.description = "Tell us what made it a dick move — one or two factual sentences.";
  else if (description.length > LIMITS.description.max) errors.description = `Keep it under ${LIMITS.description.max} characters.`;

  for (const [field, value] of Object.entries({ dickMove, title, description })) {
    const scan = scanText(value);
    if (scan.blocked) errors[field] = "That reads as a threat. DBAD calls out behaviour, it never threatens people.";
    const identifying = scan.findings.filter((f) => f.severity === "block");
    if (identifying.length && !errors[field]) errors[field] = `Remove identifying details: ${identifying.map((f) => f.kind.replace(/_/g, " ")).join(", ")}.`;
  }

  if (!Array.isArray(input.affected)) errors.affected = "Who was affected?";
  else if (input.affected.some((a) => !(a in AFFECTED_LABEL))) errors.affected = "Unknown affected group.";

  const loc = input.location;
  if (!loc || typeof loc !== "object") errors.location = "Where did it happen?";
  else {
    const suburb = (loc.suburb ?? "").trim();
    if (suburb.length < LIMITS.suburb.min) errors.suburb = "Suburb or town, please.";
    if (suburb.length > LIMITS.suburb.max) errors.suburb = "That's a long suburb name.";
    if (!AUSTRALIAN_STATES.includes(loc.state)) errors.state = "Pick a state or territory.";
    if (loc.place && loc.place.length > LIMITS.place.max) errors.place = "Keep the place name short.";
    if (/\b\d{1,5}[A-Za-z]?\s+[A-Z][a-z]+\s+(?:St|Street|Rd|Road|Ave|Avenue|Dr|Drive|Cres|Crescent|Ct|Court|Pl|Place|Cl|Close)\b/.test(`${suburb} ${loc.place ?? ""}`)) {
      errors.place = "That looks like a street address. Use the suburb and, if it's clearly public, the place name (e.g. 'Coles car park').";
    }
    if (loc.approxLat != null && (loc.approxLat < -44 || loc.approxLat > -10)) errors.location = "Those coordinates aren't in Australia.";
    if (loc.approxLng != null && (loc.approxLng < 112 || loc.approxLng > 154)) errors.location = "Those coordinates aren't in Australia.";
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(input.occurredOn ?? "")) errors.occurredOn = "When did it happen?";
  else if (new Date(input.occurredOn).getTime() > Date.now() + 86_400_000) errors.occurredOn = "That's in the future. Impressive, but no.";
  if (!(input.partOfDay in PART_OF_DAY_LABEL)) errors.partOfDay = "Roughly what time of day?";

  if (!Array.isArray(input.photos)) errors.photos = "Photos must be a list.";
  else {
    if (input.photos.length > LIMITS.photos) errors.photos = `Up to ${LIMITS.photos} photos.`;
    for (const p of input.photos) {
      if (typeof p.src !== "string" || !(p.src.startsWith("data:image/") || p.src.startsWith("photos/") || p.src.startsWith("/") || p.src.startsWith("https://"))) {
        errors.photos = "A photo didn't upload properly. Try again.";
      }
      if (p.src.startsWith("data:image/") && p.src.length > 1_600_000) errors.photos = "A photo is too large. It should have been downscaled — try re-adding it.";
    }
  }

  if (input.facebookUrl && !isFacebookUrl(input.facebookUrl)) errors.facebookUrl = "That doesn't look like a Facebook post link.";
  if (!input.acceptedStandard) errors.acceptedStandard = "You need to agree to the community standard.";
  if (input.photos?.length > 0 && !input.reviewedRedaction) errors.reviewedRedaction = "Please review the redaction step before publishing photos.";

  if (Object.keys(errors).length) {
    return { ok: false, message: "A couple of things need fixing.", fieldErrors: errors };
  }
  return { ok: true };
}

export function validateComment(body: string): string | null {
  const t = body.trim();
  if (t.length < LIMITS.comment.min) return "Say something.";
  if (t.length > LIMITS.comment.max) return `Under ${LIMITS.comment.max} characters, please.`;
  const scan = scanText(t);
  if (scan.blocked) return "That crosses the line.";
  return null;
}
