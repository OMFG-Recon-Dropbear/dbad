import type { Verdict, VoteTally } from "./types";

/**
 * The Dick-o-meter.
 *
 * Every verdict maps to a dickery level between 0 and 1. The community score is the
 * mean level across all votes. It is deliberately simple and transparent — anyone can
 * work it out on the back of a beer coaster.
 */
export const VERDICT_LEVEL: Record<Verdict, number> = {
  not: 0,
  bit: 1 / 3,
  definitely: 2 / 3,
  absolute: 1,
};

export const VERDICT_ORDER: Verdict[] = ["not", "bit", "definitely", "absolute"];

export const VERDICT_LABEL: Record<Verdict, string> = {
  not: "Not a dick move",
  bit: "Bit of a dick move",
  definitely: "Definitely a dick move",
  absolute: "Absolute dickery",
};

export const VERDICT_SHORT: Record<Verdict, string> = {
  not: "Not a dick move",
  bit: "Bit of a dick move",
  definitely: "Definitely",
  absolute: "Absolute dickery",
};

/** Minimum votes before DBAD is willing to call it. */
export const MIN_VOTES_FOR_VERDICT = 5;

export interface VerdictSummary {
  total: number;
  /** 0–100 */
  percent: number;
  /** Share of voters who thought it was at least a bit of a dick move, 0–100. */
  agreePercent: number;
  band: Verdict | "pending";
  label: string;
  /** Short shareable line: "Community verdict: 94% Dick Move" */
  shareLine: string;
  distribution: Array<{ verdict: Verdict; count: number; percent: number }>;
}

export function totalVotes(t: VoteTally): number {
  return t.not + t.bit + t.definitely + t.absolute;
}

export function bandFor(percent: number): Verdict {
  if (percent < 25) return "not";
  if (percent < 50) return "bit";
  if (percent < 80) return "definitely";
  return "absolute";
}

export function summariseVotes(t: VoteTally): VerdictSummary {
  const total = totalVotes(t);
  const distribution = VERDICT_ORDER.map((v) => ({
    verdict: v,
    count: t[v],
    percent: total === 0 ? 0 : Math.round((t[v] / total) * 100),
  }));
  if (total < MIN_VOTES_FOR_VERDICT) {
    return {
      total,
      percent: 0,
      agreePercent: 0,
      band: "pending",
      label: total === 0 ? "No verdict yet" : "Jury's still out",
      shareLine: total === 0 ? "Be the first to cast a verdict." : `${total} verdict${total === 1 ? "" : "s"} in. Jury's still out.`,
      distribution,
    };
  }
  const score = VERDICT_ORDER.reduce((acc, v) => acc + t[v] * VERDICT_LEVEL[v], 0) / total;
  const percent = Math.round(score * 100);
  const agreePercent = Math.round(((t.bit + t.definitely + t.absolute) / total) * 100);
  const band = bandFor(percent);
  return {
    total,
    percent,
    agreePercent,
    band,
    label: VERDICT_LABEL[band],
    shareLine: `Community verdict: ${agreePercent}% Dick Move`,
    distribution,
  };
}

/** Applies a vote change to a tally without mutating the original. */
export function applyVote(t: VoteTally, next: Verdict, previous?: Verdict): VoteTally {
  const out = { ...t };
  if (previous) out[previous] = Math.max(0, out[previous] - 1);
  out[next] += 1;
  return out;
}

/** Ranks incidents for "Dick Move of the Week" — confidence-weighted dickery. */
export function dickeryRank(t: VoteTally): number {
  const total = totalVotes(t);
  if (total === 0) return 0;
  const score = VERDICT_ORDER.reduce((acc, v) => acc + t[v] * VERDICT_LEVEL[v], 0) / total;
  // Wilson-ish damping: small samples can't top the chart.
  const confidence = total / (total + 8);
  return score * confidence;
}
