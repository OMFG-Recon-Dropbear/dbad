import type {
  AppealWithIncident,
  AuditEntry,
  Repository,
  ReportWithTarget,
  UserRow,
} from "@/lib/data/repository";
import type { AdminStats, Appeal, Comment, IncidentSummary, Report } from "@/lib/domain/types";

/**
 * Loaders for the moderation dashboard.
 *
 * Same contract as every other loader in the app: they only ever talk to the Repository
 * interface and hand back a plain props object, so the Next.js pages and the preview
 * harness render exactly the same views against Supabase or the in-memory demo store.
 */

/** A comment as the admin lists see it (author + parent nomination attached). */
export type AdminComment = Awaited<ReturnType<Repository["listAllComments"]>>[number];

/** Badge counts for the admin sidebar. Keys are a subset of `AdminSection`. */
export interface AdminCounts {
  queue?: number;
  reports?: number;
  appeals?: number;
  comments?: number;
  nominations?: number;
  members?: number;
}

export interface AdminDashboardProps {
  stats: AdminStats;
  queue: IncidentSummary[];
  reports: ReportWithTarget[];
  appeals: AppealWithIncident[];
  audit: AuditEntry[];
}

export interface QueueProps {
  queue: IncidentSummary[];
}

export interface ReportsProps {
  reports: ReportWithTarget[];
  status?: Report["status"];
}

export interface AppealsProps {
  appeals: AppealWithIncident[];
  status?: Appeal["status"];
}

export interface AdminCommentsProps {
  comments: AdminComment[];
  status?: Comment["status"];
}

export interface AdminIncidentsProps {
  incidents: IncidentSummary[];
  status?: string;
  query?: string;
}

export interface MembersProps {
  members: UserRow[];
  query?: string;
}

export interface AuditProps {
  audit: AuditEntry[];
}

/** How many rows each dashboard "needs attention" panel shows. */
const DASHBOARD_LIMIT = 5;

const NEEDS_REPORT_ATTENTION: Array<Report["status"]> = ["open", "reviewing"];
const NEEDS_APPEAL_ATTENTION: Array<Appeal["status"]> = ["open", "in_review"];

export async function loadAdminDashboard(repo: Repository): Promise<AdminDashboardProps> {
  const [stats, queue, reports, appeals, audit] = await Promise.all([
    repo.getAdminStats(),
    repo.listModerationQueue(),
    repo.listReports(),
    repo.listAppeals(),
    repo.listAuditLog(8),
  ]);
  return {
    stats,
    queue: queue.slice(0, DASHBOARD_LIMIT),
    reports: reports.filter((r) => NEEDS_REPORT_ATTENTION.includes(r.status)).slice(0, DASHBOARD_LIMIT),
    appeals: appeals.filter((a) => NEEDS_APPEAL_ATTENTION.includes(a.status)).slice(0, DASHBOARD_LIMIT),
    audit,
  };
}

export async function loadQueue(repo: Repository): Promise<QueueProps> {
  return { queue: await repo.listModerationQueue() };
}

export async function loadReports(repo: Repository, status?: Report["status"]): Promise<ReportsProps> {
  return { reports: await repo.listReports(status), status };
}

export async function loadAppeals(repo: Repository, status?: Appeal["status"]): Promise<AppealsProps> {
  return { appeals: await repo.listAppeals(status), status };
}

export async function loadAdminComments(repo: Repository, status?: Comment["status"]): Promise<AdminCommentsProps> {
  return { comments: await repo.listAllComments({ status, limit: 200 }), status };
}

export async function loadAdminIncidents(
  repo: Repository,
  opts: { status?: string; query?: string } = {},
): Promise<AdminIncidentsProps> {
  const incidents = await repo.listAllIncidentsAdmin({ status: opts.status, query: opts.query, limit: 200 });
  return { incidents, status: opts.status, query: opts.query };
}

export async function loadMembers(repo: Repository, query?: string): Promise<MembersProps> {
  return { members: await repo.listUsers(query), query };
}

export async function loadAudit(repo: Repository): Promise<AuditProps> {
  return { audit: await repo.listAuditLog(120) };
}

/** Sidebar badge counts. One cheap call — the stats object already carries every total. */
export async function loadAdminCounts(repo: Repository): Promise<AdminCounts> {
  const stats = await repo.getAdminStats();
  return {
    queue: stats.pendingModeration,
    reports: stats.reportedContent,
    appeals: stats.openAppeals,
    members: stats.membersTotal,
  };
}

// ---------------------------------------------------------------------------
// Query-string parsing — shared by the Next pages and the preview harness so a
// hand-typed ?status= can never smuggle an unknown value into the repository.
// ---------------------------------------------------------------------------

const REPORT_STATUSES: Array<Report["status"]> = ["open", "reviewing", "resolved", "dismissed"];
const APPEAL_STATUSES: Array<Appeal["status"]> = ["open", "in_review", "actioned", "declined"];
const COMMENT_STATUSES: Array<Comment["status"]> = ["visible", "hidden", "removed"];
const INCIDENT_ADMIN_STATUSES = ["pending", "approved", "rejected", "removed", "open", "redeemed", "overruled"] as const;

export function parseReportStatus(value?: string | null): Report["status"] | undefined {
  return REPORT_STATUSES.find((s) => s === value);
}

export function parseAppealStatus(value?: string | null): Appeal["status"] | undefined {
  return APPEAL_STATUSES.find((s) => s === value);
}

export function parseCommentStatus(value?: string | null): Comment["status"] | undefined {
  return COMMENT_STATUSES.find((s) => s === value);
}

export function parseIncidentAdminStatus(value?: string | null): string | undefined {
  return INCIDENT_ADMIN_STATUSES.find((s) => s === value);
}
