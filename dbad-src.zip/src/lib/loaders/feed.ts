import type { Repository, ViewerOrNull } from "@/lib/data/repository";
import type { AustralianState, CategoryId, FeedFilters, FeedPage, IncidentKind, IncidentStatus, MapCluster } from "@/lib/domain/types";
import { AUSTRALIAN_STATES, CATEGORY_MAP } from "@/lib/domain/categories";

export interface FeedProps {
  page: FeedPage;
  filters: FeedFilters;
  clusters: MapCluster[];
  viewer: ViewerOrNull;
  /** Base path so the same view serves /feed and /not-a-dick */
  basePath: string;
  kind: IncidentKind;
}

export type SearchParams = Record<string, string | string[] | undefined>;

function first(v: string | string[] | undefined): string | undefined {
  return Array.isArray(v) ? v[0] : v;
}

export function parseFeedFilters(sp: SearchParams, kind: IncidentKind): FeedFilters {
  const category = first(sp.category);
  const state = first(sp.state);
  const status = first(sp.status);
  const sort = first(sp.sort);
  const region = first(sp.region);
  const q = first(sp.q);
  const cursor = first(sp.cursor);
  return {
    kind,
    categoryId: category && category in CATEGORY_MAP ? (category as CategoryId) : undefined,
    state: state && (AUSTRALIAN_STATES as readonly string[]).includes(state) ? (state as AustralianState) : undefined,
    status: status === "redeemed" || status === "open" || status === "overruled" ? (status as IncidentStatus) : undefined,
    sort: sort === "top" || sort === "redeemed" ? sort : "latest",
    region: region || undefined,
    query: q?.trim() || undefined,
    cursor: cursor || undefined,
    limit: 12,
  };
}

export function feedHref(basePath: string, filters: FeedFilters, patch: Partial<FeedFilters> = {}): string {
  const f = { ...filters, ...patch, cursor: patch.cursor ?? undefined };
  const p = new URLSearchParams();
  if (f.categoryId) p.set("category", f.categoryId);
  if (f.state) p.set("state", f.state);
  if (f.status) p.set("status", f.status);
  if (f.sort && f.sort !== "latest") p.set("sort", f.sort);
  if (f.region) p.set("region", f.region);
  if (f.query) p.set("q", f.query);
  if (f.cursor) p.set("cursor", f.cursor);
  const qs = p.toString();
  return qs ? `${basePath}?${qs}` : basePath;
}

export async function loadFeed(repo: Repository, viewer: ViewerOrNull, sp: SearchParams, kind: IncidentKind, basePath: string): Promise<FeedProps> {
  const filters = parseFeedFilters(sp, kind);
  const [page, clusters] = await Promise.all([repo.listIncidents(filters, viewer), repo.getMapClusters()]);
  return { page, filters, clusters, viewer, basePath, kind };
}
