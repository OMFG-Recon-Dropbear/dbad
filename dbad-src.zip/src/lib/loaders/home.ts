import type { Repository, FeaturedSet, ViewerOrNull } from "@/lib/data/repository";
import type { IncidentSummary, MapCluster } from "@/lib/domain/types";

export interface HomeProps {
  featured: FeaturedSet;
  latest: IncidentSummary[];
  clusters: MapCluster[];
  totals: { moves: number; redeemed: number; notADick: number; regions: number };
  viewer: ViewerOrNull;
}

export async function loadHome(repo: Repository, viewer: ViewerOrNull): Promise<HomeProps> {
  const [featured, latestPage, clusters, all, redeemed, positive] = await Promise.all([
    repo.getFeatured(),
    repo.listIncidents({ kind: "dick_move", sort: "latest", limit: 7 }, viewer),
    repo.getMapClusters(),
    repo.listIncidents({ kind: "dick_move", limit: 1 }, viewer),
    repo.listIncidents({ status: "redeemed", limit: 1 }, viewer),
    repo.listIncidents({ kind: "not_a_dick", limit: 1 }, viewer),
  ]);
  return {
    featured,
    latest: latestPage.items.filter((i) => i.id !== featured.week?.id),
    clusters,
    totals: { moves: all.total, redeemed: redeemed.total, notADick: positive.total, regions: clusters.length },
    viewer,
  };
}
