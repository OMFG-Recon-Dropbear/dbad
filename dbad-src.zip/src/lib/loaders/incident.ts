import type { Repository, ViewerOrNull } from "@/lib/data/repository";
import type { IncidentDetail, IncidentSummary } from "@/lib/domain/types";

export interface IncidentPageProps {
  incident: IncidentDetail;
  related: IncidentSummary[];
  viewer: ViewerOrNull;
}

export async function loadIncident(repo: Repository, viewer: ViewerOrNull, slug: string): Promise<IncidentPageProps | null> {
  const incident = await repo.getIncidentBySlug(slug, viewer);
  if (!incident) return null;
  const related = await repo.listRelated(incident.id, 3);
  return { incident, related, viewer };
}
