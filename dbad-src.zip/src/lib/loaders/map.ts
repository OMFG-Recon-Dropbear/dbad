import type { Repository, ViewerOrNull } from "@/lib/data/repository";
import type { MapProps } from "@/components/map/map-view";

export async function loadMap(repo: Repository, viewer: ViewerOrNull, region?: string): Promise<MapProps> {
  const clusters = await repo.getMapClusters();
  const activeRegion = region && clusters.some((c) => c.region === region) ? region : undefined;
  const regionIncidents = activeRegion ? (await repo.listIncidents({ region: activeRegion, limit: 6 }, viewer)).items : [];
  return { clusters, activeRegion, regionIncidents };
}
