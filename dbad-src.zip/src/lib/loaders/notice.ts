import type { Repository, ViewerOrNull } from "@/lib/data/repository";
import type { IncidentDetail, PrintableNotice } from "@/lib/domain/types";
import { buildNoticeLines } from "@/lib/notice/lines";

export interface NoticeStudioProps {
  notice: PrintableNotice;
  incident: IncidentDetail | null;
  viewer: ViewerOrNull;
  /** True when the notice was just created for this session (not persisted by an owner). */
  fresh?: boolean;
}

/** Existing notice by id. */
export async function loadNotice(repo: Repository, viewer: ViewerOrNull, id: string): Promise<NoticeStudioProps | null> {
  const notice = await repo.getNotice(id);
  if (!notice) return null;
  const incident = notice.incidentId ? await repo.getIncidentById(notice.incidentId, viewer) : null;
  return { notice, incident, viewer };
}

/**
 * /notice/new?incident=<id> — creates a notice for an incident (or a blank standalone one)
 * and returns it. Standalone notices let anyone print a generic DBAD card.
 */
export async function createNoticeFor(repo: Repository, viewer: ViewerOrNull, incidentId?: string): Promise<NoticeStudioProps> {
  const incident = incidentId ? await repo.getIncidentById(incidentId, viewer) : null;
  const lines = incident
    ? buildNoticeLines(incident)
    : {
        headline: "YOU HAVE BEEN DBAD'D.",
        dickMove: "That was a dick move.",
        why: "Whatever it was, everyone else had to work around it.",
        location: "Australia",
        advice: "Do better next time.",
      };
  const notice = await repo.createNotice(
    {
      incidentId: incident?.id,
      template: incident?.kind === "not_a_dick" ? "friendly-reminder" : "official-warning",
      linkMode: incident ? "incident" : "site",
      lines,
    },
    viewer,
  );
  return { notice, incident, viewer, fresh: true };
}
