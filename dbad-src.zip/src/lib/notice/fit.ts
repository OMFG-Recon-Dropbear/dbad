/**
 * Sizing helpers shared by the HTML notice templates (container-query units) and the PDF
 * renderer (page-width units). Both lay the footer out as: QR block on the left, the site
 * domain on the right. The domain is whatever hostname the site is deployed under, so it
 * can be anything from 12 to 40+ characters — these helpers keep long hostnames inside a
 * fixed width instead of letting them squeeze the QR caption or run off the sheet.
 */

/** IBM Plex Mono advances 0.6 em per glyph. */
const MONO_ADVANCE = 0.6;

/**
 * Largest font size (≤ `base`) at which a monospace string fits inside `maxWidth`.
 * `base` and `maxWidth` share a unit (cqw for the cards, page-width % for the PDF).
 */
export function fitMono(text: string, base: number, maxWidth: number): number {
  const widthAtOne = Math.max(1, text.length) * MONO_ADVANCE;
  return Math.min(base, maxWidth / widthAtOne);
}

/** Domains longer than this trade some caption size for room in the footer. */
export const LONG_DOMAIN_CHARS = 18;

export function isLongDomain(domain: string): boolean {
  return domain.length > LONG_DOMAIN_CHARS;
}
