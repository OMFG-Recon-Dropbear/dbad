import type { Incident, NoticeLines, NoticeTemplateId } from "@/lib/domain/types";
import { getCategory } from "@/lib/domain/categories";
import { hash32 } from "@/lib/domain/utils";

/**
 * Builds the five lines of a DBAD notice from an incident. Kept separate from the
 * templates so the same words can be laid out as Official Warning, Friendly Reminder
 * and so on.
 */

const WHY_BY_CATEGORY: Record<string, string[]> = {
  parking: [
    "People shouldn't have to work around your car because you couldn't park properly.",
    "Everyone else had to improvise because one vehicle couldn't be bothered.",
  ],
  road: ["Nobody arrives sooner. Everybody arrives angrier.", "The road is shared. Drive like it."],
  shopping: ["Somebody else had to fix what you left behind.", "The trolley bay was right there. It's always right there."],
  neighbourhood: ["Shared spaces only work when they're actually shared.", "A public space is not a private one with extra people in it."],
  rubbish: ["A bin was in plain sight. Somebody else used it for you.", "Take it with you. It isn't heavy."],
  dog: ["Good dog. The human holding the lead is responsible for the rest.", "The dog is never the dick. The owner has one job."],
  internet: ["A public post made things harder for real people for no good reason.", "The internet remembers. DBAD forgives if it's fixed."],
  workplace: ["A small choice cost everyone else their patience.", "Basic consideration: it's free and it works."],
  other: ["It made life harder for everyone around you.", "Humanity noticed. Humanity would like better."],
};

const ADVICE = [
  "Do better next time.",
  "Do better. It's not hard.",
  "You know what to do. Do that.",
  "Fix it, take the joke, move on.",
];

const POSITIVE_ADVICE = ["This is the standard. Keep it up.", "Be this person.", "Legend. Carry on."];

export function buildNoticeLines(inc: Pick<Incident, "kind" | "categoryId" | "dickMove" | "description" | "location" | "advice" | "id">): NoticeLines {
  const seed = hash32(inc.id);
  const cat = getCategory(inc.categoryId);
  const positive = inc.kind === "not_a_dick";
  const whyOptions = WHY_BY_CATEGORY[cat.id] ?? WHY_BY_CATEGORY.other!;
  const why = inc.description.length <= 140 ? inc.description : whyOptions[seed % whyOptions.length]!;
  return {
    headline: positive ? "DEFINITELY NOT A DICK." : "YOU HAVE BEEN DBAD'D.",
    dickMove: inc.dickMove.replace(/\.?$/, "."),
    why,
    location: inc.location.place ? `${inc.location.place}, ${inc.location.suburb} ${inc.location.state}` : `${inc.location.suburb}, ${inc.location.state}`,
    advice: positive ? POSITIVE_ADVICE[seed % POSITIVE_ADVICE.length]! : inc.advice || ADVICE[seed % ADVICE.length]!,
  };
}

export interface NoticeTemplateMeta {
  id: NoticeTemplateId;
  name: string;
  blurb: string;
  /** Default headline if the user hasn't customised it. */
  headline: string;
}

export const NOTICE_TEMPLATES: NoticeTemplateMeta[] = [
  { id: "official-warning", name: "Official Warning", blurb: "Looks like a parking notice from a council with a sense of humour.", headline: "YOU HAVE BEEN DBAD'D." },
  { id: "friendly-reminder", name: "Friendly Reminder", blurb: "Gentle. Off-white. A pat on the shoulder from the community.", headline: "FRIENDLY REMINDER." },
  { id: "maximum-dickery", name: "Maximum Dickery", blurb: "Red stripes. Big stamp. For the truly spectacular.", headline: "ABSOLUTE DICKERY DETECTED." },
  { id: "public-service", name: "Australian Public Service Announcement", blurb: "Straight-faced, plain-spoken, the way a warning label would say it.", headline: "PUBLIC SERVICE ANNOUNCEMENT." },
  { id: "minimal", name: "Minimal DBAD", blurb: "Black. White. Four words. Devastating.", headline: "DON'T BE A DICK." },
];

export const NOTICE_TEMPLATE_MAP: Record<NoticeTemplateId, NoticeTemplateMeta> = Object.fromEntries(
  NOTICE_TEMPLATES.map((t) => [t.id, t]),
) as Record<NoticeTemplateId, NoticeTemplateMeta>;
