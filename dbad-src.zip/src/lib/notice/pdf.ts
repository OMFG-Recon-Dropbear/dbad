import { PDFDocument, PDFFont, PDFPage, StandardFonts, degrees, rgb, setCharacterSpacing, type RGB } from "pdf-lib";
import type { NoticeLines, NoticeLinkMode, NoticeTemplateId } from "@/lib/domain/types";
import { encodeQr, qrRects } from "@/lib/domain/qr";
import { WORDMARK_CUTS, WORDMARK_HEIGHT, WORDMARK_PATHS, WORDMARK_WIDTH } from "@/components/brand/wordmark-geometry";
import { SITE } from "@/lib/site";

/**
 * Vector PDF rendering of the DBAD notice.
 *
 * Uses pdf-lib so the output is a crisp, tiny, print-ready file (no headless browser).
 * Embeds the brand fonts when `@pdf-lib/fontkit` is installed (production); falls back
 * to Helvetica/Courier otherwise so the route always works.
 */

export type NoticeSize = "a5" | "a6";

export interface NoticePdfInput {
  template: NoticeTemplateId;
  lines: NoticeLines;
  code?: string;
  qrUrl: string;
  linkMode: NoticeLinkMode;
  size: NoticeSize;
}

const PT = { a5: { w: 419.53, h: 595.28 }, a6: { w: 297.64, h: 419.53 } } as const;

const C = {
  ink: rgb(0.059, 0.059, 0.059),
  paper: rgb(0.984, 0.973, 0.945),
  paperWarm: rgb(0.945, 0.925, 0.875),
  white: rgb(1, 1, 1),
  yellow: rgb(0.961, 0.769, 0),
  red: rgb(0.843, 0.149, 0.239),
  redLight: rgb(0.937, 0.294, 0.373),
  green: rgb(0.184, 0.49, 0.267),
  concrete: rgb(0.435, 0.435, 0.408),
  paperOn: rgb(0.969, 0.953, 0.918),
};

interface Fonts {
  display: PDFFont;
  body: PDFFont;
  bodyBold: PDFFont;
  mono: PDFFont;
  custom: boolean;
}

async function loadFonts(doc: PDFDocument): Promise<Fonts> {
  try {
    // Optional dependency: present in production (declared in package.json and kept external
    // via serverExternalPackages), absent in the offline sandbox where this falls through to
    // the standard-14 fonts below. A literal specifier keeps it traceable for the bundler.
    const fontkitMod = (await import("@pdf-lib/fontkit")) as { default?: unknown };
    const fontkit = (fontkitMod.default ?? fontkitMod) as Parameters<PDFDocument["registerFontkit"]>[0];
    doc.registerFontkit(fontkit);
    const fs = await import("node:fs/promises");
    const path = await import("node:path");
    const dir = path.join(process.cwd(), "public", "pdf-fonts");
    const [d, b, bb, m] = await Promise.all([
      fs.readFile(path.join(dir, "DBADDisplay-Black.ttf")),
      fs.readFile(path.join(dir, "PublicSans-Regular.ttf")),
      fs.readFile(path.join(dir, "PublicSans-SemiBold.ttf")),
      fs.readFile(path.join(dir, "IBMPlexMono-SemiBold.ttf")),
    ]);
    return {
      display: await doc.embedFont(d, { subset: true }),
      body: await doc.embedFont(b, { subset: true }),
      bodyBold: await doc.embedFont(bb, { subset: true }),
      mono: await doc.embedFont(m, { subset: true }),
      custom: true,
    };
  } catch {
    return {
      display: await doc.embedFont(StandardFonts.HelveticaBold),
      body: await doc.embedFont(StandardFonts.Helvetica),
      bodyBold: await doc.embedFont(StandardFonts.HelveticaBold),
      mono: await doc.embedFont(StandardFonts.CourierBold),
      custom: false,
    };
  }
}

// ---- drawing helpers --------------------------------------------------------

class Draw {
  constructor(
    public page: PDFPage,
    public fonts: Fonts,
    /** one unit = 1% of page width, like cqw in the HTML template */
    public u: number,
    public H: number,
  ) {}

  /** y from top in units → pdf y (bottom-left origin) */
  y(topUnits: number) {
    return this.H - topUnits * this.u;
  }

  rect(x: number, y: number, w: number, h: number, color: RGB, opts: { border?: RGB; borderWidth?: number } = {}) {
    this.page.drawRectangle({ x: x * this.u, y: this.y(y + h), width: w * this.u, height: h * this.u, color, borderColor: opts.border, borderWidth: opts.borderWidth ? opts.borderWidth * this.u : undefined });
  }

  /** Hazard stripes clipped to a band by drawing parallelograms inside the band. */
  hazard(y: number, h: number, dark: RGB, light: RGB) {
    const W = 100;
    this.rect(0, y, W, h, light);
    const step = 4.4;
    for (let x = -h; x < W + h; x += step * 2) {
      const pts = [
        { x: x, y: y + h },
        { x: x + step, y: y + h },
        { x: x + step + h, y: y },
        { x: x + h, y: y },
      ];
      this.page.drawSvgPath(`M${pts.map((p) => `${p.x * this.u} ${(y + h - p.y) * this.u}`).join("L")}Z`, {
        x: 0,
        y: this.y(y),
        color: dark,
        borderWidth: 0,
      });
    }
  }

  text(str: string, x: number, y: number, size: number, font: PDFFont, color: RGB, opts: { align?: "left" | "right" | "center"; upper?: boolean; tracking?: number } = {}) {
    const s = opts.upper ? str.toUpperCase() : str;
    const fs = size * this.u;
    let px = x * this.u;
    const tc = opts.tracking ? opts.tracking * fs : 0;
    const w = font.widthOfTextAtSize(s, fs) + tc * Math.max(0, s.length - 1);
    if (opts.align === "right") px -= w;
    if (opts.align === "center") px -= w / 2;
    // baseline: y is the top of the text box in units; approximate ascent = 0.78em
    if (tc) this.page.pushOperators(setCharacterSpacing(tc));
    this.page.drawText(s, { x: px, y: this.y(y) - fs * 0.78, size: fs, font, color });
    if (tc) this.page.pushOperators(setCharacterSpacing(0));
    return w / this.u;
  }

  wrap(str: string, font: PDFFont, size: number, maxWidth: number, upper = false): string[] {
    const s = upper ? str.toUpperCase() : str;
    const words = s.split(/\s+/).filter(Boolean);
    const fs = size * this.u;
    const max = maxWidth * this.u;
    const lines: string[] = [];
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, fs) <= max || !cur) cur = test;
      else {
        lines.push(cur);
        cur = w;
      }
    }
    if (cur) lines.push(cur);
    return lines;
  }

  /** Draws wrapped text; returns the y (units, from top) after the block. */
  para(str: string, x: number, y: number, size: number, font: PDFFont, color: RGB, maxWidth: number, opts: { upper?: boolean; leading?: number; maxLines?: number } = {}) {
    const lines = this.wrap(str, font, size, maxWidth, opts.upper);
    const leading = (opts.leading ?? 1.15) * size;
    const shown = opts.maxLines ? lines.slice(0, opts.maxLines) : lines;
    let yy = y;
    for (const l of shown) {
      this.text(l, x, yy, size, font, color);
      yy += leading;
    }
    return yy;
  }

  /** Like para(), but steps the font size down until the text fits in maxLines. */
  fitPara(str: string, x: number, y: number, sizes: number[], font: PDFFont, color: RGB, maxWidth: number, maxLines: number, opts: { upper?: boolean; leading?: number } = {}) {
    let size = sizes[sizes.length - 1]!;
    for (const s of sizes) {
      if (this.wrap(str, font, s, maxWidth, opts.upper).length <= maxLines) {
        size = s;
        break;
      }
    }
    return this.para(str, x, y, size, font, color, maxWidth, { ...opts, maxLines });
  }

  label(str: string, x: number, y: number, color: RGB) {
    this.text(str, x, y, 2.6, this.fonts.mono, color, { upper: true, tracking: 0.14 });
  }

  wordmark(x: number, y: number, height: number, color: RGB, bg: RGB) {
    const scale = (height * this.u) / WORDMARK_HEIGHT;
    for (const d of WORDMARK_PATHS) {
      this.page.drawSvgPath(d, { x: x * this.u, y: this.y(y), scale, color, borderWidth: 0 });
    }
    // stencil bridges: paint background over the cut positions
    for (const [cx, cy, cw, ch] of WORDMARK_CUTS) {
      this.page.drawRectangle({ x: x * this.u + cx * scale, y: this.y(y) - (cy + ch) * scale, width: cw * scale, height: ch * scale, color: bg });
    }
    return (WORDMARK_WIDTH * scale) / this.u;
  }

  /** Tilted rubber-stamp box with centred lines of display text. */
  stamp(linesText: string[], x: number, y: number, size: number, color: RGB, angle: number) {
    const fs = size * this.u;
    const widths = linesText.map((t) => this.fonts.display.widthOfTextAtSize(t, fs));
    const w = Math.max(...widths) + fs * 0.9;
    const h = linesText.length * fs * 1.05 + fs * 0.7;
    const rad = (angle * Math.PI) / 180;
    const ox = x * this.u;
    const oy = this.y(y);
    this.page.drawRectangle({ x: ox, y: oy - h, width: w, height: h, borderColor: color, borderWidth: 0.6 * this.u, rotate: degrees(angle) });
    linesText.forEach((t, i) => {
      // local coords inside the (unrotated) box, then rotate around the box origin
      const lx = (w - widths[i]!) / 2;
      const ly = h - fs * 0.45 - (i + 1) * fs * 1.05 + fs * 0.25;
      const rx = ox + lx * Math.cos(rad) - (ly - h) * Math.sin(rad);
      const ry = oy - h + lx * Math.sin(rad) + (ly - h) * Math.cos(rad) + h * Math.cos(rad) - h;
      this.page.drawText(t, { x: rx, y: ry + h, size: fs, font: this.fonts.display, color, rotate: degrees(angle) });
    });
  }

  qr(url: string, x: number, y: number, size: number, dark: RGB, light: RGB) {
    const q = encodeQr(url, "M");
    const margin = 2;
    const cell = size / (q.size + margin * 2);
    this.rect(x, y, size, size, light);
    for (const r of qrRects(q)) {
      this.rect(x + (r.x + margin) * cell, y + (r.y + margin) * cell, r.w * cell, cell, dark);
    }
  }

  qrBlock(qrUrl: string, linkMode: NoticeLinkMode, x: number, yBottom: number, dark: RGB, light: RGB, text: RGB) {
    const size = 22;
    const y = yBottom - size;
    this.rect(x - 0.6, y - 0.6, size + 1.2, size + 1.2, dark);
    this.qr(qrUrl, x, y, size, dark, light);
    const tx = x + size + 3;
    this.text("WONDERING WHY", tx, y + 1, 4.2, this.fonts.display, text);
    this.text("YOU GOT THIS?", tx, y + 5.6, 4.2, this.fonts.display, text);
    this.para(`Scan me. ${linkMode === "incident" ? "See the community verdict." : "Learn the one rule."}`, tx, y + 11.5, 2.9, this.fonts.bodyBold, text, 100 - tx - 36);
  }
}

// ---- templates ----------------------------------------------------------------

function officialWarning(d: Draw, i: NoticePdfInput) {
  const { lines, code, qrUrl, linkMode } = i;
  const Hu = d.H / d.u;
  d.rect(0, 0, 100, Hu, C.paper);
  d.rect(0, 0, 100, Hu, C.paper, { border: C.ink, borderWidth: 0.9 });
  d.hazard(0.9, 4.5, C.ink, C.yellow);
  d.hazard(Hu - 5.4, 4.5, C.ink, C.yellow);
  d.wordmark(5, 8.4, 9, C.ink, C.paper);
  d.text("OFFICIAL WARNING", 95, 8.6, 4.4, d.fonts.display, C.ink, { align: "right" });
  d.text(code ?? "NO. PENDING", 95, 13.6, 2.6, d.fonts.mono, C.ink, { align: "right", tracking: 0.1 });
  d.rect(5, 19, 90, 0.7, C.ink);
  d.text("DON'T", 5, 23, 15.5, d.fonts.display, C.ink);
  d.text("BE A DICK.", 5, 36.5, 15.5, d.fonts.display, C.ink);
  // stamp
  const w = d.text(lines.headline.toUpperCase(), 7, 53.2, 4.6, d.fonts.display, C.yellow);
  d.rect(5, 51.5, w + 4, 6.8, C.ink);
  d.text(lines.headline.toUpperCase(), 7, 53.2, 4.6, d.fonts.display, C.yellow);
  let y = 63;
  d.label("THE DICK MOVE", 5, y, C.concrete);
  y = d.fitPara(lines.dickMove, 5, y + 3.6, [6.4, 5.6, 4.8], d.fonts.display, C.ink, 90, 2, { upper: true, leading: 0.98 }) + 2.5;
  d.label("WHY YOU'RE HERE", 5, y, C.concrete);
  y = d.fitPara(lines.why, 5, y + 3.6, [3.6, 3.3, 3.0], d.fonts.bodyBold, C.ink, 90, 3, { leading: 1.25 }) + 2.5;
  d.label("LOCATION", 5, y, C.concrete);
  d.label("COMMUNITY ADVICE", 52, y, C.concrete);
  d.fitPara(lines.location, 5, y + 3.6, [3.2, 2.8], d.fonts.mono, C.ink, 44, 2, { upper: true, leading: 1.2 });
  d.fitPara(lines.advice, 52, y + 3.6, [3.3, 3.0], d.fonts.bodyBold, C.ink, 43, 2, { leading: 1.25 });
  // verdict stamp (top right, tilted)
  d.stamp(["VERDICT:", "DICK MOVE"], 72, 22, 4.2, C.red, 12);
  // footer
  const fy = Hu - 8;
  d.rect(5, fy - 26, 90, 0.4, C.ink);
  d.qrBlock(qrUrl, linkMode, 5, fy, C.ink, C.white, C.ink);
  d.text("DBAD", 95, fy - 8, 4.2, d.fonts.display, C.ink, { align: "right" });
  d.text(SITE.domain, 95, fy - 3.2, 2.6, d.fonts.mono, C.ink, { align: "right" });
}

function friendlyReminder(d: Draw, i: NoticePdfInput) {
  const { lines, code, qrUrl, linkMode } = i;
  const Hu = d.H / d.u;
  d.rect(0, 0, 100, Hu, C.paperWarm, { border: C.ink, borderWidth: 0.9 });
  d.rect(0.9, 0.9, 98.2, 14, C.yellow);
  d.rect(0.9, 14.9, 98.2, 0.7, C.ink);
  d.wordmark(5, 3.9, 8, C.ink, C.yellow);
  d.text(code ?? "FRIENDLY", 95, 6.6, 2.6, d.fonts.mono, C.ink, { align: "right", tracking: 0.1 });
  d.text("A GENTLE WORD FROM THE COMMUNITY", 6, 21, 2.8, d.fonts.mono, C.green, { tracking: 0.18 });
  let y = d.para(lines.headline, 6, 25, 12, d.fonts.display, C.ink, 88, { upper: true, leading: 0.92, maxLines: 2 }) + 2;
  // dashed box
  const boxTop = y;
  d.label("WHAT HAPPENED", 9.5, y + 3.5, C.concrete);
  let yy = d.fitPara(lines.dickMove, 9.5, y + 7.1, [5.6, 4.8, 4.2], d.fonts.display, C.ink, 81, 2, { upper: true, leading: 0.98 }) + 1.5;
  yy = d.fitPara(lines.why, 9.5, yy, [3.5, 3.2, 3.0], d.fonts.body, C.ink, 81, 3, { leading: 1.28 }) + 3;
  d.page.drawRectangle({ x: 6 * d.u, y: d.y(yy), width: 88 * d.u, height: (yy - boxTop) * d.u, borderColor: C.ink, borderWidth: 0.5 * d.u, borderDashArray: [2 * d.u, 1.5 * d.u] });
  y = yy + 3.5;
  d.label("WHERE", 6, y, C.concrete);
  d.label("OUR ADVICE", 52, y, C.concrete);
  const yl = d.fitPara(lines.location, 6, y + 3.4, [3.1, 2.7], d.fonts.mono, C.ink, 43, 2, { upper: true, leading: 1.2 });
  const ya = d.fitPara(lines.advice, 52, y + 3.4, [3.3, 3.0], d.fonts.bodyBold, C.ink, 42, 2, { leading: 1.25 });
  y = Math.max(yl, ya) + 4;
  const w = d.text("NO HARD FEELINGS. ", 6, y, 5.6, d.fonts.display, C.ink);
  d.text("JUST FIX IT.", 6 + w, y, 5.6, d.fonts.display, C.green);
  const fy = Hu - 8;
  d.rect(6, fy - 26, 88, 0.5, C.ink);
  d.qrBlock(qrUrl, linkMode, 6, fy, C.ink, C.white, C.ink);
  d.text("DON'T BE A DICK.", 94, fy - 8, 4, d.fonts.display, C.ink, { align: "right" });
  d.text(SITE.domain, 94, fy - 3.2, 2.6, d.fonts.mono, C.ink, { align: "right" });
}

function maximumDickery(d: Draw, i: NoticePdfInput) {
  const { lines, code, qrUrl, linkMode } = i;
  const Hu = d.H / d.u;
  d.rect(0, 0, 100, Hu, C.ink, { border: C.red, borderWidth: 0.9 });
  d.hazard(0.9, 5, C.red, C.paper);
  d.hazard(Hu - 5.9, 5, C.red, C.paper);
  d.wordmark(5, 9.9, 8.5, C.red, C.ink);
  d.text(code ?? "MAXIMUM", 95, 12, 2.7, d.fonts.mono, C.redLight, { align: "right", tracking: 0.12 });
  d.text("COMMUNITY ALERT LEVEL", 5, 22.4, 2.7, d.fonts.mono, C.concrete, { tracking: 0.2 });
  d.text("ABSOLUTE", 5, 25.5, 15, d.fonts.display, C.red);
  d.text("DICKERY.", 5, 38.2, 15, d.fonts.display, C.red);
  const hw = d.text(lines.headline.toUpperCase(), 7, 52.7, 4.4, d.fonts.display, C.paper);
  d.rect(5, 51.2, hw + 4, 6.6, C.paper);
  d.text(lines.headline.toUpperCase(), 7, 52.7, 4.4, d.fonts.display, C.ink);
  let y = 61.5;
  d.label("THE OFFENCE AGAINST DECENCY", 5, y, C.redLight);
  y = d.fitPara(lines.dickMove, 5, y + 3.6, [6.2, 5.4, 4.6], d.fonts.display, C.paper, 90, 2, { upper: true, leading: 0.98 }) + 2.5;
  d.label("WHY THE WHOLE COMMUNITY NOTICED", 5, y, C.redLight);
  y = d.fitPara(lines.why, 5, y + 3.6, [3.5, 3.2, 3.0], d.fonts.bodyBold, C.paperOn, 90, 3, { leading: 1.25 }) + 2.5;
  d.label("SCENE", 5, y, C.redLight);
  d.label("REQUIRED ACTION", 52, y, C.redLight);
  d.fitPara(lines.location, 5, y + 3.6, [3.1, 2.7], d.fonts.mono, C.paper, 44, 2, { upper: true, leading: 1.2 });
  d.fitPara(lines.advice, 52, y + 3.6, [3.3, 3.0], d.fonts.bodyBold, C.paper, 43, 2, { leading: 1.25 });
  const fy = Hu - 9;
  d.rect(5, fy - 26, 90, 0.5, C.red);
  d.qrBlock(qrUrl, linkMode, 5, fy, C.ink, C.white, C.paper);
  d.text("DON'T BE A DICK.", 95, fy - 8, 4.2, d.fonts.display, C.red, { align: "right" });
  d.text(SITE.domain, 95, fy - 3.2, 2.6, d.fonts.mono, C.concrete, { align: "right" });
}

function publicService(d: Draw, i: NoticePdfInput) {
  const { lines, code, qrUrl, linkMode } = i;
  const Hu = d.H / d.u;
  d.rect(0, 0, 100, Hu, C.white, { border: C.ink, borderWidth: 0.9 });
  d.rect(0.9, 0.9, 98.2, 13, C.ink);
  d.text("PUBLIC SERVICE ANNOUNCEMENT", 5, 4.9, 4.4, d.fonts.display, C.paper);
  // warning triangle
  d.page.drawSvgPath("M24 4l20 36H4z", { x: 86 * d.u, y: d.y(2.5), scale: (9 * d.u) / 48, color: C.yellow, borderWidth: 0 });
  d.rect(90.2, 5.8, 0.9, 2.6, C.ink);
  d.rect(90.2, 9.2, 0.9, 0.9, C.ink);
  d.text("NOTICE TO THE PERSON RESPONSIBLE FOR:", 6, 19, 2.7, d.fonts.mono, C.ink, { tracking: 0.2 });
  let y = d.fitPara(lines.dickMove, 6, 23, [9.5, 8, 6.8, 5.8], d.fonts.display, C.ink, 88, 2, { upper: true, leading: 0.94 }) + 1.5;
  d.rect(6, y, 88, 0.7, C.ink);
  y += 4;
  const items = [
    ["1.", "What happened.", lines.why],
    ["2.", "Where.", `${lines.location}.`],
    ["3.", "What to do about it.", lines.advice],
    ["4.", "Verdict.", "That was a dick move."],
  ];
  for (const [n, head, body] of items) {
    d.text(n!, 6, y, 3.5, d.fonts.mono, C.ink);
    const hw = d.text(head!, 11, y, 3.5, d.fonts.bodyBold, C.ink);
    // first line continues after the heading
    const firstMax = 83 - hw;
    const words = body!.split(" ");
    let first = "";
    let rest = "";
    for (let k = 0; k < words.length; k++) {
      const t = first ? `${first} ${words[k]}` : words[k]!;
      if (d.fonts.body.widthOfTextAtSize(t, 3.5 * d.u) <= firstMax * d.u) first = t;
      else {
        rest = words.slice(k).join(" ");
        break;
      }
    }
    d.text(` ${first}`, 11 + hw, y, 3.5, d.fonts.body, C.ink);
    y += 4.5;
    if (rest) y = d.para(rest, 11, y, 3.5, d.fonts.body, C.ink, 83, { leading: 1.28, maxLines: 3 });
    y += 1.7;
  }
  y += 2;
  const bw = d.fonts.display.widthOfTextAtSize("DON'T BE A DICK.", 7.5 * d.u) / d.u;
  d.rect(6, y, bw + 5, 10, C.yellow, { border: C.ink, borderWidth: 0.6 });
  d.text("DON'T BE A DICK.", 8.5, y + 1.6, 7.5, d.fonts.display, C.ink);
  const fy = Hu - 8;
  d.qrBlock(qrUrl, linkMode, 6, fy, C.ink, C.white, C.ink);
  d.text(`Authorised by the DBAD community · ${SITE.domain}${code ? ` · ${code}` : ""}`, 50, Hu - 5.6, 2.3, d.fonts.mono, C.ink, { align: "center" });
}

function minimal(d: Draw, i: NoticePdfInput) {
  const { lines, code, qrUrl } = i;
  const Hu = d.H / d.u;
  d.rect(0, 0, 100, Hu, C.white, { border: C.ink, borderWidth: 1.2 });
  d.text("DON'T", 7, 7, 22, d.fonts.display, C.ink);
  d.text("BE A", 7, 26, 22, d.fonts.display, C.ink);
  d.text("DICK.", 7, 45, 22, d.fonts.display, C.ink);
  d.para(lines.dickMove, 7, 69, 5, d.fonts.display, C.concrete, 86, { upper: true, leading: 0.98, maxLines: 3 });
  const fy = Hu - 5;
  d.wordmark(7, fy - 12.5, 7, C.ink, C.white);
  d.text(`${SITE.domain}${code ? ` · ${code}` : ""}`, 7, fy - 3.2, 2.6, d.fonts.mono, C.ink, { tracking: 0.08 });
  d.rect(72.4, fy - 20.6, 21.2, 21.2, C.ink);
  d.qr(qrUrl, 73, fy - 20, 20, C.ink, C.white);
}

const TEMPLATES: Record<NoticeTemplateId, (d: Draw, i: NoticePdfInput) => void> = {
  "official-warning": officialWarning,
  "friendly-reminder": friendlyReminder,
  "maximum-dickery": maximumDickery,
  "public-service": publicService,
  minimal,
};

export async function renderNoticePdf(input: NoticePdfInput): Promise<{ bytes: Uint8Array; customFonts: boolean }> {
  const doc = await PDFDocument.create();
  doc.setTitle(`DBAD notice — ${input.lines.dickMove}`);
  doc.setAuthor("DBAD community");
  doc.setProducer("dontbeadick.com.au");
  doc.setSubject("Don't be a dick.");
  const fonts = await loadFonts(doc);
  const { w, h } = PT[input.size];
  const page = doc.addPage([w, h]);
  const d = new Draw(page, fonts, w / 100, h);
  (TEMPLATES[input.template] ?? officialWarning)(d, input);
  const bytes = await doc.save();
  return { bytes, customFonts: fonts.custom };
}
