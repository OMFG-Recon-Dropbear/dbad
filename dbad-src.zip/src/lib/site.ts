export const SITE = {
  name: "DBAD",
  fullName: "DBAD — Don't Be A Dick.",
  tagline: "DON'T BE A DICK.",
  subline: "Because apparently some people still need reminding.",
  supporting: "Making the world slightly less dickish, one nomination at a time.",
  alt: "See a dick move? Call it out. Have a laugh. Do better.",
  closing: "THE WORLD HAS ENOUGH ALREADY.",
  url: (process.env.NEXT_PUBLIC_SITE_URL || "https://dontbeadick.com.au").replace(/\/$/, ""),
  /** Printed on notices and cards; follows the deployed hostname so QR codes and text agree. */
  domain: (() => {
    try {
      return new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://dontbeadick.com.au").hostname;
    } catch {
      return "dontbeadick.com.au";
    }
  })(),
  description:
    "DBAD is an Australian community noticeboard for calling out dick moves — the behaviour, never the person. Nominate a dick move, generate a printable DBAD notice, cast a community verdict, and celebrate redemption.",
  twitterHandle: "@dontbeadickau",
  locale: "en_AU",
} as const;

export function absoluteUrl(path: string): string {
  if (/^https?:\/\//.test(path)) return path;
  return `${SITE.url}${path.startsWith("/") ? path : `/${path}`}`;
}

export const NAV: ReadonlyArray<{ href: string; label: string }> = [
  { href: "/feed", label: "Latest Dick Moves" },
  { href: "/week", label: "Dick Move of the Week" },
  { href: "/not-a-dick", label: "Not A Dick" },
  { href: "/map", label: "Map" },
  { href: "/about", label: "About" },
];

export const FOOTER_NAV = [
  { href: "/standards", label: "Community Standard" },
  { href: "/about-you", label: "Is this about you?" },
  { href: "/about", label: "Philosophy" },
  { href: "/notice/new", label: "Make a notice" },
  { href: "/privacy", label: "Privacy" },
] as const;
