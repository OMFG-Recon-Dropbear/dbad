/**
 * Database types for the DBAD schema.
 *
 * Shape matches `supabase gen types typescript --local`, so it can be regenerated
 * with that command whenever supabase/migrations changes:
 *
 *   supabase gen types typescript --local > src/lib/supabase/database.types.ts
 *
 * Two notes about that regeneration:
 *  - `citext` and `pgcrypto` live in the public schema, so a real generation run
 *    also emits their helper functions. They are omitted here on purpose.
 *  - Generated columns (short_code, votes_total, dickery_rank, search, reference)
 *    appear in Row only; the database computes them.
 */

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  public: {
    Tables: {
      appeals: {
        Row: {
          id: string;
          incident_id: string;
          requested_action: Database["public"]["Enums"]["appeal_action"];
          message: string;
          /** PRIVATE. Moderators only — never returned to a member or an anonymous reader. */
          contact: string | null;
          status: Database["public"]["Enums"]["appeal_status"];
          public_reply: string | null;
          reference: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          incident_id: string;
          requested_action: Database["public"]["Enums"]["appeal_action"];
          message: string;
          contact?: string | null;
          status?: Database["public"]["Enums"]["appeal_status"];
          public_reply?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          incident_id?: string;
          requested_action?: Database["public"]["Enums"]["appeal_action"];
          message?: string;
          contact?: string | null;
          status?: Database["public"]["Enums"]["appeal_status"];
          public_reply?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "appeals_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: false;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
        ];
      };
      badges: {
        Row: { id: string; name: string; blurb: string; rule: string; sort_order: number; created_at: string };
        Insert: { id: string; name: string; blurb: string; rule: string; sort_order?: number; created_at?: string };
        Update: { id?: string; name?: string; blurb?: string; rule?: string; sort_order?: number; created_at?: string };
        Relationships: [];
      };
      categories: {
        Row: {
          id: string;
          label: string;
          short: string;
          blurb: string;
          caution: string | null;
          accent: Database["public"]["Enums"]["category_accent"];
          sort_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          label: string;
          short: string;
          blurb: string;
          caution?: string | null;
          accent?: Database["public"]["Enums"]["category_accent"];
          sort_order?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          label?: string;
          short?: string;
          blurb?: string;
          caution?: string | null;
          accent?: Database["public"]["Enums"]["category_accent"];
          sort_order?: number;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      comments: {
        Row: {
          id: string;
          incident_id: string;
          author_id: string;
          body: string;
          status: Database["public"]["Enums"]["comment_status"];
          parent_id: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          incident_id: string;
          author_id: string;
          body: string;
          status?: Database["public"]["Enums"]["comment_status"];
          parent_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          incident_id?: string;
          author_id?: string;
          body?: string;
          status?: Database["public"]["Enums"]["comment_status"];
          parent_id?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "comments_author_id_fkey";
            columns: ["author_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "comments_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: false;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "comments_parent_id_fkey";
            columns: ["parent_id"];
            isOneToOne: false;
            referencedRelation: "comments";
            referencedColumns: ["id"];
          },
        ];
      };
      incident_photos: {
        Row: {
          id: string;
          incident_id: string;
          storage_path: string | null;
          url: string;
          width: number;
          height: number;
          alt: string;
          redacted: boolean;
          redaction_count: number;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          incident_id: string;
          storage_path?: string | null;
          url: string;
          width: number;
          height: number;
          alt?: string;
          redacted?: boolean;
          redaction_count?: number;
          sort_order?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          incident_id?: string;
          storage_path?: string | null;
          url?: string;
          width?: number;
          height?: number;
          alt?: string;
          redacted?: boolean;
          redaction_count?: number;
          sort_order?: number;
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "incident_photos_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: false;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
        ];
      };
      incidents: {
        Row: {
          id: string;
          seq: number;
          short_code: string | null;
          slug: string;
          kind: Database["public"]["Enums"]["incident_kind"];
          category_id: string;
          title: string;
          dick_move: string;
          description: string;
          affected: string[];
          location_id: string;
          occurred_on: string;
          part_of_day: Database["public"]["Enums"]["part_of_day"];
          state: Database["public"]["Enums"]["australian_state"];
          region: string;
          submitter_id: string | null;
          status: Database["public"]["Enums"]["incident_status"];
          moderation_status: Database["public"]["Enums"]["moderation_status"];
          anonymised: boolean;
          featured_week: string | null;
          advice: string | null;
          redeemed_at: string | null;
          votes_not: number;
          votes_bit: number;
          votes_definitely: number;
          votes_absolute: number;
          react_fair_call: number;
          react_classic: number;
          react_dick_move: number;
          react_redemption: number;
          comment_count: number;
          votes_total: number | null;
          dickery_rank: number | null;
          location_label: string;
          search: unknown | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          seq?: number;
          slug: string;
          kind?: Database["public"]["Enums"]["incident_kind"];
          category_id: string;
          title: string;
          dick_move: string;
          description: string;
          affected?: string[];
          location_id: string;
          occurred_on: string;
          part_of_day?: Database["public"]["Enums"]["part_of_day"];
          /** Denormalised from the location by trigger — do not set. */
          state?: Database["public"]["Enums"]["australian_state"];
          /** Denormalised from the location by trigger — do not set. */
          region?: string;
          submitter_id?: string | null;
          status?: Database["public"]["Enums"]["incident_status"];
          moderation_status?: Database["public"]["Enums"]["moderation_status"];
          anonymised?: boolean;
          featured_week?: string | null;
          advice?: string | null;
          redeemed_at?: string | null;
          votes_not?: number;
          votes_bit?: number;
          votes_definitely?: number;
          votes_absolute?: number;
          react_fair_call?: number;
          react_classic?: number;
          react_dick_move?: number;
          react_redemption?: number;
          comment_count?: number;
          location_label?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          seq?: number;
          slug?: string;
          kind?: Database["public"]["Enums"]["incident_kind"];
          category_id?: string;
          title?: string;
          dick_move?: string;
          description?: string;
          affected?: string[];
          location_id?: string;
          occurred_on?: string;
          part_of_day?: Database["public"]["Enums"]["part_of_day"];
          /** Denormalised from the location by trigger — do not set. */
          state?: Database["public"]["Enums"]["australian_state"];
          /** Denormalised from the location by trigger — do not set. */
          region?: string;
          submitter_id?: string | null;
          status?: Database["public"]["Enums"]["incident_status"];
          moderation_status?: Database["public"]["Enums"]["moderation_status"];
          anonymised?: boolean;
          featured_week?: string | null;
          advice?: string | null;
          redeemed_at?: string | null;
          votes_not?: number;
          votes_bit?: number;
          votes_definitely?: number;
          votes_absolute?: number;
          react_fair_call?: number;
          react_classic?: number;
          react_dick_move?: number;
          react_redemption?: number;
          comment_count?: number;
          location_label?: string;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "incidents_category_id_fkey";
            columns: ["category_id"];
            isOneToOne: false;
            referencedRelation: "categories";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "incidents_location_id_fkey";
            columns: ["location_id"];
            isOneToOne: false;
            referencedRelation: "locations";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "incidents_submitter_id_fkey";
            columns: ["submitter_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      locations: {
        Row: {
          id: string;
          suburb: string;
          state: Database["public"]["Enums"]["australian_state"];
          place: string | null;
          approx_lat: number | null;
          approx_lng: number | null;
          precision: Database["public"]["Enums"]["location_precision"];
          region: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          suburb: string;
          state: Database["public"]["Enums"]["australian_state"];
          place?: string | null;
          approx_lat?: number | null;
          approx_lng?: number | null;
          precision?: Database["public"]["Enums"]["location_precision"];
          region: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          suburb?: string;
          state?: Database["public"]["Enums"]["australian_state"];
          place?: string | null;
          approx_lat?: number | null;
          approx_lng?: number | null;
          precision?: Database["public"]["Enums"]["location_precision"];
          region?: string;
          created_at?: string;
        };
        Relationships: [];
      };
      moderation_actions: {
        Row: {
          id: string;
          actor_id: string;
          action: Database["public"]["Enums"]["moderation_action_kind"];
          target_type: Database["public"]["Enums"]["moderation_target_type"];
          target_id: string;
          note: string | null;
          payload: Json | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          actor_id: string;
          action: Database["public"]["Enums"]["moderation_action_kind"];
          target_type: Database["public"]["Enums"]["moderation_target_type"];
          target_id: string;
          note?: string | null;
          payload?: Json | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          actor_id?: string;
          action?: Database["public"]["Enums"]["moderation_action_kind"];
          target_type?: Database["public"]["Enums"]["moderation_target_type"];
          target_id?: string;
          note?: string | null;
          payload?: Json | null;
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "moderation_actions_actor_id_fkey";
            columns: ["actor_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          kind: Database["public"]["Enums"]["notification_kind"];
          title: string;
          body: string;
          href: string | null;
          created_at: string;
          read_at: string | null;
        };
        Insert: {
          id?: string;
          user_id: string;
          kind: Database["public"]["Enums"]["notification_kind"];
          title: string;
          body?: string;
          href?: string | null;
          created_at?: string;
          read_at?: string | null;
        };
        Update: {
          id?: string;
          user_id?: string;
          kind?: Database["public"]["Enums"]["notification_kind"];
          title?: string;
          body?: string;
          href?: string | null;
          created_at?: string;
          read_at?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "notifications_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      printable_notices: {
        Row: {
          id: string;
          incident_id: string | null;
          template: Database["public"]["Enums"]["notice_template"];
          link_mode: Database["public"]["Enums"]["notice_link_mode"];
          headline: string;
          dick_move: string;
          why: string;
          location: string;
          advice: string;
          created_at: string;
          updated_at: string;
          created_by: string | null;
        };
        Insert: {
          id?: string;
          incident_id?: string | null;
          template?: Database["public"]["Enums"]["notice_template"];
          link_mode?: Database["public"]["Enums"]["notice_link_mode"];
          headline?: string;
          dick_move?: string;
          why?: string;
          location?: string;
          advice?: string;
          created_at?: string;
          updated_at?: string;
          created_by?: string | null;
        };
        Update: {
          id?: string;
          incident_id?: string | null;
          template?: Database["public"]["Enums"]["notice_template"];
          link_mode?: Database["public"]["Enums"]["notice_link_mode"];
          headline?: string;
          dick_move?: string;
          why?: string;
          location?: string;
          advice?: string;
          created_at?: string;
          updated_at?: string;
          created_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "printable_notices_created_by_fkey";
            columns: ["created_by"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "printable_notices_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: false;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          id: string;
          handle: string;
          display_name: string;
          avatar_seed: string;
          role: Database["public"]["Enums"]["user_role"];
          member_since: string;
          bio: string | null;
          home_area: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          handle: string;
          display_name: string;
          avatar_seed?: string;
          role?: Database["public"]["Enums"]["user_role"];
          member_since?: string;
          bio?: string | null;
          home_area?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          handle?: string;
          display_name?: string;
          avatar_seed?: string;
          /** Rejected by profiles_guard_role — change roles through moderate('change_role'). */
          role?: Database["public"]["Enums"]["user_role"];
          member_since?: string;
          bio?: string | null;
          home_area?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      reactions: {
        Row: {
          incident_id: string;
          user_id: string;
          kind: Database["public"]["Enums"]["reaction_kind"];
          created_at: string;
        };
        Insert: {
          incident_id: string;
          user_id: string;
          kind: Database["public"]["Enums"]["reaction_kind"];
          created_at?: string;
        };
        Update: {
          incident_id?: string;
          user_id?: string;
          kind?: Database["public"]["Enums"]["reaction_kind"];
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "reactions_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: false;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "reactions_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      redemptions: {
        Row: {
          id: string;
          incident_id: string;
          note: string;
          confirmed_by: Database["public"]["Enums"]["redemption_source"];
          created_at: string;
        };
        Insert: {
          id?: string;
          incident_id: string;
          note: string;
          confirmed_by?: Database["public"]["Enums"]["redemption_source"];
          created_at?: string;
        };
        Update: {
          id?: string;
          incident_id?: string;
          note?: string;
          confirmed_by?: Database["public"]["Enums"]["redemption_source"];
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "redemptions_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: true;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
        ];
      };
      reports: {
        Row: {
          id: string;
          target_type: Database["public"]["Enums"]["report_target_type"];
          target_id: string;
          reason: Database["public"]["Enums"]["report_reason"];
          details: string | null;
          reporter_id: string | null;
          status: Database["public"]["Enums"]["report_status"];
          created_at: string;
          resolved_at: string | null;
          resolved_by: string | null;
        };
        Insert: {
          id?: string;
          target_type: Database["public"]["Enums"]["report_target_type"];
          target_id: string;
          reason: Database["public"]["Enums"]["report_reason"];
          details?: string | null;
          reporter_id?: string | null;
          status?: Database["public"]["Enums"]["report_status"];
          created_at?: string;
          resolved_at?: string | null;
          resolved_by?: string | null;
        };
        Update: {
          id?: string;
          target_type?: Database["public"]["Enums"]["report_target_type"];
          target_id?: string;
          reason?: Database["public"]["Enums"]["report_reason"];
          details?: string | null;
          reporter_id?: string | null;
          status?: Database["public"]["Enums"]["report_status"];
          created_at?: string;
          resolved_at?: string | null;
          resolved_by?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "reports_reporter_id_fkey";
            columns: ["reporter_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "reports_resolved_by_fkey";
            columns: ["resolved_by"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      social_sources: {
        Row: {
          id: string;
          incident_id: string;
          platform: Database["public"]["Enums"]["social_platform"];
          url: string;
          retrieved_via: Database["public"]["Enums"]["social_retrieval"];
          note: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          incident_id: string;
          platform?: Database["public"]["Enums"]["social_platform"];
          url: string;
          retrieved_via?: Database["public"]["Enums"]["social_retrieval"];
          note?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          incident_id?: string;
          platform?: Database["public"]["Enums"]["social_platform"];
          url?: string;
          retrieved_via?: Database["public"]["Enums"]["social_retrieval"];
          note?: string | null;
          created_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "social_sources_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: true;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
        ];
      };
      user_badges: {
        Row: { user_id: string; badge_id: string; awarded_at: string };
        Insert: { user_id: string; badge_id: string; awarded_at?: string };
        Update: { user_id?: string; badge_id?: string; awarded_at?: string };
        Relationships: [
          {
            foreignKeyName: "user_badges_badge_id_fkey";
            columns: ["badge_id"];
            isOneToOne: false;
            referencedRelation: "badges";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "user_badges_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
      votes: {
        Row: {
          incident_id: string;
          user_id: string;
          verdict: Database["public"]["Enums"]["verdict"];
          created_at: string;
          updated_at: string;
        };
        Insert: {
          incident_id: string;
          user_id: string;
          verdict: Database["public"]["Enums"]["verdict"];
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          incident_id?: string;
          user_id?: string;
          verdict?: Database["public"]["Enums"]["verdict"];
          created_at?: string;
          updated_at?: string;
        };
        Relationships: [
          {
            foreignKeyName: "votes_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: false;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "votes_user_id_fkey";
            columns: ["user_id"];
            isOneToOne: false;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Views: {
      /** The published right of reply, without the appeal behind it. */
      appeal_replies: {
        Row: {
          id: string | null;
          incident_id: string | null;
          public_reply: string | null;
          created_at: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "appeals_incident_id_fkey";
            columns: ["incident_id"];
            isOneToOne: false;
            referencedRelation: "incidents";
            referencedColumns: ["id"];
          },
        ];
      };
      /** Per-member counters behind profile pages and badge rules. */
      member_stats: {
        Row: {
          user_id: string | null;
          spotted: number | null;
          fair_calls: number | null;
          redeemed: number | null;
          overruled: number | null;
          not_a_dick: number | null;
          comments: number | null;
        };
        Relationships: [
          {
            foreignKeyName: "profiles_id_fkey";
            columns: ["user_id"];
            isOneToOne: true;
            referencedRelation: "profiles";
            referencedColumns: ["id"];
          },
        ];
      };
    };
    Functions: {
      add_comment: { Args: { incident: string; body: string }; Returns: Json };
      admin_stats: { Args: Record<PropertyKey, never>; Returns: Json };
      affected_groups: { Args: Record<PropertyKey, never>; Returns: string[] };
      build_notice_lines: { Args: { p_incident: string }; Returns: Json };
      cast_vote: { Args: { incident: string; verdict: string }; Returns: Json };
      contains_contact_details: { Args: { parts: string[] }; Returns: boolean };
      contains_email: { Args: { input: string }; Returns: boolean };
      contains_phone: { Args: { input: string }; Returns: boolean };
      contains_threat: { Args: { input: string }; Returns: boolean };
      guess_region: {
        Args: { p_suburb: string; p_state: Database["public"]["Enums"]["australian_state"] };
        Returns: string;
      };
      hash32: { Args: { input: string }; Returns: number };
      incident_is_public: { Args: { p_incident: string }; Returns: boolean };
      incident_submitter: { Args: { p_incident: string }; Returns: string };
      incident_visible: { Args: { p_incident: string }; Returns: boolean };
      is_admin: { Args: Record<PropertyKey, never>; Returns: boolean };
      is_moderator: { Args: Record<PropertyKey, never>; Returns: boolean };
      log_moderation: {
        Args: {
          p_actor: string;
          p_action: Database["public"]["Enums"]["moderation_action_kind"];
          p_target_type: Database["public"]["Enums"]["moderation_target_type"];
          p_target_id: string;
          p_note?: string;
          p_payload?: Json;
        };
        Returns: string;
      };
      map_clusters: {
        Args: Record<PropertyKey, never>;
        Returns: {
          region: string;
          state: Database["public"]["Enums"]["australian_state"];
          approx_lat: number;
          approx_lng: number;
          count: number;
          count_this_week: number;
          redeemed: number;
          not_a_dick: number;
          top_category_id: string;
        }[];
      };
      mark_redeemed: { Args: { incident: string; note: string }; Returns: Json };
      min_votes_for_verdict: { Args: Record<PropertyKey, never>; Returns: number };
      moderate: { Args: { command: Json }; Returns: Json };
      notice_why_options: { Args: { p_category: string }; Returns: string[] };
      notify_member: {
        Args: {
          p_user: string;
          p_kind: Database["public"]["Enums"]["notification_kind"];
          p_title: string;
          p_body: string;
          p_href?: string;
        };
        Returns: undefined;
      };
      pii_kinds: { Args: { input: string }; Returns: string[] };
      profile_stats: { Args: { p_user: string }; Returns: Json };
      reaction_tally: { Args: { p_incident: string }; Returns: Json };
      refresh_badges: { Args: { p_user: string }; Returns: Json };
      report_content: { Args: { payload: Json }; Returns: Json };
      scrub_text: { Args: { input: string }; Returns: string };
      short_code: { Args: { seq: number }; Returns: string };
      slugify: { Args: { input: string }; Returns: string };
      submit_appeal: { Args: { payload: Json }; Returns: Json };
      submit_nomination: { Args: { payload: Json }; Returns: Json };
      toggle_reaction: { Args: { incident: string; kind: string }; Returns: Json };
      upsert_location: {
        Args: {
          p_suburb: string;
          p_state: Database["public"]["Enums"]["australian_state"];
          p_place: string;
          p_lat: number;
          p_lng: number;
          p_region?: string;
        };
        Returns: string;
      };
      verdict_agree_percent: { Args: { nt: number; bt: number; dt: number; at: number }; Returns: number };
      verdict_band: { Args: { nt: number; bt: number; dt: number; at: number }; Returns: string };
      verdict_percent: { Args: { nt: number; bt: number; dt: number; at: number }; Returns: number };
      verdict_share_line: { Args: { nt: number; bt: number; dt: number; at: number }; Returns: string };
      viewer_role: { Args: Record<PropertyKey, never>; Returns: Database["public"]["Enums"]["user_role"] };
      vote_tally: { Args: { p_incident: string }; Returns: Json };
      week_of: { Args: { d?: string }; Returns: string };
    };
    Enums: {
      appeal_action: "removal" | "correction" | "anonymisation" | "context" | "reply" | "redemption";
      appeal_status: "open" | "in_review" | "actioned" | "declined";
      australian_state: "NSW" | "VIC" | "QLD" | "WA" | "SA" | "TAS" | "ACT" | "NT";
      category_accent: "warning" | "alert" | "concrete" | "redeem";
      comment_status: "visible" | "hidden" | "removed";
      incident_kind: "dick_move" | "not_a_dick";
      incident_status: "open" | "redeemed" | "overruled";
      location_precision: "suburb" | "place";
      moderation_action_kind:
        | "approve"
        | "reject"
        | "remove"
        | "restore"
        | "anonymise"
        | "redact_photo"
        | "mark_redeemed"
        | "mark_overruled"
        | "feature_week"
        | "unfeature"
        | "hide_comment"
        | "restore_comment"
        | "resolve_report"
        | "dismiss_report"
        | "action_appeal"
        | "decline_appeal"
        | "publish_reply"
        | "change_role"
        | "edit_category"
        | "edit_template";
      moderation_status: "pending" | "approved" | "rejected" | "removed";
      moderation_target_type:
        | "incident"
        | "comment"
        | "report"
        | "appeal"
        | "user"
        | "category"
        | "template"
        | "photo";
      notice_link_mode: "site" | "incident";
      notice_template: "official-warning" | "friendly-reminder" | "maximum-dickery" | "public-service" | "minimal";
      notification_kind:
        | "verdict_reached"
        | "featured"
        | "redeemed"
        | "comment"
        | "badge"
        | "moderation"
        | "appeal_update";
      part_of_day: "morning" | "midday" | "afternoon" | "evening" | "night" | "unknown";
      reaction_kind: "fair_call" | "classic" | "dick_move" | "redemption";
      redemption_source: "submitter" | "moderator" | "community";
      report_reason:
        | "identifies_person"
        | "private_address"
        | "harassment"
        | "defamatory"
        | "children"
        | "not_a_dick_move"
        | "duplicate"
        | "spam"
        | "other";
      report_status: "open" | "reviewing" | "resolved" | "dismissed";
      report_target_type: "incident" | "comment";
      social_platform: "facebook";
      social_retrieval: "manual" | "oembed";
      user_role: "member" | "moderator" | "admin";
      verdict: "not" | "bit" | "definitely" | "absolute";
    };
    CompositeTypes: Record<string, never>;
  };
};

type PublicSchema = Database["public"];

export type Tables<T extends keyof (PublicSchema["Tables"] & PublicSchema["Views"])> =
  (PublicSchema["Tables"] & PublicSchema["Views"])[T] extends { Row: infer R } ? R : never;

export type TablesInsert<T extends keyof PublicSchema["Tables"]> =
  PublicSchema["Tables"][T] extends { Insert: infer I } ? I : never;

export type TablesUpdate<T extends keyof PublicSchema["Tables"]> =
  PublicSchema["Tables"][T] extends { Update: infer U } ? U : never;

export type Enums<T extends keyof PublicSchema["Enums"]> = PublicSchema["Enums"][T];

export type FunctionReturns<T extends keyof PublicSchema["Functions"]> =
  PublicSchema["Functions"][T] extends { Returns: infer R } ? R : never;
