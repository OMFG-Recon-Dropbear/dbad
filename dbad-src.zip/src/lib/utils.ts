/** Tiny class-name joiner (shadcn's `cn` without the dependencies). */
export function cn(...parts: Array<string | false | null | undefined | 0>): string {
  return parts.filter(Boolean).join(" ");
}

/** shadcn-style variant helper: cva without the dependency. */
export function variants<V extends Record<string, Record<string, string>>>(base: string, config: { variants: V; defaultVariants?: { [K in keyof V]?: keyof V[K] } }) {
  return (props?: { [K in keyof V]?: keyof V[K] | null } & { className?: string }) => {
    const out = [base];
    for (const key of Object.keys(config.variants) as Array<keyof V>) {
      const chosen = (props?.[key] ?? config.defaultVariants?.[key]) as string | undefined;
      if (chosen && config.variants[key]![chosen]) out.push(config.variants[key]![chosen]!);
    }
    if (props?.className) out.push(props.className);
    return out.join(" ");
  };
}
