import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Refreshes the Supabase session cookie on every request (Supabase mode only) and
 * protects /admin and /me from anonymous visitors. In demo mode the cookie is a plain
 * demo-user id and nothing needs refreshing.
 */
export async function middleware(request: NextRequest) {
  const response = NextResponse.next({ request });
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const demo = process.env.DBAD_DATA_MODE === "demo" || !url || !anon;
  const path = request.nextUrl.pathname;
  const needsAuth = path.startsWith("/admin") || path.startsWith("/me") || path.startsWith("/notifications");

  if (demo) {
    if (needsAuth && !request.cookies.get("dbad_demo_user")) {
      const to = request.nextUrl.clone();
      to.pathname = "/sign-in";
      to.searchParams.set("next", path);
      return NextResponse.redirect(to);
    }
    return response;
  }

  const supabase = createServerClient(url, anon, {
    cookies: {
      getAll: () => request.cookies.getAll(),
      setAll: (cookiesToSet) => {
        for (const { name, value, options } of cookiesToSet) response.cookies.set(name, value, options);
      },
    },
  });
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (needsAuth && !user) {
    const to = request.nextUrl.clone();
    to.pathname = "/sign-in";
    to.searchParams.set("next", path);
    return NextResponse.redirect(to);
  }
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|sw.js|manifest.webmanifest|fonts/|seed/|icons/|.*\\.(?:png|jpg|jpeg|svg|webp|ico|woff|woff2)$).*)"],
};
