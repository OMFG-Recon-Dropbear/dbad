-- ===========================================================================
-- DBAD — 0001 schema
--
-- Guiding rule, enforced by the schema and not just by the app: DBAD records
-- BEHAVIOUR, NEVER PEOPLE. There is no table, column or index anywhere in this
-- file for "the person who did the dick move". Locations are suburb-level with
-- an optional clearly-public place; coordinates are approximate centroids only;
-- free text is checked for contact details by a trigger before it is stored.
--
-- Naming: snake_case everywhere, uuid primary keys via gen_random_uuid(),
-- timestamptz for instants, date for day-precision facts (an incident is
-- recorded to the day on purpose — an exact timestamp is identifying).
-- ===========================================================================

create extension if not exists citext with schema public;

-- ---------------------------------------------------------------------------
-- Enumerated domains. These mirror the string unions in src/lib/domain/types.ts
-- one-for-one; changing either side without the other is a bug.
-- ---------------------------------------------------------------------------
create type public.australian_state as enum ('NSW', 'VIC', 'QLD', 'WA', 'SA', 'TAS', 'ACT', 'NT');
create type public.user_role as enum ('member', 'moderator', 'admin');
create type public.incident_kind as enum ('dick_move', 'not_a_dick');
create type public.incident_status as enum ('open', 'redeemed', 'overruled');
create type public.moderation_status as enum ('pending', 'approved', 'rejected', 'removed');
create type public.verdict as enum ('not', 'bit', 'definitely', 'absolute');
create type public.reaction_kind as enum ('fair_call', 'classic', 'dick_move', 'redemption');
create type public.part_of_day as enum ('morning', 'midday', 'afternoon', 'evening', 'night', 'unknown');
create type public.location_precision as enum ('suburb', 'place');
create type public.comment_status as enum ('visible', 'hidden', 'removed');
create type public.report_reason as enum (
  'identifies_person', 'private_address', 'harassment', 'defamatory',
  'children', 'not_a_dick_move', 'duplicate', 'spam', 'other');
create type public.report_status as enum ('open', 'reviewing', 'resolved', 'dismissed');
create type public.appeal_action as enum ('removal', 'correction', 'anonymisation', 'context', 'reply', 'redemption');
create type public.appeal_status as enum ('open', 'in_review', 'actioned', 'declined');
create type public.moderation_action_kind as enum (
  'approve', 'reject', 'remove', 'restore', 'anonymise', 'redact_photo',
  'mark_redeemed', 'mark_overruled', 'feature_week', 'unfeature',
  'hide_comment', 'restore_comment', 'resolve_report', 'dismiss_report',
  'action_appeal', 'decline_appeal', 'publish_reply', 'change_role',
  'edit_category', 'edit_template');
create type public.moderation_target_type as enum (
  'incident', 'comment', 'report', 'appeal', 'user', 'category', 'template', 'photo');
create type public.report_target_type as enum ('incident', 'comment');
create type public.notice_template as enum (
  'official-warning', 'friendly-reminder', 'maximum-dickery', 'public-service', 'minimal');
create type public.notice_link_mode as enum ('site', 'incident');
create type public.notification_kind as enum (
  'verdict_reached', 'featured', 'redeemed', 'comment', 'badge', 'moderation', 'appeal_update');
create type public.redemption_source as enum ('submitter', 'moderator', 'community');
create type public.category_accent as enum ('warning', 'alert', 'concrete', 'redeem');
create type public.social_platform as enum ('facebook');
create type public.social_retrieval as enum ('manual', 'oembed');

-- Who a dick move affected. Stored as text[] on incidents (a member can pick
-- several); this array is the allow-list the check constraint validates against.
create or replace function public.affected_groups() returns text[]
language sql immutable parallel safe as $$
  select array[
    'pedestrians', 'wheelchair_users', 'parents_prams', 'cyclists', 'neighbours',
    'motorists', 'local_businesses', 'the_community', 'everyone', 'probably_nobody'
  ]::text[];
$$;

-- ---------------------------------------------------------------------------
-- Shared helpers used by defaults, generated columns and triggers.
-- ---------------------------------------------------------------------------

-- URL-safe slug. Mirrors slugify() in src/lib/domain/utils.ts: lower-case,
-- accents folded, everything else collapsed to single hyphens, 72 chars max.
create or replace function public.slugify(input text) returns text
language sql immutable parallel safe as $$
  select left(
    trim(both '-' from regexp_replace(
      lower(translate(coalesce(input, ''),
        'àáâãäåāăąèéêëēĕėęěìíîïĩīĭįıòóôõöøōŏőùúûüũūŭůűųçćĉċčñńņňýÿŷđďıłśšşžźżßæœ',
        'aaaaaaaaaeeeeeeeeeiiiiiiiiiooooooooouuuuuuuuuucccccnnnnyyydddilsssszzzsao')),
      '[^a-z0-9]+', '-', 'g')),
    72);
$$;
comment on function public.slugify(text) is 'URL slug generator; mirrors slugify() in src/lib/domain/utils.ts.';

-- FNV-1a 32-bit hash. Mirrors hash32() in src/lib/domain/utils.ts so notice copy
-- picked in SQL matches the copy the browser would pick for the same seed.
create or replace function public.hash32(input text) returns bigint
language plpgsql immutable parallel safe as $$
declare
  h bigint := 2166136261;      -- 0x811c9dc5
  bytes bytea := convert_to(coalesce(input, ''), 'UTF8');
  i int;
begin
  for i in 0 .. octet_length(bytes) - 1 loop
    h := h # get_byte(bytes, i);
    h := (h * 16777619) % 4294967296;   -- 0x01000193, wrapped to 32 bits
  end loop;
  return h;
end;
$$;

-- Monday of the ISO week containing `d`. Mirrors weekOf() in domain/utils.ts.
create or replace function public.week_of(d timestamptz default now()) returns date
language sql immutable parallel safe as $$
  select (date_trunc('week', d at time zone 'UTC'))::date;
$$;

create or replace function public.short_code(seq bigint) returns text
language sql immutable parallel safe as $$
  select 'DBAD-' || lpad(seq::text, 4, '0');
$$;

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

-- ---------------------------------------------------------------------------
-- PII last line of defence.
--
-- The wizard scans text in the browser and the RPCs scrub it again on the way
-- in (see 0003_functions.sql). This trigger is the backstop: no row carrying a
-- contact detail reaches disk, whatever path it came in on. The patterns are
-- POSIX translations of EMAIL and PHONE in src/lib/domain/pii.ts.
-- ---------------------------------------------------------------------------
create or replace function public.contains_email(input text) returns boolean
language sql immutable parallel safe as $$
  select coalesce(input, '') ~* '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}';
$$;

create or replace function public.contains_phone(input text) returns boolean
language sql immutable parallel safe as $$
  select coalesce(input, '') ~ '(\+?61[ -]?|\(0[0-9]\)[ -]?|0)([23478]([ -]?[0-9]){8}|1[38]00([ -]?[0-9]){6}|13([ -]?[0-9]){4})\y';
$$;

create or replace function public.contains_contact_details(variadic parts text[]) returns boolean
language sql immutable parallel safe as $$
  select bool_or(public.contains_email(p) or public.contains_phone(p))
  from unnest(parts) as p;
$$;
comment on function public.contains_contact_details(text[]) is
  'True when any part contains an email address or Australian phone number.';

create or replace function public.reject_contact_details() returns trigger
language plpgsql as $$
declare
  col text;
  val text;
begin
  foreach col in array tg_argv loop
    execute format('select ($1).%I::text', col) into val using new;
    if public.contains_email(val) then
      raise exception 'DBAD: % contains an email address. Contact details are never published.', col
        using errcode = 'check_violation', hint = 'Describe the behaviour, not the person.';
    end if;
    if public.contains_phone(val) then
      raise exception 'DBAD: % contains a phone number. Contact details are never published.', col
        using errcode = 'check_violation', hint = 'Describe the behaviour, not the person.';
    end if;
  end loop;
  return new;
end;
$$;
comment on function public.reject_contact_details() is
  'Row trigger. Pass the names of the free-text columns to guard as trigger arguments.';

-- ---------------------------------------------------------------------------
-- profiles — 1:1 with auth.users. Public facing; contains nothing private.
-- ---------------------------------------------------------------------------
create table public.profiles (
  id            uuid primary key references auth.users (id) on delete cascade,
  handle        citext not null unique
                  constraint profiles_handle_shape check (handle::text ~ '^[a-z0-9][a-z0-9_.]{2,29}$'),
  display_name  text not null constraint profiles_display_name_len check (char_length(display_name) between 1 and 60),
  avatar_seed   text not null default '',
  role          public.user_role not null default 'member',
  member_since  date not null default current_date,
  bio           text constraint profiles_bio_len check (char_length(bio) <= 280),
  home_area     text constraint profiles_home_area_len check (char_length(home_area) <= 80),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
comment on table public.profiles is 'Public member profile, one per auth user. Created by handle_new_user().';
comment on column public.profiles.handle is 'Lower-case, unique, case-insensitive (citext). Shown publicly.';
comment on column public.profiles.avatar_seed is 'Deterministic seed for the generated sticker avatar — not an image URL.';
comment on column public.profiles.home_area is 'Member-chosen area such as "South Coast, NSW". Never precise, never an address.';
comment on column public.profiles.role is 'Changed only through moderate(''change_role'') — see profiles_guard_role.';

create trigger profiles_set_updated_at before update on public.profiles
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- categories — editable copy, seeded from src/lib/domain/categories.ts.
-- ---------------------------------------------------------------------------
create table public.categories (
  id          text primary key constraint categories_id_shape check (id ~ '^[a-z_]{2,32}$'),
  label       text not null,        -- loud label: "PARKING DICK"
  short       text not null,        -- chip label: "Parking"
  blurb       text not null,
  caution     text,                 -- guard-rail copy shown in the wizard
  accent      public.category_accent not null default 'warning',
  sort_order  int not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
comment on table public.categories is 'Nomination categories. Copy is editable by admins via moderate(''edit_category'').';

create trigger categories_set_updated_at before update on public.categories
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------
-- locations — suburb-level only. A residential address must never be storable
-- here, so `place` is capped, checked, and only meaningful when it names a
-- clearly public place ("Coles car park", "Mollymook Beach").
-- ---------------------------------------------------------------------------
create table public.locations (
  id          uuid primary key default gen_random_uuid(),
  suburb      text not null constraint locations_suburb_len check (char_length(btrim(suburb)) between 2 and 60),
  state       public.australian_state not null,
  place       text constraint locations_place_len check (char_length(place) <= 80),
  approx_lat  numeric(9, 6) constraint locations_lat_range check (approx_lat between -44 and -10),
  approx_lng  numeric(9, 6) constraint locations_lng_range check (approx_lng between 112 and 154),
  precision   public.location_precision not null default 'suburb',
  region      text not null constraint locations_region_len check (char_length(region) between 2 and 60),
  created_at  timestamptz not null default now(),
  -- A "place" precision claim without a place name is a lie about the data.
  constraint locations_precision_matches_place
    check (precision = 'suburb' or place is not null),
  -- Street addresses are not locations. Reject "12 Smith Street" shapes outright.
  constraint locations_no_street_address
    check (coalesce(place, '') !~* '^[0-9]{1,5}[a-z]?[ /-]')
);
comment on table public.locations is 'Approximate, public, suburb-level places. Never an address, never a home.';
comment on column public.locations.approx_lat is 'Suburb/town centroid, not the incident. Australia-only range enforced.';
comment on column public.locations.precision is 'How precise the record claims to be: suburb centroid, or a named public place.';

-- One row per distinct public place so the map clusters cleanly.
create unique index locations_unique_place
  on public.locations (lower(suburb), state, coalesce(lower(place), ''));
create index locations_region_idx on public.locations (region);
create index locations_state_idx on public.locations (state);

-- ---------------------------------------------------------------------------
-- incidents — the nomination itself.
-- ---------------------------------------------------------------------------
create table public.incidents (
  id                 uuid primary key default gen_random_uuid(),
  seq                bigint generated by default as identity not null unique,
  short_code         text generated always as (public.short_code(seq)) stored,
  slug               text not null unique,
  kind               public.incident_kind not null default 'dick_move',
  category_id        text not null references public.categories (id) on update cascade,
  title              text not null constraint incidents_title_len check (char_length(title) between 4 and 120),
  dick_move          text not null constraint incidents_dick_move_len check (char_length(dick_move) between 4 and 90),
  description        text not null constraint incidents_description_len check (char_length(description) between 12 and 600),
  affected           text[] not null default '{}'
                       constraint incidents_affected_known check (affected <@ public.affected_groups()),
  location_id        uuid not null references public.locations (id) on delete restrict,
  occurred_on        date not null constraint incidents_occurred_not_future check (occurred_on <= (current_date + 1)),
  part_of_day        public.part_of_day not null default 'unknown',
  submitter_id       uuid references public.profiles (id) on delete set null,
  status             public.incident_status not null default 'open',
  moderation_status  public.moderation_status not null default 'pending',
  anonymised         boolean not null default false,
  featured_week      date,
  advice             text constraint incidents_advice_len check (char_length(advice) <= 140),
  -- Set from the redemption row by trigger, so "latest redemptions" can be
  -- ordered without reaching into a joined table.
  redeemed_at        timestamptz,

  -- Denormalised tallies. Maintained by triggers on votes/reactions/comments;
  -- never written directly by the application.
  votes_not          int not null default 0 constraint incidents_votes_not_positive check (votes_not >= 0),
  votes_bit          int not null default 0 constraint incidents_votes_bit_positive check (votes_bit >= 0),
  votes_definitely   int not null default 0 constraint incidents_votes_definitely_positive check (votes_definitely >= 0),
  votes_absolute     int not null default 0 constraint incidents_votes_absolute_positive check (votes_absolute >= 0),
  react_fair_call    int not null default 0 constraint incidents_react_fair_call_positive check (react_fair_call >= 0),
  react_classic      int not null default 0 constraint incidents_react_classic_positive check (react_classic >= 0),
  react_dick_move    int not null default 0 constraint incidents_react_dick_move_positive check (react_dick_move >= 0),
  react_redemption   int not null default 0 constraint incidents_react_redemption_positive check (react_redemption >= 0),
  comment_count      int not null default 0 constraint incidents_comment_count_positive check (comment_count >= 0),

  votes_total int generated always as
    (votes_not + votes_bit + votes_definitely + votes_absolute) stored,

  -- Confidence-weighted dickery, mirroring dickeryRank() in domain/verdict.ts.
  -- Small samples cannot top the chart (Wilson-ish damping, k = 8).
  dickery_rank double precision generated always as (
    case when (votes_not + votes_bit + votes_definitely + votes_absolute) = 0 then 0
    else ((votes_bit::double precision / 3)
          + (votes_definitely::double precision * 2 / 3)
          + votes_absolute::double precision)
         / (votes_not + votes_bit + votes_definitely + votes_absolute)
         * ((votes_not + votes_bit + votes_definitely + votes_absolute)::double precision
            / ((votes_not + votes_bit + votes_definitely + votes_absolute) + 8))
    end) stored,

  -- Denormalised from the location, maintained by incidents_sync_location.
  -- The feed filters and clusters by state and region on every request, and the
  -- search index needs the place words; a join for that on every row is waste.
  state          public.australian_state not null,
  region         text not null,
  location_label text not null default '',
  search tsvector generated always as (
      setweight(to_tsvector('english', coalesce(title, '') || ' ' || coalesce(dick_move, '')), 'A')
   || setweight(to_tsvector('english', coalesce(description, '')), 'B')
   || setweight(to_tsvector('english', coalesce(location_label, '')), 'C')
  ) stored,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  -- An anonymised nomination has had its submitter detached, by definition.
  constraint incidents_anonymised_has_no_submitter
    check (not anonymised or submitter_id is null)
);
comment on table public.incidents is 'A nominated behaviour. Describes what happened, never who did it.';
comment on column public.incidents.seq is 'Human-facing sequence behind the short code. Stable for the life of the row.';
comment on column public.incidents.short_code is 'Printed on notices and QR codes: DBAD-0042.';
comment on column public.incidents.dick_move is 'The behaviour stated plainly: "Blocking the footpath."';
comment on column public.incidents.moderation_status is 'Platform lifecycle. Only ''approved'' is public.';
comment on column public.incidents.status is 'Lifecycle of the behaviour itself: open, redeemed by the doer, or overruled by the community.';
comment on column public.incidents.anonymised is 'Submitter detached at their request or by a moderator. Irreversible.';
comment on column public.incidents.featured_week is 'ISO Monday of the week this was Dick Move of the Week.';
comment on column public.incidents.state is 'Denormalised from locations.state. Kept in sync by trigger; never set by hand.';
comment on column public.incidents.region is 'Denormalised from locations.region — the map cluster this belongs to.';
comment on column public.incidents.location_label is 'Denormalised location text for search only. Kept in sync by trigger.';

-- Feed queries: public list ordered by recency, and the same filtered by
-- category / kind / status. moderation_status leads every one of them.
create index incidents_public_recent_idx
  on public.incidents (moderation_status, created_at desc);
create index incidents_public_category_idx
  on public.incidents (moderation_status, category_id, created_at desc);
create index incidents_public_kind_idx
  on public.incidents (moderation_status, kind, created_at desc);
create index incidents_public_status_idx
  on public.incidents (moderation_status, status, created_at desc);
create index incidents_public_region_idx
  on public.incidents (moderation_status, region, created_at desc);
create index incidents_public_state_idx
  on public.incidents (moderation_status, state, created_at desc);
create index incidents_top_idx
  on public.incidents (moderation_status, dickery_rank desc) where moderation_status = 'approved';
create index incidents_redeemed_idx
  on public.incidents (redeemed_at desc) where status = 'redeemed';
create index incidents_location_idx on public.incidents (location_id);
create index incidents_submitter_idx on public.incidents (submitter_id, created_at desc);
create index incidents_category_idx on public.incidents (category_id);
create index incidents_search_idx on public.incidents using gin (search);
-- At most one Dick Move of the Week per week.
create unique index incidents_featured_week_key
  on public.incidents (featured_week) where featured_week is not null;
-- Moderation queue: oldest first.
create index incidents_pending_idx
  on public.incidents (created_at) where moderation_status = 'pending';

create trigger incidents_set_updated_at before update on public.incidents
  for each row execute function public.set_updated_at();
create trigger incidents_reject_contact_details
  before insert or update of title, dick_move, description, advice on public.incidents
  for each row execute function public.reject_contact_details('title', 'dick_move', 'description', 'advice');

-- Keep the denormalised location columns in step with the row they point at.
create or replace function public.incidents_sync_location() returns trigger
language plpgsql as $$
declare
  l public.locations%rowtype;
begin
  select * into l from public.locations where id = new.location_id;
  if not found then
    raise exception 'DBAD: location % does not exist', new.location_id using errcode = 'foreign_key_violation';
  end if;
  new.state := l.state;
  new.region := l.region;
  new.location_label := concat_ws(' ', l.suburb, l.place, l.state::text, l.region);
  return new;
end;
$$;
create trigger incidents_location_columns
  before insert or update of location_id on public.incidents
  for each row execute function public.incidents_sync_location();

create or replace function public.locations_resync_incidents() returns trigger
language plpgsql as $$
begin
  update public.incidents
     set state = new.state,
         region = new.region,
         location_label = concat_ws(' ', new.suburb, new.place, new.state::text, new.region)
   where location_id = new.id;
  return new;
end;
$$;
create trigger locations_resync_incident_labels
  after update of suburb, place, state, region on public.locations
  for each row execute function public.locations_resync_incidents();

-- Auto-slug: "<dick move>-<suburb>-<seq>" when the caller did not supply one.
-- Identity defaults are materialised before BEFORE-triggers run, so NEW.seq is
-- already the final value here.
create or replace function public.incidents_autoslug() returns trigger
language plpgsql as $$
declare
  suburb text;
begin
  if new.slug is null or btrim(new.slug) = '' then
    select l.suburb into suburb from public.locations l where l.id = new.location_id;
    new.slug := public.slugify(new.dick_move) || '-' || public.slugify(coalesce(suburb, 'australia'))
                || '-' || lpad(new.seq::text, 4, '0');
  end if;
  return new;
end;
$$;
create trigger incidents_set_slug before insert on public.incidents
  for each row execute function public.incidents_autoslug();

-- ---------------------------------------------------------------------------
-- incident_photos — evidence. Faces and plates are redacted client-side before
-- upload; `redacted` records that the submitter completed the redaction review
-- and `redaction_count` how many areas were painted out.
-- ---------------------------------------------------------------------------
create table public.incident_photos (
  id               uuid primary key default gen_random_uuid(),
  incident_id      uuid not null references public.incidents (id) on delete cascade,
  storage_path     text,   -- object key inside the incident-photos bucket: "<uid>/<uuid>.jpg"
  url              text not null,
  width            int not null constraint incident_photos_width check (width between 1 and 10000),
  height           int not null constraint incident_photos_height check (height between 1 and 10000),
  alt              text not null default '',
  redacted         boolean not null default false,
  redaction_count  int not null default 0 constraint incident_photos_redaction_count check (redaction_count >= 0),
  sort_order       int not null default 0,
  created_at       timestamptz not null default now()
);
comment on table public.incident_photos is 'Evidence photos. Unredacted photos never go public — see the RLS policy.';
comment on column public.incident_photos.storage_path is 'Key in the incident-photos bucket. Null for seeded/static images.';
comment on column public.incident_photos.redacted is 'Submitter completed the redaction review step.';

create index incident_photos_incident_idx on public.incident_photos (incident_id, sort_order);

-- ---------------------------------------------------------------------------
-- social_sources — provenance for community examples that started on Facebook.
-- DBAD never scrapes: a member pastes a public post URL, or oEmbed is used.
-- ---------------------------------------------------------------------------
create table public.social_sources (
  id            uuid primary key default gen_random_uuid(),
  incident_id   uuid not null unique references public.incidents (id) on delete cascade,
  platform      public.social_platform not null default 'facebook',
  url           text not null constraint social_sources_url_shape
                  check (url ~* '^https?://(www\.|m\.|web\.)?(facebook\.com|fb\.com|fb\.watch)/'),
  retrieved_via public.social_retrieval not null default 'manual',
  note          text constraint social_sources_note_len check (char_length(note) <= 280),
  created_at    timestamptz not null default now()
);
comment on table public.social_sources is 'Where a community example came from. Manual paste or official oEmbed only.';

-- ---------------------------------------------------------------------------
-- votes / reactions — one vote and any number of reactions per member.
-- ---------------------------------------------------------------------------
create table public.votes (
  incident_id uuid not null references public.incidents (id) on delete cascade,
  user_id     uuid not null references public.profiles (id) on delete cascade,
  verdict     public.verdict not null,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  primary key (incident_id, user_id)
);
comment on table public.votes is 'The Dick-o-meter. One vote per member per nomination, changeable.';
create index votes_user_idx on public.votes (user_id);

create trigger votes_set_updated_at before update on public.votes
  for each row execute function public.set_updated_at();

create table public.reactions (
  incident_id uuid not null references public.incidents (id) on delete cascade,
  user_id     uuid not null references public.profiles (id) on delete cascade,
  kind        public.reaction_kind not null,
  created_at  timestamptz not null default now(),
  primary key (incident_id, user_id, kind)
);
create index reactions_user_idx on public.reactions (user_id);

-- Counter maintenance. The tallies on incidents are a cache of these tables and
-- are only ever written here.
create or replace function public.votes_sync_counters() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  target uuid := coalesce(new.incident_id, old.incident_id);
begin
  if tg_op in ('UPDATE', 'DELETE') then
    update public.incidents set
      votes_not        = greatest(0, votes_not        - (old.verdict = 'not')::int),
      votes_bit        = greatest(0, votes_bit        - (old.verdict = 'bit')::int),
      votes_definitely = greatest(0, votes_definitely - (old.verdict = 'definitely')::int),
      votes_absolute   = greatest(0, votes_absolute   - (old.verdict = 'absolute')::int)
    where id = old.incident_id;
  end if;
  if tg_op in ('INSERT', 'UPDATE') then
    update public.incidents set
      votes_not        = votes_not        + (new.verdict = 'not')::int,
      votes_bit        = votes_bit        + (new.verdict = 'bit')::int,
      votes_definitely = votes_definitely + (new.verdict = 'definitely')::int,
      votes_absolute   = votes_absolute   + (new.verdict = 'absolute')::int
    where id = new.incident_id;
  end if;
  perform 1 from public.incidents where id = target;
  return coalesce(new, old);
end;
$$;
create trigger votes_counters after insert or update or delete on public.votes
  for each row execute function public.votes_sync_counters();

create or replace function public.reactions_sync_counters() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    update public.incidents set
      react_fair_call  = react_fair_call  + (new.kind = 'fair_call')::int,
      react_classic    = react_classic    + (new.kind = 'classic')::int,
      react_dick_move  = react_dick_move  + (new.kind = 'dick_move')::int,
      react_redemption = react_redemption + (new.kind = 'redemption')::int
    where id = new.incident_id;
    return new;
  else
    update public.incidents set
      react_fair_call  = greatest(0, react_fair_call  - (old.kind = 'fair_call')::int),
      react_classic    = greatest(0, react_classic    - (old.kind = 'classic')::int),
      react_dick_move  = greatest(0, react_dick_move  - (old.kind = 'dick_move')::int),
      react_redemption = greatest(0, react_redemption - (old.kind = 'redemption')::int)
    where id = old.incident_id;
    return old;
  end if;
end;
$$;
create trigger reactions_counters after insert or delete on public.reactions
  for each row execute function public.reactions_sync_counters();

-- ---------------------------------------------------------------------------
-- comments
-- ---------------------------------------------------------------------------
create table public.comments (
  id          uuid primary key default gen_random_uuid(),
  incident_id uuid not null references public.incidents (id) on delete cascade,
  author_id   uuid not null references public.profiles (id) on delete cascade,
  body        text not null constraint comments_body_len check (char_length(btrim(body)) between 2 and 600),
  status      public.comment_status not null default 'visible',
  parent_id   uuid references public.comments (id) on delete cascade,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
comment on table public.comments is 'Community commentary. Comments that identify a person are auto-held as hidden.';
comment on column public.comments.status is 'visible (public), hidden (held for a moderator), removed (gone).';

create index comments_incident_idx on public.comments (incident_id, created_at);
create index comments_author_idx on public.comments (author_id, created_at desc);
create index comments_status_idx on public.comments (status, created_at desc);

create trigger comments_set_updated_at before update on public.comments
  for each row execute function public.set_updated_at();
create trigger comments_reject_contact_details
  before insert or update of body on public.comments
  for each row execute function public.reject_contact_details('body');

-- comment_count counts visible comments only, exactly like the demo store.
create or replace function public.comments_sync_counters() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  before_visible int := case when tg_op in ('UPDATE', 'DELETE') and old.status = 'visible' then 1 else 0 end;
  after_visible  int := case when tg_op in ('INSERT', 'UPDATE') and new.status = 'visible' then 1 else 0 end;
begin
  if tg_op = 'UPDATE' and old.incident_id <> new.incident_id then
    update public.incidents set comment_count = greatest(0, comment_count - before_visible) where id = old.incident_id;
    update public.incidents set comment_count = comment_count + after_visible where id = new.incident_id;
  elsif after_visible <> before_visible then
    update public.incidents
       set comment_count = greatest(0, comment_count + after_visible - before_visible)
     where id = coalesce(new.incident_id, old.incident_id);
  end if;
  return coalesce(new, old);
end;
$$;
create trigger comments_counters after insert or update or delete on public.comments
  for each row execute function public.comments_sync_counters();

-- ---------------------------------------------------------------------------
-- reports — anyone (including anonymous visitors) can flag content.
-- ---------------------------------------------------------------------------
create table public.reports (
  id           uuid primary key default gen_random_uuid(),
  target_type  public.report_target_type not null,
  target_id    uuid not null,
  reason       public.report_reason not null,
  details      text constraint reports_details_len check (char_length(details) <= 1000),
  reporter_id  uuid references public.profiles (id) on delete set null,
  status       public.report_status not null default 'open',
  created_at   timestamptz not null default now(),
  resolved_at  timestamptz,
  resolved_by  uuid references public.profiles (id) on delete set null
);
comment on table public.reports is 'Content flags. Readable by moderators only — a report can name the reporter.';
comment on column public.reports.target_id is 'incidents.id or comments.id depending on target_type (polymorphic, validated in report_content()).';

create index reports_status_idx on public.reports (status, created_at desc);
create index reports_target_idx on public.reports (target_type, target_id);

-- ---------------------------------------------------------------------------
-- appeals — right of reply for someone who believes a post is about them.
-- `contact` is the only place on the platform where a private contact detail is
-- allowed to live, and it is moderator-only. It is deliberately exempt from the
-- contact-details trigger: an appeal without a way to reply is useless.
-- ---------------------------------------------------------------------------
create table public.appeals (
  id               uuid primary key default gen_random_uuid(),
  incident_id      uuid not null references public.incidents (id) on delete cascade,
  requested_action public.appeal_action not null,
  message          text not null constraint appeals_message_len check (char_length(btrim(message)) between 10 and 2000),
  contact          text constraint appeals_contact_len check (char_length(contact) <= 200),
  status           public.appeal_status not null default 'open',
  public_reply     text constraint appeals_public_reply_len check (char_length(public_reply) <= 600),
  reference        text generated always as (upper(right(id::text, 8))) stored,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
comment on table public.appeals is 'Appeals and right-of-reply requests. Moderators only; see the appeal_replies view for the public part.';
comment on column public.appeals.contact is 'PRIVATE. Never exposed to anon or members, never returned by any public view.';
comment on column public.appeals.public_reply is 'Optional right-of-reply published under the nomination once the appeal is actioned.';
comment on column public.appeals.reference is 'Short reference quoted back to the appellant.';

create index appeals_status_idx on public.appeals (status, created_at desc);
create index appeals_incident_idx on public.appeals (incident_id);

create trigger appeals_set_updated_at before update on public.appeals
  for each row execute function public.set_updated_at();
-- Only the published part is scanned; message and contact are private by design.
create trigger appeals_reject_contact_details
  before insert or update of public_reply on public.appeals
  for each row execute function public.reject_contact_details('public_reply');

-- ---------------------------------------------------------------------------
-- redemptions — the good ending. One per incident.
-- ---------------------------------------------------------------------------
create table public.redemptions (
  id           uuid primary key default gen_random_uuid(),
  incident_id  uuid not null unique references public.incidents (id) on delete cascade,
  note         text not null constraint redemptions_note_len check (char_length(btrim(note)) between 2 and 300),
  confirmed_by public.redemption_source not null default 'submitter',
  created_at   timestamptz not null default now()
);
comment on table public.redemptions is 'Recorded when a dick move gets sorted. Humanity survives another day.';

create trigger redemptions_reject_contact_details
  before insert or update of note on public.redemptions
  for each row execute function public.reject_contact_details('note');

create or replace function public.redemptions_sync_incident() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'DELETE' then
    update public.incidents set redeemed_at = null where id = old.incident_id;
    return old;
  end if;
  update public.incidents set redeemed_at = new.created_at where id = new.incident_id;
  return new;
end;
$$;
create trigger redemptions_stamp_incident after insert or update or delete on public.redemptions
  for each row execute function public.redemptions_sync_incident();

-- ---------------------------------------------------------------------------
-- moderation_actions — append-only audit log.
-- ---------------------------------------------------------------------------
create table public.moderation_actions (
  id          uuid primary key default gen_random_uuid(),
  actor_id    uuid not null references public.profiles (id) on delete restrict,
  action      public.moderation_action_kind not null,
  target_type public.moderation_target_type not null,
  target_id   text not null,
  note        text constraint moderation_actions_note_len check (char_length(note) <= 500),
  payload     jsonb,
  created_at  timestamptz not null default now()
);
comment on table public.moderation_actions is 'Every moderator decision, append-only. Written by moderate().';
comment on column public.moderation_actions.target_id is 'Text because targets include uuids (incidents, comments) and text ids (categories, templates).';

create index moderation_actions_recent_idx on public.moderation_actions (created_at desc);
create index moderation_actions_target_idx on public.moderation_actions (target_type, target_id);
create index moderation_actions_actor_idx on public.moderation_actions (actor_id, created_at desc);

-- ---------------------------------------------------------------------------
-- printable_notices — the five lines that get printed and left on a windscreen.
-- ---------------------------------------------------------------------------
create table public.printable_notices (
  id          uuid primary key default gen_random_uuid(),
  incident_id uuid references public.incidents (id) on delete set null,
  template    public.notice_template not null default 'official-warning',
  link_mode   public.notice_link_mode not null default 'site',
  headline    text not null default '' constraint printable_notices_headline_len check (char_length(headline) <= 60),
  dick_move   text not null default '' constraint printable_notices_dick_move_len check (char_length(dick_move) <= 90),
  why         text not null default '' constraint printable_notices_why_len check (char_length(why) <= 220),
  location    text not null default '' constraint printable_notices_location_len check (char_length(location) <= 80),
  advice      text not null default '' constraint printable_notices_advice_len check (char_length(advice) <= 140),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  created_by  uuid references public.profiles (id) on delete set null
);
comment on table public.printable_notices is 'A printable DBAD notice. Public by design — it is meant to be handed out.';
comment on column public.printable_notices.link_mode is 'Whether the QR code points at the site or at this specific nomination.';

create index printable_notices_incident_idx on public.printable_notices (incident_id);
create index printable_notices_creator_idx on public.printable_notices (created_by, created_at desc);

create trigger printable_notices_set_updated_at before update on public.printable_notices
  for each row execute function public.set_updated_at();
create trigger printable_notices_reject_contact_details
  before insert or update of headline, dick_move, why, location, advice on public.printable_notices
  for each row execute function public.reject_contact_details('headline', 'dick_move', 'why', 'location', 'advice');

-- ---------------------------------------------------------------------------
-- badges / user_badges
-- ---------------------------------------------------------------------------
create table public.badges (
  id          text primary key constraint badges_id_shape check (id ~ '^[a-z_]{2,40}$'),
  name        text not null,
  blurb       text not null,
  rule        text not null,     -- human-readable rule; the machine rule lives in refresh_badges()
  sort_order  int not null default 0,
  created_at  timestamptz not null default now()
);
comment on table public.badges is 'Badge catalogue, seeded from src/lib/domain/badges.ts.';

create table public.user_badges (
  user_id    uuid not null references public.profiles (id) on delete cascade,
  badge_id   text not null references public.badges (id) on update cascade on delete cascade,
  awarded_at timestamptz not null default now(),
  primary key (user_id, badge_id)
);
create index user_badges_user_idx on public.user_badges (user_id, awarded_at desc);

-- ---------------------------------------------------------------------------
-- notifications — own-only, always.
-- ---------------------------------------------------------------------------
create table public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles (id) on delete cascade,
  kind       public.notification_kind not null,
  title      text not null constraint notifications_title_len check (char_length(title) <= 120),
  body       text not null default '' constraint notifications_body_len check (char_length(body) <= 400),
  href       text,
  created_at timestamptz not null default now(),
  read_at    timestamptz
);
comment on table public.notifications is 'Per-member notifications. Readable only by the member they belong to.';

create index notifications_user_idx on public.notifications (user_id, created_at desc);
create index notifications_unread_idx on public.notifications (user_id) where read_at is null;

-- ---------------------------------------------------------------------------
-- Sign-up: create the public profile for a new auth user.
-- Handle comes from the sign-up metadata, else the email local part, and is
-- de-duplicated with a numeric suffix.
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare
  raw        text;
  base       text;
  candidate  text;
  n          int := 1;
begin
  raw := coalesce(new.raw_user_meta_data ->> 'handle', split_part(coalesce(new.email, ''), '@', 1), '');
  base := regexp_replace(lower(raw), '[^a-z0-9_.]', '', 'g');
  base := regexp_replace(base, '^[^a-z0-9]+', '');
  base := left(base, 24);
  if char_length(base) < 3 then
    base := 'member' || right(replace(new.id::text, '-', ''), 6);
  end if;

  candidate := base;
  while exists (select 1 from public.profiles p where p.handle = candidate::citext) loop
    n := n + 1;
    candidate := left(base, 26) || n::text;
  end loop;

  insert into public.profiles (id, handle, display_name, avatar_seed, member_since, bio, home_area)
  values (
    new.id,
    candidate,
    coalesce(nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''), initcap(replace(candidate, '_', ' '))),
    coalesce(nullif(btrim(new.raw_user_meta_data ->> 'avatar_seed'), ''), candidate),
    coalesce((new.created_at)::date, current_date),
    nullif(btrim(new.raw_user_meta_data ->> 'bio'), ''),
    nullif(btrim(new.raw_user_meta_data ->> 'home_area'), '')
  )
  on conflict (id) do nothing;

  return new;
end;
$$;
comment on function public.handle_new_user() is
  'auth.users insert trigger. Derives a unique handle and creates the public profile.';

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Role changes are a moderation action, not a profile edit. moderate() sets a
-- transaction-local flag before it writes; nothing else may change the column,
-- not even an admin patching the table directly.
-- ---------------------------------------------------------------------------
create or replace function public.profiles_guard_role() returns trigger
language plpgsql as $$
begin
  if new.role is distinct from old.role
     and coalesce(current_setting('dbad.role_change', true), '') <> 'on' then
    raise exception 'DBAD: roles change through moderate(''change_role'') only.'
      using errcode = 'insufficient_privilege';
  end if;
  return new;
end;
$$;
create trigger profiles_guard_role before update on public.profiles
  for each row execute function public.profiles_guard_role();
