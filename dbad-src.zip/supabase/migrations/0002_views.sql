-- ===========================================================================
-- DBAD — 0002 views and the verdict maths
--
-- Two views, both of which earn their keep:
--
--   member_stats   — the six numbers behind every profile page, badge rule and
--                    the admin member list, computed once instead of six times.
--   appeal_replies — the ONLY public window onto the appeals table. Appeals hold
--                    a private contact and a private message, so the table is
--                    moderator-only at row level and the published right-of-reply
--                    is exposed through this view instead. The view runs with the
--                    owner's rights on purpose (no security_invoker): that is what
--                    lets an anonymous reader see a reply without ever being able
--                    to see the appeal it came from.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- The Dick-o-meter, in SQL. Mirrors src/lib/domain/verdict.ts exactly.
-- ---------------------------------------------------------------------------
create or replace function public.min_votes_for_verdict() returns int
language sql immutable parallel safe as $$ select 5; $$;
comment on function public.min_votes_for_verdict() is 'MIN_VOTES_FOR_VERDICT in src/lib/domain/verdict.ts.';

-- Mean dickery level across all votes, 0-100. Levels: not 0, bit 1/3,
-- definitely 2/3, absolute 1.
create or replace function public.verdict_percent(nt int, bt int, dt int, at int) returns int
language sql immutable parallel safe as $$
  select case when coalesce(nt, 0) + coalesce(bt, 0) + coalesce(dt, 0) + coalesce(at, 0) = 0 then 0
    else round(
      ((bt::numeric / 3) + (dt::numeric * 2 / 3) + at::numeric)
      / (nt + bt + dt + at) * 100)::int
  end;
$$;

-- Share of voters who thought it was at least a bit of a dick move, 0-100.
create or replace function public.verdict_agree_percent(nt int, bt int, dt int, at int) returns int
language sql immutable parallel safe as $$
  select case when coalesce(nt, 0) + coalesce(bt, 0) + coalesce(dt, 0) + coalesce(at, 0) = 0 then 0
    else round((bt + dt + at)::numeric / (nt + bt + dt + at) * 100)::int
  end;
$$;

-- 'pending' until MIN_VOTES_FOR_VERDICT votes are in, then the band.
create or replace function public.verdict_band(nt int, bt int, dt int, at int) returns text
language sql immutable parallel safe as $$
  select case
    when coalesce(nt, 0) + coalesce(bt, 0) + coalesce(dt, 0) + coalesce(at, 0) < public.min_votes_for_verdict() then 'pending'
    when public.verdict_percent(nt, bt, dt, at) < 25 then 'not'
    when public.verdict_percent(nt, bt, dt, at) < 50 then 'bit'
    when public.verdict_percent(nt, bt, dt, at) < 80 then 'definitely'
    else 'absolute'
  end;
$$;

-- "Community verdict: 94% Dick Move"
create or replace function public.verdict_share_line(nt int, bt int, dt int, at int) returns text
language sql immutable parallel safe as $$
  select 'Community verdict: ' || public.verdict_agree_percent(nt, bt, dt, at)::text || '% Dick Move';
$$;

-- ---------------------------------------------------------------------------
-- member_stats — one row per member. Mirrors DemoRepository.stats().
-- Only approved nominations count; a verdict counts as a fair call once the
-- community has reached one, and as overruled if the band came back 'not' or a
-- moderator marked the nomination overruled.
-- ---------------------------------------------------------------------------
create or replace view public.member_stats as
select
  p.id as user_id,
  coalesce(i.spotted, 0)     as spotted,
  coalesce(i.fair_calls, 0)  as fair_calls,
  coalesce(i.redeemed, 0)    as redeemed,
  coalesce(i.overruled, 0)   as overruled,
  coalesce(i.not_a_dick, 0)  as not_a_dick,
  coalesce(c.comments, 0)    as comments
from public.profiles p
left join lateral (
  select
    count(*) filter (where inc.kind = 'dick_move')::int as spotted,
    count(*) filter (where inc.kind = 'not_a_dick')::int as not_a_dick,
    count(*) filter (where inc.status = 'redeemed')::int as redeemed,
    count(*) filter (
      where inc.kind = 'dick_move'
        and public.verdict_band(inc.votes_not, inc.votes_bit, inc.votes_definitely, inc.votes_absolute) <> 'pending'
        and (public.verdict_band(inc.votes_not, inc.votes_bit, inc.votes_definitely, inc.votes_absolute) = 'not'
             or inc.status = 'overruled')
    )::int as overruled,
    count(*) filter (
      where inc.kind = 'dick_move'
        and public.verdict_band(inc.votes_not, inc.votes_bit, inc.votes_definitely, inc.votes_absolute) <> 'pending'
        and public.verdict_band(inc.votes_not, inc.votes_bit, inc.votes_definitely, inc.votes_absolute) <> 'not'
        and inc.status <> 'overruled'
    )::int as fair_calls
  from public.incidents inc
  where inc.submitter_id = p.id and inc.moderation_status = 'approved'
) i on true
left join lateral (
  select count(*)::int as comments
  from public.comments cm
  where cm.author_id = p.id and cm.status = 'visible'
) c on true;
comment on view public.member_stats is
  'Per-member counters behind profile pages and badge rules. Mirrors DemoRepository.stats().';

-- ---------------------------------------------------------------------------
-- appeal_replies — the published right of reply, and nothing else from the
-- appeals table. Deliberately owner-rights (not security_invoker) so that the
-- private columns stay unreachable while the reply itself is public.
-- ---------------------------------------------------------------------------
create or replace view public.appeal_replies as
select a.id, a.incident_id, a.public_reply, a.created_at
from public.appeals a
where a.status = 'actioned'
  and a.public_reply is not null
  and btrim(a.public_reply) <> '';
comment on view public.appeal_replies is
  'Public right-of-reply text for actioned appeals. Never exposes message, contact or status.';
