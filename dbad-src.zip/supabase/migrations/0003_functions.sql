-- ===========================================================================
-- DBAD — 0003 functions (the RPC surface)
--
-- Every write the application performs goes through one of the functions in
-- this file. They are SECURITY DEFINER with `set search_path = public` and they
-- do their own authorisation with auth.uid() and viewer_role() — RLS is the
-- second lock, not the only one.
--
-- They return jsonb shaped like ActionResult in src/lib/domain/types.ts
-- ({ ok, message?, fieldErrors?, ...data }) instead of raising, because every
-- one of these failures is a thing to say to a member, not a 500.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Viewer helpers. SECURITY DEFINER so that RLS policies can call them without
-- recursing into the profiles policy.
-- ---------------------------------------------------------------------------
create or replace function public.viewer_role() returns public.user_role
language sql stable security definer set search_path = public as $$
  select p.role from public.profiles p where p.id = auth.uid();
$$;
comment on function public.viewer_role() is 'Role of the signed-in member, or null when anonymous.';

create or replace function public.is_moderator() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.viewer_role() in ('moderator', 'admin'), false);
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.viewer_role() = 'admin', false);
$$;

-- ---------------------------------------------------------------------------
-- Text safety. POSIX ports of the rules in src/lib/domain/pii.ts. The browser
-- runs the TypeScript version for instant feedback; this is the authority.
-- ---------------------------------------------------------------------------

-- Threats are the only "block" that cannot be masked away — the post is refused.
create or replace function public.contains_threat(input text) returns boolean
language sql immutable parallel safe as $$
  select coalesce(input, '') ~* '(i(''ll| will| am going to| wanna| want to)\s+(kill|bash|smash|punch|hurt|find|get|stab|run over)|(kill|bash|smash|punch|stab)\s+(him|her|them|you|the (prick|bastard|idiot|c\S+))|you(''re| are) dead|watch your back|i know where you live|burn (his|her|their|your) (car|house))';
$$;

-- Which identifying details a piece of text contains. Kinds match FindingKind.
create or replace function public.pii_kinds(input text) returns text[]
language sql immutable parallel safe as $$
  select array_remove(array[
    case when public.contains_phone(input) then 'phone' end,
    case when public.contains_email(input) then 'email' end,
    case when input ~* 'https?://(www\.|m\.)?(facebook\.com|fb\.com|instagram\.com|tiktok\.com|linkedin\.com/in|x\.com|twitter\.com)/[A-Za-z0-9_.-]{2,}' then 'personal_profile_url' end,
    case when input ~ '(^|[[:space:](])@[A-Za-z0-9_.]{3,30}\y' then 'social_handle' end,
    case when input ~ '\y[0-9]{1,5}[A-Za-z]?(/[0-9]{1,4})?\s+([A-Z][A-Za-z''-]+\s){1,3}(Street|St|Road|Rd|Avenue|Ave|Drive|Dr|Crescent|Cres|Court|Ct|Place|Pl|Lane|Ln|Way|Parade|Pde|Close|Cl|Boulevard|Blvd|Circuit|Cct|Terrace|Tce|Highway|Hwy|Grove|Gr|Esplanade|Esp|Loop|Rise|Walk|Track)\y' then 'street_address' end,
    case when input ~ '\y(?!DBAD|COVID|ABN|GST)([A-Z]{2,3}[ -]?[0-9]{2,3}[ -]?[A-Z]{0,2}|[0-9]{3}[ -]?[A-Z]{3}|[0-9][A-Z]{2}[ -]?[0-9][A-Z]{2}|[A-Z][0-9]{3}[ -]?[A-Z]{3})\y' then 'rego' end,
    case when input ~ '((his|her|their) name is\s+[A-Z][a-z]+|named\s+[A-Z][a-z]+\y|(Mr|Mrs|Ms|Miss|Dr)\.?\s+[A-Z][a-z]{2,}\y)' then 'named_person' end
  ], null);
$$;
comment on function public.pii_kinds(text) is 'Identifying details found in text. Mirrors scanText().findings in domain/pii.ts.';

-- Masked copy of the text, matching ScanResult.cleaned. Rules are applied in the
-- same order as RULES in domain/pii.ts, because later masks must not chew on
-- the placeholders earlier ones leave behind.
create or replace function public.scrub_text(input text) returns text
language plpgsql immutable parallel safe as $$
declare
  t text := coalesce(input, '');
begin
  t := regexp_replace(t, '(\+?61[ -]?|\(0[0-9]\)[ -]?|0)([23478]([ -]?[0-9]){8}|1[38]00([ -]?[0-9]){6}|13([ -]?[0-9]){4})\y', '[phone removed]', 'g');
  t := regexp_replace(t, '[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', '[email removed]', 'gi');
  t := regexp_replace(t, 'https?://(www\.|m\.)?(facebook\.com|fb\.com|instagram\.com|tiktok\.com|linkedin\.com/in|x\.com|twitter\.com)/[A-Za-z0-9_.-]{2,}', '[profile link removed]', 'gi');
  t := regexp_replace(t, '(^|[[:space:](])@[A-Za-z0-9_.]{3,30}\y', '\1[handle removed]', 'g');
  t := regexp_replace(t, '\y[0-9]{1,5}[A-Za-z]?(/[0-9]{1,4})?\s+([A-Z][A-Za-z''-]+\s){1,3}(Street|St|Road|Rd|Avenue|Ave|Drive|Dr|Crescent|Cres|Court|Ct|Place|Pl|Lane|Ln|Way|Parade|Pde|Close|Cl|Boulevard|Blvd|Circuit|Cct|Terrace|Tce|Highway|Hwy|Grove|Gr|Esplanade|Esp|Loop|Rise|Walk|Track)\y\.?', '[address removed]', 'g');
  t := regexp_replace(t, '\y(?!DBAD|COVID|ABN|GST)([A-Z]{2,3}[ -]?[0-9]{2,3}[ -]?[A-Z]{0,2}|[0-9]{3}[ -]?[A-Z]{3}|[0-9][A-Z]{2}[ -]?[0-9][A-Z]{2}|[A-Z][0-9]{3}[ -]?[A-Z]{3})\y', '[rego removed]', 'g');
  t := regexp_replace(t, '((his|her|their) name is\s+[A-Z][a-z]+|named\s+[A-Z][a-z]+\y|(Mr|Mrs|Ms|Miss|Dr)\.?\s+[A-Z][a-z]{2,}\y)', '[name removed]', 'g');
  return btrim(regexp_replace(t, '\s{2,}', ' ', 'g'));
end;
$$;
comment on function public.scrub_text(text) is 'Masks contact details and identifiers. Mirrors scanText().cleaned in domain/pii.ts.';

-- ---------------------------------------------------------------------------
-- guess_region — rough clustering region for a new nomination. Mirrors
-- guessRegion() in demo-repository.ts, table for table.
-- ---------------------------------------------------------------------------
create or replace function public.guess_region(p_suburb text, p_state public.australian_state) returns text
language sql immutable parallel safe as $$
  select coalesce(
    case
      when lower(coalesce(p_suburb, '')) ~ 'batemans|batehaven|surf beach|moruya|broulee|narooma|ulladulla|mollymook|milton|tuross|malua|catalina|long beach|maloneys|lilli pilli|denhams|mossy|tomakin|rosedale|clyde' then 'South Coast NSW'
      when lower(coalesce(p_suburb, '')) ~ 'nowra|bomaderry|huskisson|vincentia|berry|kangaroo valley|sussex inlet|culburra|shoalhaven' then 'Shoalhaven'
      when lower(coalesce(p_suburb, '')) ~ 'merimbula|bega|eden|tathra|pambula|bermagui' then 'Sapphire Coast'
      when lower(coalesce(p_suburb, '')) ~ 'canberra|civic|fyshwick|woden|gungahlin|tuggeranong|belconnen|barton|kingston|braddon|dickson|queanbeyan|jerrabomberra|googong|parkes|yarralumla|manuka|phillip|weston|kambah|casey|harrison|bruce' then 'Canberra'
      when lower(coalesce(p_suburb, '')) ~ 'goulburn|marulan|yass|crookwell|bungendore' then 'Southern Tablelands'
      when lower(coalesce(p_suburb, '')) ~ 'wollongong|shellharbour|kiama|dapto|thirroul|corrimal|fairy meadow|figtree' then 'Illawarra'
      when lower(coalesce(p_suburb, '')) ~ 'newcastle|maitland|lake macquarie|charlestown|merewether|hamilton|kotara|cessnock' then 'Hunter'
      when lower(coalesce(p_suburb, '')) ~ 'gosford|bateau|erina|terrigal|wyong|tuggerah|woy woy|the entrance' then 'Central Coast'
      when lower(coalesce(p_suburb, '')) ~ 'sydney|parramatta|bondi|manly|penrith|liverpool|chatswood|newtown|surry|cbd|blacktown|hornsby|cronulla|marrickville' then 'Greater Sydney'
      when lower(coalesce(p_suburb, '')) ~ 'melbourne|fitzroy|richmond|st kilda|brunswick|footscray|carlton|dandenong|geelong|prahran|collingwood' then 'Melbourne'
      when lower(coalesce(p_suburb, '')) ~ 'brisbane|west end|south bank|fortitude|toowong|chermside|logan|ipswich|gold coast|surfers' then 'Brisbane'
      when lower(coalesce(p_suburb, '')) ~ 'perth|fremantle|joondalup|scarborough|subiaco|rockingham|mandurah' then 'Perth'
      when lower(coalesce(p_suburb, '')) ~ 'adelaide|glenelg|norwood|prospect|unley|port adelaide' then 'Adelaide'
      when lower(coalesce(p_suburb, '')) ~ 'hobart|launceston|sandy bay|kingston tas|glenorchy' then 'Hobart'
      when lower(coalesce(p_suburb, '')) ~ 'darwin|palmerston|casuarina|nightcliff' then 'Darwin'
    end,
    case p_state
      when 'NSW' then 'Regional NSW' when 'VIC' then 'Regional VIC' when 'QLD' then 'Regional QLD'
      when 'WA' then 'Regional WA' when 'SA' then 'Regional SA' when 'TAS' then 'Tasmania'
      when 'ACT' then 'Canberra' when 'NT' then 'Northern Territory'
    end,
    'Australia');
$$;

-- Find or create the public place a nomination happened at.
create or replace function public.upsert_location(
  p_suburb text, p_state public.australian_state, p_place text,
  p_lat numeric, p_lng numeric, p_region text default null
) returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_id uuid;
  v_place text := nullif(btrim(coalesce(p_place, '')), '');
  v_suburb text := btrim(p_suburb);
begin
  insert into public.locations (suburb, state, place, approx_lat, approx_lng, precision, region)
  values (
    v_suburb, p_state, v_place, p_lat, p_lng,
    case when v_place is null then 'suburb'::public.location_precision else 'place'::public.location_precision end,
    coalesce(nullif(btrim(coalesce(p_region, '')), ''), public.guess_region(v_suburb, p_state))
  )
  on conflict (lower(suburb), state, coalesce(lower(place), '')) do update
    set approx_lat = coalesce(public.locations.approx_lat, excluded.approx_lat),
        approx_lng = coalesce(public.locations.approx_lng, excluded.approx_lng)
  returning id into v_id;
  return v_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- Notice copy. Mirrors buildNoticeLines() in src/lib/notice/lines.ts, including
-- the hash32-seeded choice of "why" and "advice" lines.
-- ---------------------------------------------------------------------------
create or replace function public.notice_why_options(p_category text) returns text[]
language sql immutable parallel safe as $$
  select case p_category
    when 'parking' then array['People shouldn''t have to work around your car because you couldn''t park properly.', 'Everyone else had to improvise because one vehicle couldn''t be bothered.']
    when 'road' then array['Nobody arrives sooner. Everybody arrives angrier.', 'The road is shared. Drive like it.']
    when 'shopping' then array['Somebody else had to fix what you left behind.', 'The trolley bay was right there. It''s always right there.']
    when 'neighbourhood' then array['Shared spaces only work when they''re actually shared.', 'A public space is not a private one with extra people in it.']
    when 'rubbish' then array['A bin was in plain sight. Somebody else used it for you.', 'Take it with you. It isn''t heavy.']
    when 'dog' then array['Good dog. The human holding the lead is responsible for the rest.', 'The dog is never the dick. The owner has one job.']
    when 'internet' then array['A public post made things harder for real people for no good reason.', 'The internet remembers. DBAD forgives if it''s fixed.']
    when 'workplace' then array['A small choice cost everyone else their patience.', 'Basic consideration: it''s free and it works.']
    else array['It made life harder for everyone around you.', 'Humanity noticed. Humanity would like better.']
  end;
$$;

create or replace function public.build_notice_lines(p_incident uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  inc public.incidents%rowtype;
  loc public.locations%rowtype;
  seed bigint;
  positive boolean;
  why_options text[];
  advice_options text[] := array['Do better next time.', 'Do better. It''s not hard.', 'You know what to do. Do that.', 'Fix it, take the joke, move on.'];
  positive_advice text[] := array['This is the standard. Keep it up.', 'Be this person.', 'Legend. Carry on.'];
begin
  select * into inc from public.incidents where id = p_incident;
  if not found then return null; end if;
  select * into loc from public.locations where id = inc.location_id;

  seed := public.hash32(inc.id::text);
  positive := inc.kind = 'not_a_dick';
  why_options := public.notice_why_options(inc.category_id);

  return jsonb_build_object(
    'headline', case when positive then 'DEFINITELY NOT A DICK.' else 'YOU HAVE BEEN DBAD''D.' end,
    'dickMove', regexp_replace(inc.dick_move, '\.?$', '.'),
    'why', case when char_length(inc.description) <= 140 then inc.description
                else why_options[(seed % array_length(why_options, 1)) + 1] end,
    'location', case when loc.place is not null then loc.place || ', ' || loc.suburb || ' ' || loc.state::text
                     else loc.suburb || ', ' || loc.state::text end,
    'advice', case when positive then positive_advice[(seed % array_length(positive_advice, 1)) + 1]
                   else coalesce(nullif(inc.advice, ''), advice_options[(seed % array_length(advice_options, 1)) + 1]) end
  );
end;
$$;

-- ---------------------------------------------------------------------------
-- Internal write helpers.
-- ---------------------------------------------------------------------------
create or replace function public.notify_member(
  p_user uuid, p_kind public.notification_kind, p_title text, p_body text, p_href text default null
) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_user is null then return; end if;
  insert into public.notifications (user_id, kind, title, body, href)
  values (p_user, p_kind, left(p_title, 120), left(coalesce(p_body, ''), 400), p_href);
end;
$$;

create or replace function public.log_moderation(
  p_actor uuid, p_action public.moderation_action_kind, p_target_type public.moderation_target_type,
  p_target_id text, p_note text default null, p_payload jsonb default null
) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into public.moderation_actions (actor_id, action, target_type, target_id, note, payload)
  values (p_actor, p_action, p_target_type, p_target_id, left(p_note, 500), p_payload)
  returning id into v_id;
  return v_id;
end;
$$;

-- ---------------------------------------------------------------------------
-- refresh_badges — applies the rules in src/lib/domain/badges.ts and notifies
-- the member about anything newly earned. Idempotent.
-- ---------------------------------------------------------------------------
create or replace function public.refresh_badges(p_user uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  s public.member_stats%rowtype;
  decided int;
  earned text[] := '{}';
  b text;
  awarded text[] := '{}';
begin
  if p_user is null then return jsonb_build_object('ok', true, 'awarded', '[]'::jsonb); end if;
  select * into s from public.member_stats where user_id = p_user;
  if not found then return jsonb_build_object('ok', true, 'awarded', '[]'::jsonb); end if;

  decided := s.fair_calls + s.overruled;
  if s.spotted >= 1 then earned := array_append(earned, 'first_call'); end if;
  if s.spotted >= 10 then earned := array_append(earned, 'eagle_eye'); end if;
  if decided >= 5 and (s.fair_calls::numeric / decided) >= 0.9 then earned := array_append(earned, 'fair_dinkum'); end if;
  if s.redeemed >= 5 then earned := array_append(earned, 'redemption_arc'); end if;
  if s.spotted >= 5 then earned := array_append(earned, 'not_actually_a_karen'); end if;
  if s.not_a_dick >= 3 and s.comments >= 10 then earned := array_append(earned, 'local_legend'); end if;

  foreach b in array earned loop
    if not exists (select 1 from public.user_badges ub where ub.user_id = p_user and ub.badge_id = b) then
      insert into public.user_badges (user_id, badge_id) values (p_user, b)
      on conflict do nothing;
      awarded := array_append(awarded, b);
      perform public.notify_member(
        p_user, 'badge',
        'Badge earned: ' || upper(replace(b, '_', ' ')),
        'Check your profile.', '/me');
    end if;
  end loop;

  return jsonb_build_object('ok', true, 'awarded', to_jsonb(awarded));
end;
$$;

-- Vote tally of an incident as VoteTally-shaped jsonb.
create or replace function public.vote_tally(p_incident uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('not', i.votes_not, 'bit', i.votes_bit,
                            'definitely', i.votes_definitely, 'absolute', i.votes_absolute)
  from public.incidents i where i.id = p_incident;
$$;

create or replace function public.reaction_tally(p_incident uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('fair_call', i.react_fair_call, 'classic', i.react_classic,
                            'dick_move', i.react_dick_move, 'redemption', i.react_redemption)
  from public.incidents i where i.id = p_incident;
$$;

-- ===========================================================================
-- RPC: community actions
-- ===========================================================================

-- cast_vote — one verdict per member per nomination. Never on your own.
create or replace function public.cast_vote(incident uuid, verdict text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  inc public.incidents%rowtype;
  v public.verdict;
  prev public.verdict;
  total int;
begin
  if uid is null then return jsonb_build_object('ok', false, 'message', 'Sign in to cast a verdict.'); end if;
  if verdict is null or verdict not in ('not', 'bit', 'definitely', 'absolute') then
    return jsonb_build_object('ok', false, 'message', 'Unknown verdict.');
  end if;
  v := verdict::public.verdict;

  select * into inc from public.incidents where id = incident;
  if not found then return jsonb_build_object('ok', false, 'message', 'That nomination has gone.'); end if;
  if inc.submitter_id = uid then
    return jsonb_build_object('ok', false, 'message', 'You can''t vote on your own nomination. Nice try.');
  end if;
  if inc.moderation_status <> 'approved' then
    return jsonb_build_object('ok', false, 'message', 'That nomination isn''t public yet.');
  end if;

  select vt.verdict into prev from public.votes vt where vt.incident_id = incident and vt.user_id = uid;
  if prev is not distinct from v then
    return jsonb_build_object('ok', true, 'votes', public.vote_tally(incident), 'viewerVote', v);
  end if;

  insert into public.votes (incident_id, user_id, verdict) values (incident, uid, v)
  on conflict (incident_id, user_id) do update set verdict = excluded.verdict, updated_at = now();

  select * into inc from public.incidents where id = incident;
  total := inc.votes_not + inc.votes_bit + inc.votes_definitely + inc.votes_absolute;

  -- The moment the community reaches a verdict, tell the submitter. Once.
  if prev is null and total = public.min_votes_for_verdict() then
    perform public.notify_member(
      inc.submitter_id, 'verdict_reached', 'Community verdict reached',
      inc.dick_move || ' — ' || public.verdict_agree_percent(inc.votes_not, inc.votes_bit, inc.votes_definitely, inc.votes_absolute)::text || '% Dick Move',
      '/moves/' || inc.slug);
  end if;

  return jsonb_build_object('ok', true, 'votes', public.vote_tally(incident), 'viewerVote', v);
end;
$$;

-- toggle_reaction — reactions are a set; tapping one twice takes it back.
create or replace function public.toggle_reaction(incident uuid, kind text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  inc public.incidents%rowtype;
  k public.reaction_kind;
  mine text[];
begin
  if uid is null then return jsonb_build_object('ok', false, 'message', 'Sign in to react.'); end if;
  if kind is null or kind not in ('fair_call', 'classic', 'dick_move', 'redemption') then
    return jsonb_build_object('ok', false, 'message', 'Unknown reaction.');
  end if;
  k := kind::public.reaction_kind;

  select * into inc from public.incidents where id = incident;
  if not found then return jsonb_build_object('ok', false, 'message', 'That nomination has gone.'); end if;
  if inc.moderation_status <> 'approved' then
    return jsonb_build_object('ok', false, 'message', 'That nomination isn''t public yet.');
  end if;

  if exists (select 1 from public.reactions r where r.incident_id = incident and r.user_id = uid and r.kind = k) then
    delete from public.reactions r where r.incident_id = incident and r.user_id = uid and r.kind = k;
  else
    insert into public.reactions (incident_id, user_id, kind) values (incident, uid, k)
    on conflict do nothing;
  end if;

  select coalesce(array_agg(r.kind::text order by r.created_at), '{}')
    into mine from public.reactions r where r.incident_id = incident and r.user_id = uid;

  return jsonb_build_object('ok', true, 'reactions', public.reaction_tally(incident), 'viewerReactions', to_jsonb(mine));
end;
$$;

-- add_comment — scrubs identifying details, and holds anything that looked like
-- it identified a person for a moderator (plus an automatic report), exactly
-- like the demo store.
create or replace function public.add_comment(incident uuid, body text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  me public.profiles%rowtype;
  inc public.incidents%rowtype;
  trimmed text := btrim(coalesce(body, ''));
  kinds text[];
  identifying boolean;
  cleaned text;
  row_out public.comments%rowtype;
begin
  if uid is null then return jsonb_build_object('ok', false, 'message', 'Sign in to comment.'); end if;
  select * into me from public.profiles where id = uid;
  if not found then return jsonb_build_object('ok', false, 'message', 'Sign in to comment.'); end if;

  select * into inc from public.incidents where id = incident;
  if not found then return jsonb_build_object('ok', false, 'message', 'That nomination has gone.'); end if;
  if inc.moderation_status <> 'approved' then
    return jsonb_build_object('ok', false, 'message', 'That nomination isn''t public yet.');
  end if;

  if char_length(trimmed) < 2 then
    return jsonb_build_object('ok', false, 'message', 'Say something. Anything. Well — almost anything.');
  end if;
  if char_length(trimmed) > 600 then
    return jsonb_build_object('ok', false, 'message', 'Keep it under 600 characters. Brevity is the soul of taking the piss.');
  end if;
  if public.contains_threat(trimmed) then
    return jsonb_build_object('ok', false, 'message', 'That crosses the line. Take the piss, don''t take it too far.');
  end if;

  kinds := public.pii_kinds(trimmed);
  identifying := kinds && array['phone', 'email', 'personal_profile_url', 'named_person', 'street_address', 'rego'];
  cleaned := public.scrub_text(trimmed);

  insert into public.comments (incident_id, author_id, body, status)
  values (incident, uid, cleaned,
          case when identifying then 'hidden'::public.comment_status else 'visible'::public.comment_status end)
  returning * into row_out;

  if identifying then
    insert into public.reports (target_type, target_id, reason, details, status)
    values ('comment', row_out.id, 'identifies_person', 'Auto-held: comment contained identifying details.', 'open');
    return jsonb_build_object('ok', false,
      'message', 'That comment looked like it identified someone, so it''s been held for a moderator. Describe the behaviour, not the person.');
  end if;

  if inc.submitter_id is not null and inc.submitter_id <> uid then
    perform public.notify_member(inc.submitter_id, 'comment', 'New comment',
      me.handle::text || ': "' || left(row_out.body, 80) || '"', '/moves/' || inc.slug || '#comments');
  end if;

  perform public.refresh_badges(uid);

  return jsonb_build_object('ok', true, 'comment', jsonb_build_object(
    'id', row_out.id, 'incidentId', row_out.incident_id, 'authorId', row_out.author_id,
    'body', row_out.body, 'createdAt', row_out.created_at, 'status', row_out.status,
    'parentId', row_out.parent_id,
    'author', jsonb_build_object('handle', me.handle::text, 'displayName', me.display_name, 'avatarSeed', me.avatar_seed)));
end;
$$;

-- mark_redeemed — the submitter or a moderator records the good ending.
create or replace function public.mark_redeemed(incident uuid, note text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  role public.user_role := public.viewer_role();
  inc public.incidents%rowtype;
  cleaned text;
begin
  if uid is null then return jsonb_build_object('ok', false, 'message', 'Sign in first.'); end if;
  select * into inc from public.incidents where id = incident;
  if not found then return jsonb_build_object('ok', false, 'message', 'That nomination has gone.'); end if;
  if not (inc.submitter_id = uid or role in ('moderator', 'admin')) then
    return jsonb_build_object('ok', false, 'message', 'Only the submitter or a moderator can mark this redeemed.');
  end if;

  cleaned := left(public.scrub_text(coalesce(note, '')), 300);
  if btrim(cleaned) = '' then cleaned := 'Sorted. Humanity survives another day.'; end if;

  update public.incidents set status = 'redeemed' where id = incident;
  insert into public.redemptions (incident_id, note, confirmed_by)
  values (incident, cleaned, case when inc.submitter_id = uid
                                  then 'submitter'::public.redemption_source
                                  else 'moderator'::public.redemption_source end)
  on conflict (incident_id) do update
    set note = excluded.note, confirmed_by = excluded.confirmed_by, created_at = now();

  -- The person confirming the redemption reacts to it, which is what moves the
  -- redemption tally (the demo bumps the counter directly).
  insert into public.reactions (incident_id, user_id, kind) values (incident, uid, 'redemption')
  on conflict do nothing;

  perform public.refresh_badges(inc.submitter_id);
  return jsonb_build_object('ok', true, 'message', 'REDEEMED. Humanity survives another day.');
end;
$$;

-- report_content — open to anonymous visitors on purpose. Reporting something
-- that identifies a person must never require an account.
create or replace function public.report_content(payload jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  t text := payload ->> 'targetType';
  target uuid;
  reason text := payload ->> 'reason';
  exists_target boolean;
begin
  if t not in ('incident', 'comment') then
    return jsonb_build_object('ok', false, 'message', 'We couldn''t find that content.');
  end if;
  begin
    target := (payload ->> 'targetId')::uuid;
  exception when others then
    return jsonb_build_object('ok', false, 'message', 'We couldn''t find that content.');
  end;
  if reason is null or reason not in ('identifies_person', 'private_address', 'harassment', 'defamatory',
                                      'children', 'not_a_dick_move', 'duplicate', 'spam', 'other') then
    reason := 'other';
  end if;

  if t = 'incident' then
    select exists (select 1 from public.incidents i where i.id = target) into exists_target;
  else
    select exists (select 1 from public.comments c where c.id = target) into exists_target;
  end if;
  if not exists_target then
    return jsonb_build_object('ok', false, 'message', 'We couldn''t find that content.');
  end if;

  insert into public.reports (target_type, target_id, reason, details, reporter_id)
  values (t::public.report_target_type, target, reason::public.report_reason,
          left(nullif(btrim(coalesce(payload ->> 'details', '')), ''), 1000), uid);

  return jsonb_build_object('ok', true,
    'message', 'Thanks. A moderator will take a look. If it identifies someone, it comes down fast.');
end;
$$;

-- submit_appeal — also open to anonymous visitors: the person appealing is, by
-- definition, not a member of the community that posted about them.
create or replace function public.submit_appeal(payload jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  target uuid;
  action text := payload ->> 'requestedAction';
  msg text := btrim(coalesce(payload ->> 'message', ''));
  row_out public.appeals%rowtype;
begin
  begin
    target := (payload ->> 'incidentId')::uuid;
  exception when others then
    return jsonb_build_object('ok', false, 'message', 'We couldn''t find that nomination.');
  end;
  if not exists (select 1 from public.incidents i where i.id = target) then
    return jsonb_build_object('ok', false, 'message', 'We couldn''t find that nomination.');
  end if;
  if char_length(msg) < 10 then
    return jsonb_build_object('ok', false, 'message', 'Tell us a little more so we can act on it.');
  end if;
  if action is null or action not in ('removal', 'correction', 'anonymisation', 'context', 'reply', 'redemption') then
    action := 'context';
  end if;

  insert into public.appeals (incident_id, requested_action, message, contact)
  values (target, action::public.appeal_action, left(msg, 2000),
          left(nullif(btrim(coalesce(payload ->> 'contact', '')), ''), 200))
  returning * into row_out;

  return jsonb_build_object('ok', true, 'reference', row_out.reference,
    'message', 'Received. A human will review it, usually within a day.');
end;
$$;

-- ===========================================================================
-- RPC: nomination
-- ===========================================================================
-- submit_nomination — validates (server-side authority for validateNomination),
-- creates the location, the incident, its photos and social source, and the
-- first printable notice. Positive nominations and photo-less posts go straight
-- up; anything with a photo waits for a moderator's once-over.
create or replace function public.submit_nomination(payload jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  errors jsonb := '{}'::jsonb;
  v_kind text := payload ->> 'kind';
  v_category text := payload ->> 'categoryId';
  v_dick_move text := btrim(coalesce(payload ->> 'dickMove', ''));
  v_title text := btrim(coalesce(payload ->> 'title', ''));
  v_description text := btrim(coalesce(payload ->> 'description', ''));
  v_affected text[] := coalesce(array(select jsonb_array_elements_text(coalesce(payload -> 'affected', '[]'::jsonb))), '{}');
  v_loc jsonb := coalesce(payload -> 'location', '{}'::jsonb);
  v_suburb text := btrim(coalesce(v_loc ->> 'suburb', ''));
  v_state text := v_loc ->> 'state';
  v_place text := nullif(btrim(coalesce(v_loc ->> 'place', '')), '');
  v_occurred text := payload ->> 'occurredOn';
  v_part text := coalesce(payload ->> 'partOfDay', 'unknown');
  v_photos jsonb := coalesce(payload -> 'photos', '[]'::jsonb);
  v_fb text := nullif(btrim(coalesce(payload ->> 'facebookUrl', '')), '');
  photo jsonb;
  idx int := 0;
  loc_id uuid;
  inc public.incidents%rowtype;
  lines jsonb;
  notice_id uuid;
begin
  -- ---- validation (mirrors validateNomination in domain/validation.ts) ----
  if v_kind is null or v_kind not in ('dick_move', 'not_a_dick') then
    errors := errors || jsonb_build_object('kind', 'Pick a kind of nomination.');
  end if;
  if v_category is null or not exists (select 1 from public.categories c where c.id = v_category) then
    errors := errors || jsonb_build_object('categoryId', 'Pick a category.');
  end if;
  if char_length(v_dick_move) < 4 then
    errors := errors || jsonb_build_object('dickMove', 'Say what the dick move was, in a few words.');
  elsif char_length(v_dick_move) > 90 then
    errors := errors || jsonb_build_object('dickMove', 'Keep it under 90 characters.');
  end if;
  if char_length(v_title) < 4 then
    errors := errors || jsonb_build_object('title', 'Give it a one-liner.');
  elsif char_length(v_title) > 120 then
    errors := errors || jsonb_build_object('title', 'Keep it under 120 characters.');
  end if;
  if char_length(v_description) < 12 then
    errors := errors || jsonb_build_object('description', 'Tell us what made it a dick move — one or two factual sentences.');
  elsif char_length(v_description) > 600 then
    errors := errors || jsonb_build_object('description', 'Keep it under 600 characters.');
  end if;
  if public.contains_threat(v_dick_move) or public.contains_threat(v_title) or public.contains_threat(v_description) then
    errors := errors || jsonb_build_object('description', 'That reads as a threat. DBAD calls out behaviour, it never threatens people.');
  end if;
  if not (v_affected <@ public.affected_groups()) then
    errors := errors || jsonb_build_object('affected', 'Unknown affected group.');
  end if;
  if char_length(v_suburb) < 2 then
    errors := errors || jsonb_build_object('suburb', 'Suburb or town, please.');
  elsif char_length(v_suburb) > 60 then
    errors := errors || jsonb_build_object('suburb', 'That''s a long suburb name.');
  end if;
  if v_state is null or v_state not in ('NSW', 'VIC', 'QLD', 'WA', 'SA', 'TAS', 'ACT', 'NT') then
    errors := errors || jsonb_build_object('state', 'Pick a state or territory.');
  end if;
  if char_length(coalesce(v_place, '')) > 80 then
    errors := errors || jsonb_build_object('place', 'Keep the place name short.');
  end if;
  if coalesce(v_place, '') ~ '\y[0-9]{1,5}[A-Za-z]?\s+[A-Z][a-z]+\s+(St|Street|Rd|Road|Ave|Avenue|Dr|Drive|Cres|Crescent|Ct|Court|Pl|Place|Cl|Close)\y' then
    errors := errors || jsonb_build_object('place',
      'That looks like a street address. Use the suburb and, if it''s clearly public, the place name (e.g. ''Coles car park'').');
  end if;
  if v_occurred is null or v_occurred !~ '^\d{4}-\d{2}-\d{2}$' then
    errors := errors || jsonb_build_object('occurredOn', 'When did it happen?');
  elsif v_occurred::date > current_date + 1 then
    errors := errors || jsonb_build_object('occurredOn', 'That''s in the future. Impressive, but no.');
  end if;
  if v_part not in ('morning', 'midday', 'afternoon', 'evening', 'night', 'unknown') then
    errors := errors || jsonb_build_object('partOfDay', 'Roughly what time of day?');
  end if;
  if jsonb_typeof(v_photos) <> 'array' then
    errors := errors || jsonb_build_object('photos', 'Photos must be a list.');
  elsif jsonb_array_length(v_photos) > 4 then
    errors := errors || jsonb_build_object('photos', 'Up to 4 photos.');
  end if;
  if v_fb is not null and v_fb !~* '^https?://(www\.|m\.|web\.)?(facebook\.com|fb\.com|fb\.watch)/.+' then
    errors := errors || jsonb_build_object('facebookUrl', 'That doesn''t look like a Facebook post link.');
  end if;
  if coalesce((payload ->> 'acceptedStandard')::boolean, false) is not true then
    errors := errors || jsonb_build_object('acceptedStandard', 'You need to agree to the community standard.');
  end if;
  if jsonb_typeof(v_photos) = 'array' and jsonb_array_length(v_photos) > 0
     and coalesce((payload ->> 'reviewedRedaction')::boolean, false) is not true then
    errors := errors || jsonb_build_object('reviewedRedaction', 'Please review the redaction step before publishing photos.');
  end if;

  if errors <> '{}'::jsonb then
    return jsonb_build_object('ok', false, 'message', 'A couple of things need fixing.', 'fieldErrors', errors);
  end if;

  -- ---- write ----
  loc_id := public.upsert_location(v_suburb, v_state::public.australian_state, v_place,
                                   nullif(v_loc ->> 'approxLat', '')::numeric,
                                   nullif(v_loc ->> 'approxLng', '')::numeric,
                                   null);

  insert into public.incidents (
    kind, category_id, title, dick_move, description, affected, location_id,
    occurred_on, part_of_day, submitter_id, moderation_status, anonymised, slug
  ) values (
    v_kind::public.incident_kind, v_category,
    public.scrub_text(v_title), public.scrub_text(v_dick_move), public.scrub_text(v_description),
    v_affected, loc_id, v_occurred::date, v_part::public.part_of_day, uid,
    case when v_kind = 'not_a_dick' or jsonb_array_length(v_photos) = 0
         then 'approved'::public.moderation_status else 'pending'::public.moderation_status end,
    uid is null, null
  ) returning * into inc;

  for photo in select * from jsonb_array_elements(v_photos) loop
    insert into public.incident_photos (incident_id, storage_path, url, width, height, alt, redacted, redaction_count, sort_order)
    values (
      inc.id,
      nullif(btrim(coalesce(photo ->> 'storagePath', '')), ''),
      coalesce(nullif(photo ->> 'url', ''), photo ->> 'src'),
      coalesce((photo ->> 'width')::int, 1200),
      coalesce((photo ->> 'height')::int, 900),
      coalesce(nullif(btrim(coalesce(photo ->> 'alt', '')), ''), 'Evidence photo ' || (idx + 1)::text),
      true,
      coalesce((photo ->> 'redactionCount')::int, 0),
      idx
    );
    idx := idx + 1;
  end loop;

  if v_fb is not null then
    insert into public.social_sources (incident_id, platform, url, retrieved_via)
    values (inc.id, 'facebook', v_fb, 'manual');
  end if;

  lines := public.build_notice_lines(inc.id);
  insert into public.printable_notices (incident_id, template, link_mode, headline, dick_move, why, location, advice, created_by)
  values (
    inc.id,
    case when inc.kind = 'not_a_dick'
         then 'friendly-reminder'::public.notice_template
         else 'official-warning'::public.notice_template end,
    'site',
    left(lines ->> 'headline', 60), left(lines ->> 'dickMove', 90), left(lines ->> 'why', 220),
    left(lines ->> 'location', 80), left(lines ->> 'advice', 140), uid
  ) returning id into notice_id;

  perform public.refresh_badges(uid);

  return jsonb_build_object('ok', true, 'id', inc.id, 'slug', inc.slug, 'short_code', inc.short_code,
                            'notice_id', notice_id, 'moderation_status', inc.moderation_status);
end;
$$;

-- ===========================================================================
-- RPC: moderation
-- ===========================================================================
-- moderate — every ModerationActionKind in src/lib/domain/types.ts, with the
-- same effects and notifications as the demo store, plus an audit row.
create or replace function public.moderate(command jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  role public.user_role := public.viewer_role();
  v_action text := command ->> 'action';
  v_target_type text := coalesce(command ->> 'targetType', 'incident');
  v_target_id text := command ->> 'targetId';
  v_note text := nullif(btrim(coalesce(command ->> 'note', '')), '');
  v_payload jsonb := coalesce(command -> 'payload', '{}'::jsonb);
  inc public.incidents%rowtype;
  cm public.comments%rowtype;
  rp public.reports%rowtype;
  ap public.appeals%rowtype;
  pr public.profiles%rowtype;
  loc public.locations%rowtype;
  target_uuid uuid;
  new_week date;
  reply text;
  new_role text;
begin
  if uid is null or role is null or role = 'member' then
    return jsonb_build_object('ok', false, 'message', 'Moderators only.');
  end if;
  if v_action is null or v_action not in (
      'approve', 'reject', 'remove', 'restore', 'anonymise', 'redact_photo', 'mark_redeemed',
      'mark_overruled', 'feature_week', 'unfeature', 'hide_comment', 'restore_comment',
      'resolve_report', 'dismiss_report', 'action_appeal', 'decline_appeal', 'publish_reply',
      'change_role', 'edit_category', 'edit_template') then
    return jsonb_build_object('ok', false, 'message', format('Unknown action %s', coalesce(v_action, 'null')));
  end if;

  -- Most actions address an incident (photo actions address its parent).
  if v_target_type in ('incident', 'photo') then
    begin
      target_uuid := v_target_id::uuid;
    exception when others then
      target_uuid := null;
    end;
    select * into inc from public.incidents where id = target_uuid;
  end if;

  case v_action
    when 'approve' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      update public.incidents set moderation_status = 'approved' where id = inc.id;
      perform public.notify_member(inc.submitter_id, 'moderation', 'Nomination approved',
        inc.dick_move || ' is live.', '/moves/' || inc.slug);
      perform public.refresh_badges(inc.submitter_id);

    when 'reject' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      update public.incidents set moderation_status = 'rejected' where id = inc.id;
      perform public.notify_member(inc.submitter_id, 'moderation', 'Nomination not published',
        coalesce(v_note, 'It didn''t meet the community standard.'), '/standards');

    when 'remove' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      update public.incidents set moderation_status = 'removed' where id = inc.id;

    when 'restore' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      update public.incidents set moderation_status = 'approved' where id = inc.id;

    when 'anonymise' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      select * into loc from public.locations where id = inc.location_id;
      -- Locations are shared rows, so anonymising repoints the incident at the
      -- suburb-only location rather than editing the place out from under
      -- everyone else standing in the same car park.
      update public.incidents set
        anonymised = true,
        submitter_id = null,
        location_id = public.upsert_location(loc.suburb, loc.state, null, loc.approx_lat, loc.approx_lng, loc.region),
        description = case when v_payload ? 'description'
                           then public.scrub_text(v_payload ->> 'description') else description end
      where id = inc.id;

    when 'redact_photo' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      delete from public.incident_photos p
       where p.incident_id = inc.id
         and p.id::text = coalesce(v_payload ->> 'photoId', '');

    when 'mark_redeemed' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      update public.incidents set status = 'redeemed' where id = inc.id;
      insert into public.redemptions (incident_id, note, confirmed_by)
      values (inc.id,
              coalesce(nullif(btrim(coalesce(v_payload ->> 'note', '')), ''), 'Sorted. Humanity survives another day.'),
              'moderator')
      on conflict (incident_id) do update set note = excluded.note, confirmed_by = 'moderator';
      perform public.notify_member(inc.submitter_id, 'redeemed', 'REDEEMED',
        coalesce(nullif(btrim(coalesce(v_payload ->> 'note', '')), ''), 'Sorted. Humanity survives another day.'),
        '/moves/' || inc.slug);
      perform public.refresh_badges(inc.submitter_id);

    when 'mark_overruled' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      update public.incidents set status = 'overruled' where id = inc.id;
      perform public.notify_member(inc.submitter_id, 'moderation', 'Overruled',
        'The community reckons this one wasn''t a dick move. Owning it earns respect.', '/moves/' || inc.slug);

    when 'feature_week' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      new_week := coalesce(nullif(btrim(coalesce(v_payload ->> 'week', '')), '')::date, public.week_of(now()));
      update public.incidents set featured_week = null where featured_week = new_week and id <> inc.id;
      update public.incidents set featured_week = new_week where id = inc.id;
      perform public.notify_member(inc.submitter_id, 'featured', 'Dick Move of the Week',
        inc.dick_move || ' is this week''s Dick Move of the Week.', '/week');

    when 'unfeature' then
      if inc.id is null then return jsonb_build_object('ok', false, 'message', 'Incident not found.'); end if;
      update public.incidents set featured_week = null where id = inc.id;

    when 'hide_comment', 'restore_comment' then
      begin target_uuid := v_target_id::uuid; exception when others then target_uuid := null; end;
      select * into cm from public.comments where id = target_uuid;
      if cm.id is null then return jsonb_build_object('ok', false, 'message', 'Comment not found.'); end if;
      -- incidents.comment_count follows automatically (comments_counters).
      update public.comments set status = case when v_action = 'hide_comment'
             then 'hidden'::public.comment_status else 'visible'::public.comment_status end
       where id = cm.id;

    when 'resolve_report', 'dismiss_report' then
      begin target_uuid := v_target_id::uuid; exception when others then target_uuid := null; end;
      select * into rp from public.reports where id = target_uuid;
      if rp.id is null then return jsonb_build_object('ok', false, 'message', 'Report not found.'); end if;
      update public.reports set
        status = case when v_action = 'resolve_report'
                 then 'resolved'::public.report_status else 'dismissed'::public.report_status end,
        resolved_at = now(), resolved_by = uid
      where id = rp.id;

    when 'action_appeal', 'decline_appeal' then
      begin target_uuid := v_target_id::uuid; exception when others then target_uuid := null; end;
      select * into ap from public.appeals where id = target_uuid;
      if ap.id is null then return jsonb_build_object('ok', false, 'message', 'Appeal not found.'); end if;
      reply := nullif(btrim(coalesce(v_payload ->> 'publicReply', '')), '');
      update public.appeals set
        status = case when v_action = 'action_appeal'
                 then 'actioned'::public.appeal_status else 'declined'::public.appeal_status end,
        public_reply = case when reply is null then public_reply else left(public.scrub_text(reply), 600) end
      where id = ap.id;
      perform public.notify_member(
        (select i.submitter_id from public.incidents i where i.id = ap.incident_id),
        'appeal_update',
        case when v_action = 'action_appeal' then 'Appeal actioned' else 'Appeal declined' end,
        coalesce(v_note, 'A moderator reviewed an appeal about one of your nominations.'),
        '/moves/' || (select i.slug from public.incidents i where i.id = ap.incident_id));

    when 'publish_reply' then
      begin target_uuid := v_target_id::uuid; exception when others then target_uuid := null; end;
      select * into ap from public.appeals where id = target_uuid;
      if ap.id is null then return jsonb_build_object('ok', false, 'message', 'Appeal not found.'); end if;
      update public.appeals set
        public_reply = left(public.scrub_text(coalesce(v_payload ->> 'publicReply', '')), 600),
        status = 'actioned'
      where id = ap.id;

    when 'change_role' then
      if role <> 'admin' then return jsonb_build_object('ok', false, 'message', 'Admins only.'); end if;
      begin target_uuid := v_target_id::uuid; exception when others then target_uuid := null; end;
      select * into pr from public.profiles where id = target_uuid;
      if pr.id is null then return jsonb_build_object('ok', false, 'message', 'Member not found.'); end if;
      new_role := v_payload ->> 'role';
      if new_role is null or new_role not in ('member', 'moderator', 'admin') then
        return jsonb_build_object('ok', false, 'message', 'Unknown role.');
      end if;
      -- The only place in the system allowed to move this column.
      perform set_config('dbad.role_change', 'on', true);
      update public.profiles set role = new_role::public.user_role where id = pr.id;
      perform set_config('dbad.role_change', 'off', true);
      perform public.notify_member(pr.id, 'moderation', 'Your role changed',
        'You are now a ' || new_role || ' on DBAD.', '/me');

    when 'edit_category' then
      if not exists (select 1 from public.categories c where c.id = v_target_id) then
        return jsonb_build_object('ok', false, 'message', 'Category not found.');
      end if;
      update public.categories set
        label   = coalesce(nullif(btrim(coalesce(v_payload ->> 'label', '')), ''), label),
        short   = coalesce(nullif(btrim(coalesce(v_payload ->> 'short', '')), ''), short),
        blurb   = coalesce(nullif(btrim(coalesce(v_payload ->> 'blurb', '')), ''), blurb),
        caution = case when v_payload ? 'caution' then nullif(btrim(coalesce(v_payload ->> 'caution', '')), '') else caution end,
        accent  = coalesce(nullif(btrim(coalesce(v_payload ->> 'accent', '')), '')::public.category_accent, accent)
      where id = v_target_id;

    when 'edit_template' then
      -- Notice template copy is code (src/lib/notice/lines.ts), same as the demo
      -- store. The request is still audited so the change is on the record.
      null;
  end case;

  perform public.log_moderation(uid, v_action::public.moderation_action_kind,
                                v_target_type::public.moderation_target_type, v_target_id, v_note, v_payload);
  return jsonb_build_object('ok', true);
end;
$$;

-- ===========================================================================
-- RPC: dashboards
-- ===========================================================================
create or replace function public.admin_stats() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  result jsonb;
begin
  if not public.is_moderator() then
    return jsonb_build_object('ok', false, 'message', 'Moderators only.');
  end if;

  select jsonb_build_object(
    'dickMovesToday', (select count(*) from public.incidents where kind = 'dick_move' and created_at > now() - interval '1 day'),
    'dickMovesThisWeek', (select count(*) from public.incidents where kind = 'dick_move' and created_at > now() - interval '7 days'),
    'redemptions', (select count(*) from public.incidents where status = 'redeemed'),
    'pendingModeration', (select count(*) from public.incidents where moderation_status = 'pending'),
    'reportedContent', (select count(*) from public.reports where status in ('open', 'reviewing')),
    'openAppeals', (select count(*) from public.appeals where status in ('open', 'in_review')),
    'membersTotal', (select count(*) from public.profiles),
    'notADickThisWeek', (select count(*) from public.incidents where kind = 'not_a_dick' and created_at > now() - interval '7 days'),
    'mostActiveAreas', coalesce((
      select jsonb_agg(jsonb_build_object('region', a.region, 'count', a.n) order by a.n desc, a.region)
      from (
        select l.region as region, count(*)::int as n
        from public.incidents i join public.locations l on l.id = i.location_id
        where i.moderation_status = 'approved' and i.kind = 'dick_move'
        group by l.region order by count(*) desc, l.region limit 6
      ) a), '[]'::jsonb),
    'mostCommonCategories', coalesce((
      select jsonb_agg(jsonb_build_object('categoryId', c.category_id, 'count', c.n) order by c.n desc, c.category_id)
      from (
        select i.category_id, count(*)::int as n
        from public.incidents i
        where i.moderation_status = 'approved' and i.kind = 'dick_move'
        group by i.category_id
      ) c), '[]'::jsonb)
  ) into result;

  return result || jsonb_build_object('ok', true);
end;
$$;

create or replace function public.profile_stats(p_user uuid) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select jsonb_build_object(
       'spotted', s.spotted, 'fairCalls', s.fair_calls, 'redeemed', s.redeemed,
       'overruled', s.overruled, 'notADick', s.not_a_dick, 'comments', s.comments)
     from public.member_stats s where s.user_id = p_user),
    jsonb_build_object('spotted', 0, 'fairCalls', 0, 'redeemed', 0, 'overruled', 0, 'notADick', 0, 'comments', 0));
$$;

-- map_clusters — approximate centroids per region. Never a point per incident:
-- the map is honest about being a suburb-level picture.
create or replace function public.map_clusters()
returns table (
  region text,
  state public.australian_state,
  approx_lat numeric,
  approx_lng numeric,
  count int,
  count_this_week int,
  redeemed int,
  not_a_dick int,
  top_category_id text
)
language sql stable security definer set search_path = public as $$
  select c.region, c.state, c.lat, c.lng, c.dick_moves, c.this_week, c.redeemed_count, c.positive, c.top_category
  from (
    select
      l.region                                                      as region,
      mode() within group (order by l.state)                        as state,
      coalesce(round(avg(l.approx_lat), 6), 0)                      as lat,
      coalesce(round(avg(l.approx_lng), 6), 0)                      as lng,
      count(*) filter (where i.kind = 'dick_move')::int              as dick_moves,
      count(*) filter (where i.kind = 'dick_move'
                         and i.created_at > now() - interval '7 days')::int as this_week,
      count(*) filter (where i.status = 'redeemed')::int             as redeemed_count,
      count(*) filter (where i.kind = 'not_a_dick')::int             as positive,
      mode() within group (order by i.category_id)                   as top_category
    from public.incidents i
    join public.locations l on l.id = i.location_id
    where i.moderation_status = 'approved'
    group by l.region
  ) c
  order by c.dick_moves desc, c.region;
$$;

-- ---------------------------------------------------------------------------
-- Execution grants. Everything else in this schema is denied by default.
-- ---------------------------------------------------------------------------
revoke all on function public.cast_vote(uuid, text) from public;
revoke all on function public.toggle_reaction(uuid, text) from public;
revoke all on function public.add_comment(uuid, text) from public;
revoke all on function public.mark_redeemed(uuid, text) from public;
revoke all on function public.submit_nomination(jsonb) from public;
revoke all on function public.report_content(jsonb) from public;
revoke all on function public.submit_appeal(jsonb) from public;
revoke all on function public.moderate(jsonb) from public;
revoke all on function public.admin_stats() from public;
revoke all on function public.profile_stats(uuid) from public;
revoke all on function public.refresh_badges(uuid) from public;
revoke all on function public.map_clusters() from public;
revoke all on function public.build_notice_lines(uuid) from public;
revoke all on function public.upsert_location(text, public.australian_state, text, numeric, numeric, text) from public;
revoke all on function public.notify_member(uuid, public.notification_kind, text, text, text) from public;
revoke all on function public.log_moderation(uuid, public.moderation_action_kind, public.moderation_target_type, text, text, jsonb) from public;
revoke all on function public.handle_new_user() from public;

-- Signed-in members.
grant execute on function public.cast_vote(uuid, text) to authenticated;
grant execute on function public.toggle_reaction(uuid, text) to authenticated;
grant execute on function public.add_comment(uuid, text) to authenticated;
grant execute on function public.mark_redeemed(uuid, text) to authenticated;
grant execute on function public.moderate(jsonb) to authenticated;
grant execute on function public.admin_stats() to authenticated;

-- Anonymous visitors too: nominating, reporting and appealing must never
-- require an account.
grant execute on function public.submit_nomination(jsonb) to anon, authenticated;
grant execute on function public.report_content(jsonb) to anon, authenticated;
grant execute on function public.submit_appeal(jsonb) to anon, authenticated;
grant execute on function public.profile_stats(uuid) to anon, authenticated;
grant execute on function public.map_clusters() to anon, authenticated;
grant execute on function public.build_notice_lines(uuid) to anon, authenticated;

-- Read-only helpers used by policies and the app's own SQL.
grant execute on function public.viewer_role() to anon, authenticated;
grant execute on function public.is_moderator() to anon, authenticated;
grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.verdict_percent(int, int, int, int) to anon, authenticated;
grant execute on function public.verdict_agree_percent(int, int, int, int) to anon, authenticated;
grant execute on function public.verdict_band(int, int, int, int) to anon, authenticated;
grant execute on function public.verdict_share_line(int, int, int, int) to anon, authenticated;
grant execute on function public.min_votes_for_verdict() to anon, authenticated;
grant execute on function public.slugify(text) to anon, authenticated;
grant execute on function public.week_of(timestamptz) to anon, authenticated;
grant execute on function public.short_code(bigint) to anon, authenticated;
grant execute on function public.guess_region(text, public.australian_state) to anon, authenticated;
grant execute on function public.vote_tally(uuid) to anon, authenticated;
grant execute on function public.reaction_tally(uuid) to anon, authenticated;

-- Server-side jobs only.
grant execute on function public.refresh_badges(uuid) to service_role;
grant execute on function public.upsert_location(text, public.australian_state, text, numeric, numeric, text) to service_role;
grant execute on function public.notify_member(uuid, public.notification_kind, text, text, text) to service_role;
grant execute on function public.log_moderation(uuid, public.moderation_action_kind, public.moderation_target_type, text, text, jsonb) to service_role;
