-- ===========================================================================
-- DBAD — 0004 row level security
--
-- Two locks on every door. The RPCs in 0003 authorise the caller themselves;
-- these policies make sure that a client holding an anon or authenticated key
-- and talking straight to PostgREST cannot get past the same rules.
--
-- Table privileges are revoked first and granted back deliberately, because a
-- hosted Supabase project grants ALL on new public tables to anon and
-- authenticated by default. Without the revoke, "no policy" would still leave a
-- table writable the moment someone added a permissive policy for one column.
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- Policy helper: can the current viewer see this nomination at all?
-- SECURITY DEFINER so the policies on child tables do not re-enter the
-- incidents policy for every row.
-- ---------------------------------------------------------------------------
create or replace function public.incident_visible(p_incident uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.incidents i
    where i.id = p_incident
      and (i.moderation_status = 'approved'
           or (auth.uid() is not null and i.submitter_id = auth.uid())
           or public.is_moderator())
  );
$$;

create or replace function public.incident_is_public(p_incident uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.incidents i where i.id = p_incident and i.moderation_status = 'approved');
$$;

create or replace function public.incident_submitter(p_incident uuid) returns uuid
language sql stable security definer set search_path = public as $$
  select i.submitter_id from public.incidents i where i.id = p_incident;
$$;

grant execute on function public.incident_visible(uuid) to anon, authenticated;
grant execute on function public.incident_is_public(uuid) to anon, authenticated;
grant execute on function public.incident_submitter(uuid) to anon, authenticated;

-- ---------------------------------------------------------------------------
-- Privileges
-- ---------------------------------------------------------------------------
revoke all on all tables in schema public from anon, authenticated;
grant usage on schema public to anon, authenticated, service_role;

-- Readable by the world (rows still filtered by the policies below).
grant select on public.profiles, public.categories, public.badges, public.user_badges,
                public.locations, public.incidents, public.incident_photos,
                public.social_sources, public.redemptions, public.comments,
                public.printable_notices, public.appeal_replies, public.member_stats
  to anon, authenticated;

-- Anonymous visitors may flag content and appeal. They may never read either.
grant insert on public.reports, public.appeals to anon, authenticated;
-- Notices are made to be printed; an anonymous visitor can build and tweak one.
grant insert, update on public.printable_notices to anon, authenticated;

-- Members.
grant insert, update on public.votes to authenticated;
grant insert, delete on public.reactions to authenticated;
grant select on public.votes, public.reactions to authenticated;
grant insert on public.comments to authenticated;
grant select, update on public.notifications to authenticated;
-- Moderators are ordinary authenticated users whose rows are widened by policy.
grant select on public.reports, public.appeals, public.moderation_actions to authenticated;
grant update on public.profiles to authenticated;

-- Service role bypasses RLS but still needs the privileges.
grant all on all tables in schema public to service_role;

-- ---------------------------------------------------------------------------
alter table public.profiles            enable row level security;
alter table public.categories          enable row level security;
alter table public.locations           enable row level security;
alter table public.incidents           enable row level security;
alter table public.incident_photos     enable row level security;
alter table public.social_sources      enable row level security;
alter table public.votes               enable row level security;
alter table public.reactions           enable row level security;
alter table public.comments            enable row level security;
alter table public.reports             enable row level security;
alter table public.appeals             enable row level security;
alter table public.redemptions         enable row level security;
alter table public.moderation_actions  enable row level security;
alter table public.printable_notices   enable row level security;
alter table public.badges              enable row level security;
alter table public.user_badges         enable row level security;
alter table public.notifications       enable row level security;

-- ---- profiles -------------------------------------------------------------
-- Everything on a profile is public by design: handle, display name, avatar
-- seed, badges, chosen home area. Nothing private is stored here.
create policy profiles_select_all on public.profiles
  for select to anon, authenticated using (true);

create policy profiles_update_own on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
-- (profiles_guard_role rejects any attempt to move the role column here.)

-- ---- categories / badges --------------------------------------------------
create policy categories_select_all on public.categories
  for select to anon, authenticated using (true);
create policy badges_select_all on public.badges
  for select to anon, authenticated using (true);
create policy user_badges_select_all on public.user_badges
  for select to anon, authenticated using (true);

-- ---- locations ------------------------------------------------------------
-- A location is a suburb and, at most, a named public place. Safe to read.
create policy locations_select_all on public.locations
  for select to anon, authenticated using (true);

-- ---- incidents ------------------------------------------------------------
create policy incidents_select_public on public.incidents
  for select to anon, authenticated
  using (
    moderation_status = 'approved'
    or (auth.uid() is not null and submitter_id = auth.uid())   -- your own, whatever its state
    or public.is_moderator()
  );
-- No insert/update/delete policy on purpose: nominations are created by
-- submit_nomination() and changed by moderate(), never by a client.

-- ---- incident_photos ------------------------------------------------------
create policy incident_photos_select on public.incident_photos
  for select to anon, authenticated
  using (
    (redacted and public.incident_is_public(incident_id))
    or public.incident_submitter(incident_id) = auth.uid()
    or public.is_moderator()
  );

-- ---- social_sources -------------------------------------------------------
create policy social_sources_select on public.social_sources
  for select to anon, authenticated using (public.incident_visible(incident_id));

-- ---- redemptions ----------------------------------------------------------
create policy redemptions_select on public.redemptions
  for select to anon, authenticated using (public.incident_visible(incident_id));

-- ---- comments -------------------------------------------------------------
create policy comments_select on public.comments
  for select to anon, authenticated
  using (
    (status = 'visible' and public.incident_is_public(incident_id))
    or author_id = auth.uid()          -- you can see your own, held or not
    or public.is_moderator()
  );

create policy comments_insert_own on public.comments
  for insert to authenticated
  with check (
    author_id = auth.uid()
    and public.incident_is_public(incident_id)
    and status = 'visible'
  );
-- Hiding and restoring is moderate()'s job; members cannot edit or delete.

-- ---- votes ----------------------------------------------------------------
create policy votes_select_own on public.votes
  for select to authenticated using (user_id = auth.uid() or public.is_moderator());

create policy votes_insert_own on public.votes
  for insert to authenticated
  with check (
    user_id = auth.uid()
    and public.incident_is_public(incident_id)
    and public.incident_submitter(incident_id) is distinct from auth.uid()  -- never your own
  );

create policy votes_update_own on public.votes
  for update to authenticated
  using (user_id = auth.uid())
  with check (
    user_id = auth.uid()
    and public.incident_is_public(incident_id)
    and public.incident_submitter(incident_id) is distinct from auth.uid()
  );

-- ---- reactions ------------------------------------------------------------
create policy reactions_select_own on public.reactions
  for select to authenticated using (user_id = auth.uid() or public.is_moderator());

create policy reactions_insert_own on public.reactions
  for insert to authenticated
  with check (user_id = auth.uid() and public.incident_is_public(incident_id));

create policy reactions_delete_own on public.reactions
  for delete to authenticated using (user_id = auth.uid());

-- ---- reports --------------------------------------------------------------
-- Anyone may report; only moderators may read. A report can name its reporter,
-- and reports about a comment quote it, so this table is never public.
create policy reports_insert_anyone on public.reports
  for insert to anon, authenticated
  with check (reporter_id is null or reporter_id = auth.uid());

create policy reports_select_moderators on public.reports
  for select to authenticated using (public.is_moderator());

-- ---- appeals --------------------------------------------------------------
-- Contains a private contact detail. Moderators only; the published reply is
-- exposed through public.appeal_replies instead.
create policy appeals_insert_anyone on public.appeals
  for insert to anon, authenticated with check (true);

create policy appeals_select_moderators on public.appeals
  for select to authenticated using (public.is_moderator());

-- ---- moderation_actions ---------------------------------------------------
create policy moderation_actions_select_moderators on public.moderation_actions
  for select to authenticated using (public.is_moderator());

-- ---- printable_notices ----------------------------------------------------
-- A notice is meant to be printed and left on a windscreen; it is public.
create policy printable_notices_select_all on public.printable_notices
  for select to anon, authenticated using (true);

create policy printable_notices_insert on public.printable_notices
  for insert to anon, authenticated
  with check (created_by is null or created_by = auth.uid());

create policy printable_notices_update on public.printable_notices
  for update to anon, authenticated
  using (created_by is null or created_by = auth.uid() or public.is_moderator())
  with check (created_by is null or created_by = auth.uid() or public.is_moderator());

-- ---- notifications --------------------------------------------------------
create policy notifications_select_own on public.notifications
  for select to authenticated using (user_id = auth.uid());

create policy notifications_update_own on public.notifications
  for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------------------
-- Views. appeal_replies deliberately runs with the owner's rights so that the
-- public reply is readable while the appeal behind it stays sealed.
-- ---------------------------------------------------------------------------
grant select on public.appeal_replies to anon, authenticated;
grant select on public.member_stats to anon, authenticated;
