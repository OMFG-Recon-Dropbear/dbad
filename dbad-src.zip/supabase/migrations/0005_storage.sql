-- ===========================================================================
-- DBAD — 0005 storage
--
-- One bucket: incident-photos. Evidence is downscaled and redacted in the
-- browser before it is uploaded, so what lands here is already the published
-- image — which is why the bucket is public-read.
--
-- Writes are namespaced by uploader: an object must live under "<auth.uid()>/".
-- That gives every member a private prefix they alone can write to, and makes
-- an orphaned upload traceable to the account that made it.
-- ===========================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'incident-photos',
  'incident-photos',
  true,
  8388608,                                  -- 8 MiB
  array['image/jpeg', 'image/png', 'image/webp', 'image/avif']
)
on conflict (id) do update
  set public = excluded.public,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- Public read. The bucket is served from the CDN as well; this policy is what
-- makes the direct object API agree with that.
drop policy if exists "incident photos are public" on storage.objects;
create policy "incident photos are public" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'incident-photos');

-- Uploads land under the uploader's own folder, and nowhere else.
drop policy if exists "members upload to their own folder" on storage.objects;
create policy "members upload to their own folder" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'incident-photos'
    and auth.uid() is not null
    and (storage.foldername(name))[1] = auth.uid()::text
    and lower(storage.extension(name)) in ('jpg', 'jpeg', 'png', 'webp', 'avif')
  );

drop policy if exists "members replace their own photos" on storage.objects;
create policy "members replace their own photos" on storage.objects
  for update to authenticated
  using (bucket_id = 'incident-photos' and (storage.foldername(name))[1] = auth.uid()::text)
  with check (bucket_id = 'incident-photos' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "members delete their own photos" on storage.objects;
create policy "members delete their own photos" on storage.objects
  for delete to authenticated
  using (bucket_id = 'incident-photos' and (storage.foldername(name))[1] = auth.uid()::text);

-- Moderators redact by deleting the photo row (moderate('redact_photo')); the
-- object itself is removed by the moderation job running as the service role,
-- which bypasses these policies.
