-- ===========================================================================
-- DBAD — demo seed
--
-- A faithful SQL translation of src/lib/data/demo/seed.ts: the same members,
-- the same nominations, the same jokes. Realistic, fictional, Australian, and
-- obeying the same rules the community does — every entry describes a
-- behaviour in a public place, and not one of them names a person.
--
-- Timestamps are relative to now(), so the demo never looks stale.
-- Identifiers are deterministic, so a reset produces the same site.
--
-- Demo accounts sign in with the password `dbad-demo`
--   member    southcoastspotter@demo.dontbeadick.com.au
--   moderator mod_sarah@demo.dontbeadick.com.au
--   admin     dbad_hq@demo.dontbeadick.com.au
-- ===========================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- Categories (src/lib/domain/categories.ts)
-- ---------------------------------------------------------------------------
insert into public.categories (id, label, short, blurb, caution, accent, sort_order) values
  ('parking', 'PARKING DICK', 'Parking',
   'Blocking footpaths, disabled bays, driveways, or taking up two spaces because you couldn''t be bothered.',
   null, 'warning', 1),
  ('road', 'ROAD DICK', 'Road',
   'Dangerous or inconsiderate road behaviour. Tailgating, phone-driving, the lot.',
   'Never film while driving. Passengers and dashcams only.', 'alert', 2),
  ('shopping', 'SHOPPING DICK', 'Shopping',
   'Trolleys abandoned in the wild, aisles blockaded, fourteen items in the eight-item lane.',
   null, 'warning', 3),
  ('neighbourhood', 'NEIGHBOURHOOD DICK', 'Neighbourhood',
   'Community-space stupidity. Playgrounds, parks, shared driveways, bins.',
   'Public spaces only. Nothing about someone''s home or who lives there.', 'concrete', 4),
  ('rubbish', 'RUBBISH DICK', 'Rubbish',
   'Littering, dumping, and leaving a picnic''s worth of mess for someone else.',
   null, 'warning', 5),
  ('dog', 'DOG DICK', 'Dog',
   'Owners who don''t pick up, don''t leash where they must, or think ''he''s friendly'' is a plan.',
   'The dog is never the dick. The human holding (or not holding) the lead is.', 'concrete', 6),
  ('internet', 'INTERNET DICK', 'Internet',
   'Community examples that started online — public group posts, marketplace madness.',
   'No screenshots of names, profiles or private messages.', 'concrete', 7),
  ('workplace', 'WORKPLACE DICK MOVE', 'Workplace',
   'Light-hearted office annoyances. The microwave fish. The reply-all.',
   'Nothing confidential, nothing that identifies a colleague or employer.', 'concrete', 8),
  ('other', 'OTHER DICKERY', 'Other',
   'For everything we failed to anticipate. Humanity is inventive.',
   null, 'warning', 9);

-- ---------------------------------------------------------------------------
-- Badges (src/lib/domain/badges.ts)
-- ---------------------------------------------------------------------------
insert into public.badges (id, name, blurb, rule, sort_order) values
  ('first_call', 'FIRST CALL', 'Made your first nomination. Welcome to the noticeboard.', '1 approved nomination', 1),
  ('eagle_eye', 'EAGLE EYE', 'Spotted 10 verified Dick Moves.', '10 approved nominations', 2),
  ('fair_dinkum', 'FAIR DINKUM', '90% of your nominations agreed with by the community.', 'At least 5 verdicts reached and 90% agreed', 3),
  ('redemption_arc', 'REDEMPTION ARC', 'Helped resolve five incidents. Humanity thanks you.', '5 nominations marked Redeemed', 4),
  ('not_actually_a_karen', 'NOT ACTUALLY A KAREN', 'Had five nominations validated by moderators.', '5 nominations approved by a moderator', 5),
  ('local_legend', 'LOCAL LEGEND', 'Positive contributor to the DBAD community.', '3 Not-A-Dick nominations and 10 comments that stayed up', 6);

-- ---------------------------------------------------------------------------
-- Members. Inserting into auth.users fires handle_new_user(), which is what
-- creates the public profile — the seed exercises the same path a real sign-up
-- takes. Roles and member-since dates are applied afterwards.
-- ---------------------------------------------------------------------------
insert into auth.users (id, email, encrypted_password, email_confirmed_at, created_at, raw_user_meta_data) values
  ('00000000-0000-4000-8000-000000000001', 'southcoastspotter@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '206 days',
   '{"handle":"southcoastspotter","display_name":"Jen","home_area":"South Coast, NSW","bio":"Walks the dog. Notices things. Returns trolleys."}'::jsonb),
  ('00000000-0000-4000-8000-000000000002', 'trolleywrangler@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '187 days',
   '{"handle":"trolleywrangler","display_name":"Dave","home_area":"Canberra, ACT","bio":"Self-appointed trolley return officer."}'::jsonb),
  ('00000000-0000-4000-8000-000000000003', 'pramnavigator@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '170 days',
   '{"handle":"pramnavigator","display_name":"Priya","home_area":"Canberra, ACT","bio":"Two kids, one pram, zero patience for footpath parking."}'::jsonb),
  ('00000000-0000-4000-8000-000000000004', 'fyshwickphil@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '151 days',
   '{"handle":"fyshwickphil","display_name":"Phil","home_area":"Canberra, ACT"}'::jsonb),
  ('00000000-0000-4000-8000-000000000005', 'mollymookmick@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '136 days',
   '{"handle":"mollymookmick","display_name":"Mick","home_area":"Mollymook, NSW","bio":"Surfs before work. Picks up other people''s rubbish after."}'::jsonb),
  ('00000000-0000-4000-8000-000000000006', 'binnightbandit@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '114 days',
   '{"handle":"binnightbandit","display_name":"Lee","home_area":"Gungahlin, ACT"}'::jsonb),
  ('00000000-0000-4000-8000-000000000007', 'qbn_amara@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '96 days',
   '{"handle":"qbn_amara","display_name":"Amara","home_area":"Queanbeyan, NSW"}'::jsonb),
  ('00000000-0000-4000-8000-000000000008', 'civic_tom@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '77 days',
   '{"handle":"civic_tom","display_name":"Tom","home_area":"Canberra, ACT","bio":"Bike commuter. Would like the bike lane back, please."}'::jsonb),
  ('00000000-0000-4000-8000-000000000009', 'kate_from_freo@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '59 days',
   '{"handle":"kate_from_freo","display_name":"Kate","home_area":"Fremantle, WA"}'::jsonb),
  ('00000000-0000-4000-8000-000000000010', 'ollie_gong@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '37 days',
   '{"handle":"ollie_gong","display_name":"Ollie","home_area":"Wollongong, NSW"}'::jsonb),
  ('00000000-0000-4000-8000-000000000011', 'mod_sarah@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '228 days',
   '{"handle":"mod_sarah","display_name":"Sarah (Moderator)","home_area":"Canberra, ACT","bio":"Keeps the noticeboard tidy. Take the piss, don''t take it too far."}'::jsonb),
  ('00000000-0000-4000-8000-000000000012', 'dbad_hq@demo.dontbeadick.com.au', crypt('dbad-demo', gen_salt('bf')), now(), now() - interval '247 days',
   '{"handle":"dbad_hq","display_name":"DBAD HQ","home_area":"Australia","bio":"Making the world slightly less dickish, one nomination at a time."}'::jsonb);

-- Roles are normally a moderation action; the seed sets them directly.
-- (member_since already came from auth.users.created_at via handle_new_user.)
do $$
begin
  perform set_config('dbad.role_change', 'on', true);
  update public.profiles set role = 'moderator' where id = '00000000-0000-4000-8000-000000000011';
  update public.profiles set role = 'admin'     where id = '00000000-0000-4000-8000-000000000012';
  perform set_config('dbad.role_change', 'off', true);
end
$$;

-- ---------------------------------------------------------------------------
-- Locations — approximate suburb/town centroids, never an address.
-- ---------------------------------------------------------------------------
insert into public.locations (id, suburb, state, place, approx_lat, approx_lng, precision, region) values
  ('10000000-0000-4000-8000-000000000001', 'Batemans Bay', 'NSW', null, -35.708, 150.175, 'suburb', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000002', 'Batemans Bay', 'NSW', 'Orient Street shops', -35.708, 150.175, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000003', 'Batehaven', 'NSW', 'Corrigans Beach', -35.735, 150.205, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000004', 'Surf Beach', 'NSW', 'Surf Beach', -35.752, 150.222, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000005', 'Ulladulla', 'NSW', 'Coles car park', -35.359, 150.473, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000006', 'Mollymook', 'NSW', 'Mollymook Beach', -35.330, 150.472, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000007', 'Moruya', 'NSW', 'Gundary Oval', -35.912, 150.081, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000008', 'Broulee', 'NSW', 'Broulee main beach', -35.855, 150.175, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000009', 'Nowra', 'NSW', 'Stockland Nowra car park', -34.876, 150.601, 'place', 'Shoalhaven'),
  ('10000000-0000-4000-8000-000000000010', 'Merimbula', 'NSW', 'Market Street', -36.891, 149.905, 'place', 'Sapphire Coast'),
  ('10000000-0000-4000-8000-000000000011', 'Canberra Civic', 'ACT', null, -35.281, 149.128, 'suburb', 'Canberra'),
  ('10000000-0000-4000-8000-000000000012', 'Fyshwick', 'ACT', 'Bunnings car park', -35.328, 149.169, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000013', 'Woden', 'ACT', 'Westfield Woden car park', -35.345, 149.087, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000014', 'Gungahlin', 'ACT', null, -35.185, 149.133, 'suburb', 'Canberra'),
  ('10000000-0000-4000-8000-000000000015', 'Tuggeranong', 'ACT', 'Kmart car park', -35.414, 149.067, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000016', 'Tuggeranong', 'ACT', 'Bush reserve, Athllon Drive', -35.414, 149.067, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000017', 'Belconnen', 'ACT', 'Bunnings sausage sizzle', -35.238, 149.066, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000018', 'Barton', 'ACT', null, -35.305, 149.136, 'suburb', 'Canberra'),
  ('10000000-0000-4000-8000-000000000019', 'Kingston', 'ACT', 'Kingston Foreshore', -35.314, 149.145, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000020', 'Parkes', 'ACT', 'Commonwealth Park', -35.289, 149.132, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000021', 'Yarralumla', 'ACT', 'Lake Burley Griffin picnic area', -35.302, 149.106, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000022', 'Fyshwick', 'ACT', 'Canberra Avenue', -35.330, 149.160, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000023', 'Queanbeyan', 'NSW', 'Queanbeyan River drain', -35.353, 149.232, 'place', 'Canberra'),
  ('10000000-0000-4000-8000-000000000024', 'Goulburn', 'NSW', 'Highway service centre EV chargers', -34.755, 149.720, 'place', 'Southern Tablelands'),
  ('10000000-0000-4000-8000-000000000025', 'Clyde Mountain', 'NSW', 'Kings Highway', -35.550, 149.950, 'place', 'South Coast NSW'),
  ('10000000-0000-4000-8000-000000000026', 'Wollongong', 'NSW', null, -34.425, 150.893, 'suburb', 'Illawarra'),
  ('10000000-0000-4000-8000-000000000027', 'Newcastle', 'NSW', 'Hunter Street bike lane', -32.927, 151.780, 'place', 'Hunter'),
  ('10000000-0000-4000-8000-000000000028', 'Sydney CBD', 'NSW', null, -33.868, 151.209, 'suburb', 'Greater Sydney'),
  ('10000000-0000-4000-8000-000000000029', 'Bateau Bay', 'NSW', 'Coles Bateau Bay', -33.383, 151.474, 'place', 'Central Coast'),
  ('10000000-0000-4000-8000-000000000030', 'Fitzroy', 'VIC', 'Brunswick Street', -37.798, 144.978, 'place', 'Melbourne'),
  ('10000000-0000-4000-8000-000000000031', 'West End', 'QLD', 'Boundary Street', -27.480, 153.010, 'place', 'Brisbane'),
  ('10000000-0000-4000-8000-000000000032', 'Fremantle', 'WA', 'South Beach', -32.056, 115.747, 'place', 'Perth'),
  ('10000000-0000-4000-8000-000000000033', 'Hobart', 'TAS', 'Salamanca Place', -42.882, 147.327, 'place', 'Hobart'),
  ('10000000-0000-4000-8000-000000000034', 'Glenelg', 'SA', 'Jetty Road', -34.980, 138.515, 'place', 'Adelaide'),
  ('10000000-0000-4000-8000-000000000035', 'Darwin City', 'NT', 'Mindil Beach car park', -12.463, 130.842, 'place', 'Darwin'),
  ('10000000-0000-4000-8000-000000000036', 'Marulan', 'NSW', 'Hume Highway rest area', -34.710, 150.010, 'place', 'Southern Tablelands');

-- ---------------------------------------------------------------------------
-- Incidents. Slugs are left to the autoslug trigger, which produces exactly the
-- "<dick move>-<suburb>-<seq>" shape the demo store uses.
-- ---------------------------------------------------------------------------
insert into public.incidents (
  id, seq, kind, category_id, title, dick_move, description, affected, location_id,
  occurred_on, part_of_day, created_at, submitter_id, status, moderation_status, anonymised,
  advice, votes_not, votes_bit, votes_definitely, votes_absolute,
  react_fair_call, react_classic, react_dick_move, react_redemption
) values
  ('20000000-0000-4000-8000-000000000001', 42, 'dick_move', 'parking',
   'Apparently the footpath is now a parking space.', 'Blocking the footpath.',
   'Parked completely across the pedestrian footpath outside the Orient Street shops despite several available parking spaces nearby. Pedestrians, a bloke in a wheelchair and two prams were sent out onto the road to get past.',
   array['pedestrians', 'wheelchair_users', 'parents_prams'], '10000000-0000-4000-8000-000000000002',
   current_date, 'afternoon', now() - interval '24 minutes', '00000000-0000-4000-8000-000000000001',
   'open', 'approved', false, 'Footpaths are for people. Park in a parking space. Do better.',
   3, 9, 61, 118, 84, 22, 131, 0),

  ('20000000-0000-4000-8000-000000000002', 41, 'dick_move', 'shopping',
   'The trolley bay was right there. Twenty metres. Twenty.', 'Abandoning a trolley in a parking bay.',
   'Trolley left dead-centre of a parking bay at the Fyshwick Bunnings, a short stroll from the return bay. Three cars circled while a bloke with a boot full of pavers got out and moved it himself.',
   array['motorists', 'the_community'], '10000000-0000-4000-8000-000000000012',
   current_date, 'morning', now() - interval '3 hours', '00000000-0000-4000-8000-000000000004',
   'open', 'approved', false, 'Return the trolley. It takes eleven seconds.',
   6, 24, 40, 17, 41, 30, 22, 0),

  ('20000000-0000-4000-8000-000000000003', 40, 'dick_move', 'parking',
   '"Just two minutes" in the accessible bay. Classic.', 'Parking in an accessible bay without a permit.',
   'No permit, hazard lights on as though that makes it legal, parked in the accessible bay nearest the Westfield Woden entrance while a driver with a permit waited, gave up and parked at the far end. The two minutes was fourteen.',
   array['wheelchair_users', 'the_community'], '10000000-0000-4000-8000-000000000013',
   current_date - 1, 'midday', now() - interval '19 hours', '00000000-0000-4000-8000-000000000003',
   'open', 'approved', false, 'Those bays are not a drop zone. Park somewhere else and walk.',
   1, 4, 38, 96, 70, 8, 88, 0),

  ('20000000-0000-4000-8000-000000000004', 39, 'dick_move', 'parking',
   'One car. Two bays. Zero self-awareness.', 'Taking two parking bays.',
   'Parked squarely across the line between two bays at the Ulladulla Coles on a Saturday morning while the car park was rammed. Then came back, saw the DBAD notice, and re-parked properly. Humanity survives another day.',
   array['motorists', 'the_community'], '10000000-0000-4000-8000-000000000005',
   current_date - 2, 'morning', now() - interval '2 days', '00000000-0000-4000-8000-000000000005',
   'redeemed', 'approved', false, 'The lines are painted for a reason. Look down before you get out.',
   4, 21, 47, 12, 33, 12, 19, 58),

  ('20000000-0000-4000-8000-000000000005', 38, 'dick_move', 'dog',
   'A bag was carried. A bag was filled. A bag was hung on a fence and left.',
   'Leaving a full dog-poo bag on the beach fence.',
   'Bagged it (good), then hung the bag on the dune fence at Corrigans Beach and walked off (not good). There''s a bin at the car park forty metres away. The dog, for the record, is a good dog.',
   array['pedestrians', 'the_community'], '10000000-0000-4000-8000-000000000003',
   current_date - 1, 'morning', now() - interval '1.1 days', '00000000-0000-4000-8000-000000000001',
   'open', 'approved', false, 'You did the hard part. Finish the job: the bin is right there.',
   2, 15, 52, 31, 39, 44, 27, 0),

  ('20000000-0000-4000-8000-000000000006', 37, 'dick_move', 'rubbish',
   'The bin was three metres away. Three.', 'Leaving a picnic''s worth of rubbish behind.',
   'Pizza boxes, bottles, a broken camp chair and a small mountain of wrappers left on a picnic table by Lake Burley Griffin with a bin in plain sight. A family cleaned it up before they could sit down.',
   array['the_community', 'everyone'], '10000000-0000-4000-8000-000000000021',
   current_date - 2, 'evening', now() - interval '1.6 days', '00000000-0000-4000-8000-000000000002',
   'open', 'approved', false, 'Take it with you. It isn''t heavy.',
   0, 3, 29, 77, 61, 6, 74, 0),

  ('20000000-0000-4000-8000-000000000007', 36, 'dick_move', 'road',
   'Close enough to read the odometer.', 'Tailgating down the Clyde.',
   'Sat a car-length off the bumper down the Clyde Mountain descent, in the rain, with an overtaking lane two minutes away. Dashcam footage, plate blurred, driver invisible — because the dick move is the distance, not the person.',
   array['motorists'], '10000000-0000-4000-8000-000000000025',
   current_date - 3, 'afternoon', now() - interval '2.4 days', '00000000-0000-4000-8000-000000000005',
   'open', 'approved', false, 'Back off. Nobody arrives sooner; everybody arrives angrier.',
   5, 10, 44, 39, 36, 5, 40, 0),

  ('20000000-0000-4000-8000-000000000008', 35, 'dick_move', 'rubbish',
   'A trolley, released into the wild, has found water.', 'Dumping a trolley in the stormwater drain.',
   'Shopping trolley pushed down the embankment into the Queanbeyan River stormwater drain, three hundred metres from the shops it came from. The trolley did not ask for this.',
   array['the_community', 'local_businesses'], '10000000-0000-4000-8000-000000000023',
   current_date - 4, 'unknown', now() - interval '3.2 days', '00000000-0000-4000-8000-000000000007',
   'redeemed', 'approved', false, 'Trolleys live at the shops. Leave them there.',
   1, 6, 33, 45, 29, 17, 38, 31),

  ('20000000-0000-4000-8000-000000000009', 34, 'dick_move', 'neighbourhood',
   'Bin night was nine days ago. The bins are still holding the footpath hostage.',
   'Leaving bins blocking the footpath for over a week.',
   'Three bins left side by side across a narrow shared path for nine days after collection, so anyone with a pram or a wheelchair had to go onto the grass verge — which is now mud. Location shown as suburb only.',
   array['pedestrians', 'parents_prams', 'wheelchair_users'], '10000000-0000-4000-8000-000000000014',
   current_date - 5, 'morning', now() - interval '4.1 days', null,
   'open', 'approved', true, 'Bins go out the night before and come in the day after. Not the week after.',
   9, 31, 22, 4, 20, 9, 12, 0),

  ('20000000-0000-4000-8000-000000000010', 33, 'dick_move', 'parking',
   'The kids'' soccer ground gained a car park. On the pitch.',
   'Parking on the grass beside the junior soccer field.',
   'Drove up over the kerb and parked on the grass right beside the under-8s pitch at Gundary Oval, twenty metres from a mostly empty car park. Kids were warming up on the other side of the car.',
   array['the_community', 'parents_prams'], '10000000-0000-4000-8000-000000000007',
   current_date - 6, 'morning', now() - interval '5.5 days', '00000000-0000-4000-8000-000000000001',
   'open', 'approved', false, 'The car park is the flat bit with the lines. The grass is for the kids.',
   11, 28, 30, 9, 26, 4, 21, 0),

  ('20000000-0000-4000-8000-000000000011', 32, 'dick_move', 'internet',
   '"Is this still available?" Yes. Then silence for eternity.', 'Marketplace no-show, no message.',
   'Arranged a pickup for a free couch, confirmed twice, asked for the address (suburb only, we''re not silly), then never showed and never messaged. The couch has trust issues now.',
   array['probably_nobody'], '10000000-0000-4000-8000-000000000026',
   current_date - 6, 'evening', now() - interval '6 days', '00000000-0000-4000-8000-000000000010',
   'open', 'approved', false, 'Just send the message. It''s one message.',
   7, 40, 25, 6, 22, 48, 10, 0),

  ('20000000-0000-4000-8000-000000000012', 31, 'dick_move', 'workplace',
   'Reply-all. Four hundred people. "Thanks."', 'Replying-all to an all-staff email to say thanks.',
   'An all-staff email about the car park closure received a reply-all reading, in full, "Thanks". This triggered eleven "please remove me from this list" replies, also to all. Productivity in the building fell to zero for forty minutes.',
   array['everyone'], '10000000-0000-4000-8000-000000000018',
   current_date - 7, 'morning', now() - interval '6.8 days', '00000000-0000-4000-8000-000000000008',
   'open', 'approved', false, 'The reply button is right next to the reply-all button. Choose wisely.',
   12, 44, 19, 8, 15, 66, 9, 0),

  ('20000000-0000-4000-8000-000000000013', 30, 'dick_move', 'workplace',
   'Fish. In the office microwave. At 12:02.', 'Microwaving fish in the shared kitchen.',
   'Reheated last night''s salmon in the level-14 microwave and left the door open afterwards so the entire floor could participate. The smell outlasted the meeting about the smell.',
   array['everyone'], '10000000-0000-4000-8000-000000000028',
   current_date - 8, 'midday', now() - interval '7.5 days', '00000000-0000-4000-8000-000000000010',
   'open', 'approved', false, 'Some meals are for home. Fish is all of them.',
   4, 19, 41, 23, 30, 52, 18, 0),

  ('20000000-0000-4000-8000-000000000014', 29, 'dick_move', 'neighbourhood',
   'The whole beach got to enjoy the playlist.', 'Blasting a speaker across a quiet beach.',
   'One Bluetooth speaker, full volume, doof at 9am, three hundred metres of otherwise silent beach. Families relocated. A pelican relocated. The playlist was not good enough to justify any of this.',
   array['the_community', 'everyone'], '10000000-0000-4000-8000-000000000006',
   current_date - 9, 'morning', now() - interval '8.2 days', '00000000-0000-4000-8000-000000000005',
   'open', 'approved', false, 'Headphones exist and they are brilliant.',
   6, 22, 35, 14, 27, 15, 23, 0),

  ('20000000-0000-4000-8000-000000000015', 28, 'dick_move', 'parking',
   'The bike lane has been repurposed as a loading zone for one.', 'Parking in the bike lane.',
   'Van parked fully in the separated bike lane on Hunter Street with the hazards on, forcing cyclists out into traffic for the length of the block. There was a loading zone. It was empty.',
   array['cyclists', 'motorists'], '10000000-0000-4000-8000-000000000027',
   current_date - 10, 'midday', now() - interval '9.3 days', '00000000-0000-4000-8000-000000000008',
   'open', 'approved', false, 'Hazard lights are not a permit. The loading zone was empty.',
   3, 8, 49, 51, 45, 7, 53, 0),

  ('20000000-0000-4000-8000-000000000016', 27, 'dick_move', 'rubbish',
   'The bush now has a queen-size mattress. It did not want one.', 'Dumping a mattress in the bush reserve.',
   'Queen mattress, bed base and a broken bar fridge dumped just inside the bush reserve off Athllon Drive. The tip is eight minutes away and bulky waste collection is free. Free.',
   array['the_community', 'everyone'], '10000000-0000-4000-8000-000000000016',
   current_date - 12, 'unknown', now() - interval '11 days', '00000000-0000-4000-8000-000000000006',
   'open', 'approved', false, 'Bulky waste collection is free. The bush is not a tip.',
   0, 1, 18, 92, 68, 3, 81, 0),

  ('20000000-0000-4000-8000-000000000017', 26, 'dick_move', 'dog',
   '"He''s friendly!" is not a leash.', 'Off-lead on the on-lead section of the beach.',
   'Dog bounding off-lead through the clearly signed on-lead section at Broulee, straight at a toddler and a nervous kelpie. The lead went on within a few minutes and the rest of the walk was lovely. Redeemed.',
   array['parents_prams', 'the_community'], '10000000-0000-4000-8000-000000000008',
   current_date - 13, 'afternoon', now() - interval '12.5 days', '00000000-0000-4000-8000-000000000001',
   'redeemed', 'approved', false, 'Lovely dog. The lead is for everyone else''s sake.',
   14, 36, 20, 5, 18, 9, 11, 40),

  ('20000000-0000-4000-8000-000000000018', 25, 'dick_move', 'parking',
   'A diesel ute, parked across two EV chargers, for a forty-minute pie.',
   'Blocking both EV chargers with a non-EV.',
   'Diesel ute parked diagonally across both charging bays at the highway service centre for the duration of a pie, a coffee and a long conversation. Two EVs waited. One left with 8% and a prayer.',
   array['motorists'], '10000000-0000-4000-8000-000000000024',
   current_date - 15, 'midday', now() - interval '14 days', '00000000-0000-4000-8000-000000000002',
   'open', 'approved', false, 'Those bays are for charging. Your pie does not need 50 kW.',
   2, 5, 27, 84, 55, 14, 71, 0),

  ('20000000-0000-4000-8000-000000000019', 24, 'dick_move', 'shopping',
   'Jumped the sausage sizzle queue. In Australia. On a Saturday.', 'Pushing in at the Bunnings snag line.',
   'Walked straight to the front of a twelve-person sausage sizzle queue, ordered four, and paid with a fifty. The queue said nothing, in the Australian way, and has been quietly furious ever since.',
   array['probably_nobody'], '10000000-0000-4000-8000-000000000017',
   current_date - 15, 'midday', now() - interval '14.5 days', '00000000-0000-4000-8000-000000000006',
   'open', 'approved', false, 'The queue is sacred. Join the back of it.',
   9, 47, 21, 7, 19, 58, 12, 0),

  ('20000000-0000-4000-8000-000000000020', 23, 'dick_move', 'shopping',
   'Four trolleys, one accessible bay, zero excuses.', 'Filling the accessible bay with trolleys.',
   'Somebody''s idea of tidying up: four trolleys corralled neatly into the accessible bay closest to the entrance, so it looked full to anyone who actually needed it. The trolley return was two bays further along.',
   array['wheelchair_users', 'the_community'], '10000000-0000-4000-8000-000000000009',
   current_date - 17, 'afternoon', now() - interval '16 days', '00000000-0000-4000-8000-000000000010',
   'open', 'approved', false, 'Trolleys go in the trolley bay. The accessible bay is for people.',
   3, 16, 46, 28, 34, 11, 30, 0),

  ('20000000-0000-4000-8000-000000000021', 22, 'dick_move', 'parking',
   'Over the line by a tyre width. The community has spoken: relax.', 'Parking slightly over the line.',
   'One rear tyre about ten centimetres over the line at the Tuggeranong Kmart. The bay next to it was still very usable. The community verdict came in fast and it was: not a dick move, mate.',
   array['probably_nobody'], '10000000-0000-4000-8000-000000000015',
   current_date - 18, 'afternoon', now() - interval '17 days', '00000000-0000-4000-8000-000000000004',
   'overruled', 'approved', false, 'Sometimes it''s not a dick move. Sometimes it''s just a Tuesday.',
   71, 14, 3, 1, 5, 12, 2, 0),

  ('20000000-0000-4000-8000-000000000022', 21, 'dick_move', 'shopping',
   'A frozen chicken, abandoned in the biscuit aisle, slowly becoming a health hazard.',
   'Ditching frozen food in a dry aisle.',
   'Changed their mind about a $14 chook and left it on the Tim Tam shelf to defrost rather than walking it back forty metres. Staff found it two hours later. The Tim Tams were fine. The chicken was not.',
   array['local_businesses', 'the_community'], '10000000-0000-4000-8000-000000000029',
   current_date - 20, 'evening', now() - interval '19 days', '00000000-0000-4000-8000-000000000010',
   'open', 'approved', false, 'Changed your mind? Walk it back. The freezer misses it.',
   2, 19, 39, 21, 26, 37, 20, 0),

  ('20000000-0000-4000-8000-000000000023', 20, 'dick_move', 'neighbourhood',
   'Four public barbecues "reserved" with towels at 8am. For a 1pm party.',
   'Reserving all the public barbecues with towels.',
   'All four barbecues at Commonwealth Park draped in towels and a handwritten RESERVED sign five hours before anyone turned up. Three families cooked sausages on a camp stove on the grass instead.',
   array['the_community', 'everyone'], '10000000-0000-4000-8000-000000000020',
   current_date - 22, 'morning', now() - interval '21 days', '00000000-0000-4000-8000-000000000002',
   'redeemed', 'approved', false, 'Public means shared. Take one barbecue, not the suburb.',
   8, 20, 39, 17, 29, 21, 24, 26),

  ('20000000-0000-4000-8000-000000000024', 19, 'dick_move', 'shopping',
   'A trolley left on the tram tracks. In Fitzroy. Bold.', 'Leaving a trolley on the tram tracks.',
   'Trolley abandoned across the tracks on Brunswick Street. A tram stopped, the driver got out, moved it to the footpath and got back in, with the expression of a man who has done this before.',
   array['the_community', 'motorists'], '10000000-0000-4000-8000-000000000030',
   current_date - 24, 'evening', now() - interval '23 days', '00000000-0000-4000-8000-000000000009',
   'open', 'approved', false, 'Trams have rails for a reason. Trolleys have bays for the same reason.',
   1, 7, 34, 40, 31, 27, 36, 0),

  ('20000000-0000-4000-8000-000000000025', 18, 'dick_move', 'parking',
   'Set up camp — chairs, awning, esky — in the Mindil Beach car park. In three bays.',
   'Camping across three car park bays at sunset.',
   'Awning out, chairs deployed, esky open, across three bays of the Mindil Beach car park at peak sunset-market time while a line of cars went round and round. The sunset was good. The car park was not.',
   array['motorists', 'the_community'], '10000000-0000-4000-8000-000000000035',
   current_date - 26, 'evening', now() - interval '25 days', '00000000-0000-4000-8000-000000000009',
   'open', 'approved', false, 'One bay per vehicle. The beach is right there for the chairs.',
   6, 18, 41, 22, 28, 33, 25, 0),

  -- ---- NOT A DICK ---------------------------------------------------------
  ('20000000-0000-4000-8000-000000000026', 17, 'not_a_dick', 'shopping',
   'Returned three stray trolleys in the pouring rain. Didn''t even work there.',
   'Returning other people''s trolleys.',
   'In sideways rain at the Batemans Bay Woolies, a bloke rounded up three abandoned trolleys, wheeled them to the bay, then went and did his shopping soaked. Definitely not a dick.',
   array['the_community'], '10000000-0000-4000-8000-000000000001',
   current_date - 3, 'afternoon', now() - interval '2.7 days', '00000000-0000-4000-8000-000000000001',
   'open', 'approved', false, 'This is the standard. Definitely not a dick.',
   88, 1, 0, 0, 64, 3, 0, 71),

  ('20000000-0000-4000-8000-000000000027', 16, 'not_a_dick', 'rubbish',
   'Filled a whole bag with rubbish that wasn''t his. Left before anyone could thank him.',
   'Cleaning up someone else''s mess.',
   'Walked the length of Surf Beach with a bag, picking up bottle caps, bait packets and a thong, then quietly dropped it in the bin and drove off. We don''t know who you are, and that''s the point. Definitely not a dick.',
   array['everyone'], '10000000-0000-4000-8000-000000000004',
   current_date - 9, 'morning', now() - interval '8.5 days', '00000000-0000-4000-8000-000000000005',
   'open', 'approved', false, 'Be this person.',
   102, 0, 0, 0, 77, 5, 0, 90),

  ('20000000-0000-4000-8000-000000000028', 15, 'not_a_dick', 'parking',
   'Realised they''d blocked the ramp, sprinted back and moved the car. Apologised twice.',
   'Fixing it the second they realised.',
   'Parked over the end of the accessible ramp at Kingston Foreshore, got ten metres, clocked it, ran back and moved the car before anyone said a word. Then apologised to a passer-by who hadn''t noticed. Definitely not a dick.',
   array['wheelchair_users', 'parents_prams'], '10000000-0000-4000-8000-000000000019',
   current_date - 11, 'evening', now() - interval '10.4 days', '00000000-0000-4000-8000-000000000003',
   'open', 'approved', false, 'We''ve all been a dick at some point. This is how you fix it.',
   66, 2, 0, 0, 50, 4, 0, 61),

  ('20000000-0000-4000-8000-000000000029', 14, 'not_a_dick', 'road',
   'Truckie pulled over at the rest area to change a stranger''s tyre. Wouldn''t take a cent.',
   'Helping a stranger on the highway.',
   'A family with a flat and no idea, a truck driver on his break, twelve minutes, one changed tyre, one refused twenty-dollar note. Drove off with a wave. Definitely not a dick.',
   array['motorists'], '10000000-0000-4000-8000-000000000036',
   current_date - 14, 'afternoon', now() - interval '13.3 days', '00000000-0000-4000-8000-000000000002',
   'open', 'approved', false, 'Be the truckie.',
   94, 0, 0, 0, 70, 6, 0, 88),

  -- ---- Pending moderation (moderators and the submitter only) -------------
  ('20000000-0000-4000-8000-000000000030', 43, 'dick_move', 'parking',
   'Ute across the footpath outside the bakery. Pies were involved.',
   'Blocking the footpath for a pie run.',
   'Ute parked across the Market Street footpath for a bakery run while a woman with a walker waited on the kerb. Submitted a minute ago — awaiting a moderator''s once-over.',
   array['pedestrians', 'wheelchair_users'], '10000000-0000-4000-8000-000000000010',
   current_date, 'morning', now() - interval '6 minutes', '00000000-0000-4000-8000-000000000005',
   'open', 'pending', false, 'The footpath is not a bakery car park.',
   0, 0, 0, 0, 0, 0, 0, 0),

  ('20000000-0000-4000-8000-000000000031', 44, 'dick_move', 'road',
   'Scrolling at the lights, then scrolling after the lights.', 'Phone in hand at 60 km/h.',
   'Passenger photo from the car behind: phone held up at the wheel through a green light and the following two hundred metres. Photo shows the phone and the car interior only — no face, no plate.',
   array['motorists', 'pedestrians'], '10000000-0000-4000-8000-000000000022',
   current_date, 'afternoon', now() - interval '48 minutes', '00000000-0000-4000-8000-000000000008',
   'open', 'pending', false, 'Whatever it was, it could have waited.',
   0, 0, 0, 0, 0, 0, 0, 0);

-- Dick Move of the Week (this week) and the one that took last month.
update public.incidents set featured_week = public.week_of(now())
  where id = '20000000-0000-4000-8000-000000000001';
update public.incidents set featured_week = (now() - interval '21 days')::date
  where id = '20000000-0000-4000-8000-000000000016';

-- Nominations after the seed continue from DBAD-0045.
alter table public.incidents alter column seq restart with 45;

-- ---------------------------------------------------------------------------
-- Evidence photos (generated illustrations in public/seed, 1200x900).
-- ---------------------------------------------------------------------------
insert into public.incident_photos (id, incident_id, url, width, height, alt, redacted, redaction_count, sort_order) values
  ('30000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '/seed/parking-footpath-01.jpg', 1200, 900,
   'A dark SUV parked side-on across the full width of a concrete footpath, a pram forced onto the road around it', true, 1, 0),
  ('30000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000002', '/seed/shopping-trolley-01.jpg', 1200, 900,
   'A lone hardware trolley sitting in the middle of an empty parking bay, trolley return bay visible in the background', true, 0, 0),
  ('30000000-0000-4000-8000-000000000003', '20000000-0000-4000-8000-000000000003', '/seed/parking-accessible-01.jpg', 1200, 900,
   'A hatchback with hazard lights parked in an accessible bay marked with the wheelchair symbol, no permit on the dash', true, 1, 0),
  ('30000000-0000-4000-8000-000000000004', '20000000-0000-4000-8000-000000000004', '/seed/parking-two-bays-01.jpg', 1200, 900,
   'A white sedan parked straddling the painted line between two supermarket parking bays', true, 1, 0),
  ('30000000-0000-4000-8000-000000000005', '20000000-0000-4000-8000-000000000005', '/seed/dog-bag-fence-01.jpg', 1200, 900,
   'A knotted green dog-waste bag hanging from a timber dune fence post with the beach behind', true, 0, 0),
  ('30000000-0000-4000-8000-000000000006', '20000000-0000-4000-8000-000000000006', '/seed/rubbish-picnic-01.jpg', 1200, 900,
   'A lakeside picnic table covered in abandoned pizza boxes, bottles and wrappers with a public bin visible a few metres away', true, 0, 0),
  ('30000000-0000-4000-8000-000000000007', '20000000-0000-4000-8000-000000000007', '/seed/road-tailgate-01.jpg', 1200, 900,
   'Rear-camera view of a 4WD sitting very close behind on a wet winding mountain road, number plate blurred', true, 1, 0),
  ('30000000-0000-4000-8000-000000000008', '20000000-0000-4000-8000-000000000008', '/seed/shopping-trolley-drain-01.jpg', 1200, 900,
   'A supermarket trolley lying on its side in a shallow concrete stormwater drain surrounded by reeds', true, 0, 0),
  ('30000000-0000-4000-8000-000000000009', '20000000-0000-4000-8000-000000000009', '/seed/neighbourhood-bins-01.jpg', 1200, 900,
   'Three wheelie bins lined up across a narrow footpath with muddy footprints on the grass beside them', true, 0, 0),
  ('30000000-0000-4000-8000-000000000010', '20000000-0000-4000-8000-000000000010', '/seed/parking-grass-oval-01.jpg', 1200, 900,
   'A ute parked on the grass beside a junior soccer field with orange cones and a goal in the background', true, 1, 0),
  ('30000000-0000-4000-8000-000000000011', '20000000-0000-4000-8000-000000000013', '/seed/workplace-microwave-01.jpg', 1200, 900,
   'An office kitchen microwave with its door open and a foil container inside, a small fan pointed at it in protest', true, 0, 0),
  ('30000000-0000-4000-8000-000000000012', '20000000-0000-4000-8000-000000000014', '/seed/neighbourhood-speaker-01.jpg', 1200, 900,
   'A large portable speaker on a towel on an otherwise empty beach, sound-wave lines drawn across the sand', true, 0, 0),
  ('30000000-0000-4000-8000-000000000013', '20000000-0000-4000-8000-000000000015', '/seed/parking-bike-lane-01.jpg', 1200, 900,
   'A white van parked inside a green painted bike lane with a cyclist swerving around it into the traffic lane', true, 1, 0),
  ('30000000-0000-4000-8000-000000000014', '20000000-0000-4000-8000-000000000016', '/seed/rubbish-mattress-01.jpg', 1200, 900,
   'A stained mattress and a small fridge dumped among gum trees beside a dirt track', true, 0, 0),
  ('30000000-0000-4000-8000-000000000015', '20000000-0000-4000-8000-000000000017', '/seed/dog-offlead-01.jpg', 1200, 900,
   'An on-lead-area sign at a beach entrance with paw prints running past it toward the water', true, 0, 0),
  ('30000000-0000-4000-8000-000000000016', '20000000-0000-4000-8000-000000000018', '/seed/parking-ev-01.jpg', 1200, 900,
   'A dual-cab ute parked diagonally across two EV charging bays, charging cables hanging unused', true, 1, 0),
  ('30000000-0000-4000-8000-000000000017', '20000000-0000-4000-8000-000000000020', '/seed/shopping-trolleys-bay-01.jpg', 1200, 900,
   'Four shopping trolleys nested together inside an accessible parking bay with the wheelchair symbol painted on the ground', true, 0, 0),
  ('30000000-0000-4000-8000-000000000018', '20000000-0000-4000-8000-000000000021', '/seed/parking-slightly-over-01.jpg', 1200, 900,
   'A small hatchback with one rear tyre barely over the painted bay line in a shopping centre car park', true, 1, 0),
  ('30000000-0000-4000-8000-000000000019', '20000000-0000-4000-8000-000000000022', '/seed/shopping-frozen-01.jpg', 1200, 900,
   'A frozen chicken in plastic sitting on a supermarket shelf between packets of biscuits, a small puddle forming', true, 0, 0),
  ('30000000-0000-4000-8000-000000000020', '20000000-0000-4000-8000-000000000023', '/seed/neighbourhood-bbq-towels-01.jpg', 1200, 900,
   'Public park barbecues covered with beach towels and a cardboard reserved sign, nobody around', true, 0, 0),
  ('30000000-0000-4000-8000-000000000021', '20000000-0000-4000-8000-000000000024', '/seed/shopping-trolley-tram-01.jpg', 1200, 900,
   'A shopping trolley standing on tram tracks in an inner-city street with a tram stopped behind it', true, 0, 0),
  ('30000000-0000-4000-8000-000000000022', '20000000-0000-4000-8000-000000000025', '/seed/parking-camp-01.jpg', 1200, 900,
   'A campervan with awning, camp chairs and an esky spread across three beachside car park bays at sunset', true, 0, 0),
  ('30000000-0000-4000-8000-000000000023', '20000000-0000-4000-8000-000000000026', '/seed/positive-trolleys-01.jpg', 1200, 900,
   'Three trolleys neatly nested in a trolley bay with rain streaking across a supermarket car park', true, 0, 0),
  ('30000000-0000-4000-8000-000000000024', '20000000-0000-4000-8000-000000000027', '/seed/positive-beach-cleanup-01.jpg', 1200, 900,
   'A full rubbish bag propped beside a beach bin with a clean stretch of sand and surf behind it', true, 0, 0),
  ('30000000-0000-4000-8000-000000000025', '20000000-0000-4000-8000-000000000030', '/seed/parking-footpath-02.jpg', 1200, 900,
   'A tray-back ute parked across a footpath outside a row of shops, a person with a walking frame waiting behind it', true, 1, 0);

-- ---------------------------------------------------------------------------
-- Redemptions
-- ---------------------------------------------------------------------------
insert into public.redemptions (id, incident_id, note, confirmed_by, created_at) values
  ('a0000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000004',
   'They came back and re-parked between the lines. Humanity survives another day.', 'submitter', now() - interval '1.8 days'),
  ('a0000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000008',
   'Two locals hauled it out and wheeled it home to the shops. Not who dumped it — but the drain is clear and the trolley is where it belongs.', 'community', now() - interval '2 days'),
  ('a0000000-0000-4000-8000-000000000003', '20000000-0000-4000-8000-000000000017',
   'Lead went on within minutes. Lovely dog. Sorted.', 'submitter', now() - interval '12.4 days'),
  ('a0000000-0000-4000-8000-000000000004', '20000000-0000-4000-8000-000000000023',
   'The party turned up, saw the notice, and gave two barbecues back to the families. Snags all round.', 'submitter', now() - interval '20.8 days');

-- ---------------------------------------------------------------------------
-- Comments. incidents.comment_count is maintained by trigger, so the hidden one
-- correctly does not count.
-- ---------------------------------------------------------------------------
insert into public.comments (id, incident_id, author_id, body, status, created_at) values
  ('40000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000003',
   'I have pushed a pram around this exact spot. Onto the road. With a toddler on a scooter. Absolute dickery, fair call.', 'visible', now() - interval '21 minutes'),
  ('40000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000002',
   'Footpath: noun. A path for feet. Not tyres. We should not have to keep explaining this.', 'visible', now() - interval '18 minutes'),
  ('40000000-0000-4000-8000-000000000003', '20000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000005',
   'There are literally six empty spaces in the photo behind it.', 'visible', now() - interval '12 minutes'),
  ('40000000-0000-4000-8000-000000000004', '20000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000006',
   'Pretty sure I know whose car that is, it''s the bloke from—', 'hidden', now() - interval '9 minutes'),
  ('40000000-0000-4000-8000-000000000005', '20000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011',
   'Reminder: we call out the parking, not the parker. Comment above hidden. Carry on taking the piss out of the parking.', 'visible', now() - interval '8 minutes'),
  ('40000000-0000-4000-8000-000000000006', '20000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000002',
   'As the community''s self-appointed trolley return officer I would like to say: twenty metres. TWENTY.', 'visible', now() - interval '2.5 hours'),
  ('40000000-0000-4000-8000-000000000007', '20000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000001',
   'Bit of a dick move rather than absolute — it was raining. Still, twenty metres.', 'visible', now() - interval '2 hours'),
  ('40000000-0000-4000-8000-000000000008', '20000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-000000000001',
   'The redemption update made my morning. Notice worked!', 'visible', now() - interval '1.7 days'),
  ('40000000-0000-4000-8000-000000000009', '20000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-000000000004',
   'REDEEMED. Humanity survives another day. Love this site.', 'visible', now() - interval '1.6 days'),
  ('40000000-0000-4000-8000-000000000010', '20000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-000000000003',
   'Bagging it and then abandoning the bag is somehow worse than not bagging it. It''s littering with extra steps.', 'visible', now() - interval '1 day'),
  ('40000000-0000-4000-8000-000000000011', '20000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-000000000005',
   'To be clear: good dog. 10/10 dog. The bag-hanger is the problem.', 'visible', now() - interval '0.9 days'),
  ('40000000-0000-4000-8000-000000000012', '20000000-0000-4000-8000-000000000006', '00000000-0000-4000-8000-000000000008',
   'Nothing says ''I love this park'' like leaving it looking like a food court at closing time.', 'visible', now() - interval '1.5 days'),
  ('40000000-0000-4000-8000-000000000013', '20000000-0000-4000-8000-000000000011', '00000000-0000-4000-8000-000000000009',
   'The couch deserved better.', 'visible', now() - interval '5.5 days'),
  ('40000000-0000-4000-8000-000000000014', '20000000-0000-4000-8000-000000000011', '00000000-0000-4000-8000-000000000006',
   'Bit of a dick move. Big one if it happens twice.', 'visible', now() - interval '5.2 days'),
  ('40000000-0000-4000-8000-000000000015', '20000000-0000-4000-8000-000000000012', '00000000-0000-4000-8000-000000000003',
   'The eleven ''please remove me'' replies are the real dick moves and I will die on this hill.', 'visible', now() - interval '6.5 days'),
  ('40000000-0000-4000-8000-000000000016', '20000000-0000-4000-8000-000000000013', '00000000-0000-4000-8000-000000000002',
   'Fish in the office microwave is a Geneva Convention matter.', 'visible', now() - interval '7 days'),
  ('40000000-0000-4000-8000-000000000017', '20000000-0000-4000-8000-000000000016', '00000000-0000-4000-8000-000000000007',
   'Deserved Dick Move of the Week. Free. Collection. Is. Free.', 'visible', now() - interval '10 days'),
  ('40000000-0000-4000-8000-000000000018', '20000000-0000-4000-8000-000000000021', '00000000-0000-4000-8000-000000000002',
   'Not a dick move. Ten centimetres. Touch grass, mate.', 'visible', now() - interval '16.8 days'),
  ('40000000-0000-4000-8000-000000000019', '20000000-0000-4000-8000-000000000021', '00000000-0000-4000-8000-000000000004',
   'Fair enough, community. Overruled and I accept it. Owning it as per the rules.', 'visible', now() - interval '16.5 days'),
  ('40000000-0000-4000-8000-000000000020', '20000000-0000-4000-8000-000000000026', '00000000-0000-4000-8000-000000000002',
   'This man is the trolley return officer I aspire to be. Definitely not a dick.', 'visible', now() - interval '2.5 days'),
  ('40000000-0000-4000-8000-000000000021', '20000000-0000-4000-8000-000000000027', '00000000-0000-4000-8000-000000000001',
   'Whoever you are: legend.', 'visible', now() - interval '8 days'),
  ('40000000-0000-4000-8000-000000000022', '20000000-0000-4000-8000-000000000018', '00000000-0000-4000-8000-000000000008',
   '50 kW pie.', 'visible', now() - interval '13 days'),
  ('40000000-0000-4000-8000-000000000023', '20000000-0000-4000-8000-000000000015', '00000000-0000-4000-8000-000000000010',
   'Loading zone: empty. Bike lane: van. Every. Single. Day.', 'visible', now() - interval '9 days'),
  ('40000000-0000-4000-8000-000000000024', '20000000-0000-4000-8000-000000000019', '00000000-0000-4000-8000-000000000005',
   'Paying with a fifty is the aggravating factor here.', 'visible', now() - interval '14 days');

-- ---------------------------------------------------------------------------
-- Reports
-- ---------------------------------------------------------------------------
insert into public.reports (id, target_type, target_id, reason, details, reporter_id, status, created_at, resolved_at, resolved_by) values
  ('50000000-0000-4000-8000-000000000001', 'comment', '40000000-0000-4000-8000-000000000004', 'identifies_person',
   'Comment is about to name the driver.', '00000000-0000-4000-8000-000000000003', 'resolved',
   now() - interval '10 minutes', now() - interval '8 minutes', '00000000-0000-4000-8000-000000000011'),
  ('50000000-0000-4000-8000-000000000002', 'incident', '20000000-0000-4000-8000-000000000009', 'private_address',
   'Original post mentioned the street. Please anonymise.', null, 'resolved',
   now() - interval '4 days', now() - interval '3.9 days', '00000000-0000-4000-8000-000000000011'),
  ('50000000-0000-4000-8000-000000000003', 'incident', '20000000-0000-4000-8000-000000000019', 'not_a_dick_move',
   'Maybe they had a disability pass for the queue? Feels harsh.', '00000000-0000-4000-8000-000000000009', 'open',
   now() - interval '5 hours', null, null),
  ('50000000-0000-4000-8000-000000000004', 'incident', '20000000-0000-4000-8000-000000000025', 'duplicate',
   'Same as a post in the Darwin Facebook group last week.', null, 'open',
   now() - interval '30 hours', null, null);

-- ---------------------------------------------------------------------------
-- Appeals. `contact` is moderator-only and never leaves the table.
-- ---------------------------------------------------------------------------
insert into public.appeals (id, incident_id, requested_action, message, contact, status, public_reply, created_at, updated_at) values
  ('60000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000004', 'context',
   'That was me. I''d just had a call about my dad and wasn''t looking. Came back and fixed it as soon as I saw the card. Fair cop.',
   null, 'actioned',
   'Fair cop. Came back and fixed it as soon as I saw the card. Sorry to everyone circling.',
   now() - interval '1.9 days', now() - interval '1.8 days'),
  ('60000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000010', 'correction',
   'The car park was full for the carnival, the grass area was marked as overflow by the club that morning (cones). Photo doesn''t show the cones.',
   '(private — moderators only)', 'open', null,
   now() - interval '20 hours', now() - interval '20 hours');

-- ---------------------------------------------------------------------------
-- Audit log
-- ---------------------------------------------------------------------------
insert into public.moderation_actions (id, actor_id, action, target_type, target_id, note, created_at) values
  ('70000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000011', 'hide_comment', 'comment',
   '40000000-0000-4000-8000-000000000004', 'About to identify the driver.', now() - interval '8 minutes'),
  ('70000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000011', 'resolve_report', 'report',
   '50000000-0000-4000-8000-000000000001', null, now() - interval '8 minutes'),
  ('70000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000012', 'feature_week', 'incident',
   '20000000-0000-4000-8000-000000000001', 'Community pick, 94% dick move.', now() - interval '15 minutes'),
  ('70000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-000000000011', 'approve', 'incident',
   '20000000-0000-4000-8000-000000000001', null, now() - interval '22 minutes'),
  ('70000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-000000000011', 'approve', 'incident',
   '20000000-0000-4000-8000-000000000002', null, now() - interval '2.9 hours'),
  ('70000000-0000-4000-8000-000000000006', '00000000-0000-4000-8000-000000000011', 'anonymise', 'incident',
   '20000000-0000-4000-8000-000000000009', 'Submitter requested; street removed from description.', now() - interval '3.9 days'),
  ('70000000-0000-4000-8000-000000000007', '00000000-0000-4000-8000-000000000011', 'resolve_report', 'report',
   '50000000-0000-4000-8000-000000000002', null, now() - interval '3.9 days'),
  ('70000000-0000-4000-8000-000000000008', '00000000-0000-4000-8000-000000000012', 'action_appeal', 'appeal',
   '60000000-0000-4000-8000-000000000001', 'Published right of reply.', now() - interval '1.8 days'),
  ('70000000-0000-4000-8000-000000000009', '00000000-0000-4000-8000-000000000011', 'mark_overruled', 'incident',
   '20000000-0000-4000-8000-000000000021', 'Community verdict 82% not a dick move.', now() - interval '16.4 days'),
  ('70000000-0000-4000-8000-000000000010', '00000000-0000-4000-8000-000000000012', 'feature_week', 'incident',
   '20000000-0000-4000-8000-000000000016', null, now() - interval '9.5 days');

-- ---------------------------------------------------------------------------
-- Notifications
-- ---------------------------------------------------------------------------
insert into public.notifications (id, user_id, kind, title, body, href, created_at, read_at) values
  ('80000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000001', 'featured', 'Dick Move of the Week',
   'Your footpath nomination in Batemans Bay is this week''s Dick Move of the Week.', '/week', now() - interval '15 minutes', null),
  ('80000000-0000-4000-8000-000000000002', '00000000-0000-4000-8000-000000000001', 'verdict_reached', 'Community verdict reached',
   'Blocking the footpath — 94% Dick Move. Fair call.', '/moves/blocking-the-footpath-batemans-bay-0042', now() - interval '19 minutes', null),
  ('80000000-0000-4000-8000-000000000003', '00000000-0000-4000-8000-000000000001', 'comment', 'New comment',
   'pramnavigator: "I have pushed a pram around this exact spot…"', '/moves/blocking-the-footpath-batemans-bay-0042#comments', now() - interval '21 minutes', null),
  ('80000000-0000-4000-8000-000000000004', '00000000-0000-4000-8000-000000000001', 'badge', 'Badge earned: FAIR DINKUM',
   '90% of your nominations agreed with by the community.', '/me', now() - interval '30 days', now() - interval '29 days'),
  ('80000000-0000-4000-8000-000000000005', '00000000-0000-4000-8000-000000000005', 'redeemed', 'REDEEMED',
   'The two-bay parker in Ulladulla came back and fixed it.', '/moves/taking-two-parking-bays-ulladulla-0039', now() - interval '1.8 days', null),
  ('80000000-0000-4000-8000-000000000006', '00000000-0000-4000-8000-000000000004', 'moderation', 'Overruled',
   'The community reckons the Kmart tyre-width wasn''t a dick move. Owning it earns respect.',
   '/moves/parking-slightly-over-the-line-tuggeranong-0022', now() - interval '16.4 days', now() - interval '16 days');

-- ---------------------------------------------------------------------------
-- Printable notices
-- ---------------------------------------------------------------------------
insert into public.printable_notices (id, incident_id, template, link_mode, headline, dick_move, why, location, advice, created_at, created_by) values
  ('90000000-0000-4000-8000-000000000001', '20000000-0000-4000-8000-000000000001', 'official-warning', 'incident',
   'YOU HAVE BEEN DBAD''D.', 'Parking across a public footpath.',
   'People shouldn''t have to walk onto the road because you couldn''t park properly.',
   'Batemans Bay, NSW', 'Do better next time.', now() - interval '23 minutes', '00000000-0000-4000-8000-000000000001'),
  ('90000000-0000-4000-8000-000000000002', '20000000-0000-4000-8000-000000000004', 'friendly-reminder', 'site',
   'FRIENDLY REMINDER.', 'Taking two parking bays.',
   'The lines are painted for a reason, and it isn''t decoration.',
   'Ulladulla, NSW', 'Look down before you get out. Cheers.', now() - interval '2 days', '00000000-0000-4000-8000-000000000005');

-- ---------------------------------------------------------------------------
-- Badges already earned. (refresh_badges() would award most of these from the
-- data above; the seed pins the award dates so profiles look lived-in.)
-- ---------------------------------------------------------------------------
insert into public.user_badges (user_id, badge_id, awarded_at) values
  ('00000000-0000-4000-8000-000000000001', 'first_call', now() - interval '200 days'),
  ('00000000-0000-4000-8000-000000000001', 'eagle_eye', now() - interval '40 days'),
  ('00000000-0000-4000-8000-000000000001', 'not_actually_a_karen', now() - interval '120 days'),
  ('00000000-0000-4000-8000-000000000001', 'fair_dinkum', now() - interval '30 days'),
  ('00000000-0000-4000-8000-000000000002', 'first_call', now() - interval '180 days'),
  ('00000000-0000-4000-8000-000000000002', 'not_actually_a_karen', now() - interval '60 days'),
  ('00000000-0000-4000-8000-000000000002', 'local_legend', now() - interval '12 days'),
  ('00000000-0000-4000-8000-000000000003', 'first_call', now() - interval '160 days'),
  ('00000000-0000-4000-8000-000000000005', 'first_call', now() - interval '130 days'),
  ('00000000-0000-4000-8000-000000000005', 'redemption_arc', now() - interval '9 days'),
  ('00000000-0000-4000-8000-000000000008', 'first_call', now() - interval '70 days'),
  ('00000000-0000-4000-8000-000000000011', 'first_call', now() - interval '220 days'),
  ('00000000-0000-4000-8000-000000000011', 'local_legend', now() - interval '100 days');
