#!/usr/bin/env bash
# ===========================================================================
# DBAD — throwaway local PostgreSQL run.
#
# Spins up a temporary PostgreSQL 16 cluster, stubs out just enough of the
# Supabase platform (the auth and storage schemas, the anon/authenticated/
# service_role roles), applies every migration and the seed, then runs
# rls.test.sql against it.
#
#   ./supabase/tests/local-pg.sh            # apply + test, then clean up
#   KEEP=1 ./supabase/tests/local-pg.sh     # leave the cluster running
#
# Nothing here touches a real Supabase project. The cluster lives in a temp
# directory, listens on port 54329, and is deleted on exit.
# ===========================================================================
set -Eeuo pipefail

PORT="${PGTEST_PORT:-54329}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
MIGRATIONS="$ROOT/supabase/migrations"
SEED="$ROOT/supabase/seed.sql"
TESTS="$ROOT/supabase/tests/rls.test.sql"
PGBIN="${PGBIN:-/usr/lib/postgresql/16/bin}"
WORK="$(mktemp -d /tmp/dbad-pgtest.XXXXXX)"
DATA="$WORK/data"
SOCK="$WORK/sock"
LOG="$WORK/postgres.log"
DB="dbad_test"

# Postgres refuses to run as root; borrow an unprivileged account when we are.
RUNAS=""
if [ "$(id -u)" = "0" ]; then
  RUNAS="${PGTEST_USER:-postgres}"
  if ! id "$RUNAS" >/dev/null 2>&1; then
    useradd --system --create-home --shell /bin/sh "$RUNAS"
  fi
fi

run() {  # run a command as the cluster owner
  if [ -n "$RUNAS" ]; then
    su "$RUNAS" -s /bin/bash -c "$1"
  else
    bash -c "$1"
  fi
}

cleanup() {
  local code=$?
  if [ "${KEEP:-0}" = "1" ] && [ "$code" = "0" ]; then
    echo "KEEP=1: cluster left running on port $PORT (data: $DATA)"
    echo "  psql -h $SOCK -p $PORT -d $DB"
    return
  fi
  if [ -d "$DATA" ]; then
    run "$PGBIN/pg_ctl -D '$DATA' -m immediate -w stop" >/dev/null 2>&1 || true
  fi
  rm -rf "$WORK"
  return $code
}
trap cleanup EXIT

mkdir -p "$DATA" "$SOCK"
if [ -n "$RUNAS" ]; then chown -R "$RUNAS" "$WORK"; fi

echo "==> initdb ($WORK)"
run "$PGBIN/initdb -D '$DATA' -U postgres --auth=trust --encoding=UTF8 --locale=C" >"$WORK/initdb.log" 2>&1 \
  || { cat "$WORK/initdb.log"; exit 1; }

echo "==> starting PostgreSQL on port $PORT"
run "$PGBIN/pg_ctl -D '$DATA' -l '$LOG' -o \"-p $PORT -k '$SOCK' -c listen_addresses='' -c log_min_messages=warning\" -w start" >/dev/null \
  || { cat "$LOG"; exit 1; }

PSQL="$PGBIN/psql -h $SOCK -p $PORT -U postgres -v ON_ERROR_STOP=1 -X -q"
run "$PSQL -d postgres -c \"create database $DB\"" >/dev/null

psql_file() { run "$PSQL -d $DB -f '$1'"; }
psql_cmd()  { run "$PSQL -d $DB -c \"$1\""; }

# ---------------------------------------------------------------------------
# Supabase platform stub. Everything the migrations legitimately depend on and
# nothing else: the auth schema and its helper functions, the storage schema,
# and the three API roles with the grants Supabase gives them.
# ---------------------------------------------------------------------------
echo "==> creating Supabase platform stub (auth, storage, roles)"
cat >"$WORK/stub.sql" <<'STUB'
create extension if not exists pgcrypto;
create extension if not exists citext;

-- Roles, as Supabase creates them.
do $$
begin
  if not exists (select 1 from pg_roles where rolname = 'anon') then
    create role anon nologin noinherit;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then
    create role authenticated nologin noinherit;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'service_role') then
    create role service_role nologin noinherit bypassrls;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticator') then
    create role authenticator login noinherit;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'supabase_auth_admin') then
    create role supabase_auth_admin nologin noinherit;
  end if;
end
$$;
grant anon, authenticated, service_role to authenticator;
grant anon, authenticated, service_role to postgres;

create schema if not exists auth authorization postgres;
grant usage on schema auth to anon, authenticated, service_role;

create table if not exists auth.users (
  id                 uuid primary key default gen_random_uuid(),
  aud                text default 'authenticated',
  role               text default 'authenticated',
  email              text unique,
  encrypted_password text,
  email_confirmed_at timestamptz,
  raw_user_meta_data jsonb default '{}'::jsonb,
  raw_app_meta_data  jsonb default '{}'::jsonb,
  created_at         timestamptz default now(),
  updated_at         timestamptz default now()
);

-- The three helpers every Supabase policy is written against.
create or replace function auth.jwt() returns jsonb
language sql stable as $fn$
  select coalesce(
    nullif(current_setting('request.jwt.claim', true), ''),
    nullif(current_setting('request.jwt.claims', true), ''),
    '{}'
  )::jsonb;
$fn$;

create or replace function auth.uid() returns uuid
language sql stable as $fn$
  select nullif(auth.jwt() ->> 'sub', '')::uuid;
$fn$;

create or replace function auth.role() returns text
language sql stable as $fn$
  select coalesce(nullif(auth.jwt() ->> 'role', ''), current_setting('role', true));
$fn$;

create or replace function auth.email() returns text
language sql stable as $fn$
  select nullif(auth.jwt() ->> 'email', '');
$fn$;

-- Storage stub: enough of storage.buckets / storage.objects for the storage
-- migration and its policies to apply and be exercised.
create schema if not exists storage authorization postgres;
grant usage on schema storage to anon, authenticated, service_role;

create table if not exists storage.buckets (
  id                 text primary key,
  name               text not null unique,
  owner              uuid,
  public             boolean default false,
  file_size_limit    bigint,
  allowed_mime_types text[],
  created_at         timestamptz default now(),
  updated_at         timestamptz default now()
);

create table if not exists storage.objects (
  id               uuid primary key default gen_random_uuid(),
  bucket_id        text references storage.buckets (id),
  name             text not null,
  owner            uuid,
  metadata         jsonb,
  path_tokens      text[] generated always as (string_to_array(name, '/')) stored,
  created_at       timestamptz default now(),
  updated_at       timestamptz default now(),
  last_accessed_at timestamptz default now()
);
alter table storage.objects enable row level security;
grant select on storage.buckets to anon, authenticated, service_role;
grant all on storage.objects to anon, authenticated, service_role;

create or replace function storage.foldername(name text) returns text[]
language sql immutable as $fn$
  select (string_to_array(name, '/'))[1 : array_length(string_to_array(name, '/'), 1) - 1];
$fn$;

create or replace function storage.filename(name text) returns text
language sql immutable as $fn$
  select (string_to_array(name, '/'))[array_length(string_to_array(name, '/'), 1)];
$fn$;

-- Same shape as the real storage.extension(): everything after the last dot.
create or replace function storage.extension(name text) returns text
language sql immutable as $fn$
  select reverse(split_part(reverse(storage.filename(name)), '.', 1));
$fn$;

-- Supabase's default privileges for the API roles on the public schema.
grant usage on schema public to anon, authenticated, service_role;
alter default privileges in schema public grant all on sequences to anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
STUB
psql_file "$WORK/stub.sql"

echo "==> applying migrations"
for f in "$MIGRATIONS"/*.sql; do
  echo "    $(basename "$f")"
  psql_file "$f"
done

echo "==> applying seed"
psql_file "$SEED"

echo "==> seed summary"
run "$PGBIN/psql -h $SOCK -p $PORT -U postgres -X -d $DB -c \"
  select 'profiles' t, count(*) from public.profiles
  union all select 'incidents', count(*) from public.incidents
  union all select 'approved', count(*) from public.incidents where moderation_status = 'approved'
  union all select 'photos', count(*) from public.incident_photos
  union all select 'comments', count(*) from public.comments
  union all select 'reports', count(*) from public.reports
  union all select 'appeals', count(*) from public.appeals
  union all select 'redemptions', count(*) from public.redemptions
  union all select 'audit', count(*) from public.moderation_actions
  union all select 'notifications', count(*) from public.notifications
  union all select 'notices', count(*) from public.printable_notices
  union all select 'badges', count(*) from public.user_badges
  order by 1;\""

echo "==> running rls.test.sql"
set +e
run "$PGBIN/psql -h $SOCK -p $PORT -U postgres -X -q -v ON_ERROR_STOP=1 -d $DB -f '$TESTS'"
STATUS=$?
set -e

if [ "$STATUS" != "0" ]; then
  echo "FAIL: rls.test.sql exited with status $STATUS"
  exit 1
fi
echo "All checks passed."
