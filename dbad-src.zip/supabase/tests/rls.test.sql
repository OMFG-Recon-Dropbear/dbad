-- ===========================================================================
-- DBAD — row level security and RPC behaviour tests
--
-- Run against a database that has had every migration and the seed applied:
--
--   ./supabase/tests/local-pg.sh                 (throwaway cluster, does both)
--   psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f supabase/tests/rls.test.sql
--
-- Each check prints PASS; the first failure raises and, with ON_ERROR_STOP,
-- takes the exit code with it. Every check runs inside its own transaction and
-- rolls back, so the seed is exactly as it was when the file finishes.
-- ===========================================================================
\set ON_ERROR_STOP on
\set QUIET on
set client_min_messages = notice;

-- ---------------------------------------------------------------------------
-- Test helpers.
-- ---------------------------------------------------------------------------
create or replace function public.dbad_assert(label text, cond boolean) returns void
language plpgsql as $$
begin
  if cond is not true then
    raise exception 'FAIL  %', label using errcode = 'assert_failure';
  end if;
  raise notice 'PASS  %', label;
end;
$$;

-- Asserts that a statement is refused, whether by a privilege, a policy check
-- or a trigger.
create or replace function public.dbad_denied(label text, stmt text) returns void
language plpgsql as $$
declare
  allowed boolean := false;
  why text := '';
begin
  begin
    execute stmt;
    allowed := true;
  exception when others then
    why := sqlerrm;
  end;
  if allowed then
    raise exception 'FAIL  % (the statement was allowed)', label using errcode = 'assert_failure';
  end if;
  raise notice 'PASS  %', label;
end;
$$;

grant execute on function public.dbad_assert(text, boolean) to public;
grant execute on function public.dbad_denied(text, text) to public;

-- Fixed ids from the seed.
--   jen   00000000-0000-4000-8000-000000000001  member, submitted DBAD-0042
--   dave  00000000-0000-4000-8000-000000000002  member
--   phil  00000000-0000-4000-8000-000000000004  member, submitted DBAD-0041
--   mick  00000000-0000-4000-8000-000000000005  member, submitted the pending one
--   sarah 00000000-0000-4000-8000-000000000011  moderator
--   hq    00000000-0000-4000-8000-000000000012  admin
--   footpath  20000000-0000-4000-8000-000000000001  approved, jen's
--   trolley   20000000-0000-4000-8000-000000000002  approved, phil's
--   moruya    20000000-0000-4000-8000-000000000010  approved, jen's, has a place
--   pending   20000000-0000-4000-8000-000000000030  pending, mick's

\echo '--- anonymous visitors ---'

begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"role":"anon"}', true); end $claims$;
  set local role anon;

  do $$
  begin
    perform public.dbad_assert('anon sees approved nominations',
      (select count(*) from public.incidents) >= 20);
    perform public.dbad_assert('anon sees no unapproved nomination',
      (select count(*) from public.incidents where moderation_status <> 'approved') = 0);
    perform public.dbad_assert('anon cannot see a pending nomination by id',
      (select count(*) from public.incidents where id = '20000000-0000-4000-8000-000000000030') = 0);
    perform public.dbad_assert('anon sees photos of approved nominations',
      (select count(*) from public.incident_photos) > 0);
    perform public.dbad_assert('anon sees visible comments only',
      (select count(*) from public.comments where status <> 'visible') = 0);
    perform public.dbad_assert('anon sees redemptions on approved nominations',
      (select count(*) from public.redemptions) = 4);
    perform public.dbad_assert('anon sees public profiles',
      (select count(*) from public.profiles) = 12);
    perform public.dbad_assert('anon sees categories and badges',
      (select count(*) from public.categories) = 9 and (select count(*) from public.badges) = 6);
    perform public.dbad_assert('anon sees printable notices',
      (select count(*) from public.printable_notices) = 2);
  end;
  $$;

  do $$
  begin
    perform public.dbad_denied('anon cannot read appeals', 'select * from public.appeals');
    perform public.dbad_denied('anon cannot read reports', 'select * from public.reports');
    perform public.dbad_denied('anon cannot read the audit log', 'select * from public.moderation_actions');
    perform public.dbad_denied('anon cannot read notifications', 'select * from public.notifications');
    perform public.dbad_denied('anon cannot read votes', 'select * from public.votes');
    perform public.dbad_denied('anon cannot write a nomination directly',
      'update public.incidents set title = ''nope'' where moderation_status = ''approved''');
  end;
  $$;

  -- The published right of reply is public even though the appeal is not.
  do $$
  begin
    perform public.dbad_assert('anon reads the published right of reply, not the appeal',
      (select count(*) from public.appeal_replies) = 1);
    perform public.dbad_assert('the right-of-reply view exposes no private column',
      (select count(*) from information_schema.columns
        where table_schema = 'public' and table_name = 'appeal_replies'
          and column_name in ('contact', 'message', 'status')) = 0);
  end;
  $$;

  -- Anonymous reporting and appealing: allowed to write, never to read.
  do $$
  declare res jsonb;
  begin
    res := public.report_content(jsonb_build_object(
      'targetType', 'incident', 'targetId', '20000000-0000-4000-8000-000000000001',
      'reason', 'identifies_person', 'details', 'Anonymous test report.'));
    perform public.dbad_assert('anon can report content', (res ->> 'ok')::boolean);

    res := public.submit_appeal(jsonb_build_object(
      'incidentId', '20000000-0000-4000-8000-000000000001', 'requestedAction', 'context',
      'message', 'That was my car and I have moved it since, please add that context.',
      'contact', 'someone@example.com'));
    perform public.dbad_assert('anon can submit an appeal', (res ->> 'ok')::boolean);
    perform public.dbad_assert('the appeal comes back with a reference',
      char_length(res ->> 'reference') = 8);

    perform public.dbad_denied('anon still cannot read the appeal it just filed',
      'select * from public.appeals');
    perform public.dbad_denied('anon still cannot read the report it just filed',
      'select * from public.reports');
  end;
  $$;

  -- Direct inserts, not just the RPCs.
  do $$
  begin
    insert into public.reports (target_type, target_id, reason, details)
    values ('incident', '20000000-0000-4000-8000-000000000001', 'spam', 'Direct anonymous insert.');
    perform public.dbad_assert('anon can insert a report row directly', true);

    insert into public.appeals (incident_id, requested_action, message)
    values ('20000000-0000-4000-8000-000000000001', 'removal', 'Please take this down, it is about my vehicle.');
    perform public.dbad_assert('anon can insert an appeal row directly', true);
  end;
  $$;

  do $$
  begin
    perform public.dbad_assert('anon can read the map clusters',
      (select count(*) from public.map_clusters()) > 3);
    perform public.dbad_assert('anon can read profile stats',
      (public.profile_stats('00000000-0000-4000-8000-000000000001') ->> 'spotted')::int = 4);
  end;
  $$;
rollback;

\echo '--- members ---'

begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-000000000001","role":"authenticated"}', true); end $claims$;
  set local role authenticated;

  do $$
  begin
    perform public.dbad_assert('a member reads only their own notifications',
      (select count(*) from public.notifications where user_id <> '00000000-0000-4000-8000-000000000001') = 0);
    perform public.dbad_assert('a member cannot see another member''s notification',
      (select count(*) from public.notifications
        where user_id = '00000000-0000-4000-8000-000000000004') = 0);
    perform public.dbad_assert('a member does see their own notifications',
      (select count(*) from public.notifications) = 4);
    perform public.dbad_assert('a member cannot read appeals',
      (select count(*) from public.appeals) = 0);
    perform public.dbad_assert('a member cannot read reports',
      (select count(*) from public.reports) = 0);
    perform public.dbad_assert('a member cannot read the audit log',
      (select count(*) from public.moderation_actions) = 0);
  end;
  $$;

  -- Roles are not something you give yourself.
  do $$
  begin
    perform public.dbad_denied('a member cannot promote themselves',
      'update public.profiles set role = ''admin'' where id = ''00000000-0000-4000-8000-000000000001''');
    perform public.dbad_assert('the member is still a member',
      (select role from public.profiles where id = '00000000-0000-4000-8000-000000000001') = 'member');
    -- Another member's row is simply not there to update.
    update public.profiles set role = 'moderator' where id = '00000000-0000-4000-8000-000000000002';
    perform public.dbad_assert('a member cannot promote anyone else either',
      (select role from public.profiles where id = '00000000-0000-4000-8000-000000000002') = 'member');
    update public.profiles set display_name = 'Hacked' where id = '00000000-0000-4000-8000-000000000002';
    perform public.dbad_assert('a member cannot edit another member''s profile',
      (select display_name from public.profiles where id = '00000000-0000-4000-8000-000000000002') = 'Dave');
  end;
  $$;

  -- Voting.
  do $$
  declare res jsonb; before_definitely int; after_definitely int;
  begin
    res := public.cast_vote('20000000-0000-4000-8000-000000000001', 'absolute');
    perform public.dbad_assert('a member cannot vote on their own nomination',
      (res ->> 'ok')::boolean is false
      and res ->> 'message' = 'You can''t vote on your own nomination. Nice try.');

    perform public.dbad_denied('nor by writing the votes table directly',
      'insert into public.votes (incident_id, user_id, verdict)
       values (''20000000-0000-4000-8000-000000000001'', ''00000000-0000-4000-8000-000000000001'', ''absolute'')');

    select votes_definitely into before_definitely from public.incidents
      where id = '20000000-0000-4000-8000-000000000002';
    res := public.cast_vote('20000000-0000-4000-8000-000000000002', 'definitely');
    select votes_definitely into after_definitely from public.incidents
      where id = '20000000-0000-4000-8000-000000000002';

    perform public.dbad_assert('a member can vote on someone else''s nomination',
      (res ->> 'ok')::boolean and res ->> 'viewerVote' = 'definitely');
    perform public.dbad_assert('the tally moves by exactly one',
      after_definitely = before_definitely + 1
      and (res -> 'votes' ->> 'definitely')::int = after_definitely);

    -- Changing your mind moves the tally across, it does not add a second vote.
    res := public.cast_vote('20000000-0000-4000-8000-000000000002', 'bit');
    perform public.dbad_assert('changing a verdict moves the tally instead of adding one',
      (res -> 'votes' ->> 'definitely')::int = before_definitely
      and (select count(*) from public.votes
            where incident_id = '20000000-0000-4000-8000-000000000002'
              and user_id = '00000000-0000-4000-8000-000000000001') = 1);

    perform public.dbad_denied('a member cannot vote as somebody else',
      'insert into public.votes (incident_id, user_id, verdict)
       values (''20000000-0000-4000-8000-000000000002'', ''00000000-0000-4000-8000-000000000002'', ''not'')');
  end;
  $$;

  -- Reactions.
  do $$
  declare res jsonb;
  begin
    res := public.toggle_reaction('20000000-0000-4000-8000-000000000002', 'fair_call');
    perform public.dbad_assert('a member can react',
      (res ->> 'ok')::boolean and (res -> 'reactions' ->> 'fair_call')::int = 42);
    res := public.toggle_reaction('20000000-0000-4000-8000-000000000002', 'fair_call');
    perform public.dbad_assert('reacting again takes it back',
      (res -> 'reactions' ->> 'fair_call')::int = 41);
  end;
  $$;

  -- Comments, and the PII backstop.
  do $$
  declare res jsonb; held record;
  begin
    res := public.add_comment('20000000-0000-4000-8000-000000000002', 'Twenty metres. The bay is right there.');
    perform public.dbad_assert('a member can comment on an approved nomination',
      (res ->> 'ok')::boolean and res -> 'comment' ->> 'status' = 'visible');
    perform public.dbad_assert('the comment count follows',
      (select comment_count from public.incidents where id = '20000000-0000-4000-8000-000000000002') = 3);

    perform public.dbad_denied('the PII trigger rejects a comment carrying a phone number',
      'insert into public.comments (incident_id, author_id, body)
       values (''20000000-0000-4000-8000-000000000002'', ''00000000-0000-4000-8000-000000000001'',
               ''His number is 0412 345 678 if you want a word'')');

    perform public.dbad_denied('the PII trigger rejects a comment carrying an email address',
      'insert into public.comments (incident_id, author_id, body)
       values (''20000000-0000-4000-8000-000000000002'', ''00000000-0000-4000-8000-000000000001'',
               ''email him on parker@example.com'')');

    -- The RPC scrubs first, then holds the comment for a moderator.
    res := public.add_comment('20000000-0000-4000-8000-000000000002', 'His number is 0412 345 678 if you want a word');
    perform public.dbad_assert('add_comment holds an identifying comment instead of publishing it',
      (res ->> 'ok')::boolean is false
      and res ->> 'message' like 'That comment looked like it identified someone%');
    select c.status, c.body into held from public.comments c
      where c.author_id = '00000000-0000-4000-8000-000000000001'
        and c.body like '%[phone removed]%' order by c.created_at desc limit 1;
    perform public.dbad_assert('the held comment is hidden and the number is gone',
      held.status = 'hidden' and held.body not like '%0412%');
    perform public.dbad_assert('a member still cannot see the report it triggered',
      (select count(*) from public.reports) = 0);
    perform public.dbad_assert('a held comment does not move the comment count',
      (select comment_count from public.incidents where id = '20000000-0000-4000-8000-000000000002') = 3);
  end;
  $$;

  do $$
  begin
    perform public.dbad_denied('a member cannot comment on a pending nomination',
      'insert into public.comments (incident_id, author_id, body)
       values (''20000000-0000-4000-8000-000000000030'', ''00000000-0000-4000-8000-000000000001'', ''Not public yet.'')');
    perform public.dbad_denied('a member cannot edit a nomination',
      'update public.incidents set title = ''mine now'' where id = ''20000000-0000-4000-8000-000000000001''');
    perform public.dbad_denied('a member cannot delete a nomination',
      'delete from public.incidents where id = ''20000000-0000-4000-8000-000000000001''');
    perform public.dbad_assert('a member is refused the admin dashboard',
      (public.admin_stats() ->> 'ok')::boolean is false);
    perform public.dbad_assert('a member is refused moderation',
      (public.moderate('{"action":"approve","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000030"}'::jsonb) ->> 'message')
        = 'Moderators only.');
  end;
  $$;
rollback;

\echo '--- what an auto-held comment leaves behind ---'

-- Same viewer, but without dropping to the authenticated role, so the whole
-- effect of the RPC is visible rather than just the member's slice of it.
begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-000000000001","role":"authenticated"}', true); end $claims$;
  do $$
  declare res jsonb;
  begin
    res := public.add_comment('20000000-0000-4000-8000-000000000002',
      'Ring the owner on 0412 345 678, he parked it');
    perform public.dbad_assert('the comment is held, not published',
      (res ->> 'ok')::boolean is false);
    perform public.dbad_assert('holding a comment files a report for a moderator',
      (select count(*) from public.reports r
        where r.reason = 'identifies_person' and r.status = 'open'
          and r.details = 'Auto-held: comment contained identifying details.') = 1);
    perform public.dbad_assert('the held comment is stored scrubbed',
      (select count(*) from public.comments c
        where c.status = 'hidden' and c.body like '%[phone removed]%' and c.body not like '%0412%') = 1);
  end;
  $$;
rollback;

\echo '--- submitters see their own work in progress ---'

begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-000000000005","role":"authenticated"}', true); end $claims$;
  set local role authenticated;
  do $$
  begin
    perform public.dbad_assert('the submitter can see their own pending nomination',
      (select count(*) from public.incidents where id = '20000000-0000-4000-8000-000000000030') = 1);
    perform public.dbad_assert('but still not somebody else''s',
      (select count(*) from public.incidents where id = '20000000-0000-4000-8000-000000000031') = 0);
  end;
  $$;
rollback;

\echo '--- nominating ---'

begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"role":"anon"}', true); end $claims$;
  set local role anon;
  do $$
  declare res jsonb; inc public.incidents%rowtype;
  begin
    res := public.submit_nomination(jsonb_build_object(
      'kind', 'dick_move', 'categoryId', 'shopping',
      'dickMove', 'Leaving a trolley in the disabled bay.',
      'title', 'A trolley, parked with more care than most cars.',
      'description', 'Trolley left in the accessible bay at the shops while the return bay sat empty ten metres away.',
      'affected', jsonb_build_array('wheelchair_users', 'the_community'),
      'location', jsonb_build_object('suburb', 'Batehaven', 'state', 'NSW', 'place', 'Beach Road shops'),
      'occurredOn', to_char(current_date, 'YYYY-MM-DD'), 'partOfDay', 'morning',
      'photos', '[]'::jsonb, 'acceptedStandard', true, 'reviewedRedaction', true));
    perform public.dbad_assert('an anonymous visitor can nominate', (res ->> 'ok')::boolean);
    select * into inc from public.incidents where id = (res ->> 'id')::uuid;
    perform public.dbad_assert('a photo-less nomination goes straight up',
      inc.moderation_status = 'approved' and res ->> 'moderation_status' = 'approved');
    perform public.dbad_assert('an anonymous nomination has no submitter',
      inc.submitter_id is null and inc.anonymised);
    perform public.dbad_assert('the short code and slug are generated',
      res ->> 'short_code' = 'DBAD-0045'
      and inc.slug = 'leaving-a-trolley-in-the-disabled-bay-batehaven-0045');
    perform public.dbad_assert('the region is guessed for the map',
      (select l.region from public.locations l where l.id = inc.location_id) = 'South Coast NSW');
    perform public.dbad_assert('a printable notice is created with it',
      (select count(*) from public.printable_notices n where n.id = (res ->> 'notice_id')::uuid) = 1);

    res := public.submit_nomination(jsonb_build_object(
      'kind', 'dick_move', 'categoryId', 'shopping', 'dickMove', 'x', 'title', 'y', 'description', 'z',
      'affected', '[]'::jsonb,
      'location', jsonb_build_object('suburb', 'Q', 'state', 'ZZZ'),
      'occurredOn', 'tomorrow', 'partOfDay', 'morning', 'photos', '[]'::jsonb,
      'acceptedStandard', false, 'reviewedRedaction', false));
    perform public.dbad_assert('a bad nomination comes back with field errors',
      (res ->> 'ok')::boolean is false
      and res -> 'fieldErrors' ? 'dickMove' and res -> 'fieldErrors' ? 'state'
      and res -> 'fieldErrors' ? 'occurredOn' and res -> 'fieldErrors' ? 'acceptedStandard');
  end;
  $$;
rollback;

\echo '--- moderators ---'

begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-000000000011","role":"authenticated"}', true); end $claims$;
  set local role authenticated;

  do $$
  begin
    perform public.dbad_assert('a moderator sees every nomination',
      (select count(*) from public.incidents where moderation_status = 'pending') = 2);
    perform public.dbad_assert('a moderator reads reports and appeals',
      (select count(*) from public.reports) = 4 and (select count(*) from public.appeals) = 2);
    perform public.dbad_assert('a moderator reads the audit log',
      (select count(*) from public.moderation_actions) = 10);
    perform public.dbad_assert('a moderator sees held comments',
      (select count(*) from public.comments where status = 'hidden') = 1);
    perform public.dbad_assert('a moderator gets the dashboard',
      (public.admin_stats() ->> 'pendingModeration')::int = 2);
  end;
  $$;
rollback;

\echo '--- what moderation does ---'

-- Moderator claims without the role switch, so the notifications and audit rows
-- moderate() writes for other people are visible to the assertions.
begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-000000000011","role":"authenticated"}', true); end $claims$;

  -- approve
  do $$
  declare res jsonb; inc public.incidents%rowtype;
  begin
    res := public.moderate(jsonb_build_object(
      'action', 'approve', 'targetType', 'incident',
      'targetId', '20000000-0000-4000-8000-000000000030', 'note', 'Photo is clean.'));
    perform public.dbad_assert('a moderator can approve', (res ->> 'ok')::boolean);
    select * into inc from public.incidents where id = '20000000-0000-4000-8000-000000000030';
    perform public.dbad_assert('approving publishes the nomination', inc.moderation_status = 'approved');
    perform public.dbad_assert('approving writes an audit row',
      (select count(*) from public.moderation_actions a
        where a.action = 'approve' and a.target_id = '20000000-0000-4000-8000-000000000030'
          and a.actor_id = '00000000-0000-4000-8000-000000000011') = 1);
    perform public.dbad_assert('approving notifies the submitter',
      (select count(*) from public.notifications n
        where n.user_id = inc.submitter_id and n.kind = 'moderation'
          and n.title = 'Nomination approved') = 1);
  end;
  $$;

  -- anonymise
  do $$
  declare res jsonb; inc public.incidents%rowtype; loc public.locations%rowtype;
  begin
    res := public.moderate(jsonb_build_object(
      'action', 'anonymise', 'targetType', 'incident',
      'targetId', '20000000-0000-4000-8000-000000000010', 'note', 'Submitter asked.'));
    perform public.dbad_assert('a moderator can anonymise', (res ->> 'ok')::boolean);
    select * into inc from public.incidents where id = '20000000-0000-4000-8000-000000000010';
    select * into loc from public.locations where id = inc.location_id;
    perform public.dbad_assert('anonymising detaches the submitter',
      inc.submitter_id is null and inc.anonymised);
    perform public.dbad_assert('anonymising drops back to the suburb',
      loc.place is null and loc.precision = 'suburb' and loc.suburb = 'Moruya');
    perform public.dbad_assert('anonymising is on the record',
      (select count(*) from public.moderation_actions a
        where a.action = 'anonymise' and a.target_id = '20000000-0000-4000-8000-000000000010') = 1);
  end;
  $$;

  -- the rest of the moderation vocabulary
  do $$
  declare res jsonb;
  begin
    perform public.moderate('{"action":"reject","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000031","note":"Too close to the driver."}'::jsonb);
    perform public.dbad_assert('reject',
      (select moderation_status from public.incidents where id = '20000000-0000-4000-8000-000000000031') = 'rejected');

    perform public.moderate('{"action":"remove","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000002"}'::jsonb);
    perform public.dbad_assert('remove',
      (select moderation_status from public.incidents where id = '20000000-0000-4000-8000-000000000002') = 'removed');
    perform public.moderate('{"action":"restore","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000002"}'::jsonb);
    perform public.dbad_assert('restore puts it back',
      (select moderation_status from public.incidents where id = '20000000-0000-4000-8000-000000000002') = 'approved');

    perform public.moderate('{"action":"redact_photo","targetType":"photo","targetId":"20000000-0000-4000-8000-000000000001","payload":{"photoId":"30000000-0000-4000-8000-000000000001"}}'::jsonb);
    perform public.dbad_assert('redact_photo removes the photo',
      (select count(*) from public.incident_photos where id = '30000000-0000-4000-8000-000000000001') = 0);

    perform public.moderate('{"action":"mark_redeemed","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000005","payload":{"note":"Bag binned, fence clear."}}'::jsonb);
    perform public.dbad_assert('mark_redeemed records the redemption',
      (select status from public.incidents where id = '20000000-0000-4000-8000-000000000005') = 'redeemed'
      and (select confirmed_by from public.redemptions where incident_id = '20000000-0000-4000-8000-000000000005') = 'moderator');

    perform public.moderate('{"action":"mark_overruled","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000019"}'::jsonb);
    perform public.dbad_assert('mark_overruled',
      (select status from public.incidents where id = '20000000-0000-4000-8000-000000000019') = 'overruled');

    perform public.moderate('{"action":"feature_week","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000006"}'::jsonb);
    perform public.dbad_assert('feature_week moves the crown, it does not share it',
      (select count(*) from public.incidents where featured_week = public.week_of(now())) = 1
      and (select featured_week from public.incidents where id = '20000000-0000-4000-8000-000000000006') = public.week_of(now()));

    perform public.moderate('{"action":"unfeature","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000006"}'::jsonb);
    perform public.dbad_assert('unfeature',
      (select featured_week from public.incidents where id = '20000000-0000-4000-8000-000000000006') is null);

    perform public.moderate('{"action":"hide_comment","targetType":"comment","targetId":"40000000-0000-4000-8000-000000000003"}'::jsonb);
    perform public.dbad_assert('hide_comment hides it and drops the count',
      (select status from public.comments where id = '40000000-0000-4000-8000-000000000003') = 'hidden'
      and (select comment_count from public.incidents where id = '20000000-0000-4000-8000-000000000001') = 3);
    perform public.moderate('{"action":"restore_comment","targetType":"comment","targetId":"40000000-0000-4000-8000-000000000003"}'::jsonb);
    perform public.dbad_assert('restore_comment puts it back',
      (select comment_count from public.incidents where id = '20000000-0000-4000-8000-000000000001') = 4);

    perform public.moderate('{"action":"resolve_report","targetType":"report","targetId":"50000000-0000-4000-8000-000000000003"}'::jsonb);
    perform public.dbad_assert('resolve_report',
      (select status from public.reports where id = '50000000-0000-4000-8000-000000000003') = 'resolved');
    perform public.moderate('{"action":"dismiss_report","targetType":"report","targetId":"50000000-0000-4000-8000-000000000004"}'::jsonb);
    perform public.dbad_assert('dismiss_report',
      (select status from public.reports where id = '50000000-0000-4000-8000-000000000004') = 'dismissed');

    perform public.moderate('{"action":"action_appeal","targetType":"appeal","targetId":"60000000-0000-4000-8000-000000000002","payload":{"publicReply":"The club had marked the grass as overflow that morning. Fair enough."}}'::jsonb);
    perform public.dbad_assert('action_appeal publishes the right of reply',
      (select status from public.appeals where id = '60000000-0000-4000-8000-000000000002') = 'actioned'
      and (select count(*) from public.appeal_replies where id = '60000000-0000-4000-8000-000000000002') = 1);

    perform public.moderate('{"action":"decline_appeal","targetType":"appeal","targetId":"60000000-0000-4000-8000-000000000001"}'::jsonb);
    perform public.dbad_assert('decline_appeal',
      (select status from public.appeals where id = '60000000-0000-4000-8000-000000000001') = 'declined');

    perform public.moderate('{"action":"publish_reply","targetType":"appeal","targetId":"60000000-0000-4000-8000-000000000001","payload":{"publicReply":"Fair cop, sorted it the same day."}}'::jsonb);
    perform public.dbad_assert('publish_reply actions the appeal',
      (select status from public.appeals where id = '60000000-0000-4000-8000-000000000001') = 'actioned');

    perform public.moderate('{"action":"edit_category","targetType":"category","targetId":"parking","payload":{"short":"Parking bays"}}'::jsonb);
    perform public.dbad_assert('edit_category updates the copy',
      (select short from public.categories where id = 'parking') = 'Parking bays');

    res := public.moderate('{"action":"edit_template","targetType":"template","targetId":"official-warning","payload":{"headline":"YOU HAVE BEEN DBAD''D."}}'::jsonb);
    perform public.dbad_assert('edit_template is audited even though the copy lives in code',
      (res ->> 'ok')::boolean
      and (select count(*) from public.moderation_actions a
            where a.action = 'edit_template' and a.target_id = 'official-warning') = 1);

    perform public.dbad_assert('an unknown action is refused',
      (public.moderate('{"action":"launch_missiles","targetType":"incident","targetId":"20000000-0000-4000-8000-000000000001"}'::jsonb) ->> 'ok')::boolean is false);
    perform public.dbad_assert('a missing target is refused',
      (public.moderate('{"action":"approve","targetType":"incident","targetId":"20000000-0000-4000-8000-000000009999"}'::jsonb) ->> 'message') = 'Incident not found.');

    perform public.dbad_assert('a moderator cannot change roles',
      (public.moderate('{"action":"change_role","targetType":"user","targetId":"00000000-0000-4000-8000-000000000002","payload":{"role":"moderator"}}'::jsonb) ->> 'message') = 'Admins only.');
  end;
  $$;
rollback;

\echo '--- admins ---'

begin;
  do $claims$ begin perform set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-000000000012","role":"authenticated"}', true); end $claims$;
  set local role authenticated;
  do $$
  declare res jsonb;
  begin
    res := public.moderate('{"action":"change_role","targetType":"user","targetId":"00000000-0000-4000-8000-000000000002","payload":{"role":"moderator"}}'::jsonb);
    perform public.dbad_assert('an admin can change a role', (res ->> 'ok')::boolean
      and (select role from public.profiles where id = '00000000-0000-4000-8000-000000000002') = 'moderator');
    perform public.dbad_assert('the role change is on the record',
      (select count(*) from public.moderation_actions a
        where a.action = 'change_role' and a.target_id = '00000000-0000-4000-8000-000000000002') = 1);
    perform public.dbad_assert('an unknown role is refused',
      (public.moderate('{"action":"change_role","targetType":"user","targetId":"00000000-0000-4000-8000-000000000002","payload":{"role":"overlord"}}'::jsonb) ->> 'message') = 'Unknown role.');
    -- Even on their own row, and even as an admin, the column is off limits
    -- outside moderate(): the guard trigger does not care who you are.
    perform public.dbad_denied('not even an admin can patch the role column directly',
      'update public.profiles set role = ''member'' where id = ''00000000-0000-4000-8000-000000000012''');
    perform public.dbad_assert('the admin is still an admin',
      (select role from public.profiles where id = '00000000-0000-4000-8000-000000000012') = 'admin');
  end;
  $$;
rollback;

\echo '--- storage ---'

begin;
  -- Somebody else's object, put there before we drop role, to test both ends.
  insert into storage.objects (bucket_id, name, owner)
  values ('incident-photos', '00000000-0000-4000-8000-000000000003/theirs.jpg', '00000000-0000-4000-8000-000000000003');

  do $claims$ begin perform set_config('request.jwt.claims', '{"sub":"00000000-0000-4000-8000-000000000001","role":"authenticated"}', true); end $claims$;
  set local role authenticated;
  do $$
  begin
    insert into storage.objects (bucket_id, name, owner)
    values ('incident-photos', '00000000-0000-4000-8000-000000000001/evidence.jpg', '00000000-0000-4000-8000-000000000001');
    perform public.dbad_assert('a member can upload under their own folder', true);

    perform public.dbad_denied('a member cannot upload into someone else''s folder',
      'insert into storage.objects (bucket_id, name, owner)
       values (''incident-photos'', ''00000000-0000-4000-8000-000000000002/evidence.jpg'', ''00000000-0000-4000-8000-000000000001'')');

    perform public.dbad_denied('a member cannot upload to the bucket root',
      'insert into storage.objects (bucket_id, name, owner)
       values (''incident-photos'', ''evidence.jpg'', ''00000000-0000-4000-8000-000000000001'')');

    perform public.dbad_denied('only image extensions are accepted',
      'insert into storage.objects (bucket_id, name, owner)
       values (''incident-photos'', ''00000000-0000-4000-8000-000000000001/payload.exe'', ''00000000-0000-4000-8000-000000000001'')');

    perform public.dbad_denied('a member cannot upload to another bucket',
      'insert into storage.objects (bucket_id, name, owner)
       values (''secrets'', ''00000000-0000-4000-8000-000000000001/evidence.jpg'', ''00000000-0000-4000-8000-000000000001'')');

    -- Someone else's object is readable (the bucket is public) but untouchable.
    perform public.dbad_assert('a member can read someone else''s photo',
      (select count(*) from storage.objects
        where name = '00000000-0000-4000-8000-000000000003/theirs.jpg') = 1);

    delete from storage.objects where name = '00000000-0000-4000-8000-000000000003/theirs.jpg';
    perform public.dbad_assert('a member cannot delete someone else''s photo',
      (select count(*) from storage.objects
        where name = '00000000-0000-4000-8000-000000000003/theirs.jpg') = 1);

    update storage.objects set name = '00000000-0000-4000-8000-000000000001/stolen.jpg'
      where name = '00000000-0000-4000-8000-000000000003/theirs.jpg';
    perform public.dbad_assert('a member cannot move someone else''s photo into their folder',
      (select count(*) from storage.objects
        where name = '00000000-0000-4000-8000-000000000001/stolen.jpg') = 0);

    delete from storage.objects where name = '00000000-0000-4000-8000-000000000001/evidence.jpg';
    perform public.dbad_assert('a member can delete their own photo',
      (select count(*) from storage.objects
        where name = '00000000-0000-4000-8000-000000000001/evidence.jpg') = 0);
  end;
  $$;
rollback;

begin;
  insert into storage.objects (bucket_id, name, owner)
  values ('incident-photos', '00000000-0000-4000-8000-000000000003/theirs.jpg', '00000000-0000-4000-8000-000000000003');

  do $claims$ begin perform set_config('request.jwt.claims', '{"role":"anon"}', true); end $claims$;
  set local role anon;
  do $$
  begin
    perform public.dbad_assert('anon can read incident photos from storage',
      (select count(*) from storage.objects where bucket_id = 'incident-photos') = 1);
    perform public.dbad_denied('anon cannot upload anything',
      'insert into storage.objects (bucket_id, name) values (''incident-photos'', ''anon/evidence.jpg'')');
  end;
  $$;
rollback;

\echo '--- privacy invariants ---'

begin;
  do $$
  declare bad int;
  begin
    -- No published text anywhere carries a contact detail.
    select count(*) into bad from public.incidents
      where public.contains_contact_details(title, dick_move, description, coalesce(advice, ''));
    perform public.dbad_assert('no nomination text carries a contact detail', bad = 0);

    select count(*) into bad from public.comments where public.contains_contact_details(body);
    perform public.dbad_assert('no comment carries a contact detail', bad = 0);

    select count(*) into bad from public.printable_notices
      where public.contains_contact_details(headline, dick_move, why, location, advice);
    perform public.dbad_assert('no printable notice carries a contact detail', bad = 0);

    select count(*) into bad from public.locations
      where place ~* '^[0-9]{1,5}[a-z]?[ /-]';
    perform public.dbad_assert('no location looks like a street address', bad = 0);

    perform public.dbad_assert('every anonymised nomination has lost its submitter',
      (select count(*) from public.incidents where anonymised and submitter_id is not null) = 0);

    perform public.dbad_assert('coordinates stay inside Australia',
      (select count(*) from public.locations
        where (approx_lat is not null and approx_lat not between -44 and -10)
           or (approx_lng is not null and approx_lng not between 112 and 154)) = 0);

    perform public.dbad_assert('every table in public has row level security on',
      (select count(*) from pg_tables t
        where t.schemaname = 'public' and not t.rowsecurity) = 0);

    perform public.dbad_assert('the denormalised state and region match the location',
      (select count(*) from public.incidents i join public.locations l on l.id = i.location_id
        where i.state <> l.state or i.region <> l.region) = 0);

    perform public.dbad_assert('full-text search finds a nomination by its suburb',
      (select count(*) from public.incidents
        where search @@ websearch_to_tsquery('english', 'Batemans')) >= 2);

    perform public.dbad_assert('moving a location updates the nominations that point at it',
      (select count(*) from public.incidents i join public.locations l on l.id = i.location_id
        where i.state <> l.state) = 0);
  end;
  $$;
rollback;

\echo '--- badges ---'

begin;
  do $$
  declare res jsonb;
  begin
    delete from public.user_badges where user_id = '00000000-0000-4000-8000-000000000001';
    res := public.refresh_badges('00000000-0000-4000-8000-000000000001');
    perform public.dbad_assert('refresh_badges awards first_call and fair_dinkum, not eagle_eye',
      res -> 'awarded' ? 'first_call'
      and not (res -> 'awarded' ? 'eagle_eye')
      and (select count(*) from public.user_badges where user_id = '00000000-0000-4000-8000-000000000001') > 0);
    perform public.dbad_assert('refresh_badges is idempotent',
      (public.refresh_badges('00000000-0000-4000-8000-000000000001') -> 'awarded') = '[]'::jsonb);
  end;
  $$;
rollback;

drop function public.dbad_assert(text, boolean);
drop function public.dbad_denied(text, text);

\echo 'All DBAD checks passed.'
