/**
 * Generates the PWA/app icons from the wordmark geometry with sharp.
 *   bun run tools/brand/icons.ts
 */
import sharp from "sharp";
import { WORDMARK_CUTS, WORDMARK_HEIGHT, WORDMARK_PATHS, WORDMARK_WIDTH } from "../../src/components/brand/wordmark-geometry";

function iconSvg(size: number, opts: { maskable?: boolean; tape?: boolean }): string {
  const pad = opts.maskable ? 0.18 : 0.12;
  const inner = size * (1 - pad * 2);
  const scale = inner / WORDMARK_WIDTH;
  const wmH = WORDMARK_HEIGHT * scale;
  const x = size * pad;
  const y = (size - wmH) / 2;
  const cuts = WORDMARK_CUTS.map(([cx, cy, cw, ch]) => `<rect x="${cx}" y="${cy}" width="${cw}" height="${ch}" fill="black"/>`).join("");
  const tapeH = size * 0.09;
  const tape = opts.tape
    ? `<defs><pattern id="hz" width="${size * 0.12}" height="${size * 0.12}" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><rect width="${size * 0.06}" height="${size * 0.12}" fill="#0f0f0f"/><rect x="${size * 0.06}" width="${size * 0.06}" height="${size * 0.12}" fill="#f5c400"/></pattern></defs><rect width="${size}" height="${tapeH}" fill="url(#hz)"/><rect y="${size - tapeH}" width="${size}" height="${tapeH}" fill="url(#hz)"/>`
    : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect width="${size}" height="${size}" fill="#0f0f0f" rx="${opts.maskable ? 0 : size * 0.12}"/>
  ${tape}
  <mask id="m" maskUnits="userSpaceOnUse" x="0" y="0" width="${WORDMARK_WIDTH}" height="${WORDMARK_HEIGHT}"><rect width="${WORDMARK_WIDTH}" height="${WORDMARK_HEIGHT}" fill="white"/>${cuts}</mask>
  <g transform="translate(${x} ${y}) scale(${scale})" fill="#f5c400" mask="url(#m)">${WORDMARK_PATHS.map((d) => `<path d="${d}"/>`).join("")}</g>
</svg>`;
}

const out = new URL("../../public/icons/", import.meta.url).pathname;
await Bun.write(`${out}icon.svg`, iconSvg(512, { tape: true }));
for (const [name, size, opts] of [
  ["icon-192.png", 192, { tape: true }],
  ["icon-512.png", 512, { tape: true }],
  ["icon-512-maskable.png", 512, { maskable: true, tape: true }],
  ["apple-touch-icon.png", 180, { tape: true }],
] as const) {
  await sharp(Buffer.from(iconSvg(size, opts))).png().toFile(`${out}${name}`);
  console.log("wrote", name);
}
const fav = await sharp(Buffer.from(iconSvg(64, {}))).resize(32, 32).png().toBuffer();
// Minimal ICO container with a single PNG entry
const header = Buffer.alloc(6 + 16);
header.writeUInt16LE(0, 0); header.writeUInt16LE(1, 2); header.writeUInt16LE(1, 4);
header.writeUInt8(32, 6); header.writeUInt8(32, 7); header.writeUInt8(0, 8); header.writeUInt8(0, 9);
header.writeUInt16LE(1, 10); header.writeUInt16LE(32, 12); header.writeUInt32LE(fav.length, 14); header.writeUInt32LE(22, 18);
await Bun.write(new URL("../../public/favicon.ico", import.meta.url).pathname, Buffer.concat([header, fav]));
console.log("wrote favicon.ico");
