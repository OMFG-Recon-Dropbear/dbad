#!/usr/bin/env bun
/**
 * DBAD — seed "evidence photo" illustration generator.
 *
 *   cd /home/claude/dbad && bun run tools/illustrations/generate.ts
 *
 * Composes flat-vector scenes as SVG from a small reusable primitive library and
 * rasterises them with sharp to public/seed/<key>.jpg (1200x900, q82, progressive).
 * Also writes public/seed/contact-sheet.png for at-a-glance review.
 *
 * House rules baked in:
 *  - no readable text anywhere in a scene (blank signage, pictograms only)
 *  - every number plate is a pixelated grey mosaic (plates are redacted)
 *  - people are faceless silhouettes / seen from behind / cropped
 *  - every image gets vignette + film grain + a scrubbed metadata strip
 *  - deterministic: all randomness is seeded per scene key
 */

import sharp from "sharp";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";

const W = 1200;
const H = 900;
const OUT_DIR = path.resolve(import.meta.dir, "../../public/seed");

/* ------------------------------------------------------------------ *
 * utilities
 * ------------------------------------------------------------------ */

/** deterministic 32-bit hash of a string -> seed */
function hashSeed(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

/** mulberry32 PRNG */
function rng(seed: number) {
  let a = seed >>> 0;
  const next = () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    next,
    /** float in [lo,hi) */
    f: (lo: number, hi: number) => lo + next() * (hi - lo),
    /** int in [lo,hi] */
    i: (lo: number, hi: number) => Math.floor(lo + next() * (hi - lo + 1)),
    pick: <T,>(arr: readonly T[]): T => arr[Math.floor(next() * arr.length)]!,
  };
}
type Rng = ReturnType<typeof rng>;

const n = (v: number) => Math.round(v * 100) / 100;

/* colour helpers -------------------------------------------------- */

function hexToRgb(h: string): [number, number, number] {
  const s = h.replace("#", "");
  const v =
    s.length === 3
      ? s
          .split("")
          .map((c) => c + c)
          .join("")
      : s;
  return [
    parseInt(v.slice(0, 2), 16),
    parseInt(v.slice(2, 4), 16),
    parseInt(v.slice(4, 6), 16),
  ];
}
function rgbToHex(r: number, g: number, b: number): string {
  const c = (x: number) =>
    Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, "0");
  return `#${c(r)}${c(g)}${c(b)}`;
}
/** mix two hex colours, t=0 -> a, t=1 -> b */
function mix(a: string, b: string, t: number): string {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  return rgbToHex(r1 + (r2 - r1) * t, g1 + (g2 - g1) * t, b1 + (b2 - b1) * t);
}
const lighten = (c: string, t: number) => mix(c, "#ffffff", t);
const darken = (c: string, t: number) => mix(c, "#000000", t);

/* geometry helpers ------------------------------------------------ */

type Pt = [number, number] | [number, number, number]; // x, y, optional corner radius

/**
 * Rounded polygon path. Each vertex may carry its own radius (3rd element),
 * otherwise `r` is used. Corners are cut back along both edges and joined with
 * a quadratic through the original vertex.
 */
function rp(pts: Pt[], r = 4, close = true): string {
  const N = pts.length;
  if (N < 3) return "";
  let d = "";
  for (let i = 0; i < N; i++) {
    const p0 = pts[(i - 1 + N) % N]!;
    const p1 = pts[i]!;
    const p2 = pts[(i + 1) % N]!;
    const rr = p1[2] ?? r;
    const d1x = p0[0] - p1[0];
    const d1y = p0[1] - p1[1];
    const d2x = p2[0] - p1[0];
    const d2y = p2[1] - p1[1];
    const l1 = Math.hypot(d1x, d1y) || 1;
    const l2 = Math.hypot(d2x, d2y) || 1;
    const cut = Math.min(rr, l1 / 2, l2 / 2);
    const ax = p1[0] + (d1x / l1) * cut;
    const ay = p1[1] + (d1y / l1) * cut;
    const bx = p1[0] + (d2x / l2) * cut;
    const by = p1[1] + (d2y / l2) * cut;
    d += i === 0 ? `M${n(ax)} ${n(ay)}` : `L${n(ax)} ${n(ay)}`;
    if (cut > 0.01) d += `Q${n(p1[0])} ${n(p1[1])} ${n(bx)} ${n(by)}`;
  }
  return d + (close ? "Z" : "");
}

/** plain polygon */
function poly(pts: number[][]): string {
  return pts.map((p) => `${n(p[0]!)},${n(p[1]!)}`).join(" ");
}

/** group with transform */
function g(
  body: string,
  o: { x?: number; y?: number; s?: number; sy?: number; rot?: number; flip?: boolean; op?: number } = {},
): string {
  const t: string[] = [];
  if (o.x || o.y) t.push(`translate(${n(o.x ?? 0)},${n(o.y ?? 0)})`);
  if (o.rot) t.push(`rotate(${n(o.rot)})`);
  const sx = (o.s ?? 1) * (o.flip ? -1 : 1);
  const sy = o.sy ?? o.s ?? 1;
  if (sx !== 1 || sy !== 1) t.push(`scale(${n(sx)},${n(sy)})`);
  const op = o.op !== undefined && o.op !== 1 ? ` opacity="${o.op}"` : "";
  return `<g transform="${t.join(" ")}"${op}>${body}</g>`;
}

/** point moved toward a vanishing point by factor t (0 = near, 1 = at vp) */
function vp(x: number, y: number, vx: number, vy: number, t: number): [number, number] {
  return [x + (vx - x) * t, y + (vy - y) * t];
}

/* ------------------------------------------------------------------ *
 * palette
 * ------------------------------------------------------------------ */

const C = {
  ink: "#0f0f0f",
  asphalt: "#3a3a3a",
  asphaltLight: "#4a4a48",
  concrete: "#d9d5c8",
  concreteDark: "#c9c4b4",
  kerb: "#b8b3a3",
  paint: "#f4efe2",
  skyTop: "#cfe3ee",
  skyLow: "#eef3ef",
  warm: "#f7d9a8",
  euc: "#5f7d5a",
  eucMid: "#7c9a6d",
  eucLight: "#9bb18a",
  dryGrass: "#c9b982",
  sand: "#e8dcbf",
  sea: "#4f8fa8",
  yellow: "#f5c400",
  red: "#d7263d",
  steel: "#9aa0a2",
  steelDark: "#6f7679",
  timber: "#a98a63",
  timberDark: "#7e6444",
  binGreen: "#2f4a34",
  brick: "#b08a72",
} as const;

/* ------------------------------------------------------------------ *
 * photo treatment — vignette, grain, scrubbed metadata strip
 * ------------------------------------------------------------------ */

function treatmentDefs(seed: number): string {
  return `
<radialGradient id="vig" cx="50%" cy="47%" r="72%">
  <stop offset="55%" stop-color="#000000" stop-opacity="0"/>
  <stop offset="82%" stop-color="#04070a" stop-opacity="0.09"/>
  <stop offset="100%" stop-color="#04070a" stop-opacity="0.30"/>
</radialGradient>
<filter id="grain" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">
  <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" seed="${seed % 9973}" result="n"/>
  <feColorMatrix type="saturate" values="0"/>
</filter>`;
}

/** vignette + grain + evidence strip, drawn last over everything */
function treatment(): string {
  const stripX = 30;
  const stripY = H - 78;
  const bars = [
    [104, 0],
    [70, 13],
    [128, 26],
  ];
  return `
<rect width="${W}" height="${H}" fill="url(#vig)"/>
<rect width="${W}" height="${H}" filter="url(#grain)" opacity="0.058" style="mix-blend-mode:multiply"/>
<rect width="${W}" height="${H}" filter="url(#grain)" opacity="0.035"/>
<g opacity="0.62">
  <rect x="${stripX}" y="${stripY}" width="198" height="52" rx="9" fill="#0b0b0c"/>
</g>
<g opacity="0.5">
  ${bars
    .map(
      ([w, dy]) =>
        `<rect x="${stripX + 14}" y="${stripY + 10 + dy!}" width="${w}" height="6" rx="3" fill="#d8d8d4"/>`,
    )
    .join("")}
</g>`;
}

/* ------------------------------------------------------------------ *
 * environment primitives
 * ------------------------------------------------------------------ */

type SkyVariant = "day" | "warm" | "sunset" | "overcast" | "rain" | "bright";

function skyDefs(v: SkyVariant): string {
  const stops: Record<SkyVariant, string> = {
    day: `<stop offset="0" stop-color="#c3dbe9"/><stop offset="0.62" stop-color="#dbe9ea"/><stop offset="1" stop-color="#eef3ef"/>`,
    bright: `<stop offset="0" stop-color="#bcdcec"/><stop offset="0.55" stop-color="#dcecec"/><stop offset="1" stop-color="#f4f1e4"/>`,
    warm: `<stop offset="0" stop-color="#c6dced"/><stop offset="0.55" stop-color="#e4ecdf"/><stop offset="1" stop-color="#f7d9a8"/>`,
    sunset: `<stop offset="0" stop-color="#6d87a8"/><stop offset="0.4" stop-color="#c99a86"/><stop offset="0.72" stop-color="#f0b27a"/><stop offset="1" stop-color="#f7d9a8"/>`,
    overcast: `<stop offset="0" stop-color="#b9c6cb"/><stop offset="0.6" stop-color="#cfd8d8"/><stop offset="1" stop-color="#e2e6e2"/>`,
    rain: `<stop offset="0" stop-color="#9fb0b8"/><stop offset="0.6" stop-color="#bcc8ca"/><stop offset="1" stop-color="#d6dcd7"/>`,
  };
  return `<linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">${stops[v]}</linearGradient>`;
}

/** full-width sky. horizon = y of the ground line */
function sky(horizon: number, v: SkyVariant = "day", r?: Rng): string {
  let s = `<rect x="0" y="0" width="${W}" height="${n(horizon + 2)}" fill="url(#sky)"/>`;
  if (v === "sunset") {
    s += `<circle cx="880" cy="${n(horizon - 26)}" r="46" fill="#ffd9a0" opacity="0.85"/>`;
    s += `<circle cx="880" cy="${n(horizon - 26)}" r="96" fill="#ffcf90" opacity="0.18"/>`;
  } else if (v === "warm" || v === "bright") {
    s += `<circle cx="${v === "bright" ? 300 : 940}" cy="${n(horizon * 0.32)}" r="120" fill="#fff6e2" opacity="0.35"/>`;
  }
  // soft cloud bands: low, stretched, barely-there
  if (r && v !== "rain") {
    const cl = v === "sunset" ? "#f6d0aa" : "#ffffff";
    const op = v === "overcast" ? 0.26 : 0.34;
    for (let i = 0; i < 3; i++) {
      const cx = r.f(80, W - 80);
      const cy = r.f(46, Math.max(70, horizon * 0.55));
      const rx = r.f(110, 190);
      const ry = rx * r.f(0.055, 0.085);
      s += `<ellipse cx="${n(cx)}" cy="${n(cy)}" rx="${n(rx)}" ry="${n(ry)}" fill="${cl}" opacity="${n(op * r.f(0.5, 0.9))}"/>`;
      s += `<ellipse cx="${n(cx + rx * 0.26)}" cy="${n(cy - ry * 1.4)}" rx="${n(rx * 0.44)}" ry="${n(ry * 1.25)}" fill="${cl}" opacity="${n(op * r.f(0.4, 0.7))}"/>`;
      s += `<ellipse cx="${n(cx - rx * 0.4)}" cy="${n(cy + ry * 0.5)}" rx="${n(rx * 0.34)}" ry="${n(ry * 0.8)}" fill="${cl}" opacity="${n(op * r.f(0.3, 0.55))}"/>`;
    }
  }
  return s;
}

/** distant lumpy treeline sitting on the horizon */
function treeline(horizon: number, r: Rng, colour = "#84967e", height = 34): string {
  let d = `M-20 ${n(horizon + 4)} L-20 ${n(horizon - height * 0.5)}`;
  for (let x = -20; x <= W + 20; x += 26) {
    const h = horizon - height * r.f(0.35, 1.1);
    d += ` Q${n(x + 13)} ${n(h)} ${n(x + 26)} ${n(horizon - height * r.f(0.3, 0.8))}`;
  }
  d += ` L${W + 20} ${n(horizon + 4)} Z`;
  return `<path d="${d}" fill="${colour}" opacity="0.9"/>`;
}

/** flat ground band */
function band(y0: number, y1: number, fill: string, extra = ""): string {
  return `<rect x="-2" y="${n(y0)}" width="${W + 4}" height="${n(y1 - y0)}" fill="${fill}"/>${extra}`;
}

/** ground shading: subtle darkening toward the bottom of a surface */
function groundShade(y0: number, y1: number, id: string, strength = 0.16): string {
  return `<rect x="-2" y="${n(y0)}" width="${W + 4}" height="${n(y1 - y0)}" fill="url(#${id})" opacity="${strength}"/>`;
}

function shadeDefs(): string {
  return `
<linearGradient id="gsh" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#000000" stop-opacity="0"/>
  <stop offset="1" stop-color="#000000" stop-opacity="0.55"/>
</linearGradient>
<linearGradient id="gshUp" x1="0" y1="1" x2="0" y2="0">
  <stop offset="0" stop-color="#000000" stop-opacity="0"/>
  <stop offset="1" stop-color="#000000" stop-opacity="0.5"/>
</linearGradient>
<linearGradient id="glo" x1="0" y1="1" x2="0" y2="0">
  <stop offset="0" stop-color="#ffffff" stop-opacity="0"/>
  <stop offset="1" stop-color="#ffffff" stop-opacity="0.5"/>
</linearGradient>
<filter id="soft" x="-60%" y="-160%" width="220%" height="420%">
  <feGaussianBlur stdDeviation="5"/>
</filter>
<filter id="soft2" x="-40%" y="-40%" width="180%" height="180%">
  <feGaussianBlur stdDeviation="12"/>
</filter>`;
}

/** speckled asphalt texture (deterministic dots) */
function asphaltSpeckle(y0: number, y1: number, r: Rng, count = 220): string {
  let s = "";
  for (let i = 0; i < count; i++) {
    const y = r.f(y0, y1);
    const depth = (y - y0) / Math.max(1, y1 - y0);
    const rad = 0.7 + depth * 2.0;
    s += `<circle cx="${n(r.f(-10, W + 10))}" cy="${n(y)}" r="${n(rad)}" fill="${r.next() > 0.5 ? "#ffffff" : "#000000"}" opacity="${n(r.f(0.03, 0.09))}"/>`;
  }
  return s;
}

/**
 * Concrete footpath as a receding ground plane: slab joints converge on a
 * vanishing point and the cross joints compress with depth, so it reads as
 * ground rather than as a wall.
 */
function footpath(o: {
  yNear: number;
  yFar: number;
  vpx?: number;
  conv?: number;
  colour?: string;
  joints?: number;
}): string {
  const col = o.colour ?? C.concrete;
  const vx = o.vpx ?? 600;
  const conv = o.conv ?? 0.5;
  const jc = darken(col, 0.15);
  let b = band(o.yFar, o.yNear, col);
  b += `<rect x="-2" y="${n(o.yFar)}" width="${W + 4}" height="8" fill="${darken(col, 0.2)}"/>`;
  // longitudinal joints, converging
  for (let i = 0; i <= (o.joints ?? 8); i++) {
    const xn = -120 + i * ((W + 240) / (o.joints ?? 8));
    const xf = vx + (xn - vx) * conv;
    b += `<line x1="${n(xn)}" y1="${n(o.yNear)}" x2="${n(xf)}" y2="${n(o.yFar)}" stroke="${jc}" stroke-width="2.6" opacity="0.42"/>`;
  }
  // cross joints, compressing with depth
  for (const t of [0.26, 0.5, 0.7, 0.85, 0.95]) {
    const y = o.yNear + (o.yFar - o.yNear) * t;
    b += `<line x1="-2" y1="${n(y)}" x2="${W}" y2="${n(y)}" stroke="${jc}" stroke-width="${n(2.6 * (1 - t * 0.7))}" opacity="${n(0.42 * (1 - t * 0.5))}"/>`;
  }
  b += groundShade(o.yFar, o.yNear, "gshUp", 0.09);
  return b;
}

/** kerb seen edge-on: top face + vertical face */
function kerb(y: number, faceH = 16, topH = 9): string {
  return `
<rect x="-2" y="${n(y)}" width="${W + 4}" height="${n(topH)}" fill="${lighten(C.kerb, 0.12)}"/>
<rect x="-2" y="${n(y + topH)}" width="${W + 4}" height="${n(faceH)}" fill="${darken(C.kerb, 0.16)}"/>
<rect x="-2" y="${n(y + topH + faceH)}" width="${W + 4}" height="3" fill="${darken(C.kerb, 0.42)}" opacity="0.5"/>`;
}

/**
 * Painted parking-bay dividers converging on a vanishing point.
 * xs are the near-edge centre positions.
 */
function parkingBays(o: {
  xs: number[];
  yNear: number;
  t: number;
  vpx: number;
  vpy: number;
  w?: number;
  colour?: string;
  opacity?: number;
  headLine?: boolean;
}): string {
  const wid = o.w ?? 11;
  const col = o.colour ?? C.paint;
  const op = o.opacity ?? 0.82;
  let s = "";
  const farPts: [number, number][] = [];
  for (const x of o.xs) {
    const a = vp(x - wid / 2, o.yNear, o.vpx, o.vpy, o.t);
    const b = vp(x + wid / 2, o.yNear, o.vpx, o.vpy, o.t);
    s += `<polygon points="${poly([
      [x - wid / 2, o.yNear],
      [x + wid / 2, o.yNear],
      [b[0], b[1]],
      [a[0], a[1]],
    ])}" fill="${col}" opacity="${op}"/>`;
    farPts.push([(a[0] + b[0]) / 2, a[1]]);
  }
  if (o.headLine && farPts.length > 1) {
    const l = farPts[0]!;
    const rr = farPts[farPts.length - 1]!;
    const hw = wid * (1 - o.t) * 0.55;
    s += `<polygon points="${poly([
      [l[0] - 6, l[1] - hw],
      [rr[0] + 6, rr[1] - hw],
      [rr[0] + 6, rr[1] + hw],
      [l[0] - 6, l[1] + hw],
    ])}" fill="${col}" opacity="${op * 0.9}"/>`;
  }
  return s;
}

/** dashed centre line down a road, receding */
function laneDashes(o: {
  xNear: number;
  yNear: number;
  vpx: number;
  vpy: number;
  segs?: number;
  colour?: string;
}): string {
  const segs = o.segs ?? 6;
  const col = o.colour ?? C.paint;
  let s = "";
  for (let i = 0; i < segs; i++) {
    const t0 = 1 - Math.pow(1 - i / segs, 1.9) * 0.94;
    const t1 = 1 - Math.pow(1 - (i + 0.52) / segs, 1.9) * 0.94;
    const w0 = 13 * (1 - t0);
    const w1 = 13 * (1 - t1);
    const a = vp(o.xNear, o.yNear, o.vpx, o.vpy, t0);
    const b = vp(o.xNear, o.yNear, o.vpx, o.vpy, t1);
    s += `<polygon points="${poly([
      [a[0] - w0, a[1]],
      [a[0] + w0, a[1]],
      [b[0] + w1, b[1]],
      [b[0] - w1, b[1]],
    ])}" fill="${col}" opacity="0.75"/>`;
  }
  return s;
}

/** simplified international wheelchair symbol painted flat on the ground */
function wheelchairPaint(o: {
  x: number;
  y: number;
  s: number;
  colour?: string;
  opacity?: number;
  squash?: number;
}): string {
  const col = o.colour ?? C.paint;
  const body = `
<circle cx="0" cy="-74" r="12.5" fill="${col}"/>
<path d="${rp(
    [
      [-9, -58],
      [4, -58],
      [8, -30],
      [30, -30],
      [30, -18],
      [-2, -18],
      [-11, -34],
    ],
    5,
  )}" fill="${col}"/>
<path d="M-26 -46 A 30 30 0 1 0 22 -4" fill="none" stroke="${col}" stroke-width="8" stroke-linecap="round"/>
<circle cx="-6" cy="-24" r="4.5" fill="${col}"/>
<path d="M20 -12 L34 -4 L22 -4 Z" fill="${col}"/>`;
  return g(body, { x: o.x, y: o.y, s: o.s, sy: o.s * (o.squash ?? 0.62), op: o.opacity ?? 0.8 });
}

/** simplified bicycle pictogram painted flat on the ground */
function bikePaint(o: { x: number; y: number; s: number; colour?: string; opacity?: number; squash?: number }): string {
  const col = o.colour ?? C.paint;
  const body = `
<circle cx="-30" cy="0" r="18" fill="none" stroke="${col}" stroke-width="6"/>
<circle cx="30" cy="0" r="18" fill="none" stroke="${col}" stroke-width="6"/>
<path d="M-30 0 L-6 -30 L20 -30 L30 0 M-6 -30 L4 0 M-30 0 L4 0" fill="none" stroke="${col}" stroke-width="6" stroke-linejoin="round" stroke-linecap="round"/>
<path d="M14 -36 L28 -36" stroke="${col}" stroke-width="6" stroke-linecap="round"/>
<path d="M-14 -36 L-2 -36" stroke="${col}" stroke-width="6" stroke-linecap="round"/>`;
  return g(body, { x: o.x, y: o.y, s: o.s, sy: o.s * (o.squash ?? 0.6), op: o.opacity ?? 0.85 });
}

/** rain overlay: diagonal streaks */
function rain(r: Rng, count = 150, op = 0.3): string {
  let s = "";
  for (let i = 0; i < count; i++) {
    const x = r.f(-80, W + 40);
    const y = r.f(-40, H);
    const len = r.f(26, 74);
    s += `<line x1="${n(x)}" y1="${n(y)}" x2="${n(x + len * 0.3)}" y2="${n(y + len)}" stroke="#eef4f6" stroke-width="${n(r.f(1, 2.1))}" opacity="${n(r.f(0.12, op))}" stroke-linecap="round"/>`;
  }
  return s;
}

/** wet-ground puddle with a pale reflection band */
function puddle(x: number, y: number, w: number, h: number, tint = "#8fa3ac", op = 0.5): string {
  return `
<ellipse cx="${n(x)}" cy="${n(y)}" rx="${n(w)}" ry="${n(h)}" fill="${tint}" opacity="${op}"/>
<ellipse cx="${n(x - w * 0.15)}" cy="${n(y - h * 0.2)}" rx="${n(w * 0.55)}" ry="${n(h * 0.34)}" fill="#dfeaee" opacity="${op * 0.55}"/>`;
}

/** soft contact shadow under an object (light comes from the upper left) */
function shadow(x: number, y: number, rx: number, ry: number, op = 0.26): string {
  return `<ellipse cx="${n(x)}" cy="${n(y)}" rx="${n(rx)}" ry="${n(ry)}" fill="#191a17" opacity="${op}" filter="url(#soft)"/>`;
}

/* ------------------------------------------------------------------ *
 * redaction: pixelated number-plate block
 * ------------------------------------------------------------------ */

const MOSAIC = ["#6f6f6f", "#828282", "#949494", "#a3a3a3", "#767676", "#8c8c8c", "#5f5f5f", "#9c9c9c"] as const;

/** a coarse grey mosaic block standing in for a redacted plate */
function plate(x: number, y: number, w: number, h: number, r: Rng, cols = 5, rows = 3): string {
  const cw = w / cols;
  const ch = h / rows;
  let s = `<rect x="${n(x - 1.5)}" y="${n(y - 1.5)}" width="${n(w + 3)}" height="${n(h + 3)}" rx="2" fill="#2a2a2a" opacity="0.85"/>`;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      s += `<rect x="${n(x + i * cw)}" y="${n(y + j * ch)}" width="${n(cw + 0.5)}" height="${n(ch + 0.5)}" fill="${r.pick(MOSAIC)}"/>`;
    }
  }
  s += `<rect x="${n(x)}" y="${n(y)}" width="${n(w)}" height="${n(h)}" fill="url(#gsh)" opacity="0.12"/>`;
  return s;
}

/* ------------------------------------------------------------------ *
 * vehicles
 * ------------------------------------------------------------------ */

type VehicleKind =
  | "sedan"
  | "hatch"
  | "suv"
  | "wagon"
  | "van"
  | "ute"
  | "dualcab"
  | "campervan"
  | "fourwd";

type SideSpec = {
  body: Pt[];
  glass: Pt[];
  pillars?: number[]; // x positions of body-coloured pillars over the glass
  wheels: { x: number; r: number }[];
  extra?: (col: string) => string;
  beltline?: number;
};

/*
 * Proportions are held to roughly life-like length:height ratios (a stylised
 * ~2.7 for cars, ~2.3 for SUVs, ~2.0 for vans) so the fleet reads as one set.
 * Local units: about 46px per metre of length.
 */
const SIDE: Record<VehicleKind, SideSpec> = {
  sedan: {
    body: [
      [-110, -14, 5],
      [-110, -44, 8],
      [-100, -52, 7],
      [-64, -56, 4],
      [-38, -79, 12],
      [16, -80, 12],
      [46, -57, 6],
      [92, -52, 8],
      [110, -42, 8],
      [110, -14, 5],
    ],
    glass: [
      [-46, -75, 6],
      [12, -76, 6],
      [42, -58, 4],
      [-58, -54, 4],
    ],
    pillars: [-14],
    wheels: [
      { x: -66, r: 19 },
      { x: 68, r: 19 },
    ],
    beltline: -54,
  },
  hatch: {
    body: [
      [-90, -13, 5],
      [-90, -44, 7],
      [-85, -70, 9],
      [-76, -77, 8],
      [12, -78, 10],
      [42, -56, 5],
      [74, -50, 7],
      [90, -40, 7],
      [90, -13, 5],
    ],
    glass: [
      [-78, -71, 5],
      [8, -72, 5],
      [36, -57, 4],
      [-76, -52, 4],
    ],
    pillars: [-34, -6],
    wheels: [
      { x: -56, r: 18 },
      { x: 56, r: 18 },
    ],
    beltline: -52,
  },
  wagon: {
    body: [
      [-115, -14, 5],
      [-115, -46, 7],
      [-110, -78, 9],
      [-100, -85, 9],
      [18, -86, 11],
      [48, -59, 5],
      [94, -53, 8],
      [112, -43, 8],
      [112, -14, 5],
    ],
    glass: [
      [-102, -79, 5],
      [14, -80, 5],
      [42, -60, 4],
      [-100, -54, 4],
    ],
    pillars: [-46, -10],
    wheels: [
      { x: -70, r: 19 },
      { x: 70, r: 19 },
    ],
    beltline: -54,
  },
  suv: {
    body: [
      [-120, -18, 6],
      [-120, -56, 8],
      [-116, -92, 10],
      [-106, -103, 10],
      [16, -105, 12],
      [46, -80, 5],
      [98, -72, 8],
      [120, -58, 8],
      [120, -18, 6],
    ],
    glass: [
      [-108, -96, 6],
      [12, -98, 6],
      [40, -79, 4],
      [-106, -60, 4],
    ],
    pillars: [-58, -16],
    wheels: [
      { x: -74, r: 24 },
      { x: 76, r: 24 },
    ],
    beltline: -60,
  },
  fourwd: {
    body: [
      [-125, -22, 5],
      [-125, -62, 7],
      [-122, -102, 8],
      [-112, -114, 8],
      [22, -116, 10],
      [52, -90, 4],
      [104, -82, 7],
      [125, -66, 7],
      [125, -22, 5],
    ],
    glass: [
      [-114, -108, 5],
      [18, -110, 5],
      [46, -89, 4],
      [-112, -68, 4],
    ],
    pillars: [-62, -18],
    wheels: [
      { x: -78, r: 27 },
      { x: 80, r: 27 },
    ],
    beltline: -68,
    extra: (col) => `
<rect x="-118" y="-128" width="152" height="8" rx="4" fill="${darken(col, 0.55)}"/>
<rect x="-112" y="-122" width="7" height="7" fill="${darken(col, 0.5)}"/>
<rect x="22" y="-122" width="7" height="7" fill="${darken(col, 0.5)}"/>
<path d="M100 -86 q15 -6 15 -24 l0 -20" fill="none" stroke="${darken(col, 0.5)}" stroke-width="8" stroke-linecap="round"/>`,
  },
  van: {
    body: [
      [-125, -16, 6],
      [-125, -108, 9],
      [-118, -119, 10],
      [74, -121, 10],
      [100, -100, 7],
      [125, -78, 8],
      [125, -16, 6],
    ],
    glass: [
      [58, -114, 5],
      [72, -115, 5],
      [96, -96, 4],
      [56, -92, 4],
    ],
    pillars: [],
    wheels: [
      { x: -78, r: 22 },
      { x: 76, r: 22 },
    ],
    beltline: -92,
    extra: (col) => `
<rect x="16" y="-114" width="34" height="23" rx="4" fill="#2b3236" opacity="0.9"/>
<rect x="16" y="-114" width="34" height="23" rx="4" fill="url(#glo)" opacity="0.16"/>
<rect x="-118" y="-90" width="102" height="2.5" fill="${darken(col, 0.22)}" opacity="0.7"/>
<rect x="-22" y="-117" width="3" height="100" fill="${darken(col, 0.18)}" opacity="0.6"/>`,
  },
  ute: {
    body: [
      [-125, -18, 5],
      [-125, -58, 5],
      [-32, -58, 2],
      [-32, -92, 3],
      [-20, -100, 8],
      [36, -101, 10],
      [66, -75, 4],
      [104, -66, 7],
      [125, -52, 7],
      [125, -18, 5],
    ],
    glass: [
      [-24, -93, 5],
      [32, -94, 5],
      [58, -77, 4],
      [-22, -72, 4],
    ],
    pillars: [],
    wheels: [
      { x: -76, r: 22 },
      { x: 72, r: 22 },
    ],
    beltline: -70,
    extra: (col) => `
<rect x="-34" y="-84" width="5" height="27" fill="${darken(col, 0.3)}"/>
<rect x="-125" y="-60" width="94" height="4.5" rx="2" fill="${darken(col, 0.36)}"/>
<rect x="-121" y="-55.5" width="86" height="3.5" fill="${darken(col, 0.5)}" opacity="0.35"/>`,
  },
  dualcab: {
    body: [
      [-132, -18, 5],
      [-132, -62, 6],
      [-56, -62, 2],
      [-56, -96, 3],
      [-44, -104, 8],
      [44, -105, 10],
      [76, -79, 4],
      [112, -70, 7],
      [132, -56, 7],
      [132, -18, 5],
    ],
    glass: [
      [-48, -97, 5],
      [40, -98, 5],
      [68, -81, 4],
      [-46, -76, 4],
    ],
    pillars: [-4],
    wheels: [
      { x: -84, r: 23 },
      { x: 80, r: 23 },
    ],
    beltline: -74,
    extra: (col) => `
<rect x="-58" y="-88" width="5" height="27" fill="${darken(col, 0.3)}"/>
<rect x="-132" y="-64" width="78" height="4.5" rx="2" fill="${darken(col, 0.36)}"/>
<rect x="-128" y="-59.5" width="70" height="3.5" fill="${darken(col, 0.5)}" opacity="0.35"/>`,
  },
  campervan: {
    body: [
      [-135, -18, 6],
      [-135, -126, 9],
      [-127, -138, 10],
      [64, -140, 10],
      [94, -116, 7],
      [135, -88, 8],
      [135, -18, 6],
    ],
    glass: [
      [46, -133, 5],
      [60, -134, 5],
      [90, -112, 4],
      [44, -108, 4],
    ],
    pillars: [],
    wheels: [
      { x: -86, r: 23 },
      { x: 82, r: 23 },
    ],
    beltline: -106,
    extra: (col) => `
<rect x="10" y="-132" width="26" height="24" rx="4" fill="#2b3236" opacity="0.9"/>
<rect x="-104" y="-124" width="58" height="32" rx="5" fill="#2b3236" opacity="0.85"/>
<rect x="-104" y="-124" width="58" height="32" rx="5" fill="url(#glo)" opacity="0.14"/>
<rect x="-32" y="-122" width="28" height="28" rx="4" fill="#2b3236" opacity="0.85"/>
<rect x="-135" y="-82" width="270" height="11" fill="${darken(col, 0.3)}" opacity="0.5"/>
<rect x="-135" y="-71" width="270" height="5" fill="${C.yellow}" opacity="0.55"/>`,
  },
};

/** side elevation of a vehicle */
function carSide(
  kind: VehicleKind,
  o: {
    x: number;
    y: number;
    s?: number;
    colour: string;
    flip?: boolean;
    r: Rng;
    shadowOp?: number;
    hazard?: boolean;
    noShadow?: boolean;
    plate?: boolean;
  },
): string {
  const spec = SIDE[kind]!;
  const col = o.colour;
  const s = o.s ?? 1;
  const dark = darken(col, 0.34);
  const glassCol = "#333c42";

  let body = "";
  // cast shadow (light from upper-left -> shadow falls right/under)
  if (!o.noShadow) {
    const wid = Math.max(...spec.body.map((p) => Math.abs(p[0]))) + 12;
    body += shadow(6, -3, wid, 11, o.shadowOp ?? 0.28);
  }
  // main body
  body += `<path d="${rp(spec.body, 6)}" fill="${col}"/>`;
  // lower rocker shading + upper highlight
  const minX = Math.min(...spec.body.map((p) => p[0]));
  const maxX = Math.max(...spec.body.map((p) => p[0]));
  const topY = Math.min(...spec.body.map((p) => p[1]));
  body += `<path d="${rp(spec.body, 6)}" fill="url(#gsh)" opacity="0.2"/>`;
  body += `<path d="${rp(spec.body, 6)}" fill="url(#glo)" opacity="0.1"/>`;
  // beltline crease
  if (spec.beltline !== undefined) {
    body += `<rect x="${minX + 6}" y="${spec.beltline + 4}" width="${maxX - minX - 12}" height="2.5" fill="${darken(col, 0.2)}" opacity="0.5"/>`;
  }
  // glass
  body += `<path d="${rp(spec.glass, 6)}" fill="${glassCol}"/>`;
  body += `<path d="${rp(spec.glass, 6)}" fill="url(#glo)" opacity="0.13"/>`;
  for (const px of spec.pillars ?? []) {
    body += `<rect x="${px - 2.5}" y="${topY}" width="5" height="${Math.abs(topY) - 40}" fill="${col}"/>`;
  }
  if (spec.extra) body += spec.extra(col);

  // door line + handle
  const doorX = kind === "van" || kind === "campervan" ? 6 : -6;
  if (kind !== "ute" && kind !== "van") {
    body += `<rect x="${doorX}" y="${(spec.beltline ?? -70) + 2}" width="2.5" height="${Math.abs(spec.beltline ?? -70) - 26}" fill="${darken(col, 0.24)}" opacity="0.55"/>`;
  }
  body += `<rect x="${doorX + 8}" y="${(spec.beltline ?? -70) + 10}" width="14" height="4" rx="2" fill="${darken(col, 0.32)}" opacity="0.7"/>`;

  // lights: tail (rear, left in unflipped local space) + head (front)
  body += `<rect x="${minX - 0.5}" y="${(spec.beltline ?? -70) + 18}" width="7" height="11" rx="2.5" fill="#b0384a" opacity="0.9"/>`;
  body += `<rect x="${maxX - 7}" y="${(spec.beltline ?? -70) + 20}" width="8" height="9" rx="3" fill="#f2ead2" opacity="0.9"/>`;
  if (o.hazard) {
    body += `<rect x="${minX - 0.5}" y="${(spec.beltline ?? -70) + 30}" width="7" height="7" rx="2" fill="${C.yellow}"/>`;
    body += `<rect x="${maxX - 7}" y="${(spec.beltline ?? -70) + 30}" width="7" height="7" rx="2" fill="${C.yellow}"/>`;
  }

  // wheels: arch crescent (upper half only, so nothing spills below the ground
  // line), then tyre and hub
  for (const w of spec.wheels) {
    const ar = w.r + 5;
    body += `<path d="M${n(w.x - ar)} ${n(-w.r)} A ${ar} ${ar} 0 0 1 ${n(w.x + ar)} ${n(-w.r)} Z" fill="${dark}" opacity="0.9"/>`;
    body += `<circle cx="${w.x}" cy="${-w.r}" r="${w.r}" fill="#232526"/>`;
    body += `<circle cx="${w.x}" cy="${-w.r}" r="${n(w.r * 0.56)}" fill="${C.steel}"/>`;
    body += `<circle cx="${w.x}" cy="${-w.r}" r="${n(w.r * 0.56)}" fill="url(#gsh)" opacity="0.28"/>`;
    body += `<circle cx="${w.x}" cy="${-w.r}" r="${n(w.r * 0.2)}" fill="${darken(C.steel, 0.35)}"/>`;
  }

  // plate seen edge-on at the rear bumper — narrow, but still redacted
  if (o.plate !== false) {
    body += plate(minX + 1, (spec.beltline ?? -60) + 30, 13, 9, o.r, 3, 2);
  }

  return g(body, { x: o.x, y: o.y, s, flip: o.flip });
}

type FaceSpec = {
  w: number;
  h: number; // overall height (for a ute this is the tub, not the cab)
  beltline: number; // y of the glass bottom (negative up)
  roofW: number;
  bumper: number; // y of bumper band top
  track: number; // wheel outer x
  wheelR: number;
  tub?: boolean; // rear face is an open tub with a tailgate, not a glasshouse
};

const FACE: Partial<Record<VehicleKind, FaceSpec>> = {
  sedan: { w: 100, h: 80, beltline: -52, roofW: 76, bumper: -24, track: 46, wheelR: 18 },
  hatch: { w: 96, h: 78, beltline: -50, roofW: 74, bumper: -22, track: 44, wheelR: 17 },
  wagon: { w: 102, h: 86, beltline: -54, roofW: 80, bumper: -24, track: 47, wheelR: 19 },
  suv: { w: 112, h: 105, beltline: -64, roofW: 90, bumper: -28, track: 52, wheelR: 23 },
  fourwd: { w: 118, h: 116, beltline: -72, roofW: 96, bumper: -32, track: 55, wheelR: 26 },
  dualcab: { w: 116, h: 64, beltline: -46, roofW: 114, bumper: -30, track: 53, wheelR: 23, tub: true },
  ute: { w: 116, h: 62, beltline: -44, roofW: 114, bumper: -28, track: 52, wheelR: 22, tub: true },
  van: { w: 112, h: 121, beltline: -88, roofW: 102, bumper: -26, track: 52, wheelR: 21 },
  campervan: { w: 118, h: 140, beltline: -104, roofW: 108, bumper: -26, track: 54, wheelR: 22 },
};

/** rear elevation (we are behind the vehicle) */
function carRear(
  kind: VehicleKind,
  o: {
    x: number;
    y: number;
    s?: number;
    colour: string;
    r: Rng;
    hazard?: boolean;
    tailLightRed?: string;
    noShadow?: boolean;
  },
): string {
  const f = FACE[kind] ?? FACE.sedan!;
  const col = o.colour;
  const hw = f.w / 2;
  const rw = f.roofW / 2;
  let body = "";
  if (!o.noShadow) body += shadow(4, -2, hw + 14, 12, 0.3);

  // wheels peeking out at the bottom
  for (const sgn of [-1, 1]) {
    body += `<rect x="${n(sgn * f.track - 9)}" y="${n(-f.wheelR * 1.5)}" width="18" height="${n(f.wheelR * 1.5)}" rx="4" fill="#232526"/>`;
  }

  // utes: an open tub with a tailgate, and the cab standing behind it
  if (f.tub) {
    const cabW = f.w * 0.84;
    const cabTop = -(f.h + 48);
    body += `<path d="${rp(
      [
        [-cabW / 2, -f.h + 12, 4],
        [-cabW / 2 + 5, cabTop, 12],
        [cabW / 2 - 5, cabTop, 12],
        [cabW / 2, -f.h + 12, 4],
      ],
      8,
    )}" fill="${darken(col, 0.1)}"/>`;
    body += `<path d="${rp(
      [
        [-cabW / 2 + 9, cabTop + 8, 6],
        [cabW / 2 - 9, cabTop + 8, 6],
        [cabW / 2 - 13, cabTop + 40, 4],
        [-cabW / 2 + 13, cabTop + 40, 4],
      ],
      5,
    )}" fill="#333c42"/>`;
    const tub: Pt[] = [
      [-hw, -6, 5],
      [-hw, -f.h, 7],
      [hw, -f.h, 7],
      [hw, -6, 5],
    ];
    body += `<path d="${rp(tub, 6)}" fill="${col}"/>`;
    body += `<path d="${rp(tub, 6)}" fill="url(#gsh)" opacity="0.2"/>`;
    // tailgate panel + top rail
    body += `<rect x="${n(-hw + 8)}" y="${n(-f.h + 10)}" width="${n(f.w - 16)}" height="${n(f.h - 30)}" rx="4" fill="${darken(col, 0.1)}" opacity="0.55"/>`;
    body += `<rect x="${n(-hw)}" y="${n(-f.h)}" width="${n(f.w)}" height="6" rx="3" fill="${lighten(col, 0.16)}"/>`;
    const tlc = o.tailLightRed ?? "#b0384a";
    for (const sgn of [-1, 1]) {
      body += `<rect x="${n(sgn === -1 ? -hw + 4 : hw - 26)}" y="${n(f.beltline + 8)}" width="22" height="16" rx="4" fill="${tlc}"/>`;
    }
    body += `<rect x="${-hw}" y="${n(f.bumper)}" width="${f.w}" height="${n(Math.abs(f.bumper) - 6)}" rx="6" fill="${darken(col, 0.2)}" opacity="0.6"/>`;
    body += plate(-24, f.bumper - 26, 48, 24, o.r, 5, 3);
    return g(body, { x: o.x, y: o.y, s: o.s ?? 1 });
  }

  // greenhouse first (a distinct, narrower volume sitting on the body)
  const roofY = -f.h;
  const gh: Pt[] = [
    [-rw - 5, f.beltline + 4, 4],
    [-rw, roofY, 13],
    [rw, roofY, 13],
    [rw + 5, f.beltline + 4, 4],
  ];
  body += `<path d="${rp(gh, 8)}" fill="${darken(col, 0.06)}"/>`;
  const gy0 = roofY + 8;
  const glass: Pt[] = [
    [-rw + 7, gy0, 7],
    [rw - 7, gy0, 7],
    [rw - 1, f.beltline - 1, 4],
    [-rw + 1, f.beltline - 1, 4],
  ];
  body += `<path d="${rp(glass, 6)}" fill="#333c42"/>`;
  body += `<path d="${rp(glass, 6)}" fill="url(#glo)" opacity="0.16"/>`;
  body += `<rect x="${n(-rw)}" y="${n(roofY)}" width="${n(f.roofW)}" height="5" rx="2.5" fill="${lighten(col, 0.22)}"/>`;

  // lower body: near-vertical sides
  const lower: Pt[] = [
    [-hw, -6, 6],
    [-hw + 1, f.beltline + 6, 6],
    [hw - 1, f.beltline + 6, 6],
    [hw, -6, 6],
  ];
  body += `<path d="${rp(lower, 7)}" fill="${col}"/>`;
  body += `<path d="${rp(lower, 7)}" fill="url(#gsh)" opacity="0.2"/>`;
  // shoulder highlight along the top of the body
  body += `<rect x="${n(-hw + 6)}" y="${n(f.beltline + 6)}" width="${n(f.w - 12)}" height="3" rx="1.5" fill="${lighten(col, 0.24)}" opacity="0.7"/>`;
  // boot / tailgate shut line
  body += `<path d="M${n(-hw + 10)} ${n(f.beltline + 26)} L${n(hw - 10)} ${n(f.beltline + 26)}" stroke="${darken(col, 0.2)}" stroke-width="2" opacity="0.45"/>`;

  // tail lights, tucked under the shoulder
  const tl = o.tailLightRed ?? "#b0384a";
  const ty = f.beltline + 12;
  for (const sgn of [-1, 1]) {
    const lx = sgn === -1 ? -hw + 5 : hw - 24;
    body += `<rect x="${n(lx)}" y="${n(ty)}" width="19" height="12" rx="3.5" fill="${tl}"/>`;
    body += `<rect x="${n(lx)}" y="${n(ty)}" width="19" height="12" rx="3.5" fill="url(#glo)" opacity="0.22"/>`;
    if (o.hazard) {
      body += `<rect x="${n(lx + 2)}" y="${n(ty + 2.5)}" width="15" height="7" rx="2.5" fill="${C.yellow}"/>`;
    }
  }
  // bumper band
  body += `<rect x="${-hw}" y="${n(f.bumper)}" width="${f.w}" height="${n(Math.abs(f.bumper) - 6)}" rx="6" fill="${darken(col, 0.16)}" opacity="0.5"/>`;
  // redacted plate
  body += plate(-24, f.bumper - 25, 48, 23, o.r, 5, 3);
  return g(body, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** front elevation (we are in front of the vehicle, e.g. a rear-camera view) */
function carFront(
  kind: VehicleKind,
  o: { x: number; y: number; s?: number; colour: string; r: Rng; bullbar?: boolean; noShadow?: boolean },
): string {
  const f = FACE[kind] ?? FACE.suv!;
  const col = o.colour;
  const hw = f.w / 2;
  const rw = f.roofW / 2;
  let body = "";
  if (!o.noShadow) body += shadow(4, -2, hw + 16, 13, 0.32);
  for (const sgn of [-1, 1]) {
    body += `<rect x="${n(sgn * f.track - 10)}" y="${n(-f.wheelR * 1.5)}" width="20" height="${n(f.wheelR * 1.5)}" rx="4" fill="#232526"/>`;
  }
  const shell: Pt[] = [
    [-hw, -6, 5],
    [-hw, f.beltline - 4, 10],
    [-rw, -f.h, 14],
    [rw, -f.h, 14],
    [hw, f.beltline - 4, 10],
    [hw, -6, 5],
  ];
  body += `<path d="${rp(shell, 6)}" fill="${col}"/>`;
  body += `<path d="${rp(shell, 6)}" fill="url(#gsh)" opacity="0.18"/>`;
  // windscreen
  const gy0 = -f.h + 9;
  const wsc: Pt[] = [
    [-rw + 7, gy0, 8],
    [rw - 7, gy0, 8],
    [hw - 13, f.beltline + 2, 6],
    [-hw + 13, f.beltline + 2, 6],
  ];
  body += `<path d="${rp(wsc, 6)}" fill="#333c42"/>`;
  body += `<path d="${rp(wsc, 6)}" fill="url(#glo)" opacity="0.16"/>`;
  // wiper hint
  body += `<path d="M${-rw + 12} ${n(f.beltline - 2)} L${-6} ${n(gy0 + 16)}" stroke="#20262a" stroke-width="3" opacity="0.6" stroke-linecap="round"/>`;
  // bonnet crease
  body += `<rect x="${-hw + 8}" y="${n(f.beltline + 10)}" width="${f.w - 16}" height="2.5" fill="${darken(col, 0.2)}" opacity="0.5"/>`;
  // headlights
  const hy = f.beltline + 18;
  for (const sgn of [-1, 1]) {
    const hx = sgn === -1 ? -hw + 6 : hw - 32;
    body += `<path d="${rp(
      [
        [hx, hy, 4],
        [hx + 26, hy + (sgn === -1 ? 3 : -0), 4],
        [hx + 26, hy + 15, 4],
        [hx, hy + 15, 4],
      ],
      4,
    )}" fill="#efe7d2"/>`;
    body += `<circle cx="${n(hx + 13)}" cy="${n(hy + 8)}" r="5" fill="#cfc6ae"/>`;
  }
  // grille
  body += `<rect x="${-hw + 22}" y="${n(hy + 2)}" width="${f.w - 44}" height="14" rx="4" fill="#22262a"/>`;
  for (let i = 0; i < 3; i++) {
    body += `<rect x="${-hw + 25}" y="${n(hy + 4.5 + i * 4)}" width="${f.w - 50}" height="1.6" fill="${lighten(col, 0.1)}" opacity="0.25"/>`;
  }
  // bumper + plate
  body += `<rect x="${-hw}" y="${n(f.bumper)}" width="${f.w}" height="${n(Math.abs(f.bumper) - 6)}" rx="6" fill="${darken(col, 0.18)}" opacity="0.6"/>`;
  body += `<rect x="${-hw + 14}" y="${n(f.bumper + 4)}" width="${f.w - 28}" height="9" rx="4" fill="#22262a" opacity="0.75"/>`;
  body += plate(-26, f.bumper - 27, 52, 25, o.r, 6, 3);
  if (o.bullbar) {
    body += `<rect x="${-hw - 5}" y="${n(f.beltline + 30)}" width="${f.w + 10}" height="10" rx="5" fill="#3b3f41"/>`;
    for (const bx of [-hw + 16, -6, hw - 26]) {
      body += `<rect x="${n(bx)}" y="${n(f.beltline + 30)}" width="9" height="${n(Math.abs(f.beltline + 30) - 8)}" rx="4" fill="#3b3f41"/>`;
    }
    body += `<path d="M${-hw - 2} ${n(f.beltline + 30)} q${hw} -22 ${f.w + 4} 0" fill="none" stroke="#3b3f41" stroke-width="8" stroke-linecap="round"/>`;
  }
  return g(body, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/**
 * Rear three-quarter view. The flank is the vehicle's own side silhouette
 * projected into a receding plane: each profile point is placed at a depth u
 * along the recession, lifted by the perspective rise and shrunk in height, so
 * the roofline, glass and wheels all stay consistent with the side elevation.
 * `dir` = -1 means the flank recedes to the left.
 */
function carRear3Q(
  kind: VehicleKind,
  o: {
    x: number;
    y: number;
    s?: number;
    colour: string;
    r: Rng;
    dir?: -1 | 1;
    depth?: number;
    rise?: number;
    shrink?: number;
  },
): string {
  const f = FACE[kind] ?? FACE.sedan!;
  const side = SIDE[kind]!;
  const col = o.colour;
  const dir = o.dir ?? -1;
  const depth = o.depth ?? 150;
  const D = depth * dir; // horizontal recession
  const E = -(o.rise ?? 30); // ground line rises toward the vanishing point
  const shrink = o.shrink ?? 0.84; // heights at the far end
  const hw = f.w / 2;
  const rw = f.roofW / 2;
  const nearX = -dir * hw;
  const farX = dir * hw;

  // side-profile extents, so profile x can be mapped to a depth fraction
  const pMinX = Math.min(...side.body.map((p) => p[0]));
  const pMaxX = Math.max(...side.body.map((p) => p[0]));
  const pLen = pMaxX - pMinX;
  const pMinY = Math.min(...side.body.map((p) => p[1]));
  /** project a side-profile point into the receding flank plane */
  const pr = (px: number, py: number): number[] => {
    const u = (px - pMinX) / pLen;
    return [farX + D * u, E * u + py * (1 + (shrink - 1) * u)];
  };

  const flank = lighten(col, 0.11);
  const roofC = lighten(col, 0.2);
  let body = "";

  // ground shadow spanning both volumes
  body += `<polygon points="${poly([
    [nearX - 10, -4],
    [farX + 8, -4],
    [farX + D + 14, E - 4],
    [nearX + D - 8, E - 4],
  ])}" fill="#191a17" opacity="0.26" filter="url(#soft)"/>`;

  // ---- flank: the side silhouette, projected ----
  const flankPts = side.body.map((p) => pr(p[0], p[1]));
  body += `<polygon points="${poly(flankPts)}" fill="${flank}"/>`;
  body += `<polygon points="${poly(flankPts)}" fill="url(#gsh)" opacity="0.15"/>`;
  // flank glass
  const glassPts = side.glass.map((p) => pr(p[0], p[1]));
  body += `<polygon points="${poly(glassPts)}" fill="#333c42"/>`;
  body += `<polygon points="${poly(glassPts)}" fill="url(#glo)" opacity="0.12"/>`;
  // flank wheels, foreshortened into ellipses
  for (const w of side.wheels) {
    const u = (w.x - pMinX) / pLen;
    const c = pr(w.x, -w.r);
    const rr = w.r * (1 + (shrink - 1) * u);
    body += `<path d="M${n(c[0]! - rr * 0.46)} ${n(c[1]! + rr)} a${n(rr * 0.46)} ${n(rr)} 0 0 1 ${n(rr * 0.92)} 0 Z" fill="${darken(col, 0.34)}"/>`;
    body += `<ellipse cx="${n(c[0]!)}" cy="${n(c[1]!)}" rx="${n(rr * 0.4)}" ry="${n(rr)}" fill="#232526"/>`;
    body += `<ellipse cx="${n(c[0]!)}" cy="${n(c[1]!)}" rx="${n(rr * 0.19)}" ry="${n(rr * 0.52)}" fill="${C.steel}" opacity="0.85"/>`;
  }
  // beltline crease + a door shut line
  if (side.beltline !== undefined) {
    const a = pr(pMinX + pLen * 0.1, side.beltline);
    const c = pr(pMinX + pLen * 0.72, side.beltline);
    body += `<line x1="${n(a[0]!)}" y1="${n(a[1]!)}" x2="${n(c[0]!)}" y2="${n(c[1]!)}" stroke="${darken(col, 0.2)}" stroke-width="2" opacity="0.45"/>`;
    const d0 = pr(pMinX + pLen * 0.42, side.beltline + 4);
    const d1 = pr(pMinX + pLen * 0.42, -6);
    body += `<line x1="${n(d0[0]!)}" y1="${n(d0[1]!)}" x2="${n(d1[0]!)}" y2="${n(d1[1]!)}" stroke="${darken(col, 0.2)}" stroke-width="2" opacity="0.4"/>`;
  }

  // ---- roof plane between the rear face and the flank ----
  // (a ute has no roof at the rear face — the flank already carries the cab)
  if (!f.tub) {
    const roofFar = pr(pMinX + pLen * 0.34, pMinY);
    body += `<polygon points="${poly([
      [-rw, -f.h],
      [rw, -f.h],
      [roofFar[0]!, roofFar[1]!],
      [farX - dir * (hw - rw), -f.h + E * 0.06],
    ])}" fill="${roofC}"/>`;
  }

  // ---- rear face ----
  const beltF = f.beltline;
  const roofY = -f.h;
  if (f.tub) {
    const tub: Pt[] = [
      [-hw, -6, 5],
      [-hw, roofY, 7],
      [hw, roofY, 7],
      [hw, -6, 5],
    ];
    body += `<path d="${rp(tub, 6)}" fill="${col}"/>`;
    body += `<path d="${rp(tub, 6)}" fill="url(#gsh)" opacity="0.2"/>`;
    body += `<rect x="${n(-hw + 8)}" y="${n(roofY + 10)}" width="${n(f.w - 16)}" height="${n(f.h - 30)}" rx="4" fill="${darken(col, 0.1)}" opacity="0.55"/>`;
    body += `<rect x="${n(-hw)}" y="${n(roofY)}" width="${n(f.w)}" height="6" rx="3" fill="${lighten(col, 0.16)}"/>`;
    for (const sgn of [-1, 1]) {
      body += `<rect x="${n(sgn === -1 ? -hw + 4 : hw - 26)}" y="${n(beltF + 8)}" width="22" height="16" rx="4" fill="#b0384a"/>`;
    }
    body += `<rect x="${-hw}" y="${n(f.bumper)}" width="${f.w}" height="${n(Math.abs(f.bumper) - 6)}" rx="6" fill="${darken(col, 0.2)}" opacity="0.6"/>`;
    body += plate(-24, f.bumper - 26, 48, 24, o.r, 5, 3);
    for (const sgn of [-1, 1]) {
      body += `<rect x="${n(sgn * f.track - 9)}" y="${n(-f.wheelR * 1.3)}" width="18" height="${n(f.wheelR * 1.3)}" rx="4" fill="#232526"/>`;
    }
    return g(body, { x: o.x, y: o.y, s: o.s ?? 1 });
  }
  const shell: Pt[] = [
    [-hw, -6, 5],
    [-hw, beltF - 2, 10],
    [-rw, roofY, 14],
    [rw, roofY, 14],
    [hw, beltF - 2, 10],
    [hw, -6, 5],
  ];
  body += `<path d="${rp(shell, 6)}" fill="${col}"/>`;
  body += `<path d="${rp(shell, 6)}" fill="url(#gsh)" opacity="0.22"/>`;
  const gy0 = roofY + 10;
  const rg: Pt[] = [
    [-rw + 8, gy0, 8],
    [rw - 8, gy0, 8],
    [hw - 14, beltF + 4, 6],
    [-hw + 14, beltF + 4, 6],
  ];
  body += `<path d="${rp(rg, 6)}" fill="#333c42"/>`;
  body += `<path d="${rp(rg, 6)}" fill="url(#glo)" opacity="0.13"/>`;
  const ty = beltF + 16;
  for (const sgn of [-1, 1]) {
    body += `<rect x="${n(sgn === -1 ? -hw + 5 : hw - 27)}" y="${n(ty)}" width="22" height="15" rx="4" fill="#b0384a"/>`;
  }
  body += `<rect x="${-hw}" y="${n(f.bumper)}" width="${f.w}" height="${n(Math.abs(f.bumper) - 6)}" rx="6" fill="${darken(col, 0.16)}" opacity="0.55"/>`;
  body += plate(-24, f.bumper - 26, 48, 24, o.r, 5, 3);
  // near rear wheels
  for (const sgn of [-1, 1]) {
    body += `<rect x="${n(sgn * f.track - 9)}" y="${n(-f.wheelR * 1.3)}" width="18" height="${n(f.wheelR * 1.3)}" rx="4" fill="#232526"/>`;
  }
  return g(body, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/* ------------------------------------------------------------------ *
 * objects
 * ------------------------------------------------------------------ */

/** supermarket / hardware trolley, side-on */
function trolley(o: {
  x: number;
  y: number;
  s?: number;
  flip?: boolean;
  basket?: string;
  handle?: string;
  noShadow?: boolean;
  rot?: number;
}): string {
  const bk = o.basket ?? "#b9bfc2";
  const hd = o.handle ?? C.yellow;
  const wire = lighten(bk, 0.34);
  const frame = lighten(bk, 0.16);
  let b = "";
  if (!o.noShadow) b += shadow(2, 0, 44, 8, 0.24);
  // basket: an open wire box, tapering toward the front
  const basket: Pt[] = [
    [-38, -46, 2],
    [34, -54, 2],
    [30, -86, 2],
    [-34, -80, 2],
  ];
  b += `<path d="${rp(basket, 2)}" fill="${darken(bk, 0.5)}" opacity="0.32"/>`;
  // the wire mesh itself: uprights and horizontal runs, clipped to the basket
  const cid = `bk${Math.abs(Math.round(o.x * 7 + o.y * 13))}`;
  b += `<clipPath id="${cid}"><path d="${rp(basket, 2)}"/></clipPath>`;
  b += `<g clip-path="url(#${cid})" stroke="${wire}" fill="none" stroke-width="2.6" opacity="0.95">`;
  for (let i = 0; i <= 8; i++) {
    const t = i / 8;
    const xt = -38 + t * 72;
    b += `<line x1="${n(xt)}" y1="-40" x2="${n(xt + 4)}" y2="-92"/>`;
  }
  for (let j = 0; j <= 3; j++) {
    const t = j / 3;
    b += `<line x1="-38" y1="${n(-48 - t * 32)}" x2="34" y2="${n(-56 - t * 30)}"/>`;
  }
  b += `</g>`;
  // basket rim, front and back edges
  b += `<path d="${rp(basket, 2)}" fill="none" stroke="${frame}" stroke-width="4" stroke-linejoin="round"/>`;
  b += `<path d="M-34 -80 L30 -86" stroke="${lighten(bk, 0.3)}" stroke-width="4.5" stroke-linecap="round"/>`;
  // lower shelf
  b += `<path d="${rp(
    [
      [-32, -22, 2],
      [28, -28, 2],
      [28, -22, 2],
      [-32, -16, 2],
    ],
    2,
  )}" fill="${frame}"/>`;
  // frame legs and cross brace
  b += `<g stroke="${frame}" stroke-width="4.5" stroke-linecap="round">
<line x1="-31" y1="-46" x2="-27" y2="-9"/>
<line x1="27" y1="-54" x2="25" y2="-12"/>
<line x1="-30" y1="-32" x2="28" y2="-40"/></g>`;
  // handle: a short stout stem off the back of the basket, bar sitting on it
  b += `<path d="M-35 -78 q-14 -6 -17 -18" fill="none" stroke="${frame}" stroke-width="6.5" stroke-linecap="round"/>`;
  b += `<path d="M-30 -50 q-18 -18 -22 -46" fill="none" stroke="${frame}" stroke-width="5" stroke-linecap="round"/>`;
  b += `<rect x="-68" y="-101" width="34" height="10" rx="5" fill="${hd}"/>`;
  b += `<rect x="-68" y="-101" width="34" height="4" rx="2" fill="${lighten(hd, 0.35)}"/>`;
  // castors
  for (const [cx, cy] of [
    [-27, -6],
    [25, -9],
  ]) {
    b += `<circle cx="${cx}" cy="${cy}" r="6" fill="#2c2f30"/>`;
    b += `<circle cx="${cx}" cy="${cy}" r="2.4" fill="${C.steel}"/>`;
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip, rot: o.rot });
}

/** several trolleys nested into each other */
function trolleyNest(o: {
  x: number;
  y: number;
  s?: number;
  count?: number;
  step?: number;
  flip?: boolean;
  basket?: string;
}): string {
  const count = o.count ?? 3;
  const step = o.step ?? 22;
  let b = shadow(0, 0, 44 + step * (count - 1) * 0.6, 9, 0.24);
  for (let i = count - 1; i >= 0; i--) {
    b += trolley({
      x: -i * step,
      y: -i * 3,
      s: 1 - i * 0.02,
      basket: o.basket,
      noShadow: true,
    });
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** trolley bay: steel canopy with rails */
function trolleyBay(o: { x: number; y: number; s?: number; flip?: boolean }): string {
  const st = C.steelDark;
  let b = "";
  b += shadow(0, 0, 108, 10, 0.2);
  // rails on the ground
  b += `<path d="${poly([
    [-96, -6],
    [92, -22],
  ])
    .split(" ")
    .map((p, i) => (i === 0 ? `M${p.replace(",", " ")}` : `L${p.replace(",", " ")}`))
    .join(" ")}" stroke="${st}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
  b += `<path d="M-92 -20 L96 -36" stroke="${st}" stroke-width="5" fill="none" stroke-linecap="round"/>`;
  // uprights
  for (const [ux, uy] of [
    [-94, -8],
    [-90, -22],
    [92, -24],
    [96, -38],
  ]) {
    b += `<rect x="${ux - 3.5}" y="${uy - 108}" width="7" height="108" rx="3" fill="${st}"/>`;
  }
  // canopy
  b += `<path d="${rp(
    [
      [-108, -116, 4],
      [110, -132, 4],
      [110, -122, 4],
      [-108, -106, 4],
    ],
    4,
  )}" fill="${C.steel}"/>`;
  b += `<path d="${rp(
    [
      [-108, -118, 4],
      [110, -134, 4],
      [110, -128, 4],
      [-108, -112, 4],
    ],
    4,
  )}" fill="${lighten(C.steel, 0.25)}"/>`;
  // blank sign panel on the canopy edge
  b += `<rect x="-30" y="-160" width="60" height="30" rx="4" fill="#e9e6dc"/>`;
  b += `<rect x="-30" y="-160" width="60" height="30" rx="4" fill="none" stroke="${C.steelDark}" stroke-width="3"/>`;
  b += `<rect x="-6" y="-158" width="6" height="26" fill="${C.steelDark}" opacity="0.35"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** domestic wheelie bin, slight 3/4 */
function wheelieBin(o: { x: number; y: number; s?: number; lid: string; body?: string; flip?: boolean; open?: boolean }): string {
  const bd = o.body ?? "#4b5350";
  let b = shadow(3, 0, 30, 7, 0.26);
  const shell: Pt[] = [
    [-24, -6, 3],
    [-27, -92, 4],
    [27, -92, 4],
    [24, -6, 3],
  ];
  b += `<path d="${rp(shell, 4)}" fill="${bd}"/>`;
  b += `<path d="${rp(shell, 4)}" fill="url(#gsh)" opacity="0.22"/>`;
  b += `<rect x="-18" y="-70" width="36" height="44" rx="4" fill="${darken(bd, 0.12)}" opacity="0.5"/>`;
  // lid
  b += `<path d="${rp(
    [
      [-30, -92, 4],
      [30, -92, 4],
      [28, -104, 5],
      [-28, -104, 5],
    ],
    4,
  )}" fill="${o.lid}"/>`;
  b += `<path d="${rp(
    [
      [-30, -100, 4],
      [30, -100, 4],
      [28, -105, 5],
      [-28, -105, 5],
    ],
    4,
  )}" fill="${lighten(o.lid, 0.22)}"/>`;
  // wheels
  b += `<circle cx="-17" cy="-7" r="7" fill="#232526"/><circle cx="17" cy="-7" r="7" fill="#232526"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** council bin: dark green body, yellow lid, on a post */
function councilBin(o: { x: number; y: number; s?: number }): string {
  let b = shadow(3, 0, 30, 7, 0.26);
  const shell: Pt[] = [
    [-25, -8, 3],
    [-28, -86, 4],
    [28, -86, 4],
    [25, -8, 3],
  ];
  b += `<path d="${rp(shell, 4)}" fill="${C.binGreen}"/>`;
  b += `<path d="${rp(shell, 4)}" fill="url(#gsh)" opacity="0.24"/>`;
  b += `<path d="${rp(shell, 4)}" fill="url(#glo)" opacity="0.08"/>`;
  b += `<path d="${rp(
    [
      [-32, -86, 4],
      [32, -86, 4],
      [30, -102, 6],
      [-30, -102, 6],
    ],
    5,
  )}" fill="${C.yellow}"/>`;
  b += `<rect x="-15" y="-101" width="30" height="9" rx="4" fill="#2b2b26" opacity="0.6"/>`;
  b += `<rect x="-6" y="-8" width="12" height="8" fill="${darken(C.binGreen, 0.3)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** gum tree: pale forking trunk, drooping olive canopy */
function gumTree(o: { x: number; y: number; s?: number; r: Rng; lean?: number; bare?: boolean }): string {
  const r = o.r;
  const lean = o.lean ?? 0;
  const trunk = "#c8c2b2";
  let b = "";
  b += `<path d="M-9 0 Q${n(-5 + lean)} -90 ${n(2 + lean * 1.6)} -168 L${n(14 + lean * 1.6)} -168 Q${n(11 + lean)} -88 ${n(11)} 0 Z" fill="${trunk}"/>`;
  b += `<path d="M-9 0 Q${n(-5 + lean)} -90 ${n(2 + lean * 1.6)} -168 L${n(7 + lean * 1.6)} -168 Q${n(3 + lean)} -88 ${n(1)} 0 Z" fill="${darken(trunk, 0.16)}"/>`;
  // bark flecks
  for (let i = 0; i < 7; i++) {
    const yy = -r.f(20, 150);
    b += `<rect x="${n(-6 + lean * (yy / -168) + r.f(-2, 8))}" y="${n(yy)}" width="${n(r.f(3, 7))}" height="${n(r.f(6, 16))}" rx="2" fill="${darken(trunk, 0.28)}" opacity="${n(r.f(0.2, 0.45))}"/>`;
  }
  // branches
  const bxs = [
    [-52, -206, -6, -160],
    [56, -196, 12, -158],
    [-24, -238, 2, -180],
    [34, -246, 8, -184],
  ];
  for (const [ex, ey, sx, sy] of bxs) {
    b += `<path d="M${n(sx! + lean * 1.6)} ${sy} Q${n((sx! + ex!) / 2 + lean * 1.8)} ${n((sy! + ey!) / 2 - 14)} ${n(ex! + lean * 1.9)} ${ey}" fill="none" stroke="${darken(trunk, 0.1)}" stroke-width="7" stroke-linecap="round"/>`;
  }
  if (!o.bare) {
    const greens = [C.euc, C.eucMid, C.eucLight];
    const blobs: number[][] = [
      [-64, -216, 52, 34],
      [-16, -252, 62, 40],
      [44, -232, 56, 36],
      [8, -206, 48, 28],
      [-46, -258, 44, 28],
      [72, -262, 40, 26],
      [-84, -244, 36, 24],
    ];
    for (const [bx, by, brx, bry] of blobs) {
      const col = r.pick(greens);
      b += `<ellipse cx="${n(bx! + lean * 2)}" cy="${by}" rx="${brx}" ry="${bry}" fill="${col}" opacity="0.95"/>`;
      b += `<ellipse cx="${n(bx! + lean * 2 - brx! * 0.2)}" cy="${n(by! - bry! * 0.35)}" rx="${n(brx! * 0.6)}" ry="${n(bry! * 0.5)}" fill="${lighten(col, 0.18)}" opacity="0.8"/>`;
    }
    // a few hanging leaf strokes
    for (let i = 0; i < 12; i++) {
      const lx = r.f(-96, 96) + lean * 2;
      const ly = -r.f(190, 268);
      b += `<ellipse cx="${n(lx)}" cy="${n(ly)}" rx="${n(r.f(3, 6))}" ry="${n(r.f(9, 15))}" fill="${r.pick(greens)}" opacity="${n(r.f(0.5, 0.9))}" transform="rotate(${n(r.f(-40, 40))} ${n(lx)} ${n(ly)})"/>`;
    }
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** low shrub / saltbush clump */
function shrub(o: { x: number; y: number; s?: number; r: Rng; colour?: string }): string {
  const r = o.r;
  const base = o.colour ?? C.eucMid;
  let b = shadow(2, 0, 34, 6, 0.18);
  for (let i = 0; i < 7; i++) {
    const bx = r.f(-30, 30);
    const by = -r.f(6, 40);
    const rx = r.f(14, 24);
    const col = mix(base, i % 2 ? C.eucLight : C.euc, r.f(0, 0.6));
    b += `<ellipse cx="${n(bx)}" cy="${n(by)}" rx="${n(rx)}" ry="${n(rx * 0.78)}" fill="${col}"/>`;
  }
  b += `<ellipse cx="-6" cy="-30" rx="16" ry="12" fill="${lighten(base, 0.2)}" opacity="0.6"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** clump of reeds */
function reeds(o: { x: number; y: number; s?: number; r: Rng; count?: number; colour?: string }): string {
  const r = o.r;
  const count = o.count ?? 12;
  const col = o.colour ?? "#8f9a5e";
  let b = "";
  for (let i = 0; i < count; i++) {
    const bx = r.f(-26, 26);
    const h = r.f(34, 78);
    const sway = r.f(-16, 16);
    b += `<path d="M${n(bx)} 0 Q${n(bx + sway * 0.4)} ${n(-h * 0.6)} ${n(bx + sway)} ${n(-h)}" fill="none" stroke="${mix(col, C.dryGrass, r.f(0, 0.7))}" stroke-width="${n(r.f(2, 3.6))}" stroke-linecap="round"/>`;
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** yellow safety bollard */
function bollard(o: { x: number; y: number; s?: number }): string {
  let b = shadow(3, 0, 12, 4, 0.24);
  b += `<rect x="-7" y="-84" width="14" height="84" rx="7" fill="${C.yellow}"/>`;
  b += `<rect x="-7" y="-84" width="14" height="84" rx="7" fill="url(#gsh)" opacity="0.18"/>`;
  b += `<rect x="-7" y="-58" width="14" height="9" fill="#e9e6dc"/>`;
  b += `<rect x="-7" y="-84" width="5" height="84" fill="#ffffff" opacity="0.18"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/**
 * Sign on a post. `panel` is drawn inside the blank plate — pictograms only.
 * shape: 'rect' | 'diamond'
 */
function signPost(o: {
  x: number;
  y: number;
  s?: number;
  h?: number;
  w?: number;
  ph?: number;
  shape?: "rect" | "diamond";
  face?: string;
  border?: string;
  panel?: string;
  post?: string;
}): string {
  const h = o.h ?? 150;
  const pw = o.w ?? 64;
  const ph = o.ph ?? 84;
  const face = o.face ?? "#eeeade";
  const border = o.border ?? "#2f4d86";
  const post = o.post ?? C.steelDark;
  let b = shadow(3, 0, 12, 4, 0.22);
  b += `<rect x="-4" y="${-h}" width="8" height="${h}" rx="3" fill="${post}"/>`;
  b += `<rect x="-4" y="${-h}" width="3" height="${h}" fill="#ffffff" opacity="0.16"/>`;
  if (o.shape === "diamond") {
    const s = pw;
    b += `<g transform="translate(0,${-h - s * 0.72}) rotate(45)"><rect x="${-s / 2}" y="${-s / 2}" width="${s}" height="${s}" rx="6" fill="${C.yellow}"/><rect x="${-s / 2}" y="${-s / 2}" width="${s}" height="${s}" rx="6" fill="none" stroke="#2b2b26" stroke-width="3"/></g>`;
    if (o.panel) b += g(o.panel, { x: 0, y: -h - pw * 0.72 });
  } else {
    b += `<rect x="${-pw / 2}" y="${-h - ph}" width="${pw}" height="${ph}" rx="5" fill="${face}"/>`;
    b += `<rect x="${-pw / 2 + 3.5}" y="${-h - ph + 3.5}" width="${pw - 7}" height="${ph - 7}" rx="3" fill="none" stroke="${border}" stroke-width="4"/>`;
    b += `<rect x="${-pw / 2}" y="${-h - ph}" width="${pw}" height="${ph}" rx="5" fill="url(#gsh)" opacity="0.1"/>`;
    if (o.panel) b += g(o.panel, { x: 0, y: -h - ph / 2 });
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** timber dune fence receding along a vanishing direction */
function duneFence(o: {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
  posts?: number;
  s0?: number;
  s1?: number;
  colour?: string;
}): string {
  const posts = o.posts ?? 8;
  const col = o.colour ?? C.timber;
  const s0 = o.s0 ?? 1;
  const s1 = o.s1 ?? 0.42;
  let rails = "";
  let pts = "";
  const tops: number[][] = [];
  const mids: number[][] = [];
  for (let i = 0; i < posts; i++) {
    const t = i / (posts - 1);
    const e = Math.pow(t, 1.35);
    const x = o.x0 + (o.x1 - o.x0) * e;
    const y = o.y0 + (o.y1 - o.y0) * e;
    const s = s0 + (s1 - s0) * e;
    const h = 78 * s;
    const w = 9 * s;
    pts += `<rect x="${n(x - w / 2)}" y="${n(y - h)}" width="${n(w)}" height="${n(h)}" rx="${n(w * 0.3)}" fill="${mix(col, C.timberDark, 0.15 + t * 0.2)}"/>`;
    pts += `<rect x="${n(x - w / 2)}" y="${n(y - h)}" width="${n(w * 0.36)}" height="${n(h)}" fill="#ffffff" opacity="0.14"/>`;
    tops.push([x, y - h * 0.86]);
    mids.push([x, y - h * 0.44]);
  }
  const line = (arr: number[][], sw: number) =>
    `<polyline points="${poly(arr)}" fill="none" stroke="${C.timberDark}" stroke-width="${sw}" opacity="0.85" stroke-linecap="round"/>`;
  rails += line(tops, 4);
  rails += line(mids, 3.4);
  return rails + pts;
}

/** picnic table, 3/4 view */
function picnicTable(o: { x: number; y: number; s?: number; colour?: string }): string {
  const t = o.colour ?? C.timber;
  const td = darken(t, 0.3);
  let b = shadow(4, 0, 106, 12, 0.24);
  // benches (far, then near)
  b += `<path d="${rp(
    [
      [-118, -56, 2],
      [96, -70, 2],
      [96, -60, 2],
      [-118, -46, 2],
    ],
    2,
  )}" fill="${darken(t, 0.16)}"/>`;
  // legs
  for (const [lx, ly] of [
    [-84, -4],
    [72, -18],
  ]) {
    b += `<path d="M${lx} ${ly} l22 -84 M${lx + 46} ${ly - 4} l-24 -80" stroke="${td}" stroke-width="9" fill="none" stroke-linecap="round"/>`;
  }
  // table top
  b += `<path d="${rp(
    [
      [-126, -94, 3],
      [104, -110, 3],
      [104, -96, 3],
      [-126, -80, 3],
    ],
    3,
  )}" fill="${t}"/>`;
  b += `<path d="${rp(
    [
      [-126, -96, 3],
      [104, -112, 3],
      [104, -104, 3],
      [-126, -88, 3],
    ],
    3,
  )}" fill="${lighten(t, 0.16)}"/>`;
  for (let i = 1; i < 4; i++) {
    b += `<line x1="-124" y1="${n(-94 + i * 3.2)}" x2="102" y2="${n(-110 + i * 3.2)}" stroke="${td}" stroke-width="1.2" opacity="0.45"/>`;
  }
  // near bench
  b += `<path d="${rp(
    [
      [-122, -34, 2],
      [100, -48, 2],
      [100, -36, 2],
      [-122, -22, 2],
    ],
    2,
  )}" fill="${mix(t, "#ffffff", 0.06)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** portable bluetooth speaker */
function speaker(o: { x: number; y: number; s?: number; rot?: number }): string {
  let b = shadow(3, 0, 46, 8, 0.26);
  b += `<rect x="-46" y="-62" width="92" height="62" rx="16" fill="#2f3437"/>`;
  b += `<rect x="-46" y="-62" width="92" height="62" rx="16" fill="url(#glo)" opacity="0.12"/>`;
  b += `<rect x="-38" y="-54" width="76" height="46" rx="11" fill="#3f4649"/>`;
  // mesh dots
  for (let i = 0; i < 7; i++)
    for (let j = 0; j < 4; j++)
      b += `<circle cx="${n(-32 + i * 10.6)}" cy="${n(-48 + j * 10.6)}" r="2.4" fill="#252a2c"/>`;
  b += `<circle cx="-22" cy="-31" r="15" fill="#2b3033" opacity="0.7"/>`;
  b += `<circle cx="22" cy="-31" r="15" fill="#2b3033" opacity="0.7"/>`;
  b += `<rect x="-14" y="-70" width="28" height="9" rx="4" fill="#25292b"/>`;
  b += `<circle cx="30" cy="-56" r="3.4" fill="${C.yellow}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, rot: o.rot });
}

/** concentric sound-wave arcs radiating from a point */
function soundWaves(o: { x: number; y: number; s?: number; count?: number; colour?: string; squash?: number }): string {
  const count = o.count ?? 4;
  const col = o.colour ?? "#5b6a70";
  let b = "";
  for (let i = 0; i < count; i++) {
    const r = 70 + i * 52;
    b += `<path d="M${n(-r * 0.62)} ${n(-r * 0.28)} A ${n(r)} ${n(r)} 0 0 1 ${n(r * 0.62)} ${n(-r * 0.28)}" fill="none" stroke="${col}" stroke-width="${n(5 - i * 0.7)}" opacity="${n(0.42 - i * 0.07)}" stroke-linecap="round"/>`;
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, sy: (o.s ?? 1) * (o.squash ?? 0.55) });
}

/** office microwave, optionally with the door swung open */
function microwave(o: { x: number; y: number; s?: number; open?: boolean; r: Rng }): string {
  const shellC = "#d7d8d3";
  let b = shadow(4, 0, 96, 10, 0.22);
  b += `<rect x="-92" y="-104" width="184" height="104" rx="7" fill="${shellC}"/>`;
  b += `<rect x="-92" y="-104" width="184" height="104" rx="7" fill="url(#gsh)" opacity="0.14"/>`;
  // cavity
  b += `<rect x="-84" y="-96" width="118" height="88" rx="4" fill="#2b2e2c"/>`;
  b += `<rect x="-80" y="-92" width="110" height="80" rx="3" fill="#3a3e3a"/>`;
  // splatter inside
  for (let i = 0; i < 9; i++) {
    b += `<circle cx="${n(o.r.f(-74, 24))}" cy="${n(o.r.f(-86, -18))}" r="${n(o.r.f(1.6, 4.4))}" fill="#b98b5a" opacity="${n(o.r.f(0.3, 0.7))}"/>`;
  }
  // turntable
  b += `<ellipse cx="-26" cy="-18" rx="48" ry="9" fill="#585d59"/>`;
  // the foil container: a shallow crimped tray, unmistakably metal
  b += g(
    `<path d="${rp(
      [
        [-44, 0, 2],
        [44, 0, 2],
        [37, -26, 2],
        [-37, -26, 2],
      ],
      2,
    )}" fill="#b9bfc1"/>
     <g stroke="#8f9698" stroke-width="1.6" opacity="0.8">
       ${Array.from({ length: 9 }, (_, i) => {
         const t = (i + 0.5) / 9;
         return `<line x1="${n(-44 + t * 88)}" y1="-1" x2="${n(-37 + t * 74)}" y2="-25"/>`;
       }).join("")}
     </g>
     <path d="${rp(
       [
         [-48, -26, 2],
         [48, -26, 2],
         [42, -36, 2],
         [-42, -36, 2],
       ],
       2,
     )}" fill="#dce1e2"/>
     <path d="${rp(
       [
         [-48, -26, 2],
         [48, -26, 2],
         [42, -36, 2],
         [-42, -36, 2],
       ],
       2,
     )}" fill="url(#glo)" opacity="0.34"/>
     <g stroke="#a9b0b2" stroke-width="1.5" opacity="0.7">
       ${Array.from({ length: 11 }, (_, i) => {
         const t = (i + 0.5) / 11;
         return `<line x1="${n(-48 + t * 96)}" y1="-27" x2="${n(-42 + t * 84)}" y2="-35"/>`;
       }).join("")}
     </g>
     <ellipse cx="0" cy="-35" rx="40" ry="5" fill="#eef1f1"/>
     <ellipse cx="-2" cy="-34" rx="31" ry="4" fill="#8f5f3a"/>`,
    { x: -26, y: -20, s: 0.82 },
  );
  // control panel
  b += `<rect x="40" y="-96" width="46" height="88" rx="4" fill="#c3c5c0"/>`;
  b += `<rect x="45" y="-90" width="36" height="20" rx="3" fill="#2f3a35"/>`;
  for (let i = 0; i < 3; i++)
    for (let j = 0; j < 3; j++)
      b += `<rect x="${n(46 + i * 12)}" y="${n(-64 + j * 12)}" width="9" height="9" rx="2" fill="#a9aca7"/>`;
  b += `<rect x="46" y="-24" width="34" height="10" rx="4" fill="#8f938e"/>`;

  if (o.open) {
    // Door hung open toward the viewer: hinged on the left edge of the shell
    // and foreshortened, so it reads as a door rather than a second appliance.
    const face: Pt[] = [
      [-92, -104, 3],
      [-152, -88, 4],
      [-152, 16, 4],
      [-92, 0, 3],
    ];
    b += `<path d="${rp(face, 4)}" fill="${lighten(shellC, 0.06)}"/>`;
    b += `<path d="${rp(face, 4)}" fill="url(#gsh)" opacity="0.12"/>`;
    // the tinted window in the door
    b += `<path d="${rp(
      [
        [-100, -94, 3],
        [-144, -82, 3],
        [-144, 4, 3],
        [-100, -8, 3],
      ],
      3,
    )}" fill="#5c6a63" opacity="0.9"/>`;
    b += `<path d="${rp(
      [
        [-100, -94, 3],
        [-144, -82, 3],
        [-144, 4, 3],
        [-100, -8, 3],
      ],
      3,
    )}" fill="url(#glo)" opacity="0.22"/>`;
    // handle down the outer edge, and the hinge line
    b += `<path d="${rp(
      [
        [-156, -86, 3],
        [-148, -88, 3],
        [-148, 16, 3],
        [-156, 14, 3],
      ],
      3,
    )}" fill="#b7bab5"/>`;
    b += `<line x1="-92" y1="-104" x2="-92" y2="0" stroke="${darken(shellC, 0.3)}" stroke-width="3" opacity="0.6"/>`;
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** small desk fan on a stand */
function deskFan(o: { x: number; y: number; s?: number; flip?: boolean }): string {
  const bodyC = "#e2e3de";
  let b = shadow(2, 0, 26, 6, 0.22);
  b += `<ellipse cx="0" cy="-4" rx="26" ry="7" fill="${darken(bodyC, 0.2)}"/>`;
  b += `<rect x="-4" y="-52" width="8" height="48" rx="4" fill="${darken(bodyC, 0.12)}"/>`;
  b += g(
    `<circle cx="0" cy="0" r="34" fill="${bodyC}"/>
     <circle cx="0" cy="0" r="34" fill="url(#gsh)" opacity="0.14"/>
     <circle cx="0" cy="0" r="27" fill="#5f6b66"/>
     <g stroke="${bodyC}" stroke-width="2.4" opacity="0.85">
       <circle cx="0" cy="0" r="21" fill="none"/><circle cx="0" cy="0" r="13" fill="none"/><circle cx="0" cy="0" r="6" fill="none"/>
       <line x1="-27" y1="0" x2="27" y2="0"/><line x1="0" y1="-27" x2="0" y2="27"/>
       <line x1="-19" y1="-19" x2="19" y2="19"/><line x1="-19" y1="19" x2="19" y2="-19"/>
     </g>
     <circle cx="0" cy="0" r="6" fill="#8d9490"/>`,
    { x: 0, y: -76, s: 0.92 },
  );
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** beach towel lying flat, in slight perspective */
function towel(o: {
  x: number;
  y: number;
  s?: number;
  rot?: number;
  a?: string;
  b?: string;
  w?: number;
  h?: number;
}): string {
  const A = o.a ?? "#e46f5a";
  const B = o.b ?? "#f3e7d2";
  const w = o.w ?? 130;
  const h = o.h ?? 56;
  let b = shadow(3, 4, w * 0.5, h * 0.22, 0.16);
  const shape: Pt[] = [
    [-w / 2, -h / 2, 5],
    [w / 2, -h / 2 - 4, 5],
    [w / 2 + 4, h / 2, 5],
    [-w / 2 - 3, h / 2 + 3, 5],
  ];
  b += `<path d="${rp(shape, 5)}" fill="${B}"/>`;
  b += `<clipPath id="tw${Math.round(o.x)}_${Math.round(o.y)}"><path d="${rp(shape, 5)}"/></clipPath>`;
  b += `<g clip-path="url(#tw${Math.round(o.x)}_${Math.round(o.y)})">`;
  for (let i = 0; i < 4; i++) {
    b += `<rect x="${n(-w / 2 - 6 + i * (w / 3.6))}" y="${n(-h / 2 - 8)}" width="${n(w / 9)}" height="${n(h + 16)}" fill="${A}" opacity="0.9"/>`;
  }
  b += `</g>`;
  b += `<path d="${rp(shape, 5)}" fill="url(#gsh)" opacity="0.12"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, rot: o.rot });
}

/** esky / cooler box */
function esky(o: { x: number; y: number; s?: number; body?: string; lid?: string }): string {
  const bd = o.body ?? "#dfe3e2";
  const ld = o.lid ?? "#2f6a8c";
  let b = shadow(3, 0, 44, 7, 0.24);
  b += `<path d="${rp(
    [
      [-42, -4, 3],
      [-38, -50, 3],
      [38, -50, 3],
      [42, -4, 3],
    ],
    4,
  )}" fill="${bd}"/>`;
  b += `<path d="${rp(
    [
      [-42, -4, 3],
      [-38, -50, 3],
      [38, -50, 3],
      [42, -4, 3],
    ],
    4,
  )}" fill="url(#gsh)" opacity="0.16"/>`;
  b += `<rect x="-44" y="-64" width="88" height="16" rx="5" fill="${ld}"/>`;
  b += `<rect x="-44" y="-64" width="88" height="6" rx="3" fill="${lighten(ld, 0.24)}"/>`;
  b += `<rect x="-12" y="-72" width="24" height="7" rx="3.5" fill="${darken(ld, 0.24)}"/>`;
  b += `<rect x="-34" y="-40" width="18" height="4" rx="2" fill="${darken(bd, 0.18)}" opacity="0.7"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** folding camp chair, 3/4 */
function campChair(o: { x: number; y: number; s?: number; flip?: boolean; fabric?: string }): string {
  const f = o.fabric ?? "#3f6b74";
  const fr = "#4a4f50";
  let b = shadow(2, 0, 34, 6, 0.22);
  b += `<g stroke="${fr}" stroke-width="6" stroke-linecap="round" fill="none">
  <line x1="-30" y1="-2" x2="6" y2="-64"/>
  <line x1="30" y1="-4" x2="-6" y2="-62"/>
  <line x1="-26" y1="-60" x2="26" y2="-62"/>
  <line x1="-22" y1="-62" x2="-20" y2="-118"/>
  <line x1="22" y1="-64" x2="20" y2="-118"/>
</g>`;
  b += `<path d="${rp(
    [
      [-26, -58, 4],
      [26, -60, 4],
      [22, -76, 4],
      [-22, -74, 4],
    ],
    4,
  )}" fill="${f}"/>`;
  b += `<path d="${rp(
    [
      [-22, -74, 5],
      [22, -76, 5],
      [20, -122, 6],
      [-20, -120, 6],
    ],
    5,
  )}" fill="${lighten(f, 0.08)}"/>`;
  b += `<path d="${rp(
    [
      [-22, -74, 5],
      [22, -76, 5],
      [20, -122, 6],
      [-20, -120, 6],
    ],
    5,
  )}" fill="url(#gsh)" opacity="0.16"/>`;
  b += `<circle cx="-24" cy="-88" r="8" fill="${darken(f, 0.14)}"/>`;
  b += `<circle cx="24" cy="-90" r="8" fill="${darken(f, 0.14)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/**
 * Striped awning rolled out from the side of a vehicle, toward the camera.
 * The canopy is a broad trapezoid — the back edge is pinned to the vehicle at
 * roof height, the front edge hangs lower (nearer) on two poles.
 */
function awning(o: {
  x: number;
  y: number;
  w: number;
  drop: number;
  poleH: number;
  s?: number;
  a?: string;
  b?: string;
}): string {
  const A = o.a ?? "#e9e2cf";
  const B = o.b ?? "#9db08a";
  const back = -o.poleH; // pinned to the vehicle
  const front = -o.poleH + o.drop; // front edge, lower and nearer
  const flare = 20; // the near edge reads a touch wider
  let b = "";
  b += shadow(o.w / 2, 4, o.w * 0.52, 12, 0.14);
  const canopy: Pt[] = [
    [0, back, 3],
    [o.w, back, 3],
    [o.w + flare, front, 5],
    [-flare, front, 5],
  ];
  b += `<path d="${rp(canopy, 4)}" fill="${A}"/>`;
  // stripes running front-to-back across the canopy
  const cid = `aw${Math.abs(Math.round(o.x * 3 + o.y * 7))}`;
  b += `<clipPath id="${cid}"><path d="${rp(canopy, 4)}"/></clipPath>`;
  b += `<g clip-path="url(#${cid})">`;
  for (let i = 0; i < 7; i++) {
    const t0 = i / 7 + 0.5 / 14;
    const t1 = t0 + 1 / 14;
    b += `<polygon points="${poly([
      [o.w * t0, back],
      [o.w * t1, back],
      [-flare + (o.w + 2 * flare) * t1, front],
      [-flare + (o.w + 2 * flare) * t0, front],
    ])}" fill="${B}"/>`;
  }
  b += `</g>`;
  b += `<path d="${rp(canopy, 4)}" fill="url(#gshUp)" opacity="0.13"/>`;
  // scalloped front valance
  b += `<path d="${rp(
    [
      [-flare, front, 4],
      [o.w + flare, front, 4],
      [o.w + flare, front + 13, 4],
      [-flare, front + 13, 4],
    ],
    4,
  )}" fill="${darken(A, 0.12)}"/>`;
  // poles at the front corners
  for (const px of [-flare + 5, o.w + flare - 5]) {
    b += `<rect x="${n(px - 2.5)}" y="${n(front + 10)}" width="5" height="${n(-front - 10)}" rx="2.5" fill="${C.steel}"/>`;
    b += `<rect x="${n(px - 2.5)}" y="${n(front + 10)}" width="2" height="${n(-front - 10)}" fill="#ffffff" opacity="0.25"/>`;
  }
  // guy ropes
  b += `<path d="M${n(-flare + 5)} ${n(front + 12)} L${n(-flare - 34)} 0" stroke="${C.steelDark}" stroke-width="2" opacity="0.55"/>`;
  b += `<path d="M${n(o.w + flare - 5)} ${n(front + 12)} L${n(o.w + flare + 34)} 0" stroke="${C.steelDark}" stroke-width="2" opacity="0.55"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** EV charging pedestal with a hanging cable */
function evCharger(o: { x: number; y: number; s?: number; flip?: boolean; cableDrop?: number }): string {
  const shell = "#f0f1ec";
  const acc = "#2f7d55";
  let b = shadow(3, 0, 26, 6, 0.24);
  b += `<rect x="-24" y="-6" width="48" height="8" rx="3" fill="${C.steelDark}"/>`;
  b += `<path d="${rp(
    [
      [-21, -6, 3],
      [-21, -156, 10],
      [21, -156, 10],
      [21, -6, 3],
    ],
    5,
  )}" fill="${shell}"/>`;
  b += `<path d="${rp(
    [
      [-21, -6, 3],
      [-21, -156, 10],
      [21, -156, 10],
      [21, -6, 3],
    ],
    5,
  )}" fill="url(#gsh)" opacity="0.12"/>`;
  b += `<rect x="-21" y="-156" width="42" height="26" rx="10" fill="${acc}"/>`;
  b += `<rect x="-14" y="-124" width="28" height="34" rx="4" fill="#2c3335"/>`;
  b += `<rect x="-14" y="-124" width="28" height="34" rx="4" fill="url(#glo)" opacity="0.14"/>`;
  b += `<circle cx="0" cy="-76" r="6" fill="${acc}"/>`;
  b += `<rect x="-16" y="-58" width="32" height="6" rx="3" fill="${darken(shell, 0.18)}"/>`;
  // cable: a hanging loop into a holstered connector
  const drop = o.cableDrop ?? 62;
  b += `<path d="M18 -112 q42 ${n(drop * 0.5)} 26 ${n(drop)} q-8 20 -22 14" fill="none" stroke="#2b2f30" stroke-width="7" stroke-linecap="round"/>`;
  b += `<rect x="16" y="${n(-112 + drop - 6)}" width="16" height="22" rx="6" fill="#3a4042" transform="rotate(12 24 ${n(-112 + drop + 5)})"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/**
 * Dumped mattress, seen obliquely from above so it reads as a mattress lying on
 * the ground rather than a flat slab: a foreshortened top face with quilting
 * and stains, plus the thick side edge below it.
 */
function mattress(o: { x: number; y: number; s?: number; rot?: number; r: Rng }): string {
  const base = "#cdc3a8";
  const r = o.r;
  // top face, in oblique projection
  const TL: number[] = [-96, -74];
  const TR: number[] = [104, -50];
  const BR: number[] = [128, 6];
  const BL: number[] = [-78, -16];
  const depth = 15;
  let b = shadow(14, 18, 122, 18, 0.26);
  // side edge (the thickness of the mattress), below the top face
  b += `<path d="${rp(
    [
      [BL[0]!, BL[1]!, 5],
      [BR[0]!, BR[1]!, 5],
      [BR[0]!, BR[1]! + depth, 6],
      [BL[0]!, BL[1]! + depth, 6],
    ],
    6,
  )}" fill="${darken(base, 0.2)}"/>`;
  b += `<path d="${rp(
    [
      [BR[0]!, BR[1]!, 5],
      [TR[0]!, TR[1]!, 5],
      [TR[0]!, TR[1]! + depth, 6],
      [BR[0]!, BR[1]! + depth, 6],
    ],
    6,
  )}" fill="${darken(base, 0.3)}"/>`;
  // top face
  const top: Pt[] = [
    [TL[0]!, TL[1]!, 10],
    [TR[0]!, TR[1]!, 10],
    [BR[0]!, BR[1]!, 10],
    [BL[0]!, BL[1]!, 10],
  ];
  b += `<path d="${rp(top, 11)}" fill="${base}"/>`;
  b += `<path d="${rp(top, 11)}" fill="url(#gsh)" opacity="0.1"/>`;
  const cid = `mt${Math.abs(Math.round(o.x * 5 + o.y * 11))}`;
  b += `<clipPath id="${cid}"><path d="${rp(top, 11)}"/></clipPath>`;
  b += `<g clip-path="url(#${cid})">`;
  // stains soaked into the ticking
  const stains = ["#9c8154", "#87704f", "#786343", "#a8946a"];
  for (let i = 0; i < 7; i++) {
    const t = r.f(0.1, 0.9);
    const u = r.f(0.15, 0.85);
    const sx = TL[0]! + (TR[0]! - TL[0]!) * t + (BL[0]! - TL[0]!) * u;
    const sy = TL[1]! + (TR[1]! - TL[1]!) * t + (BL[1]! - TL[1]!) * u;
    const rx = r.f(16, 40);
    b += `<ellipse cx="${n(sx)}" cy="${n(sy)}" rx="${n(rx)}" ry="${n(rx * r.f(0.4, 0.62))}" fill="${r.pick(stains)}" opacity="${n(r.f(0.34, 0.6))}" filter="url(#soft)"/>`;
  }
  // quilting, following the two axes of the top face
  b += `<g stroke="${darken(base, 0.2)}" stroke-width="1.8" opacity="0.55" fill="none">`;
  for (let i = 1; i < 6; i++) {
    const t = i / 6;
    b += `<line x1="${n(TL[0]! + (TR[0]! - TL[0]!) * t)}" y1="${n(TL[1]! + (TR[1]! - TL[1]!) * t)}" x2="${n(BL[0]! + (BR[0]! - BL[0]!) * t)}" y2="${n(BL[1]! + (BR[1]! - BL[1]!) * t)}"/>`;
  }
  for (let j = 1; j < 3; j++) {
    const u = j / 3;
    b += `<line x1="${n(TL[0]! + (BL[0]! - TL[0]!) * u)}" y1="${n(TL[1]! + (BL[1]! - TL[1]!) * u)}" x2="${n(TR[0]! + (BR[0]! - TR[0]!) * u)}" y2="${n(TR[1]! + (BR[1]! - TR[1]!) * u)}"/>`;
  }
  b += `</g>`;
  // buttons at the quilt intersections
  for (let i = 1; i < 6; i++) {
    for (let j = 1; j < 3; j++) {
      const t = i / 6;
      const u = j / 3;
      const px = TL[0]! + (TR[0]! - TL[0]!) * t + (BL[0]! - TL[0]!) * u;
      const py = TL[1]! + (TR[1]! - TL[1]!) * t + (BL[1]! - TL[1]!) * u;
      b += `<circle cx="${n(px)}" cy="${n(py)}" r="2.8" fill="${darken(base, 0.32)}" opacity="0.6"/>`;
    }
  }
  b += `</g>`;
  // piped binding around the top edge (subtle — not a tray rim)
  b += `<path d="${rp(top, 11)}" fill="none" stroke="${lighten(base, 0.16)}" stroke-width="4" stroke-linejoin="round"/>`;
  b += `<ellipse cx="${n((TL[0]! + BL[0]!) / 2)}" cy="${n((TL[1]! + BL[1]!) / 2)}" rx="20" ry="26" fill="${darken(base, 0.1)}" opacity="0.3" filter="url(#soft)"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, rot: o.rot });
}

/** small bar fridge */
function barFridge(o: { x: number; y: number; s?: number; rot?: number; open?: boolean }): string {
  const shell = "#dcded7";
  let b = shadow(4, 0, 46, 9, 0.26);
  b += `<path d="${rp(
    [
      [-44, 0, 3],
      [44, 0, 3],
      [44, -104, 5],
      [-44, -104, 5],
    ],
    5,
  )}" fill="${shell}"/>`;
  b += `<path d="${rp(
    [
      [-44, 0, 3],
      [44, 0, 3],
      [44, -104, 5],
      [-44, -104, 5],
    ],
    5,
  )}" fill="url(#gsh)" opacity="0.18"/>`;
  b += `<rect x="-44" y="-76" width="88" height="3" fill="${darken(shell, 0.24)}" opacity="0.7"/>`;
  b += `<rect x="26" y="-70" width="7" height="34" rx="3.5" fill="${C.steelDark}"/>`;
  b += `<rect x="-38" y="-6" width="76" height="6" rx="2" fill="${darken(shell, 0.3)}" opacity="0.6"/>`;
  // dents / grime
  b += `<ellipse cx="-16" cy="-40" rx="14" ry="10" fill="${darken(shell, 0.16)}" opacity="0.35"/>`;
  b += `<ellipse cx="10" cy="-92" rx="18" ry="7" fill="${darken(shell, 0.2)}" opacity="0.28"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, rot: o.rot });
}

/** park barbecue: stainless plate on a masonry plinth */
function bbq(o: { x: number; y: number; s?: number }): string {
  const plinth = "#b9b2a3";
  let b = shadow(4, 0, 78, 10, 0.24);
  b += `<path d="${rp(
    [
      [-64, 0, 2],
      [64, 0, 2],
      [58, -66, 3],
      [-58, -66, 3],
    ],
    4,
  )}" fill="${plinth}"/>`;
  b += `<path d="${rp(
    [
      [-64, 0, 2],
      [64, 0, 2],
      [58, -66, 3],
      [-58, -66, 3],
    ],
    4,
  )}" fill="url(#gsh)" opacity="0.2"/>`;
  // plate
  b += `<path d="${rp(
    [
      [-72, -66, 3],
      [72, -66, 3],
      [66, -80, 3],
      [-66, -80, 3],
    ],
    3,
  )}" fill="${C.steel}"/>`;
  b += `<path d="${rp(
    [
      [-66, -80, 3],
      [66, -80, 3],
      [62, -86, 3],
      [-62, -86, 3],
    ],
    3,
  )}" fill="${lighten(C.steel, 0.28)}"/>`;
  b += `<rect x="-58" y="-79" width="116" height="4" fill="${darken(C.steel, 0.3)}" opacity="0.5"/>`;
  // control button
  b += `<circle cx="46" cy="-46" r="8" fill="${C.steelDark}"/>`;
  b += `<circle cx="46" cy="-46" r="4" fill="${lighten(C.steel, 0.2)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** rough cardboard sign with illegible pencil strokes */
function cardboardSign(o: { x: number; y: number; s?: number; rot?: number; r: Rng }): string {
  const cd = "#c9a878";
  let b = `<path d="${rp(
    [
      [-40, 0, 2],
      [42, -3, 2],
      [40, -54, 2],
      [-38, -50, 2],
    ],
    2,
  )}" fill="${cd}"/>`;
  b += `<path d="${rp(
    [
      [-40, 0, 2],
      [42, -3, 2],
      [40, -54, 2],
      [-38, -50, 2],
    ],
    2,
  )}" fill="url(#gsh)" opacity="0.14"/>`;
  // illegible marker strokes (deliberately not letters)
  b += `<g stroke="#3a3630" stroke-width="4" stroke-linecap="round" opacity="0.8">`;
  for (let i = 0; i < 3; i++) {
    const y = -40 + i * 13;
    let x = -30;
    while (x < 30) {
      const w = o.r.f(5, 13);
      b += `<line x1="${n(x)}" y1="${n(y + o.r.f(-1.5, 1.5))}" x2="${n(x + w)}" y2="${n(y + o.r.f(-1.5, 1.5))}"/>`;
      x += w + o.r.f(4, 8);
    }
  }
  b += `</g>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, rot: o.rot });
}

/** Melbourne-ish tram, side view, no livery text */
function tram(o: { x: number; y: number; s?: number; flip?: boolean }): string {
  const body = "#8fae4d";
  const bandC = C.yellow;
  let b = shadow(6, 2, 214, 12, 0.24);
  const shell: Pt[] = [
    [-210, -14, 6],
    [-214, -104, 14],
    [-204, -116, 16],
    [204, -116, 16],
    [214, -104, 14],
    [210, -14, 6],
  ];
  b += `<path d="${rp(shell, 8)}" fill="${body}"/>`;
  b += `<path d="${rp(shell, 8)}" fill="url(#gsh)" opacity="0.16"/>`;
  // window band
  b += `<rect x="-198" y="-104" width="396" height="40" rx="8" fill="#2f3a3e"/>`;
  b += `<rect x="-198" y="-104" width="396" height="40" rx="8" fill="url(#glo)" opacity="0.12"/>`;
  for (let i = 0; i < 7; i++) {
    b += `<rect x="${n(-190 + i * 56)}" y="-106" width="7" height="44" fill="${body}"/>`;
  }
  // yellow band
  b += `<rect x="-212" y="-56" width="424" height="13" fill="${bandC}" opacity="0.9"/>`;
  // doors
  for (const dx of [-120, 110]) {
    b += `<rect x="${dx - 22}" y="-104" width="44" height="86" rx="4" fill="${darken(body, 0.22)}" opacity="0.6"/>`;
    b += `<rect x="${dx - 1.5}" y="-104" width="3" height="86" fill="${darken(body, 0.4)}" opacity="0.7"/>`;
  }
  // front glass + light
  b += `<rect x="188" y="-100" width="24" height="34" rx="6" fill="#2f3a3e"/>`;
  b += `<rect x="180" y="-32" width="26" height="10" rx="4" fill="#e8e2cc" opacity="0.9"/>`;
  // skirt + bogies
  b += `<rect x="-206" y="-22" width="412" height="12" rx="4" fill="${darken(body, 0.42)}"/>`;
  for (const bx of [-150, 0, 150]) {
    b += `<rect x="${bx - 34}" y="-16" width="68" height="14" rx="5" fill="#2a2d2e"/>`;
    b += `<circle cx="${bx - 20}" cy="-6" r="9" fill="#232526"/><circle cx="${bx + 20}" cy="-6" r="9" fill="#232526"/>`;
  }
  // pantograph
  b += `<path d="M-30 -116 L-6 -156 L34 -156 L58 -118" fill="none" stroke="#4b504f" stroke-width="5" stroke-linecap="round"/>`;
  b += `<rect x="-14" y="-162" width="66" height="5" rx="2" fill="#4b504f"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** tram tracks embedded in the road, receding */
function tramTracks(o: {
  yNear: number;
  xNearL: number;
  xNearR: number;
  vpx: number;
  vpy: number;
  t: number;
}): string {
  let b = "";
  for (const x of [o.xNearL, o.xNearR]) {
    const far = vp(x, o.yNear, o.vpx, o.vpy, o.t);
    const nw = 9;
    const fw = nw * (1 - o.t);
    // rail groove (dark) then the polished rail head
    b += `<polygon points="${poly([
      [x - nw, o.yNear],
      [x + nw, o.yNear],
      [far[0] + fw, far[1]],
      [far[0] - fw, far[1]],
    ])}" fill="#2b2b29"/>`;
    b += `<polygon points="${poly([
      [x - nw * 0.42, o.yNear],
      [x + nw * 0.42, o.yNear],
      [far[0] + fw * 0.42, far[1]],
      [far[0] - fw * 0.42, far[1]],
    ])}" fill="${lighten(C.steel, 0.24)}" opacity="0.9"/>`;
  }
  return b;
}

/** green painted bike lane with white edge lines, receding */
function bikeLane(o: {
  xNearL: number;
  xNearR: number;
  yNear: number;
  vpx: number;
  vpy: number;
  t: number;
}): string {
  const fl = vp(o.xNearL, o.yNear, o.vpx, o.vpy, o.t);
  const fr = vp(o.xNearR, o.yNear, o.vpx, o.vpy, o.t);
  let b = `<polygon points="${poly([
    [o.xNearL, o.yNear],
    [o.xNearR, o.yNear],
    [fr[0], fr[1]],
    [fl[0], fl[1]],
  ])}" fill="#3f7a52"/>`;
  b += `<polygon points="${poly([
    [o.xNearL, o.yNear],
    [o.xNearR, o.yNear],
    [fr[0], fr[1]],
    [fl[0], fl[1]],
  ])}" fill="url(#gshUp)" opacity="0.12"/>`;
  // edge lines
  for (const [xn, fp] of [
    [o.xNearL, fl],
    [o.xNearR, fr],
  ] as [number, [number, number]][]) {
    const w = 9;
    const fw = w * (1 - o.t);
    b += `<polygon points="${poly([
      [xn - w / 2, o.yNear],
      [xn + w / 2, o.yNear],
      [fp[0] + fw / 2, fp[1]],
      [fp[0] - fw / 2, fp[1]],
    ])}" fill="${C.paint}" opacity="0.85"/>`;
  }
  return b;
}

/** stormwater channel: concrete trapezoid with a shallow watercourse */
function stormDrain(o: { yNear: number; yFar: number; r: Rng }): string {
  const cw = "#c4c0b2";
  let b = "";
  // outer banks
  b += `<polygon points="${poly([
    [-40, o.yNear],
    [W + 40, o.yNear],
    [W - 120, o.yFar],
    [120, o.yFar],
  ])}" fill="${cw}"/>`;
  // sloped walls (lighter on the left = light from upper-left)
  b += `<polygon points="${poly([
    [-40, o.yNear],
    [250, o.yNear],
    [330, o.yFar],
    [120, o.yFar],
  ])}" fill="${lighten(cw, 0.14)}"/>`;
  b += `<polygon points="${poly([
    [W + 40, o.yNear],
    [960, o.yNear],
    [880, o.yFar],
    [W - 120, o.yFar],
  ])}" fill="${darken(cw, 0.14)}"/>`;
  // channel floor
  b += `<polygon points="${poly([
    [250, o.yNear],
    [960, o.yNear],
    [880, o.yFar],
    [330, o.yFar],
  ])}" fill="${darken(cw, 0.06)}"/>`;
  // expansion joints
  for (let i = 1; i < 5; i++) {
    const t = i / 5;
    const a = [250 + (330 - 250) * t, o.yNear + (o.yFar - o.yNear) * t];
    const bb = [960 + (880 - 960) * t, o.yNear + (o.yFar - o.yNear) * t];
    b += `<line x1="${n(a[0]!)}" y1="${n(a[1]!)}" x2="${n(bb[0]!)}" y2="${n(bb[1]!)}" stroke="${darken(cw, 0.22)}" stroke-width="${n(3 * (1 - t))}" opacity="0.5"/>`;
  }
  // shallow water trickle
  b += `<polygon points="${poly([
    [470, o.yNear],
    [700, o.yNear],
    [640, o.yFar],
    [520, o.yFar],
  ])}" fill="#78909a" opacity="0.55"/>`;
  b += `<polygon points="${poly([
    [510, o.yNear],
    [610, o.yNear],
    [592, o.yFar],
    [548, o.yFar],
  ])}" fill="#a8bfc4" opacity="0.4"/>`;
  // grime along the waterline
  b += `<polygon points="${poly([
    [462, o.yNear],
    [486, o.yNear],
    [534, o.yFar],
    [516, o.yFar],
  ])}" fill="#6f7a5e" opacity="0.35"/>`;
  return b;
}

/* ------------------------------------------------------------------ *
 * people (faceless) and animals
 * ------------------------------------------------------------------ */

const SIL = "#262b2a";
const SIL2 = "#39423f";

/** standing / walking figure seen from behind */
function personBack(o: { x: number; y: number; s?: number; shirt?: string; flip?: boolean; stride?: number }): string {
  const shirt = o.shirt ?? SIL2;
  const st = o.stride ?? 1;
  let b = shadow(2, 0, 20, 5, 0.2);
  b += `<path d="${rp(
    [
      [-8, 0, 3],
      [-9, -44, 3],
      [-2, -44, 3],
      [-1, 0, 3],
    ],
    3,
  )}" fill="${SIL}"/>`;
  b += `<path d="${rp(
    [
      [2 + 5 * st, 0, 3],
      [1, -44, 3],
      [8, -44, 3],
      [9 + 5 * st, 0, 3],
    ],
    3,
  )}" fill="${SIL}"/>`;
  b += `<path d="${rp(
    [
      [-15, -40, 6],
      [-13, -84, 8],
      [13, -84, 8],
      [15, -40, 6],
    ],
    7,
  )}" fill="${shirt}"/>`;
  b += `<path d="${rp(
    [
      [-15, -40, 6],
      [-13, -84, 8],
      [13, -84, 8],
      [15, -40, 6],
    ],
    7,
  )}" fill="url(#gsh)" opacity="0.14"/>`;
  b += `<circle cx="0" cy="-96" r="11" fill="${SIL}"/>`;
  b += `<rect x="-4" y="-88" width="8" height="8" fill="${SIL}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** figure seen from behind pushing a pram */
function personPram(o: { x: number; y: number; s?: number; flip?: boolean; shirt?: string }): string {
  const shirt = o.shirt ?? "#4a5a63";
  const frame = "#4d5453";
  const pram = "#33424b";
  // Unflipped the figure walks to the right; the pram is ahead of it, and the
  // handle post sweeps back and up into the figure's hands.
  let b = shadow(26, 0, 52, 7, 0.2);
  const basin: Pt[] = [
    [8, -42, 8],
    [74, -38, 8],
    [68, -74, 12],
    [4, -78, 14],
  ];
  // frame
  b += `<path d="M16 -15 L78 -11" stroke="${frame}" stroke-width="5" stroke-linecap="round"/>`;
  b += `<path d="M16 -15 L-2 -68" stroke="${frame}" stroke-width="5.5" stroke-linecap="round"/>`;
  b += `<path d="M78 -11 L56 -44" stroke="${frame}" stroke-width="5" stroke-linecap="round"/>`;
  b += `<path d="M-2 -68 L-16 -71" stroke="${frame}" stroke-width="5.5" stroke-linecap="round"/>`;
  // wheels
  b += `<circle cx="16" cy="-15" r="14" fill="#2b2f2e"/><circle cx="16" cy="-15" r="4.6" fill="${C.steel}"/>`;
  b += `<circle cx="78" cy="-11" r="10" fill="#2b2f2e"/><circle cx="78" cy="-11" r="3.4" fill="${C.steel}"/>`;
  // bassinet + hood
  b += `<path d="${rp(basin, 10)}" fill="${pram}"/>`;
  b += `<path d="${rp(basin, 10)}" fill="url(#gsh)" opacity="0.16"/>`;
  b += `<path d="M4 -74 a30 30 0 0 1 30 -28 l4 30 z" fill="${darken(pram, 0.24)}"/>`;
  b += `<rect x="8" y="-58" width="64" height="4" rx="2" fill="${lighten(pram, 0.18)}" opacity="0.55"/>`;
  // figure from behind, hands on the handle
  b += personBack({ x: -22, y: 0, shirt, stride: 1.1 });
  b += `<path d="M-12 -76 Q-6 -72 -6 -68" stroke="${shirt}" stroke-width="8" fill="none" stroke-linecap="round"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** side view of a person with a walking frame; hat brim hides the face */
function personFrame(o: { x: number; y: number; s?: number; flip?: boolean; shirt?: string }): string {
  const shirt = o.shirt ?? "#6c6f63";
  let b = shadow(4, 0, 30, 6, 0.22);
  // frame
  b += `<g stroke="${C.steel}" stroke-width="5" stroke-linecap="round" fill="none">
  <line x1="26" y1="-2" x2="28" y2="-70"/>
  <line x1="42" y1="-4" x2="44" y2="-70"/>
  <line x1="26" y1="-70" x2="46" y2="-70"/>
  <line x1="26" y1="-36" x2="44" y2="-36"/>
</g>`;
  b += `<circle cx="26" cy="0" r="5" fill="#2b2f2e"/><circle cx="43" cy="-2" r="5" fill="#2b2f2e"/>`;
  // legs (slightly apart, standing)
  b += `<path d="${rp(
    [
      [-10, 0, 3],
      [-11, -42, 3],
      [-3, -42, 3],
      [-1, 0, 3],
    ],
    3,
  )}" fill="${SIL}"/>`;
  b += `<path d="${rp(
    [
      [4, 0, 3],
      [1, -42, 3],
      [9, -42, 3],
      [12, 0, 3],
    ],
    3,
  )}" fill="${darken(SIL, 0.15)}"/>`;
  // slightly stooped torso
  b += `<path d="${rp(
    [
      [-14, -38, 6],
      [-8, -80, 8],
      [14, -82, 8],
      [14, -38, 6],
    ],
    7,
  )}" fill="${shirt}"/>`;
  b += `<path d="${rp(
    [
      [-14, -38, 6],
      [-8, -80, 8],
      [14, -82, 8],
      [14, -38, 6],
    ],
    7,
  )}" fill="url(#gsh)" opacity="0.14"/>`;
  // arm to the frame
  b += `<path d="M10 -76 Q24 -74 32 -68" stroke="${shirt}" stroke-width="7.5" fill="none" stroke-linecap="round"/>`;
  // head + broad hat brim (face hidden)
  b += `<circle cx="8" cy="-92" r="10" fill="${SIL}"/>`;
  b += `<ellipse cx="9" cy="-99" rx="21" ry="5" fill="${darken(shirt, 0.3)}"/>`;
  b += `<path d="M0 -99 q9 -12 18 0 z" fill="${darken(shirt, 0.3)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** walking figure, side on, cap brim over the face */
function personSide(o: { x: number; y: number; s?: number; flip?: boolean; shirt?: string }): string {
  const shirt = o.shirt ?? "#54636b";
  let b = shadow(3, 0, 22, 5, 0.2);
  b += `<path d="M-4 0 L-14 -44 L-4 -46 L4 -2 Z" fill="${SIL}"/>`;
  b += `<path d="M10 0 L2 -44 L12 -46 L18 -2 Z" fill="${darken(SIL, 0.12)}"/>`;
  b += `<path d="${rp(
    [
      [-8, -40, 6],
      [-6, -82, 8],
      [14, -82, 8],
      [12, -40, 6],
    ],
    7,
  )}" fill="${shirt}"/>`;
  b += `<path d="M8 -76 Q18 -62 14 -48" stroke="${shirt}" stroke-width="7.5" fill="none" stroke-linecap="round"/>`;
  b += `<circle cx="6" cy="-93" r="10.5" fill="${SIL}"/>`;
  b += `<path d="M-4 -96 q10 -8 20 -2 l4 4 l-26 2 z" fill="${darken(shirt, 0.34)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** crouching figure (picking something up), seen from behind/side */
function personCrouch(o: { x: number; y: number; s?: number; flip?: boolean; shirt?: string }): string {
  const shirt = o.shirt ?? "#c4703f";
  let b = shadow(3, 0, 26, 6, 0.2);
  b += `<path d="M-16 0 Q-20 -22 -4 -30 L10 -26 L12 0 Z" fill="${SIL}"/>`;
  b += `<path d="${rp(
    [
      [-14, -24, 6],
      [-4, -62, 8],
      [16, -60, 8],
      [12, -22, 6],
    ],
    7,
  )}" fill="${shirt}"/>`;
  b += `<path d="M12 -56 Q26 -44 24 -24" stroke="${shirt}" stroke-width="7.5" fill="none" stroke-linecap="round"/>`;
  b += `<circle cx="6" cy="-72" r="10" fill="${SIL}"/>`;
  b += `<path d="M-4 -74 q10 -9 20 -2 l3 3 l-25 2 z" fill="${darken(shirt, 0.34)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** cyclist seen from behind */
function cyclistBack(o: { x: number; y: number; s?: number; shirt?: string; lean?: number }): string {
  const shirt = o.shirt ?? "#c9522f";
  let b = shadow(2, 0, 24, 5, 0.22);
  // rear wheel + frame hint
  b += `<ellipse cx="0" cy="-26" rx="10" ry="26" fill="none" stroke="#2b2f2e" stroke-width="5"/>`;
  b += `<ellipse cx="0" cy="-26" rx="10" ry="26" fill="none" stroke="#5a6163" stroke-width="1.4" opacity="0.7"/>`;
  b += `<path d="M0 -50 L0 -74" stroke="#4d5453" stroke-width="5" stroke-linecap="round"/>`;
  // handlebars
  b += `<path d="M-26 -86 L26 -86" stroke="#4d5453" stroke-width="5" stroke-linecap="round"/>`;
  // legs
  b += `<path d="M-10 -44 L-8 -76 M10 -46 L8 -76" stroke="${SIL}" stroke-width="10" stroke-linecap="round"/>`;
  // torso leaning forward
  b += `<path d="${rp(
    [
      [-17, -74, 6],
      [-14, -110, 9],
      [14, -110, 9],
      [17, -74, 6],
    ],
    8,
  )}" fill="${shirt}"/>`;
  b += `<path d="${rp(
    [
      [-17, -74, 6],
      [-14, -110, 9],
      [14, -110, 9],
      [17, -74, 6],
    ],
    8,
  )}" fill="url(#gsh)" opacity="0.14"/>`;
  // arms out to the bars
  b += `<path d="M-13 -104 Q-24 -96 -25 -86 M13 -104 Q24 -96 25 -86" stroke="${shirt}" stroke-width="7" fill="none" stroke-linecap="round"/>`;
  // helmet
  b += `<path d="${rp(
    [
      [-12, -114, 4],
      [12, -114, 4],
      [11, -128, 10],
      [-11, -128, 10],
    ],
    8,
  )}" fill="#2f3a3e"/>`;
  b += `<path d="M-12 -118 L12 -118" stroke="#e8e2cc" stroke-width="2.5" opacity="0.55"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, rot: o.lean });
}

/** dog, side on, no face detail */
function dogSide(o: { x: number; y: number; s?: number; flip?: boolean; colour?: string }): string {
  const c = o.colour ?? "#8a7256";
  let b = shadow(2, 0, 26, 5, 0.2);
  // legs
  b += `<g stroke="${darken(c, 0.2)}" stroke-width="6" stroke-linecap="round">
  <line x1="-16" y1="-4" x2="-18" y2="-26"/><line x1="-6" y1="-2" x2="-10" y2="-26"/>
  <line x1="16" y1="-4" x2="16" y2="-28"/><line x1="26" y1="-2" x2="24" y2="-28"/></g>`;
  // body
  b += `<path d="${rp(
    [
      [-24, -26, 10],
      [26, -28, 10],
      [30, -46, 12],
      [-24, -44, 12],
    ],
    11,
  )}" fill="${c}"/>`;
  // chest/neck to head
  b += `<path d="${rp(
    [
      [22, -40, 6],
      [36, -50, 6],
      [34, -62, 6],
      [20, -54, 6],
    ],
    6,
  )}" fill="${c}"/>`;
  // head (muzzle + ear, no eye)
  b += `<path d="${rp(
    [
      [28, -56, 6],
      [50, -60, 5],
      [50, -70, 5],
      [28, -70, 8],
    ],
    6,
  )}" fill="${lighten(c, 0.06)}"/>`;
  b += `<circle cx="32" cy="-66" r="10" fill="${lighten(c, 0.06)}"/>`;
  b += `<path d="M26 -72 q-4 -12 6 -10 z" fill="${darken(c, 0.24)}"/>`;
  b += `<circle cx="50" cy="-64" r="3" fill="${darken(c, 0.55)}"/>`;
  // tail
  b += `<path d="M-24 -40 q-16 -6 -18 -24" fill="none" stroke="${c}" stroke-width="7" stroke-linecap="round"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** paw prints running away along a path */
function pawPrints(o: { pts: number[][]; s?: number; colour?: string; opacity?: number }): string {
  const col = o.colour ?? "#a8977a";
  let b = "";
  for (let i = 0; i < o.pts.length; i++) {
    const [x, y, sc] = o.pts[i]!;
    const s = (sc ?? 1) * (o.s ?? 1);
    const side = i % 2 === 0 ? -1 : 1;
    b += g(
      `<ellipse cx="0" cy="0" rx="7" ry="6" fill="${col}"/>
       <circle cx="-6" cy="-8" r="2.8" fill="${col}"/>
       <circle cx="-1" cy="-10.5" r="2.8" fill="${col}"/>
       <circle cx="4.5" cy="-9.5" r="2.8" fill="${col}"/>
       <circle cx="8.5" cy="-5" r="2.6" fill="${col}"/>`,
      { x: x! + side * 5 * s, y: y!, s, op: o.opacity ?? 0.7 },
    );
  }
  return b;
}

/* ------------------------------------------------------------------ *
 * buildings / backdrops
 * ------------------------------------------------------------------ */

/** a row of suburban shopfronts with blank awnings (no signage text) */
function shopRow(o: {
  y: number;
  x0: number;
  x1: number;
  h?: number;
  r: Rng;
  awningY?: number;
}): string {
  const h = o.h ?? 250;
  const r = o.r;
  const top = o.y - h;
  const awY = o.awningY ?? o.y - 118;
  const facades = ["#cfc7b8", "#bdb3a1", "#d6cfc0", "#b3a996", "#c6c3b6", "#c9bda9"];
  const awnings = ["#6f8272", "#8d8168", "#5f7484", "#8f7f60", "#74796d", "#7d6f62"];
  let b = "";
  let x = o.x0;
  let i = 0;
  while (x < o.x1) {
    const w = r.f(160, 220);
    const fc = facades[i % facades.length]!;
    const parapet = top + r.f(0, 30);
    // upper storey wall
    b += `<rect x="${n(x)}" y="${n(parapet)}" width="${n(w)}" height="${n(o.y - parapet)}" fill="${fc}"/>`;
    b += `<rect x="${n(x)}" y="${n(parapet)}" width="${n(w)}" height="11" fill="${darken(fc, 0.2)}"/>`;
    b += `<rect x="${n(x)}" y="${n(parapet + 11)}" width="${n(w)}" height="6" fill="${lighten(fc, 0.22)}"/>`;
    // upper-storey windows (two small dark panes)
    for (let k = 0; k < 2; k++) {
      b += `<rect x="${n(x + w * (0.22 + k * 0.38))}" y="${n(parapet + 40)}" width="${n(w * 0.2)}" height="${n(Math.min(52, awY - parapet - 62))}" rx="2" fill="#4b565a" opacity="0.7"/>`;
    }
    // fascia band above the awning (blank — no signage text)
    b += `<rect x="${n(x + 4)}" y="${n(awY - 26)}" width="${n(w - 8)}" height="24" fill="${lighten(fc, 0.26)}"/>`;
    b += `<rect x="${n(x + 4)}" y="${n(awY - 26)}" width="${n(w - 8)}" height="24" fill="url(#gsh)" opacity="0.1"/>`;
    // recessed shopfront under the awning, framed by masonry pilasters
    const pil = 15;
    b += `<rect x="${n(x)}" y="${n(awY)}" width="${n(w)}" height="${n(o.y - awY)}" fill="${darken(fc, 0.38)}"/>`;
    const inner = w - pil * 2;
    const gw = (inner - 10) / 3;
    for (let k = 0; k < 3; k++) {
      const isDoor = k === 2;
      const gx = x + pil + k * (gw + 5);
      b += `<rect x="${n(gx)}" y="${n(awY + 14)}" width="${n(gw)}" height="${n(o.y - awY - 14 - (isDoor ? 0 : 5))}" fill="${isDoor ? "#2c3839" : "#41504e"}"/>`;
      b += `<rect x="${n(gx)}" y="${n(awY + 14)}" width="${n(gw)}" height="${n((o.y - awY) * 0.4)}" fill="url(#glo)" opacity="0.18"/>`;
    }
    // pilasters, lit from the upper left
    b += `<rect x="${n(x)}" y="${n(awY)}" width="${n(pil)}" height="${n(o.y - awY)}" fill="${lighten(fc, 0.1)}"/>`;
    b += `<rect x="${n(x + w - pil)}" y="${n(awY)}" width="${n(pil)}" height="${n(o.y - awY)}" fill="${darken(fc, 0.14)}"/>`;
    b += `<rect x="${n(x)}" y="${n(o.y - 12)}" width="${n(w)}" height="12" fill="${darken(fc, 0.28)}"/>`;
    // awning: canopy sloping down and out, plus a valance. Shops each get their
    // own canopy with a visible gap, so the row doesn't read as one long band.
    const ac = awnings[i % awnings.length]!;
    const ax0 = x + 6;
    const ax1 = x + w - 6;
    const canopy: Pt[] = [
      [ax0, awY - 6, 2],
      [ax1, awY - 6, 2],
      [ax1 + 9, awY + 20, 3],
      [ax0 - 9, awY + 20, 3],
    ];
    b += `<path d="${rp(canopy, 3)}" fill="${ac}"/>`;
    b += `<path d="${rp(canopy, 3)}" fill="url(#glo)" opacity="0.18"/>`;
    b += `<path d="${rp(
      [
        [ax0 - 9, awY + 20, 2],
        [ax1 + 9, awY + 20, 2],
        [ax1 + 9, awY + 33, 2],
        [ax0 - 9, awY + 33, 2],
      ],
      2,
    )}" fill="${darken(ac, 0.28)}"/>`;
    // under-awning shade on the shopfront
    b += `<rect x="${n(x)}" y="${n(awY + 33)}" width="${n(w)}" height="30" fill="#000000" opacity="0.13"/>`;
    x += w + 3;
    i++;
  }
  return b;
}

/**
 * Large blank retail facade (supermarket / shopping centre). `entryX` places
 * the entry canopy, `tint` shifts the masonry, so the seven car-park scenes
 * that use it don't all read as the same building.
 */
function retailFacade(o: {
  y: number;
  x0: number;
  x1: number;
  h?: number;
  r: Rng;
  tint?: string;
  entryX?: number;
  glazeY?: number;
}): string {
  const h = o.h ?? 168;
  const top = o.y - h;
  const fc = o.tint ?? "#cdc7b7";
  const wid = o.x1 - o.x0;
  const ex = o.entryX ?? (o.x0 + o.x1) / 2;
  let b = `<rect x="${n(o.x0)}" y="${n(top)}" width="${n(wid)}" height="${n(h)}" fill="${fc}"/>`;
  // stepped parapet, so the roofline isn't one dead-flat rule
  b += `<rect x="${n(o.x0)}" y="${n(top)}" width="${n(wid)}" height="14" fill="${darken(fc, 0.18)}"/>`;
  b += `<rect x="${n(ex - 250)}" y="${n(top - 26)}" width="500" height="30" fill="${lighten(fc, 0.1)}"/>`;
  b += `<rect x="${n(ex - 250)}" y="${n(top - 26)}" width="500" height="12" fill="${darken(fc, 0.18)}"/>`;
  b += `<rect x="${n(o.x0)}" y="${n(top)}" width="${n(wid)}" height="${n(h)}" fill="url(#gsh)" opacity="0.1"/>`;
  // pilaster rhythm across the blank wall
  for (let x = o.x0 + 60; x < o.x1; x += 172) {
    b += `<rect x="${n(x)}" y="${n(top + 14)}" width="16" height="${n(h - 14)}" fill="${lighten(fc, 0.09)}"/>`;
  }
  // glazing kept to a low band, mullions widely spaced
  const gy = o.glazeY ?? o.y - 62;
  b += `<rect x="${n(o.x0)}" y="${n(gy)}" width="${n(wid)}" height="${n(o.y - gy)}" fill="#4b5754" opacity="0.9"/>`;
  b += `<rect x="${n(o.x0)}" y="${n(gy)}" width="${n(wid)}" height="${n((o.y - gy) * 0.55)}" fill="url(#glo)" opacity="0.17"/>`;
  for (let x = o.x0 + 112; x < o.x1; x += 112) {
    b += `<rect x="${n(x)}" y="${n(gy)}" width="6" height="${n(o.y - gy)}" fill="${fc}" opacity="0.85"/>`;
  }
  // entry: recessed doors under a canopy
  b += `<rect x="${n(ex - 96)}" y="${n(gy - 6)}" width="192" height="${n(o.y - gy + 6)}" fill="#37413f"/>`;
  b += `<rect x="${n(ex - 3)}" y="${n(gy - 6)}" width="6" height="${n(o.y - gy + 6)}" fill="${fc}" opacity="0.7"/>`;
  b += `<rect x="${n(ex - 120)}" y="${n(gy - 26)}" width="240" height="22" rx="4" fill="${lighten(fc, 0.28)}"/>`;
  b += `<rect x="${n(ex - 120)}" y="${n(gy - 8)}" width="240" height="8" fill="#000000" opacity="0.16"/>`;
  // blank sign band above the entry
  b += `<rect x="${n(ex - 138)}" y="${n(top + 24)}" width="276" height="40" rx="4" fill="${lighten(fc, 0.34)}"/>`;
  b += `<rect x="${n(ex - 138)}" y="${n(top + 24)}" width="276" height="40" rx="4" fill="url(#gsh)" opacity="0.1"/>`;
  // shadow the building casts onto the tarmac
  b += `<rect x="${n(o.x0)}" y="${n(o.y)}" width="${n(wid)}" height="16" fill="#000000" opacity="0.18"/>`;
  void o.r;
  return b;
}

/** car park light pole */
function lightPole(o: { x: number; y: number; s?: number; flip?: boolean }): string {
  let b = shadow(4, 0, 12, 4, 0.2);
  b += `<rect x="-5" y="-250" width="10" height="250" rx="4" fill="#7c8280"/>`;
  b += `<rect x="-5" y="-250" width="3.5" height="250" fill="#ffffff" opacity="0.18"/>`;
  b += `<path d="M0 -250 q0 -18 26 -18 l26 0" fill="none" stroke="#7c8280" stroke-width="9" stroke-linecap="round"/>`;
  b += `<path d="${rp(
    [
      [40, -268, 2],
      [76, -268, 2],
      [70, -280, 3],
      [46, -280, 3],
    ],
    3,
  )}" fill="#8d9391"/>`;
  b += `<rect x="40" y="-269" width="36" height="5" rx="2.5" fill="#dfe3de"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1, flip: o.flip });
}

/** planted kerb island splitting rows of bays */
function kerbIsland(o: { x: number; y: number; w: number; s?: number; r: Rng }): string {
  const hw = o.w / 2;
  let b = `<path d="${rp(
    [
      [-hw, 0, 10],
      [hw, 0, 10],
      [hw - 10, -22, 8],
      [-hw + 10, -22, 8],
    ],
    9,
  )}" fill="${C.kerb}"/>`;
  b += `<path d="${rp(
    [
      [-hw, -8, 10],
      [hw, -8, 10],
      [hw - 10, -22, 8],
      [-hw + 10, -22, 8],
    ],
    9,
  )}" fill="${lighten(C.kerb, 0.16)}"/>`;
  b += `<ellipse cx="0" cy="-20" rx="${n(hw - 14)}" ry="9" fill="#8c8a6e"/>`;
  b += shrub({ x: -hw * 0.5, y: -20, s: 0.62, r: o.r });
  b += shrub({ x: hw * 0.45, y: -20, s: 0.54, r: o.r, colour: C.euc });
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** scattered takeaway rubbish: flat boxes, bottles, wrappers */
function rubbishPile(o: { x: number; y: number; s?: number; r: Rng; spread?: number; count?: number }): string {
  const r = o.r;
  const spread = o.spread ?? 90;
  let b = "";
  // pizza boxes, stacked and askew
  const boxC = ["#d8c49a", "#cbb488", "#e0cfa8"];
  for (let i = 0; i < 3; i++) {
    const bx = r.f(-spread * 0.7, spread * 0.5);
    const by = -i * 9 - r.f(0, 4);
    const bw = r.f(46, 62);
    b += g(
      `<path d="${rp(
        [
          [-bw / 2, 0, 2],
          [bw / 2, -3, 2],
          [bw / 2, -11, 2],
          [-bw / 2, -8, 2],
        ],
        2,
      )}" fill="${r.pick(boxC)}"/>
       <path d="${rp(
         [
           [-bw / 2, -8, 2],
           [bw / 2, -11, 2],
           [bw / 2, -14, 2],
           [-bw / 2, -11, 2],
         ],
         2,
       )}" fill="${lighten(r.pick(boxC), 0.2)}"/>`,
      { x: bx, y: by, rot: r.f(-6, 6) },
    );
  }
  // bottles and cans
  const drinks = ["#6b8f5f", "#8a6a3c", "#8f9aa0", "#b8ac8a"];
  for (let i = 0; i < (o.count ?? 5); i++) {
    const bx = r.f(-spread, spread);
    const col = r.pick(drinks);
    const h = r.f(24, 38);
    const lying = r.next() > 0.55;
    const shape = `<path d="${rp(
      [
        [-6, 0, 2],
        [6, 0, 2],
        [6, -h * 0.68, 3],
        [3.5, -h * 0.82, 2],
        [3.5, -h, 1.5],
        [-3.5, -h, 1.5],
        [-3.5, -h * 0.82, 2],
        [-6, -h * 0.68, 3],
      ],
      2,
    )}" fill="${col}"/>
    <rect x="-6" y="${n(-h * 0.5)}" width="3" height="${n(h * 0.4)}" fill="#ffffff" opacity="0.2"/>`;
    b += g(shape, { x: bx, y: r.f(-6, 2), rot: lying ? r.f(74, 102) : r.f(-4, 4) });
  }
  // wrappers / paper scraps
  for (let i = 0; i < 6; i++) {
    const bx = r.f(-spread * 1.15, spread * 1.15);
    const by = r.f(-4, 10);
    b += `<path d="${rp(
      [
        [-9, 0, 2],
        [4, -4, 2],
        [10, 3, 2],
        [-3, 6, 2],
      ],
      3,
    )}" fill="${r.pick(["#e8e2d2", "#d9d2bd", "#cf7f5f", "#efe8d8"])}" opacity="0.95" transform="translate(${n(bx)},${n(by)}) rotate(${n(r.f(-40, 40))})"/>`;
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** traffic cone */
function cone(o: { x: number; y: number; s?: number }): string {
  return g(
    `${shadow(2, 0, 15, 4, 0.22)}
     <path d="${rp(
       [
         [-16, 0, 3],
         [16, 0, 3],
         [6, -38, 3],
         [-6, -38, 3],
       ],
       3,
     )}" fill="#e2762e"/>
     <path d="${rp(
       [
         [-16, 0, 3],
         [16, 0, 3],
         [6, -38, 3],
         [-6, -38, 3],
       ],
       3,
     )}" fill="url(#gsh)" opacity="0.16"/>
     <path d="M-11 -18 L11 -18 L9 -26 L-9 -26 Z" fill="#f0ece0"/>`,
    { x: o.x, y: o.y, s: o.s ?? 1 },
  );
}

/** soccer goal, seen roughly face on */
function goal(o: { x: number; y: number; s?: number }): string {
  const p = "#eceadf";
  let b = `<g stroke="${p}" stroke-width="7" fill="none" stroke-linecap="round">
  <line x1="-120" y1="0" x2="-120" y2="-88"/>
  <line x1="120" y1="0" x2="120" y2="-88"/>
  <line x1="-124" y1="-88" x2="124" y2="-88"/></g>`;
  // net: light hatch
  b += `<g stroke="${p}" stroke-width="1.5" opacity="0.5">`;
  for (let i = 1; i < 14; i++) b += `<line x1="${n(-120 + i * 17)}" y1="-86" x2="${n(-116 + i * 16)}" y2="-2"/>`;
  for (let j = 1; j < 6; j++) b += `<line x1="-119" y1="${n(-86 + j * 15)}" x2="119" y2="${n(-86 + j * 15)}"/>`;
  b += `</g>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** guard rail beside a road, receding */
function guardRail(o: { x0: number; y0: number; x1: number; y1: number; s0?: number; s1?: number; posts?: number }): string {
  const s0 = o.s0 ?? 1;
  const s1 = o.s1 ?? 0.3;
  const posts = o.posts ?? 9;
  const top: number[][] = [];
  const bot: number[][] = [];
  let p = "";
  for (let i = 0; i < posts; i++) {
    const t = Math.pow(i / (posts - 1), 1.4);
    const x = o.x0 + (o.x1 - o.x0) * t;
    const y = o.y0 + (o.y1 - o.y0) * t;
    const s = s0 + (s1 - s0) * t;
    p += `<rect x="${n(x - 4 * s)}" y="${n(y - 52 * s)}" width="${n(8 * s)}" height="${n(52 * s)}" fill="#7e837f"/>`;
    top.push([x, y - 48 * s]);
    bot.push([x, y - 34 * s]);
  }
  const beam = `<polygon points="${poly([...top, ...bot.slice().reverse()])}" fill="${C.steel}"/>`;
  const beamHi = `<polyline points="${poly(top)}" fill="none" stroke="${lighten(C.steel, 0.3)}" stroke-width="3"/>`;
  return p + beam + beamHi;
}

/** muddy footprints tracking across grass */
function footprints(o: { pts: number[][]; s?: number; colour?: string }): string {
  const col = o.colour ?? "#6d5c42";
  let b = "";
  for (let i = 0; i < o.pts.length; i++) {
    const [x, y, sc] = o.pts[i]!;
    const s = (sc ?? 1) * (o.s ?? 1);
    const side = i % 2 === 0 ? -1 : 1;
    b += `<ellipse cx="${n(x! + side * 6 * s)}" cy="${n(y!)}" rx="${n(6 * s)}" ry="${n(3.4 * s)}" fill="${col}" opacity="${n(0.42 + 0.3 * (i / o.pts.length))}"/>`;
  }
  return b;
}

/** tied-off rubbish bag */
function rubbishBag(o: { x: number; y: number; s?: number; colour?: string; r: Rng }): string {
  const col = o.colour ?? "#3a4a44";
  let b = shadow(3, 0, 32, 6, 0.24);
  b += `<path d="${rp(
    [
      [-32, -2, 10],
      [-36, -52, 22],
      [-14, -78, 10],
      [16, -78, 10],
      [36, -50, 22],
      [32, -2, 10],
    ],
    14,
  )}" fill="${col}"/>`;
  b += `<path d="${rp(
    [
      [-32, -2, 10],
      [-36, -52, 22],
      [-14, -78, 10],
      [16, -78, 10],
      [36, -50, 22],
      [32, -2, 10],
    ],
    14,
  )}" fill="url(#glo)" opacity="0.13"/>`;
  // knot
  b += `<path d="M-13 -76 q6 -16 14 -6 q8 -12 13 4 z" fill="${darken(col, 0.2)}"/>`;
  // creases
  for (let i = 0; i < 4; i++) {
    b += `<path d="M${n(o.r.f(-26, 20))} ${n(o.r.f(-64, -14))} q8 ${n(o.r.f(-12, 12))} 16 ${n(o.r.f(-6, 10))}" fill="none" stroke="${darken(col, 0.24)}" stroke-width="2" opacity="0.45"/>`;
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** small knotted dog-waste bag */
function dogBag(o: { x: number; y: number; s?: number; colour?: string }): string {
  const col = o.colour ?? "#4f7a4a";
  let b = `<path d="${rp(
    [
      [-17, -4, 10],
      [-19, -30, 10],
      [-6, -40, 5],
      [8, -40, 5],
      [19, -28, 10],
      [17, -4, 12],
    ],
    10,
  )}" fill="${col}"/>`;
  b += `<path d="${rp(
    [
      [-17, -4, 10],
      [-19, -30, 10],
      [-6, -40, 5],
      [8, -40, 5],
      [19, -28, 10],
      [17, -4, 12],
    ],
    10,
  )}" fill="url(#glo)" opacity="0.16"/>`;
  b += `<path d="M-7 -38 q5 -14 9 -4 q6 -10 8 2 z" fill="${darken(col, 0.22)}"/>`;
  b += `<path d="M-11 -26 q4 6 3 14" fill="none" stroke="${darken(col, 0.2)}" stroke-width="2" opacity="0.5"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** marram / dune grass tuft */
function duneGrass(o: { x: number; y: number; s?: number; r: Rng; count?: number }): string {
  return reeds({ ...o, colour: "#a8ac74", count: o.count ?? 9 });
}

/** supermarket shelving bay, seen face on */
function shelfUnit(o: { x: number; y: number; w: number; shelves: number; gap: number; s?: number }): string {
  const back = "#d5d2c6";
  let b = `<rect x="${n(-o.w / 2)}" y="${n(-o.shelves * o.gap - 20)}" width="${n(o.w)}" height="${n(o.shelves * o.gap + 20)}" fill="${back}"/>`;
  b += `<rect x="${n(-o.w / 2)}" y="${n(-o.shelves * o.gap - 20)}" width="${n(o.w)}" height="${n(o.shelves * o.gap + 20)}" fill="url(#gsh)" opacity="0.12"/>`;
  for (let i = 0; i <= o.shelves; i++) {
    const y = -i * o.gap;
    b += `<rect x="${n(-o.w / 2 - 6)}" y="${n(y - 9)}" width="${n(o.w + 12)}" height="9" rx="2" fill="${C.steel}"/>`;
    b += `<rect x="${n(-o.w / 2 - 6)}" y="${n(y - 9)}" width="${n(o.w + 12)}" height="3.5" rx="1.5" fill="${lighten(C.steel, 0.3)}"/>`;
    b += `<rect x="${n(-o.w / 2 - 6)}" y="${n(y)}" width="${n(o.w + 12)}" height="7" fill="#000000" opacity="0.16"/>`;
  }
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/** a packet of biscuits: blank pack with an abstract shape, no text */
function packet(o: { x: number; y: number; w: number; h: number; colour: string; s?: number }): string {
  let b = `<path d="${rp(
    [
      [-o.w / 2, 0, 2],
      [o.w / 2, 0, 2],
      [o.w / 2, -o.h, 4],
      [-o.w / 2, -o.h, 4],
    ],
    3,
  )}" fill="${o.colour}"/>`;
  b += `<path d="${rp(
    [
      [-o.w / 2, 0, 2],
      [o.w / 2, 0, 2],
      [o.w / 2, -o.h, 4],
      [-o.w / 2, -o.h, 4],
    ],
    3,
  )}" fill="url(#glo)" opacity="0.14"/>`;
  b += `<circle cx="0" cy="${n(-o.h * 0.58)}" r="${n(Math.min(o.w, o.h) * 0.24)}" fill="${lighten(o.colour, 0.42)}" opacity="0.8"/>`;
  b += `<rect x="${n(-o.w * 0.32)}" y="${n(-o.h * 0.26)}" width="${n(o.w * 0.64)}" height="${n(o.h * 0.1)}" rx="3" fill="${lighten(o.colour, 0.34)}" opacity="0.7"/>`;
  b += `<rect x="${n(-o.w / 2)}" y="${n(-o.h)}" width="${n(o.w)}" height="4" fill="${darken(o.colour, 0.24)}"/>`;
  return g(b, { x: o.x, y: o.y, s: o.s ?? 1 });
}

/* ------------------------------------------------------------------ *
 * scene assembly
 * ------------------------------------------------------------------ */

type Scene = { key: string; render: (r: Rng) => { defs?: string; body: string; sky: SkyVariant } };

const scenes: Scene[] = [];
const scene = (key: string, render: Scene["render"]) => scenes.push({ key, render });

/* --- 1. parking-footpath-01 ------------------------------------------
   Dark SUV parked side-on right across a concrete footpath outside a row
   of shops; a pram-pusher is forced off the path onto the road. Empty
   bays with white lines in the background. */
scene("parking-footpath-01", (r) => {
  const shopBase = 452;
  let b = sky(300, "day", r);
  b += treeline(292, r, "#93a291", 26);
  b += shopRow({ y: shopBase, x0: -40, x1: W + 60, h: 268, r, awningY: 356 });

  b += footpath({ yNear: 620, yFar: shopBase, colour: C.concreteDark });
  b += kerb(620, 20, 10);

  // road
  b += band(650, H, C.asphalt);
  b += asphaltSpeckle(650, H, r, 300);
  b += groundShade(650, H, "gsh", 0.24);
  // visibly empty parking bays along the kerb
  b += parkingBays({
    xs: [770, 900, 1055, 1235],
    yNear: 900,
    t: 0.5,
    vpx: 470,
    vpy: 600,
    w: 14,
    opacity: 0.72,
  });
  // the line along the kerb side of the bays
  b += `<polygon points="${poly([
    [660, 736],
    [1240, 736],
    [1240, 745],
    [660, 745],
  ])}" fill="${C.paint}" opacity="0.5"/>`;

  // someone using the footpath as intended, further along
  b += personSide({ x: 1024, y: 596, s: 0.66, flip: true, shirt: "#6a7a72" });
  b += signPost({
    x: 96,
    y: 620,
    s: 0.6,
    h: 148,
    panel: `<circle cx="0" cy="0" r="17" fill="none" stroke="#2f4d86" stroke-width="7"/><rect x="-19" y="-5" width="38" height="10" rx="3" fill="#2f4d86" transform="rotate(-38)"/>`,
  });
  b += bollard({ x: 1136, y: 622, s: 0.6 });

  // SUBJECT: dark SUV parked side-on right across the footpath
  b += carSide("suv", { x: 606, y: 612, s: 1.18, colour: "#333a3d", r, flip: true });

  // pram-pusher forced off the path, onto the road
  b += personPram({ x: 356, y: 792, s: 1.16, flip: true, shirt: "#4a5a63" });
  return { body: b, sky: "day" };
});

/** shared beach staging: sky, sea, wet sand, dry sand */
function beachGround(o: {
  horizon: number;
  wetY: number;
  dryY: number;
  r: Rng;
  variant?: SkyVariant;
  sand?: string;
}): string {
  const sand = o.sand ?? C.sand;
  let b = sky(o.horizon, o.variant ?? "day", o.r);
  // sea
  b += `<rect x="-2" y="${n(o.horizon - 2)}" width="${W + 4}" height="${n(o.wetY - o.horizon + 2)}" fill="${C.sea}"/>`;
  b += `<rect x="-2" y="${n(o.horizon - 2)}" width="${W + 4}" height="${n(o.wetY - o.horizon + 2)}" fill="url(#gshUp)" opacity="0.16"/>`;
  // swell lines
  for (let i = 0; i < 5; i++) {
    const y = o.horizon + (o.wetY - o.horizon) * Math.pow(i / 5, 1.5) + 6;
    b += `<rect x="-2" y="${n(y)}" width="${W + 4}" height="${n(2 + i * 0.9)}" fill="${lighten(C.sea, 0.3)}" opacity="${n(0.25 + i * 0.05)}"/>`;
  }
  // breaking foam
  b += `<path d="M-2 ${n(o.wetY - 12)} q120 -10 240 0 t240 0 t240 0 t240 0 t240 0 L${W + 2} ${n(o.wetY + 8)} L-2 ${n(o.wetY + 8)} Z" fill="#eef3f2" opacity="0.9"/>`;
  // wet sand
  b += `<rect x="-2" y="${n(o.wetY)}" width="${W + 4}" height="${n(o.dryY - o.wetY)}" fill="${darken(sand, 0.2)}"/>`;
  b += `<rect x="-2" y="${n(o.wetY)}" width="${W + 4}" height="${n(o.dryY - o.wetY)}" fill="url(#glo)" opacity="0.14"/>`;
  // dry sand
  b += `<path d="M-2 ${n(o.dryY + 8)} q160 -14 320 -2 t320 0 t320 2 t260 -2 L${W + 2} ${H} L-2 ${H} Z" fill="${sand}"/>`;
  b += groundShade(o.dryY, H, "gsh", 0.12);
  return b;
}

/** a distant row of cars nose-in against the building, to fill the far tarmac */
function farCarRow(r: Rng, o: { y: number; s: number; xs: number[] }): string {
  const kinds: VehicleKind[] = ["hatch", "sedan", "suv", "wagon", "hatch", "sedan"];
  const cols = ["#9aa4a8", "#b4ada0", "#6f7a80", "#8f7f63", "#c3c0b6", "#5f6f75", "#a8a293"];
  let b = "";
  o.xs.forEach((x, i) => {
    b += carRear(kinds[(i + 1) % kinds.length]!, {
      x: x + r.f(-5, 5),
      y: o.y + r.f(-3, 3),
      s: o.s * r.f(0.93, 1.07),
      colour: cols[(i * 3 + 1) % cols.length]!,
      r,
      noShadow: true,
    });
  });
  return b;
}

/** supermarket / shopping-centre car park backdrop, varied per scene */
function carParkBack(
  r: Rng,
  o: {
    horizon: number;
    base: number;
    variant?: SkyVariant;
    tint?: string;
    entryX?: number;
    h?: number;
    trees?: boolean;
  },
): string {
  let b = sky(o.horizon, o.variant ?? "day", r);
  if (o.trees !== false) b += treeline(o.horizon + 2, r, "#8fa08b", 24);
  b += retailFacade({
    y: o.base,
    x0: -40,
    x1: W + 40,
    h: o.h ?? 150,
    r,
    tint: o.tint,
    entryX: o.entryX,
  });
  return b;
}

/* --- 2. shopping-trolley-01 ------------------------------------------
   A lone trolley abandoned in the middle of an empty bay, with the
   trolley return bay plainly visible behind it. */
scene("shopping-trolley-01", (r) => {
  const base = 356;
  let b = carParkBack(r, { horizon: 262, base, tint: "#c9c0ac", entryX: 250, h: 158 });
  b += band(base, H, C.asphalt);
  b += asphaltSpeckle(base, H, r, 320);
  b += groundShade(base, H, "gsh", 0.24);
  b += parkingBays({
    xs: [-200, 60, 320, 580, 840, 1100, 1360],
    yNear: 920,
    t: 0.7,
    vpx: 620,
    vpy: 348,
    w: 17,
    headLine: true,
  });
  b += farCarRow(r, { y: 402, s: 0.4, xs: [70, 158, 246, 334, 422, 510, 598, 686] });
  b += lightPole({ x: 1058, y: 640, s: 0.95 });
  // trolley return bay, mid ground right — the place it should have gone
  b += trolleyBay({ x: 902, y: 568, s: 0.98 });
  b += trolleyNest({ x: 888, y: 562, s: 0.6, count: 3, step: 22 });
  // SUBJECT: the lone trolley, dead centre of an empty bay
  b += trolley({ x: 478, y: 792, s: 2.05, handle: C.yellow, basket: "#b0b7ba" });
  return { body: b, sky: "day" };
});

/* --- 3. parking-accessible-01 ----------------------------------------
   Hatchback sitting in an accessible bay with its hazards on and no
   permit on the dash. */
scene("parking-accessible-01", (r) => {
  const base = 344;
  let b = carParkBack(r, { horizon: 258, base, tint: "#c4beb0", entryX: 940, h: 152 });
  b += band(base, H, C.asphalt);
  b += asphaltSpeckle(base, H, r, 320);
  b += groundShade(base, H, "gsh", 0.24);
  // one wide accessible bay in the middle, ordinary bays either side
  b += parkingBays({
    xs: [100, 330, 452, 748, 870, 1100],
    yNear: 920,
    t: 0.66,
    vpx: 600,
    vpy: 340,
    w: 16,
    headLine: true,
  });
  // hatched buffer alongside the accessible bay
  for (let i = 0; i < 6; i++) {
    const x0 = 340 + i * 22;
    const a = vp(x0, 916, 600, 340, 0.08);
    const bb = vp(x0 + 74, 916, 600, 340, 0.3);
    b += `<polygon points="${poly([
      [a[0], a[1]],
      [a[0] + 10, a[1]],
      [bb[0] + 10, bb[1]],
      [bb[0], bb[1]],
    ])}" fill="${C.paint}" opacity="0.4"/>`;
  }
  b += wheelchairPaint({ x: 600, y: 836, s: 1.75, opacity: 0.82 });
  b += farCarRow(r, { y: 392, s: 0.38, xs: [64, 148, 232, 316, 400, 484, 568, 1004, 1088, 1172] });
  b += lightPole({ x: 158, y: 636, s: 0.9, flip: true });
  // the sign
  b += signPost({
    x: 264,
    y: 628,
    s: 1.06,
    h: 176,
    w: 70,
    ph: 88,
    face: "#3560a8",
    border: "#eeeade",
    panel: `${g(
      `<circle cx="0" cy="-16" r="7" fill="#eeeade"/>
       <path d="${rp(
         [
           [-5, -6],
           [3, -6],
           [6, 10],
           [19, 10],
           [19, 17],
           [1, 17],
           [-6, 6],
         ],
         3,
       )}" fill="#eeeade"/>
       <path d="M-16 -1 A 19 19 0 1 0 14 21" fill="none" stroke="#eeeade" stroke-width="5" stroke-linecap="round"/>`,
      { x: -2, y: 2, s: 1 },
    )}`,
  });
  // SUBJECT: parked in it anyway, hazards flashing, nothing on the dash
  b += carRear("hatch", { x: 600, y: 690, s: 1.62, colour: "#c8ccc6", r, hazard: true });
  return { body: b, sky: "day" };
});

/* --- 4. parking-two-bays-01 ------------------------------------------
   White sedan straddling the painted line between two bays. */
scene("parking-two-bays-01", (r) => {
  const base = 350;
  let b = carParkBack(r, { horizon: 264, base, tint: "#d2ccbc", entryX: 690, h: 146 });
  b += band(base, H, C.asphalt);
  b += asphaltSpeckle(base, H, r, 320);
  b += groundShade(base, H, "gsh", 0.24);
  b += parkingBays({
    xs: [-60, 170, 390, 600, 810, 1030, 1260],
    yNear: 924,
    t: 0.66,
    vpx: 600,
    vpy: 344,
    w: 17,
    headLine: true,
  });
  // neighbours parked correctly, to make the straddle obvious
  b += carRear("suv", { x: 262, y: 660, s: 1.0, colour: "#5d6a70", r });
  b += carRear("hatch", { x: 946, y: 660, s: 1.0, colour: "#8f7f63", r });
  b += farCarRow(r, { y: 398, s: 0.38, xs: [60, 144, 228, 312, 396, 480, 812, 896, 980, 1064, 1148] });
  b += trolleyBay({ x: 1120, y: 566, s: 0.72 });
  b += lightPole({ x: 118, y: 632, s: 0.86, flip: true });
  // SUBJECT: sitting square on the line between two bays
  b += carRear("sedan", { x: 604, y: 736, s: 1.66, colour: "#eceae2", r });
  return { body: b, sky: "day" };
});

/* --- 5. dog-bag-fence-01 ---------------------------------------------
   Knotted green dog-waste bag left hanging on a dune fence post. */
scene("dog-bag-fence-01", (r) => {
  let b = beachGround({ horizon: 268, wetY: 402, dryY: 470, r, variant: "day" });
  // dune fence running away to the right
  b += duneFence({ x0: -40, y0: 830, x1: 1010, y1: 486, posts: 12, s0: 2.5, s1: 0.42 });
  // dune grass along the fence
  for (let i = 0; i < 9; i++) {
    const t = Math.pow(i / 8, 1.3);
    b += duneGrass({ x: -20 + t * 1040, y: 838 - t * 348, s: 1.5 - t * 1.1, r, count: 8 });
  }
  b += duneGrass({ x: 1090, y: 640, s: 1.5, r, count: 11 });
  b += duneGrass({ x: 224, y: 872, s: 1.9, r, count: 12 });
  // SUBJECT: the bag, knotted onto the nearest post
  b += `<path d="M312 690 q10 20 4 44" fill="none" stroke="${darken("#4f7a4a", 0.34)}" stroke-width="6" stroke-linecap="round"/>`;
  b += dogBag({ x: 318, y: 806, s: 2.9 });
  b += shadow(346, 852, 44, 10, 0.16);
  return { body: b, sky: "day" };
});

/* --- 6. rubbish-picnic-01 --------------------------------------------
   Lakeside picnic table buried in takeaway rubbish, with a public bin
   only a few metres away. */
scene("rubbish-picnic-01", (r) => {
  const horizon = 286;
  let b = sky(horizon, "day", r);
  b += treeline(horizon, r, "#6f8468", 42);
  // lake
  b += `<rect x="-2" y="${horizon}" width="${W + 4}" height="96" fill="#5f93a6"/>`;
  b += `<rect x="-2" y="${horizon}" width="${W + 4}" height="96" fill="url(#gshUp)" opacity="0.18"/>`;
  for (let i = 0; i < 5; i++) {
    b += `<rect x="${n(r.f(-20, 800))}" y="${n(horizon + 18 + i * 15)}" width="${n(r.f(120, 380))}" height="3" rx="1.5" fill="#a8ccd6" opacity="0.4"/>`;
  }
  // grass bank
  b += `<path d="M-2 384 q200 -12 420 -4 t420 6 t364 -6 L${W + 2} ${H} L-2 ${H} Z" fill="${C.eucMid}"/>`;
  b += `<rect x="-2" y="384" width="${W + 4}" height="${H - 384}" fill="url(#gsh)" opacity="0.16"/>`;
  // shoreline reeds and trees
  b += reeds({ x: 120, y: 400, s: 1.5, r, count: 16 });
  b += reeds({ x: 980, y: 398, s: 1.3, r, count: 14 });
  b += gumTree({ x: 158, y: 404, s: 0.72, r, lean: -5 });
  b += gumTree({ x: 1074, y: 412, s: 0.86, r, lean: 6 });
  b += shrub({ x: 856, y: 452, s: 0.9, r });
  // the bin, a few metres away
  b += councilBin({ x: 986, y: 700, s: 1.5 });
  // SUBJECT: the picnic table, buried
  b += picnicTable({ x: 466, y: 780, s: 1.5 });
  b += rubbishPile({ x: 442, y: 668, s: 1.42, r, spread: 104, count: 7 });
  b += rubbishPile({ x: 632, y: 812, s: 1.1, r, spread: 92, count: 5 });
  return { body: b, sky: "day" };
});

/* --- 7. road-tailgate-01 ---------------------------------------------
   Rear-camera view: a 4WD sitting far too close on a wet mountain road. */
scene("road-tailgate-01", (r) => {
  const horizon = 258;
  let b = sky(horizon, "rain", r);
  // ridge line behind
  b += `<path d="M-20 ${horizon} L160 ${horizon - 78} L360 ${horizon - 24} L560 ${horizon - 92} L800 ${horizon - 30} L1020 ${horizon - 70} L${W + 20} ${horizon - 14} L${W + 20} ${horizon + 10} L-20 ${horizon + 10} Z" fill="#7c8a84" opacity="0.75"/>`;
  b += treeline(horizon + 8, r, "#5d6f61", 40);
  // verge
  b += band(horizon + 6, H, "#6d7a63");
  // the road: one ribbon swinging away to the left as it climbs
  b += `<path d="M-180 ${H} L1180 ${H} Q900 600 560 ${horizon + 46} L404 ${horizon + 40} Q300 610 -430 ${H} Z" fill="${C.asphalt}"/>`;
  b += `<path d="M-180 ${H} L1180 ${H} Q900 600 560 ${horizon + 46} L404 ${horizon + 40} Q300 610 -430 ${H} Z" fill="url(#glo)" opacity="0.07"/>`;
  // gravel shoulders
  b += `<path d="M404 ${horizon + 40} Q300 610 -430 ${H} L-520 ${H} Q250 600 388 ${horizon + 38} Z" fill="#8d8a70" opacity="0.8"/>`;
  // wet sheen streaks down the road
  for (let i = 0; i < 16; i++) {
    const x = r.f(200, 1180);
    const y = r.f(560, H);
    b += `<rect x="${n(x)}" y="${n(y)}" width="${n(r.f(2, 5))}" height="${n(r.f(28, 90))}" rx="2" fill="#c6d4d6" opacity="${n(r.f(0.05, 0.14))}"/>`;
  }
  // centre line following the curve
  b += `<path d="M380 ${H} Q420 620 480 ${horizon + 44}" fill="none" stroke="${C.paint}" stroke-width="13" opacity="0.5" stroke-dasharray="48 42" stroke-linecap="round"/>`;
  // guard rail on the outside of the bend
  b += guardRail({ x0: 1210, y0: 806, x1: 596, y1: horizon + 58, s0: 1.5, s1: 0.24, posts: 11 });
  b += gumTree({ x: 106, y: 460, s: 0.9, r, lean: -8 });
  b += gumTree({ x: 1136, y: 392, s: 0.6, r, lean: 7 });
  b += shrub({ x: 246, y: 468, s: 0.7, r, colour: "#5f7d5a" });
  // puddles
  b += puddle(360, 848, 130, 22, "#7f939a", 0.4);
  b += puddle(980, 806, 96, 16, "#7f939a", 0.32);
  // SUBJECT: the 4WD, right on the bumper
  b += carFront("fourwd", { x: 636, y: 846, s: 2.6, colour: "#6b7a72", r, bullbar: true });
  // spray thrown up around its wheels
  b += `<ellipse cx="470" cy="828" rx="70" ry="18" fill="#dde6e6" opacity="0.24" filter="url(#soft)"/>`;
  b += `<ellipse cx="812" cy="828" rx="70" ry="18" fill="#dde6e6" opacity="0.24" filter="url(#soft)"/>`;
  b += rain(r, 190, 0.34);
  // reversing-camera guide lines, very faint
  b += `<g opacity="0.3" fill="none" stroke-width="7" stroke-linecap="round">
  <path d="M232 ${H} L360 792" stroke="#e8d24a"/>
  <path d="M1030 ${H} L906 792" stroke="#e8d24a"/>
  <path d="M372 786 L900 786" stroke="#e8d24a"/>
</g>`;
  return { body: b, sky: "rain" };
});

/* --- 8. shopping-trolley-drain-01 ------------------------------------
   Trolley dumped on its side in a shallow concrete stormwater drain. */
scene("shopping-trolley-drain-01", (r) => {
  const horizon = 268;
  let b = sky(horizon, "day", r);
  b += treeline(horizon + 4, r, "#7c8f74", 36);
  // grass banks behind the drain
  b += band(horizon + 6, 424, "#8fa06e");
  b += `<rect x="-2" y="${horizon + 6}" width="${W + 4}" height="${424 - horizon - 6}" fill="url(#gsh)" opacity="0.14"/>`;
  b += gumTree({ x: 138, y: 366, s: 0.6, r, lean: -6 });
  b += gumTree({ x: 1042, y: 372, s: 0.68, r, lean: 5 });
  b += shrub({ x: 420, y: 420, s: 0.7, r });
  b += shrub({ x: 792, y: 424, s: 0.8, r, colour: C.euc });
  // the channel
  b += stormDrain({ yNear: H + 20, yFar: 408, r });
  // reeds along both banks
  for (let i = 0; i < 8; i++) {
    const t = i / 7;
    b += reeds({ x: 236 - t * 150, y: 430 + t * 470, s: 0.6 + t * 1.2, r, count: 12 });
    b += reeds({ x: 964 + t * 190, y: 430 + t * 470, s: 0.6 + t * 1.2, r, count: 12 });
  }
  b += reeds({ x: 356, y: 546, s: 0.8, r, count: 11 });
  b += reeds({ x: 876, y: 558, s: 0.86, r, count: 11 });
  b += reeds({ x: 244, y: 700, s: 1.4, r, count: 13 });
  b += reeds({ x: 984, y: 720, s: 1.5, r, count: 13 });
  // SUBJECT: the trolley on its side in the channel
  b += g(trolley({ x: 0, y: 0, s: 2.1, handle: C.yellow, basket: "#aeb5b8", noShadow: true }), {
    x: 582,
    y: 790,
    rot: 82,
  });
  b += shadow(592, 846, 136, 18, 0.24);
  // silt and litter caught around it
  b += `<ellipse cx="482" cy="806" rx="92" ry="16" fill="#6f7a5e" opacity="0.3"/>`;
  b += `<ellipse cx="722" cy="822" rx="66" ry="13" fill="#6f7a5e" opacity="0.24"/>`;
  return { body: b, sky: "day" };
});

/* --- 9. neighbourhood-bins-01 ----------------------------------------
   Three wheelie bins parked right across a narrow footpath, with muddy
   footprints where people have had to go around. */
scene("neighbourhood-bins-01", (r) => {
  const horizon = 262;
  let b = sky(horizon, "day", r);
  // fence line and hedge behind
  b += band(horizon, 470, "#8ba07d");
  b += `<rect x="-2" y="${horizon}" width="${W + 4}" height="86" fill="#9db08a"/>`;
  // paling fence
  b += `<rect x="-2" y="300" width="${W + 4}" height="128" fill="${C.timber}"/>`;
  for (let i = 0; i < 46; i++) {
    b += `<rect x="${n(-6 + i * 27)}" y="300" width="23" height="128" fill="${mix(C.timber, C.timberDark, r.f(0, 0.5))}"/>`;
  }
  b += `<rect x="-2" y="300" width="${W + 4}" height="8" fill="${darken(C.timber, 0.34)}"/>`;
  b += `<rect x="-2" y="428" width="${W + 4}" height="10" fill="#000000" opacity="0.16"/>`;
  b += shrub({ x: 120, y: 470, s: 1.1, r });
  b += shrub({ x: 1088, y: 476, s: 1.25, r });
  b += gumTree({ x: 906, y: 300, s: 0.5, r, lean: 4 });
  // nature strip grass
  b += band(438, 560, "#8fa370");
  b += `<rect x="-2" y="438" width="${W + 4}" height="122" fill="url(#gshUp)" opacity="0.1"/>`;
  // narrow footpath
  b += footpath({ yNear: 688, yFar: 560, colour: C.concrete, joints: 7, conv: 0.62 });
  // nature strip in front of the path, then kerb and road
  b += band(688, 742, "#8fa370");
  b += kerb(742, 18, 9);
  b += band(769, H, C.asphalt);
  b += asphaltSpeckle(769, H, r, 200);
  b += groundShade(769, H, "gsh", 0.22);
  // muddy detour worn into the grass beside the bins
  b += `<path d="M300 700 q120 -34 250 -32 q140 2 250 30" fill="none" stroke="#7d6a4c" stroke-width="30" opacity="0.3" stroke-linecap="round"/>`;
  b += footprints({
    pts: [
      [318, 706, 1],
      [370, 696, 1],
      [424, 688, 1],
      [478, 682, 1],
      [534, 680, 1],
      [590, 682, 1],
      [646, 688, 1],
      [700, 696, 1],
      [754, 706, 1],
    ],
    s: 1.3,
  });
  // SUBJECT: three bins straight across the footpath
  b += wheelieBin({ x: 396, y: 676, s: 1.42, lid: "#d7263d", body: "#4b5350" });
  b += wheelieBin({ x: 578, y: 684, s: 1.48, lid: "#f5c400", body: "#4b5350" });
  b += wheelieBin({ x: 762, y: 676, s: 1.42, lid: "#3f7a52", body: "#4b5350" });
  return { body: b, sky: "day" };
});

/* --- 10. parking-grass-oval-01 ---------------------------------------
   Ute parked on the grass beside a junior soccer pitch. */
scene("parking-grass-oval-01", (r) => {
  const horizon = 268;
  let b = sky(horizon, "day", r);
  b += treeline(horizon + 2, r, "#7b8f72", 40);
  b += gumTree({ x: 168, y: 352, s: 0.78, r, lean: -6 });
  b += gumTree({ x: 402, y: 344, s: 0.6, r, lean: 4 });
  b += gumTree({ x: 1058, y: 358, s: 0.86, r, lean: 7 });
  // the field
  b += band(330, H, "#7f9a5f");
  b += `<rect x="-2" y="330" width="${W + 4}" height="${H - 330}" fill="url(#gsh)" opacity="0.16"/>`;
  // mown stripes
  for (let i = 0; i < 7; i++) {
    const y0 = 330 + i * 82;
    b += `<rect x="-2" y="${n(y0)}" width="${W + 4}" height="${n(40 + i * 4)}" fill="#8aa668" opacity="0.5"/>`;
  }
  // pitch markings
  b += `<path d="M-40 476 L${W + 40} 468" stroke="${C.paint}" stroke-width="5" opacity="0.6"/>`;
  b += goal({ x: 762, y: 470, s: 0.92 });
  b += cone({ x: 360, y: 500, s: 0.62 });
  b += cone({ x: 992, y: 512, s: 0.66 });
  b += cone({ x: 596, y: 486, s: 0.56 });
  b += cone({ x: 1128, y: 556, s: 0.8 });
  // tyre ruts through the grass to the ute
  b += `<path d="M-40 880 q220 -70 470 -108" fill="none" stroke="#6d6a4a" stroke-width="22" opacity="0.3" stroke-linecap="round"/>`;
  b += `<path d="M-40 826 q220 -66 460 -100" fill="none" stroke="#6d6a4a" stroke-width="18" opacity="0.24" stroke-linecap="round"/>`;
  // SUBJECT
  b += carSide("ute", { x: 556, y: 812, s: 1.62, colour: "#b9bcc0", r, flip: true });
  return { body: b, sky: "day" };
});

/* --- 11. workplace-microwave-01 --------------------------------------
   Office kitchen: microwave door hanging open with a foil container
   inside, and a desk fan aimed at it in protest. */
scene("workplace-microwave-01", () => {
  const r = rng(hashSeed("workplace-microwave-01"));
  const wall = "#dfdcd0";
  const bench = "#b9ae97";
  let b = `<rect x="-2" y="-2" width="${W + 4}" height="${H + 4}" fill="${wall}"/>`;
  // upper cupboards
  b += `<rect x="-2" y="-2" width="${W + 4}" height="196" fill="#c9c3b2"/>`;
  b += `<rect x="-2" y="186" width="${W + 4}" height="12" fill="${darken("#c9c3b2", 0.3)}"/>`;
  for (let i = 0; i < 5; i++) {
    b += `<rect x="${n(-10 + i * 250)}" y="6" width="240" height="176" rx="4" fill="#d3cdbc"/>`;
    b += `<rect x="${n(-10 + i * 250)}" y="6" width="240" height="176" rx="4" fill="url(#gsh)" opacity="0.1"/>`;
    b += `<rect x="${n(96 + i * 250)}" y="150" width="70" height="8" rx="4" fill="${C.steel}"/>`;
  }
  b += `<rect x="-2" y="196" width="${W + 4}" height="18" fill="#000000" opacity="0.13"/>`;
  // tiled splashback
  for (let j = 0; j < 4; j++) {
    for (let i = 0; i < 22; i++) {
      const off = j % 2 ? 30 : 0;
      b += `<rect x="${n(-30 + off + i * 60)}" y="${n(214 + j * 58)}" width="56" height="54" rx="2" fill="${mix("#e6e3da", "#d8d6cc", r.f(0, 1))}"/>`;
    }
  }
  b += `<rect x="-2" y="214" width="${W + 4}" height="24" fill="#000000" opacity="0.07"/>`;
  // bench top
  b += `<rect x="-2" y="446" width="${W + 4}" height="26" fill="${lighten(bench, 0.18)}"/>`;
  b += `<rect x="-2" y="446" width="${W + 4}" height="8" fill="${lighten(bench, 0.4)}"/>`;
  b += `<rect x="-2" y="472" width="${W + 4}" height="${H - 472}" fill="${bench}"/>`;
  b += `<rect x="-2" y="472" width="${W + 4}" height="${H - 472}" fill="url(#gsh)" opacity="0.2"/>`;
  // cupboard doors below the bench
  for (let i = 0; i < 5; i++) {
    b += `<rect x="${n(6 + i * 244)}" y="500" width="228" height="${H - 520}" rx="4" fill="${lighten(bench, 0.08)}"/>`;
    b += `<rect x="${n(96 + i * 244)}" y="540" width="60" height="8" rx="4" fill="${C.steel}"/>`;
  }
  b += `<rect x="-2" y="472" width="${W + 4}" height="16" fill="#000000" opacity="0.15"/>`;
  // a mug for company
  b += g(
    `${shadow(3, 0, 22, 5, 0.2)}
     <path d="${rp(
       [
         [-19, 0, 3],
         [19, 0, 3],
         [16, -42, 4],
         [-16, -42, 4],
       ],
       4,
     )}" fill="#c96f52"/>
     <path d="M19 -32 q16 10 0 20" fill="none" stroke="#c96f52" stroke-width="7"/>
     <ellipse cx="0" cy="-42" rx="16" ry="5" fill="#e8d9c8"/>`,
    { x: 1064, y: 446, s: 1.05 },
  );
  // SUBJECT: microwave, door open, foil container inside
  b += microwave({ x: 496, y: 452, s: 1.62, open: true, r });
  // the fan, aimed squarely at it
  b += deskFan({ x: 872, y: 452, s: 1.5, flip: true });
  return { body: b, sky: "day" };
});

/* --- 12. neighbourhood-speaker-01 ------------------------------------
   A big portable speaker on a towel on an otherwise empty beach. */
scene("neighbourhood-speaker-01", (r) => {
  let b = beachGround({ horizon: 262, wetY: 394, dryY: 462, r, variant: "day" });
  b += duneGrass({ x: 92, y: 862, s: 1.8, r, count: 12 });
  b += duneGrass({ x: 1132, y: 792, s: 1.4, r, count: 10 });
  // sound spreading across the empty sand
  b += soundWaves({ x: 604, y: 720, s: 2.6, count: 5, colour: "#4e6068", squash: 0.5 });
  // SUBJECT
  b += towel({ x: 592, y: 790, s: 2.0, rot: -3, a: "#c9522f", b: "#f0e6d2", w: 152, h: 62 });
  b += speaker({ x: 588, y: 782, s: 1.95 });
  return { body: b, sky: "day" };
});

/* --- 13. parking-bike-lane-01 ----------------------------------------
   White van stopped in the green bike lane; the cyclist has to swing
   out into the traffic lane to get round it. */
scene("parking-bike-lane-01", (r) => {
  const horizon = 258;
  let b = sky(horizon, "day", r);
  b += treeline(horizon, r, "#8a9b84", 26);
  // low buildings along the street
  b += shopRow({ y: 402, x0: -40, x1: W + 60, h: 176, r, awningY: 340 });
  // road
  b += band(402, H, C.asphalt);
  b += asphaltSpeckle(402, H, r, 300);
  b += groundShade(402, H, "gsh", 0.2);
  // kerb along the left
  b += `<polygon points="${poly([
    [-40, H],
    [150, H],
    [452, 404],
    [366, 404],
  ])}" fill="${C.kerb}"/>`;
  b += `<polygon points="${poly([
    [-40, H],
    [60, H],
    [420, 404],
    [366, 404],
  ])}" fill="${darken(C.kerb, 0.2)}"/>`;
  // green bike lane hugging the kerb
  b += bikeLane({ xNearL: 156, xNearR: 470, yNear: H + 10, vpx: 600, vpy: 388, t: 0.86 });
  b += bikePaint({ x: 320, y: 764, s: 1.15, opacity: 0.75 });
  b += bikePaint({ x: 468, y: 566, s: 0.6, opacity: 0.6 });
  // traffic lane markings
  b += laneDashes({ xNear: 980, yNear: H + 10, vpx: 600, vpy: 388, segs: 6 });
  b += `<polygon points="${poly([
    [1290, H],
    [1330, H],
    [720, 404],
    [706, 404],
  ])}" fill="${C.paint}" opacity="0.6"/>`;
  // SUBJECT: van sitting in the bike lane
  b += carSide("van", { x: 452, y: 690, s: 1.24, colour: "#eeece4", r, flip: true });
  // cyclist swerving out around it
  b += cyclistBack({ x: 794, y: 838, s: 1.5, shirt: "#c9522f", lean: -8 });
  return { body: b, sky: "day" };
});

/* --- 14. rubbish-mattress-01 -----------------------------------------
   A stained mattress and a bar fridge dumped in the bush beside a dirt
   track. */
scene("rubbish-mattress-01", (r) => {
  const horizon = 274;
  let b = sky(horizon, "warm", r);
  b += treeline(horizon + 6, r, "#6d8064", 46);
  // dry bush floor
  b += band(horizon + 8, H, "#a89a68");
  b += `<rect x="-2" y="${horizon + 8}" width="${W + 4}" height="${H - horizon - 8}" fill="url(#gsh)" opacity="0.18"/>`;
  // patchy grass
  for (let i = 0; i < 34; i++) {
    const y = r.f(330, H);
    const d = (y - 330) / (H - 330);
    b += `<ellipse cx="${n(r.f(-20, W + 20))}" cy="${n(y)}" rx="${n(r.f(24, 76) * (0.4 + d))}" ry="${n(r.f(5, 14) * (0.4 + d))}" fill="${r.pick([C.dryGrass, "#9aa86c", "#b3a473"])}" opacity="${n(r.f(0.2, 0.5))}"/>`;
  }
  // dirt track cutting across
  b += `<path d="M-40 ${H} q300 -220 560 -290 q250 -60 720 -80 L${W + 40} ${H} Z" fill="#a8895f"/>`;
  b += `<path d="M-40 ${H} q300 -220 560 -290 q250 -60 720 -80 L${W + 40} ${H} Z" fill="url(#gsh)" opacity="0.12"/>`;
  b += `<path d="M-30 ${H - 30} q290 -206 546 -276" fill="none" stroke="#8d7048" stroke-width="16" opacity="0.4" stroke-linecap="round"/>`;
  // gum trees
  b += gumTree({ x: 138, y: 476, s: 1.02, r, lean: -8 });
  b += gumTree({ x: 372, y: 440, s: 0.78, r, lean: 5 });
  b += gumTree({ x: 1064, y: 500, s: 1.14, r, lean: 9 });
  b += gumTree({ x: 866, y: 428, s: 0.62, r, lean: -4 });
  b += shrub({ x: 262, y: 548, s: 0.9, r, colour: "#7c8f5e" });
  b += shrub({ x: 950, y: 596, s: 1.1, r, colour: "#77895c" });
  // SUBJECT: the mattress propped on its side against a trunk, fridge tipped
  // beside it — it reads as dumped, not as bedding laid out
  b += mattress({ x: 452, y: 816, s: 1.72, rot: -5, r });
  b += barFridge({ x: 812, y: 842, s: 1.44, rot: 9 });
  b += shrub({ x: 664, y: 872, s: 0.9, r, colour: "#83965f" });
  b += shrub({ x: 176, y: 856, s: 1.0, r, colour: "#7c8f5e" });
  b += shrub({ x: 1096, y: 826, s: 1.1, r, colour: "#77895c" });
  b += reeds({ x: 300, y: 890, s: 1.1, r, count: 10, colour: "#a89a68" });
  b += rubbishPile({ x: 960, y: 880, s: 0.8, r, spread: 62, count: 3 });
  return { body: b, sky: "warm" };
});

/* --- 15. dog-offlead-01 ----------------------------------------------
   An on-lead sign at the beach entrance, with paw prints running
   straight past it toward the water. */
scene("dog-offlead-01", (r) => {
  let b = beachGround({ horizon: 258, wetY: 384, dryY: 452, r, variant: "day" });
  // dune with fence framing the entrance on the left
  b += `<path d="M-2 ${H} L-2 520 q130 -66 290 -40 q120 12 168 66 L560 ${H} Z" fill="${lighten(C.sand, 0.06)}"/>`;
  b += duneFence({ x0: -30, y0: 620, x1: 372, y1: 528, posts: 6, s0: 1.7, s1: 1.0 });
  b += duneGrass({ x: 96, y: 588, s: 1.5, r, count: 12 });
  b += duneGrass({ x: 268, y: 552, s: 1.2, r, count: 10 });
  b += duneGrass({ x: 1116, y: 812, s: 1.7, r, count: 12 });
  // paw prints running from the entrance down toward the water
  b += pawPrints({
    pts: [
      [430, 828, 1.5],
      [492, 786, 1.42],
      [552, 748, 1.34],
      [610, 714, 1.26],
      [666, 682, 1.18],
      [720, 654, 1.1],
      [772, 628, 1.02],
      [822, 604, 0.94],
      [870, 582, 0.86],
      [916, 562, 0.78],
      [960, 544, 0.7],
      [1002, 528, 0.62],
      [1042, 514, 0.56],
    ],
    colour: "#b8a583",
    opacity: 0.85,
  });
  // SUBJECT: the sign, a dog on a lead — pictogram only
  b += signPost({
    x: 322,
    y: 826,
    s: 1.6,
    h: 176,
    w: 78,
    ph: 92,
    face: "#eeeade",
    border: "#2f4d86",
    panel: `${g(
      `${dogSide({ x: -6, y: 20, s: 0.5, colour: "#22282a" })}
       <path d="M14 6 q16 -12 20 -30" fill="none" stroke="#22282a" stroke-width="3.4" stroke-linecap="round"/>
       <circle cx="34" cy="-26" r="4" fill="#22282a"/>`,
      { x: -4, y: 0 },
    )}`,
  });
  return { body: b, sky: "day" };
});

/* --- 16. parking-ev-01 -----------------------------------------------
   Dual-cab ute slewed diagonally across two EV charging bays, cables
   left hanging. */
scene("parking-ev-01", (r) => {
  const base = 344;
  let b = carParkBack(r, { horizon: 258, base, tint: "#c7c2b2", entryX: 190, h: 150 });
  b += band(base, H, C.asphalt);
  b += asphaltSpeckle(base, H, r, 320);
  b += groundShade(base, H, "gsh", 0.24);
  const vy = 344;
  b += parkingBays({
    xs: [80, 330, 580, 830, 1080, 1330],
    yNear: 926,
    t: 0.64,
    vpx: 600,
    vpy: vy,
    w: 16,
    headLine: true,
  });
  // the two EV bays, tinted green
  for (const x0 of [330, 580]) {
    const a = vp(x0 + 10, 920, 600, vy, 0);
    const c = vp(x0 + 10, 920, 600, vy, 0.64);
    const a2 = vp(x0 + 240, 920, 600, vy, 0);
    const c2 = vp(x0 + 240, 920, 600, vy, 0.64);
    b += `<polygon points="${poly([
      [a[0], a[1]],
      [a2[0], a2[1]],
      [c2[0], c2[1]],
      [c[0], c[1]],
    ])}" fill="#4f9068" opacity="0.17"/>`;
  }
  // chargers at the head of the bays, cables still holstered
  b += evCharger({ x: 452, y: 598, s: 1.0, cableDrop: 70 });
  b += evCharger({ x: 726, y: 598, s: 1.0, flip: true, cableDrop: 70 });
  b += bollard({ x: 344, y: 610, s: 0.72 });
  b += bollard({ x: 836, y: 610, s: 0.72 });
  b += farCarRow(r, { y: 392, s: 0.38, xs: [60, 144, 228, 312, 872, 956, 1040, 1124] });
  b += lightPole({ x: 1078, y: 646, s: 0.9 });
  // SUBJECT: slewed diagonally across both of them
  b += carRear3Q("dualcab", {
    x: 766,
    y: 812,
    s: 1.5,
    colour: "#3f4a52",
    r,
    dir: -1,
    depth: 232,
    rise: 46,
    shrink: 0.86,
  });
  return { body: b, sky: "day" };
});

/* --- 17. shopping-trolleys-bay-01 ------------------------------------
   Four trolleys nested inside an accessible bay. */
scene("shopping-trolleys-bay-01", (r) => {
  const base = 324;
  let b = carParkBack(r, { horizon: 246, base });
  b += band(base, H, C.asphalt);
  b += asphaltSpeckle(base, H, r, 320);
  b += groundShade(base, H, "gsh", 0.24);
  b += parkingBays({
    xs: [100, 330, 452, 748, 870, 1100],
    yNear: 910,
    t: 0.72,
    vpx: 600,
    vpy: 322,
    w: 15,
    headLine: true,
  });
  b += wheelchairPaint({ x: 600, y: 800, s: 1.3, opacity: 0.78 });
  b += signPost({
    x: 250,
    y: 590,
    s: 0.8,
    h: 164,
    w: 64,
    ph: 82,
    face: "#3560a8",
    border: "#eeeade",
    panel: g(
      `<circle cx="0" cy="-16" r="7" fill="#eeeade"/>
       <path d="${rp(
         [
           [-5, -6],
           [3, -6],
           [6, 10],
           [19, 10],
           [19, 17],
           [1, 17],
           [-6, 6],
         ],
         3,
       )}" fill="#eeeade"/>
       <path d="M-16 -1 A 19 19 0 1 0 14 21" fill="none" stroke="#eeeade" stroke-width="5" stroke-linecap="round"/>`,
      { x: -2, y: 2 },
    ),
  });
  b += carRear("suv", { x: 208, y: 604, s: 0.7, colour: "#6b767c", r });
  b += carRear("sedan", { x: 986, y: 604, s: 0.7, colour: "#b9b3a4", r });
  b += kerbIsland({ x: 150, y: 606, w: 320, s: 1.05, r });
  // SUBJECT: four trolleys nested, right in the middle of the bay
  b += farCarRow(r, { y: 394, s: 0.38, xs: [62, 146, 230, 314, 886, 970, 1054, 1138] });
  b += trolleyNest({ x: 712, y: 762, s: 1.72, count: 4, step: 27, basket: "#b0b7ba" });
  return { body: b, sky: "day" };
});

/* --- 18. parking-slightly-over-01 ------------------------------------
   Small hatchback with one rear tyre just over the line. The mild one. */
scene("parking-slightly-over-01", (r) => {
  const base = 326;
  let b = carParkBack(r, { horizon: 248, base });
  b += band(base, H, C.asphalt);
  b += asphaltSpeckle(base, H, r, 300);
  b += groundShade(base, H, "gsh", 0.22);
  b += parkingBays({
    xs: [-40, 180, 390, 600, 810, 1020, 1240],
    yNear: 912,
    t: 0.74,
    vpx: 600,
    vpy: 330,
    w: 16,
    headLine: true,
  });
  b += farCarRow(r, { y: 398, s: 0.38, xs: [58, 142, 226, 310, 394, 862, 946, 1030, 1114] });
  b += carRear("wagon", { x: 296, y: 654, s: 0.98, colour: "#7e8a8e", r });
  b += carRear("suv", { x: 918, y: 656, s: 0.98, colour: "#8b7f6a", r });
  b += trolleyBay({ x: 150, y: 552, s: 0.62 });
  b += kerbIsland({ x: 1088, y: 598, w: 300, s: 1.0, r });
  // SUBJECT: near-side rear tyre just over the line — the mild one
  b += carRear("hatch", { x: 670, y: 790, s: 1.56, colour: "#5f7d8a", r });
  return { body: b, sky: "day" };
});

/* --- 19. shopping-frozen-01 ------------------------------------------
   A frozen chicken abandoned on a shelf between the biscuits, already
   starting to pool. */
scene("shopping-frozen-01", () => {
  const r = rng(hashSeed("shopping-frozen-01"));
  let b = `<rect x="-2" y="-2" width="${W + 4}" height="${H + 4}" fill="#cfcdc2"/>`;
  b += `<rect x="-2" y="-2" width="${W + 4}" height="${H + 4}" fill="url(#gsh)" opacity="0.12"/>`;
  // Closer in than a wide aisle shot: three shelves, so the chicken is the
  // subject rather than one item in a wall of stock.
  b += shelfUnit({ x: 600, y: 940, w: 1300, shelves: 3, gap: 300 });
  // muted packet palette, so the biscuits stay background
  // deliberately muted: the biscuits are background, the chicken is the subject
  const packs = ["#a8836f", "#75838c", "#b3a071", "#7d8a72", "#8a7a80", "#a89073", "#77878a"];
  const drawRow = (sy: number, hgt: number, x0: number, x1: number, seedI: number) => {
    let x = x0;
    let i = seedI;
    let s = "";
    while (x < x1) {
      const pw = 84 + ((i * 37) % 46);
      if (x + pw > x1) break;
      s += packet({
        x: x + pw / 2,
        y: sy,
        w: pw,
        h: hgt - ((i * 29) % 52),
        colour: packs[i % packs.length]!,
      });
      x += pw + 7;
      i++;
    }
    return s;
  };
  b += drawRow(340, 150, 20, W - 20, 0);
  b += drawRow(940, 160, 20, W - 20, 5);
  // the shelf the chicken is on: biscuits either side, a gap in the middle
  const sy = 640;
  b += drawRow(sy, 168, 20, 348, 3);
  b += drawRow(sy, 168, 848, W - 20, 9);
  // SUBJECT: the chicken, sweating in its plastic, dumped between the biscuits
  b += g(
    `${shadow(6, 0, 118, 14, 0.24)}
     <path d="${rp(
       [
         [-108, 0, 16],
         [-88, -86, 40],
         [4, -112, 46],
         [100, -68, 40],
         [108, -6, 18],
       ],
       30,
     )}" fill="#e6cfc0"/>
     <path d="${rp(
       [
         [-108, 0, 16],
         [-88, -86, 40],
         [4, -112, 46],
         [100, -68, 40],
         [108, -6, 18],
       ],
       30,
     )}" fill="url(#glo)" opacity="0.32"/>
     <ellipse cx="-18" cy="-56" rx="54" ry="35" fill="#d8b3a0" opacity="0.55"/>
     <ellipse cx="40" cy="-72" rx="24" ry="15" fill="#f2e6da" opacity="0.5"/>
     <path d="M-108 -3 q104 -24 214 -10" fill="none" stroke="#c9ae9d" stroke-width="5" opacity="0.55"/>
     <path d="M-68 -94 q26 14 10 40 M50 -86 q-18 18 -2 36" fill="none" stroke="#ffffff" stroke-width="6" opacity="0.4" stroke-linecap="round"/>
     <path d="M92 -82 q30 -20 34 -2 q4 14 -16 16 z" fill="#e0e4e2" opacity="0.75"/>
     <path d="M-96 -34 q40 -12 78 -4" fill="none" stroke="#ffffff" stroke-width="4" opacity="0.3" stroke-linecap="round"/>`,
    { x: 590, y: sy, s: 1.62 },
  );
  // the puddle spreading along the shelf lip, and a drip over the edge
  b += puddle(548, 660, 176, 17, "#b9c6c4", 0.62);
  b += puddle(672, 666, 96, 10, "#cbd6d2", 0.48);
  b += `<path d="M448 664 q-9 34 -5 58" fill="none" stroke="#b9c6c4" stroke-width="8" opacity="0.5" stroke-linecap="round"/>`;
  b += `<ellipse cx="443" cy="728" rx="10" ry="13" fill="#b9c6c4" opacity="0.5"/>`;
  return { body: b, sky: "day" };
});

/* --- 20. neighbourhood-bbq-towels-01 ---------------------------------
   Park barbecues draped with towels and a cardboard sign, nobody in
   sight. */
scene("neighbourhood-bbq-towels-01", (r) => {
  const horizon = 268;
  let b = sky(horizon, "warm", r);
  b += treeline(horizon + 2, r, "#748a6c", 44);
  b += band(330, H, "#84a065");
  b += `<rect x="-2" y="330" width="${W + 4}" height="${H - 330}" fill="url(#gsh)" opacity="0.16"/>`;
  for (let i = 0; i < 6; i++) {
    b += `<rect x="-2" y="${n(360 + i * 92)}" width="${W + 4}" height="${n(40 + i * 5)}" fill="#8fab6c" opacity="0.45"/>`;
  }
  b += gumTree({ x: 190, y: 392, s: 0.86, r, lean: -7 });
  b += gumTree({ x: 1042, y: 400, s: 0.94, r, lean: 8 });
  b += shrub({ x: 108, y: 470, s: 1.0, r });
  b += shrub({ x: 1146, y: 492, s: 1.1, r });
  // concrete pad the barbecues stand on
  b += `<path d="${rp(
    [
      [70, 900, 18],
      [1130, 900, 18],
      [948, 636, 12],
      [252, 636, 12],
    ],
    16,
  )}" fill="${C.concreteDark}"/>`;
  b += `<path d="${rp(
    [
      [70, 900, 18],
      [1130, 900, 18],
      [948, 636, 12],
      [252, 636, 12],
    ],
    16,
  )}" fill="url(#gshUp)" opacity="0.09"/>`;
  // shelter over the pad
  b += `<g><rect x="246" y="330" width="712" height="15" rx="6" fill="#8a8d86"/>
  <path d="${rp(
    [
      [232, 330, 4],
      [972, 330, 4],
      [936, 296, 4],
      [268, 296, 4],
    ],
    4,
  )}" fill="#a5a89f"/>
  <rect x="292" y="345" width="15" height="368" fill="#7e827c"/>
  <rect x="294" y="345" width="5" height="368" fill="#ffffff" opacity="0.18"/>
  <rect x="900" y="345" width="15" height="344" fill="#6f736e"/></g>`;
  b += shadow(600, 700, 320, 20, 0.13);
  // SUBJECT: two barbecues, both draped and bagsed, nobody around
  b += bbq({ x: 396, y: 812, s: 1.78 });
  b += towel({ x: 372, y: 674, s: 1.3, rot: -5, a: "#c9522f", b: "#f0e6d2", w: 116, h: 42 });
  b += g(
    `<path d="${rp([[-44, -6, 6], [44, 0, 6], [40, 60, 8], [-40, 54, 8]], 7)}" fill="#f0e6d2"/>
     <path d="${rp([[-44, -6, 6], [44, 0, 6], [40, 60, 8], [-40, 54, 8]], 7)}" fill="url(#gsh)" opacity="0.16"/>
     <rect x="-30" y="-4" width="18" height="62" fill="#c9522f" opacity="0.9"/>
     <rect x="10" y="-2" width="18" height="62" fill="#c9522f" opacity="0.9"/>`,
    { x: 424, y: 682, s: 1.15 },
  );
  b += bbq({ x: 820, y: 832, s: 1.78 });
  b += towel({ x: 852, y: 690, s: 1.3, rot: 5, a: "#3f6b8a", b: "#eee5d0", w: 116, h: 42 });
  b += g(
    `<path d="${rp([[-42, 0, 6], [42, -6, 6], [38, 56, 8], [-38, 62, 8]], 7)}" fill="#eee5d0"/>
     <path d="${rp([[-42, 0, 6], [42, -6, 6], [38, 56, 8], [-38, 62, 8]], 7)}" fill="url(#gsh)" opacity="0.16"/>
     <rect x="-28" y="-2" width="17" height="62" fill="#3f6b8a" opacity="0.9"/>
     <rect x="8" y="-4" width="17" height="62" fill="#3f6b8a" opacity="0.9"/>`,
    { x: 800, y: 698, s: 1.15 },
  );
  b += shadow(604, 764, 52, 9, 0.2);
  b += cardboardSign({ x: 602, y: 756, s: 1.6, rot: -5, r });
  return { body: b, sky: "warm" };
});

/* --- 21. shopping-trolley-tram-01 ------------------------------------
   A trolley parked on the tram tracks, with a tram stopped behind it. */
scene("shopping-trolley-tram-01", (r) => {
  const horizon = 236;
  let b = sky(horizon, "day", r);
  // inner-city buildings
  const facades = ["#c2b8a6", "#b0a897", "#cfc7b6", "#a89e8d", "#c6bfae"];
  let x = -60;
  let i = 0;
  while (x < W + 40) {
    const w = r.f(120, 190);
    const h = r.f(150, 290);
    const fc = facades[i % facades.length]!;
    b += `<rect x="${n(x)}" y="${n(392 - h)}" width="${n(w)}" height="${n(h)}" fill="${fc}"/>`;
    b += `<rect x="${n(x)}" y="${n(392 - h)}" width="${n(w)}" height="10" fill="${darken(fc, 0.24)}"/>`;
    for (let ry = 0; ry < Math.floor(h / 62); ry++) {
      for (let cx = 0; cx < 3; cx++) {
        b += `<rect x="${n(x + 16 + cx * (w - 34) / 3)}" y="${n(392 - h + 30 + ry * 62)}" width="${n((w - 44) / 3)}" height="34" fill="#4d5a5c" opacity="0.72"/>`;
      }
    }
    x += w + 4;
    i++;
  }
  b += `<rect x="-2" y="352" width="${W + 4}" height="44" fill="#000000" opacity="0.1"/>`;
  // footpaths either side, road down the middle
  b += band(392, H, C.asphalt);
  b += asphaltSpeckle(392, H, r, 300);
  b += groundShade(392, H, "gsh", 0.2);
  b += `<polygon points="${poly([
    [-40, H],
    [130, H],
    [420, 394],
    [340, 394],
  ])}" fill="${C.concreteDark}"/>`;
  b += `<polygon points="${poly([
    [W + 40, H],
    [1070, H],
    [780, 394],
    [860, 394],
  ])}" fill="${C.concreteDark}"/>`;
  // tram tracks running away up the street
  b += tramTracks({ yNear: H + 10, xNearL: 402, xNearR: 552, vpx: 600, vpy: 388, t: 0.9 });
  b += tramTracks({ yNear: H + 10, xNearL: 706, xNearR: 856, vpx: 600, vpy: 388, t: 0.9 });
  // the tram, stopped a little way back
  b += tram({ x: 542, y: 560, s: 0.72, flip: true });
  // SUBJECT: trolley standing squarely on the near rail
  b += trolley({ x: 468, y: 858, s: 2.15, handle: C.yellow, basket: "#b0b7ba" });
  return { body: b, sky: "day" };
});

/* --- 22. parking-camp-01 ---------------------------------------------
   Campervan set up across three beachside bays at sunset: awning out,
   chairs and esky claiming the lot. */
scene("parking-camp-01", (r) => {
  const horizon = 300;
  let b = sky(horizon, "sunset", r);
  // sea behind the car park
  b += `<rect x="-2" y="${horizon - 2}" width="${W + 4}" height="72" fill="#3f6f86"/>`;
  b += `<rect x="-2" y="${horizon - 2}" width="${W + 4}" height="72" fill="url(#gshUp)" opacity="0.2"/>`;
  for (let i = 0; i < 4; i++) {
    b += `<rect x="${n(r.f(-20, 700))}" y="${n(horizon + 14 + i * 13)}" width="${n(r.f(140, 420))}" height="3" rx="1.5" fill="#f0c48e" opacity="${n(0.3 - i * 0.05)}"/>`;
  }
  // sun path on the water
  for (let i = 0; i < 9; i++) {
    const t = i / 8;
    const yy = horizon + 5 + t * 64;
    const hwid = (22 + t * 58) * r.f(0.55, 1.25);
    b += `<rect x="${n(880 - hwid / 2 + r.f(-14, 14))}" y="${n(yy)}" width="${n(hwid)}" height="${n(2.5 + t * 2)}" rx="1.5" fill="#f7d9a8" opacity="${n((0.52 - t * 0.26) * r.f(0.6, 1.1))}"/>`;
  }
  // dune strip, then the car park
  b += `<path d="M-2 372 q180 -14 380 -6 t400 6 t424 -4 L${W + 2} 420 L-2 420 Z" fill="#c2ad83"/>`;
  b += duneGrass({ x: 140, y: 386, s: 1.0, r, count: 9 });
  b += duneGrass({ x: 1024, y: 392, s: 1.1, r, count: 10 });
  b += band(414, H, darken(C.asphalt, -0.06));
  b += asphaltSpeckle(414, H, r, 260);
  b += groundShade(414, H, "gsh", 0.26);
  // warm rake of light across the tarmac
  b += `<rect x="-2" y="414" width="${W + 4}" height="${H - 414}" fill="#f7b877" opacity="0.15"/>`;
  b += parkingBays({
    xs: [-70, 150, 370, 590, 810, 1030, 1250],
    yNear: 910,
    t: 0.66,
    vpx: 600,
    vpy: 404,
    w: 15,
    colour: "#f0e6cf",
    headLine: true,
  });
  // SUBJECT: the campervan, straight across three bays
  b += carSide("campervan", { x: 486, y: 704, s: 1.16, colour: "#e6e2d6", r, flip: true });
  b += awning({ x: 640, y: 802, w: 292, drop: 66, poleH: 260, a: "#efe4cd", b: "#9db08a" });
  // camp set-up spilling into the next bay
  b += campChair({ x: 706, y: 792, s: 1.12, fabric: "#3f6b74" });
  b += campChair({ x: 856, y: 800, s: 1.12, flip: true, fabric: "#7d5f4a" });
  b += esky({ x: 784, y: 822, s: 1.05, lid: "#2f6a8c" });
  b += campChair({ x: 986, y: 846, s: 1.24, fabric: "#6b7f5a" });
  return { body: b, sky: "sunset" };
});

/* --- 23. positive-trolleys-01 ----------------------------------------
   Three trolleys put back neatly in the bay, in the rain. Warmer light:
   this one is a nomination, not a complaint. */
scene("positive-trolleys-01", (r) => {
  const base = 330;
  let b = sky(252, "bright", r);
  b += treeline(254, r, "#93a58c", 24);
  b += retailFacade({ y: base, x0: -40, x1: W + 40, h: 178, r });
  b += band(base, H, "#686864");
  b += asphaltSpeckle(base, H, r, 300);
  b += groundShade(base, H, "gsh", 0.12);
  // wet tarmac catching the light
  b += `<rect x="-2" y="${base}" width="${W + 4}" height="${H - base}" fill="#d8e6e4" opacity="0.16"/>`;
  b += parkingBays({
    xs: [-120, 110, 340, 860, 1090, 1320],
    yNear: 910,
    t: 0.74,
    vpx: 600,
    vpy: 322,
    w: 16,
    headLine: true,
  });
  b += puddle(266, 812, 150, 26, "#9fb6bb", 0.42);
  b += puddle(980, 858, 176, 28, "#9fb6bb", 0.4);
  b += puddle(742, 742, 96, 15, "#9fb6bb", 0.32);
  // reflections of the light on the wet ground
  for (let i = 0; i < 10; i++) {
    b += `<rect x="${n(r.f(60, 1140))}" y="${n(r.f(560, 880))}" width="${n(r.f(3, 7))}" height="${n(r.f(30, 88))}" rx="3" fill="#e6f0ef" opacity="${n(r.f(0.05, 0.13))}"/>`;
  }
  // SUBJECT: the trolley bay, tidily filled
  b += farCarRow(r, { y: 396, s: 0.38, xs: [70, 154, 238, 322, 900, 984, 1068, 1152] });
  b += trolleyBay({ x: 596, y: 748, s: 1.9 });
  b += trolleyNest({ x: 636, y: 738, s: 1.5, count: 3, step: 30, basket: "#b6bdbf" });
  b += rain(r, 130, 0.24);
  // late sun breaking under the cloud
  b += `<rect x="-2" y="252" width="${W + 4}" height="${H - 252}" fill="#ffd9a0" opacity="0.17"/>`;
  b += `<ellipse cx="880" cy="300" rx="300" ry="150" fill="#fff0d2" opacity="0.2" filter="url(#soft2)"/>`;
  return { body: b, sky: "bright" };
});

/* --- 24. positive-beach-cleanup-01 -----------------------------------
   A full bag of other people's rubbish propped beside the beach bin,
   and a clean stretch of sand. */
scene("positive-beach-cleanup-01", (r) => {
  let b = beachGround({ horizon: 262, wetY: 392, dryY: 458, r, variant: "bright", sand: "#efe3c6" });
  // warm wash over the whole scene
  b += `<rect x="-2" y="258" width="${W + 4}" height="${H - 258}" fill="#ffd9a0" opacity="0.07"/>`;
  b += duneGrass({ x: 96, y: 862, s: 1.7, r, count: 12 });
  b += duneGrass({ x: 1140, y: 806, s: 1.4, r, count: 10 });
  b += duneFence({ x0: -30, y0: 700, x1: 320, y1: 604, posts: 5, s0: 1.3, s1: 0.8 });
  // SUBJECT: bin, and the full bag someone left neatly beside it
  b += councilBin({ x: 720, y: 830, s: 2.1 });
  b += rubbishBag({ x: 518, y: 848, s: 1.85, colour: "#3f4f48", r });
  // footprints leading away up the beach
  b += pawPrints({
    pts: [
      [880, 812, 0.9],
      [936, 780, 0.82],
      [990, 752, 0.74],
    ],
    colour: "#cbbb96",
    opacity: 0.4,
  });
  return { body: b, sky: "bright" };
});

/* --- 25. parking-footpath-02 -----------------------------------------
   A tray-back ute across the footpath outside the shops, with someone
   on a walking frame stuck behind it. Closer, warmer, later in the day
   than parking-footpath-01. */
scene("parking-footpath-02", (r) => {
  const shopBase = 424;
  let b = sky(286, "warm", r);
  b += shopRow({ y: shopBase, x0: -60, x1: W + 60, h: 250, r, awningY: 336 });
  b += footpath({ yNear: 686, yFar: shopBase, colour: C.concrete, conv: 0.46 });
  // late light raking across the footpath
  b += `<rect x="-2" y="${shopBase}" width="${W + 4}" height="${686 - shopBase}" fill="#f7d9a8" opacity="0.16"/>`;
  b += kerb(686, 22, 11);
  b += band(719, H, C.asphalt);
  b += asphaltSpeckle(719, H, r, 240);
  b += groundShade(719, H, "gsh", 0.24);
  b += parkingBays({
    xs: [180, 420, 690, 1000],
    yNear: 900,
    t: 0.42,
    vpx: 520,
    vpy: 660,
    w: 15,
    opacity: 0.66,
  });
  b += bollard({ x: 96, y: 688, s: 0.72 });
  b += signPost({
    x: 1132,
    y: 688,
    s: 0.7,
    h: 158,
    panel: `<circle cx="0" cy="0" r="17" fill="none" stroke="#2f4d86" stroke-width="7"/><rect x="-19" y="-5" width="38" height="10" rx="3" fill="#2f4d86" transform="rotate(-38)"/>`,
  });
  // SUBJECT: tray-back ute, straight across the path
  b += carSide("ute", { x: 662, y: 676, s: 1.32, colour: "#8e6f4f", r, flip: true });
  // someone on a walking frame, stopped behind it with nowhere to go
  b += personFrame({ x: 268, y: 682, s: 1.28, shirt: "#6c7a6d" });
  return { body: b, sky: "warm" };
});

/* ------------------------------------------------------------------ *
 * rendering
 * ------------------------------------------------------------------ */

function buildSvg(s: Scene): string {
  const seed = hashSeed(s.key);
  const r = rng(seed);
  const out = s.render(r);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
<defs>${skyDefs(out.sky)}${shadeDefs()}${treatmentDefs(seed)}${out.defs ?? ""}</defs>
<rect width="${W}" height="${H}" fill="${C.skyLow}"/>
${out.body}
${treatment()}
</svg>`;
}

async function main() {
  const only = process.argv.slice(2).filter((a) => !a.startsWith("-"));
  const list = only.length ? scenes.filter((s) => only.includes(s.key)) : scenes;
  await mkdir(OUT_DIR, { recursive: true });
  const t0 = Date.now();
  const written: { key: string; bytes: number }[] = [];

  for (const s of list) {
    const svg = buildSvg(s);
    const file = path.join(OUT_DIR, `${s.key}.jpg`);
    const buf = await sharp(Buffer.from(svg))
      .resize(W, H, { fit: "fill" })
      .jpeg({ quality: 82, progressive: true, chromaSubsampling: "4:4:4" })
      .toBuffer();
    await writeFile(file, buf);
    written.push({ key: s.key, bytes: buf.length });
    console.log(`  ${s.key.padEnd(30)} ${(buf.length / 1024).toFixed(0).padStart(4)} KB`);
  }

  if (!only.length) await contactSheet(written.map((w) => w.key));
  console.log(`\n${written.length} images in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
}

/** grid of every image with its key underneath, for review */
async function contactSheet(keys: string[]) {
  const cols = 5;
  const cw = 300;
  const ch = 225;
  const lab = 22;
  const pad = 10;
  const rows = Math.ceil(keys.length / cols);
  const sw = cols * cw + pad * (cols + 1);
  const sh = rows * (ch + lab) + pad * (rows + 1);

  const tiles = await Promise.all(
    keys.map(async (k) => ({
      k,
      buf: await sharp(path.join(OUT_DIR, `${k}.jpg`)).resize(cw, ch).png().toBuffer(),
    })),
  );

  const labels = keys
    .map((k, i) => {
      const cx = pad + (i % cols) * (cw + pad);
      const cy = pad + Math.floor(i / cols) * (ch + lab + pad);
      return `<text x="${cx + 2}" y="${cy + ch + 15}" font-family="DejaVu Sans Mono, monospace" font-size="12" fill="#1c1c1c">${k}</text>`;
    })
    .join("");
  const bg = Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${sw}" height="${sh}"><rect width="${sw}" height="${sh}" fill="#f2f1ec"/>${labels}</svg>`,
  );

  const composites = tiles.map((t, i) => ({
    input: t.buf,
    left: pad + (i % cols) * (cw + pad),
    top: pad + Math.floor(i / cols) * (ch + lab + pad),
  }));

  await sharp(bg).composite(composites).png().toFile(path.join(OUT_DIR, "contact-sheet.png"));
  console.log(`  contact-sheet.png (${cols}x${rows})`);
}

await main();
