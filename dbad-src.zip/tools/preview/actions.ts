import type { Repository, ViewerOrNull } from "@/lib/data/repository";
import type { AdminActions, AppealActions, CommunityActions, NominationActions, NoticeActions } from "@/lib/actions/types";
import { localRewrite } from "@/lib/ai/rewrite";

export interface PreviewActions {
  community: CommunityActions;
  nomination: NominationActions;
  notice: NoticeActions;
  appeal: AppealActions;
  admin: AdminActions;
}

/** Browser-side stand-ins for the Server Actions, wired straight to the demo repository. */
export function makeActions(repo: Repository, viewer: () => ViewerOrNull, refresh: () => void): PreviewActions {
  const after = <T,>(p: Promise<T>) => p.then((r) => (refresh(), r));
  return {
    community: {
      castVote: (id, verdict) => repo.castVote(id, verdict, viewer()),
      toggleReaction: (id, kind) => repo.toggleReaction(id, kind, viewer()),
      addComment: (id, body) => repo.addComment(id, body, viewer()),
      reportContent: (input) => repo.reportContent(input, viewer()),
      markRedeemed: (id, note) => after(repo.markRedeemed(id, note, viewer())),
    },
    nomination: {
      submit: (input) => repo.createIncident(input, viewer()),
      suggest: async (input) => localRewrite(input),
    },
    notice: {
      update: (id, patch) => repo.updateNotice(id, patch, viewer()),
      create: (input) => repo.createNotice(input, viewer()),
    },
    appeal: {
      submit: (input) => repo.submitAppeal(input),
    },
    admin: {
      moderate: (cmd) => {
        const v = viewer();
        if (!v) return Promise.resolve({ ok: false, message: "Sign in" });
        return after(repo.moderate(cmd, v));
      },
    },
  };
}
