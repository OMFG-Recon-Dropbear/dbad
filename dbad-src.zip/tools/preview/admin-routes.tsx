// Preview-harness routes for the moderation console.
import * as React from "react";
import { registerRoute, type RouteContext } from "./routes";
import type { Viewer } from "@/lib/data/repository";
import { isModerator } from "@/lib/data/repository";
import {
  loadAdminComments,
  loadAdminCounts,
  loadAdminDashboard,
  loadAdminIncidents,
  loadAppeals,
  loadAudit,
  loadMembers,
  loadQueue,
  loadReports,
  parseAppealStatus,
  parseCommentStatus,
  parseIncidentAdminStatus,
  parseReportStatus,
} from "@/lib/loaders/admin";
import { AdminShell, type AdminSection } from "@/components/admin/admin-shell";
import { DashboardView } from "@/components/admin/dashboard-view";
import { QueueView } from "@/components/admin/queue-view";
import { ReportsView } from "@/components/admin/reports-view";
import { AppealsView } from "@/components/admin/appeals-view";
import { CommentsView } from "@/components/admin/comments-view";
import { IncidentsAdminView } from "@/components/admin/incidents-admin-view";
import { MembersView } from "@/components/admin/members-view";
import { CategoriesView } from "@/components/admin/categories-view";
import { TemplatesView } from "@/components/admin/templates-view";
import { AuditView } from "@/components/admin/audit-view";
import { Container } from "@/components/layout/site-shell";
import { ButtonLink } from "@/components/ui/button";
import { Stamp } from "@/components/brand/stamp";

/** Wraps a view in the console chrome, or turns the whole thing away. */
async function admin(section: AdminSection, ctx: RouteContext, render: (viewer: Viewer) => Promise<React.ReactNode>): Promise<React.ReactNode> {
  if (!isModerator(ctx.viewer)) return <ModeratorsOnly />;
  const [counts, body] = await Promise.all([loadAdminCounts(ctx.repo), render(ctx.viewer)]);
  return (
    <AdminShell viewer={ctx.viewer} section={section} counts={counts}>
      {body}
    </AdminShell>
  );
}

function ModeratorsOnly() {
  return (
    <Container size="md" className="py-12">
      <div className="border-[3px] border-ink-950 bg-paper-50 p-6 text-center shadow-hard sm:p-10">
        <Stamp tone="red" size="lg">
          Moderators only
        </Stamp>
        <h1 className="mt-6 text-4xl">This bit is behind the counter.</h1>
        <p className="mx-auto mt-3 max-w-md text-ink-700">
          The moderation console is for moderators and admins. If that&rsquo;s you, sign in and we&rsquo;ll bring you straight back.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <ButtonLink href="/sign-in?next=/admin" variant="primary">
            Sign in
          </ButtonLink>
          <ButtonLink href="/feed" variant="paper">
            Back to the feed
          </ButtonLink>
        </div>
        <p className="mt-6 font-mono text-[11px] uppercase tracking-wider text-concrete-600">
          Preview tip: append ?viewer=u_hq (admin) or ?viewer=u_sarah (moderator)
        </p>
      </div>
    </Container>
  );
}

registerRoute("/admin", async (_p, _url, ctx) =>
  admin("dashboard", ctx, async (viewer) => <DashboardView {...(await loadAdminDashboard(ctx.repo))} viewer={viewer} actions={ctx.actions.admin} />),
);

registerRoute("/admin/queue", async (_p, _url, ctx) =>
  admin("queue", ctx, async (viewer) => <QueueView {...(await loadQueue(ctx.repo))} viewer={viewer} actions={ctx.actions.admin} />),
);

registerRoute("/admin/reports", async (_p, url, ctx) =>
  admin("reports", ctx, async (viewer) => (
    <ReportsView {...(await loadReports(ctx.repo, parseReportStatus(url.searchParams.get("status"))))} viewer={viewer} actions={ctx.actions.admin} />
  )),
);

registerRoute("/admin/appeals", async (_p, url, ctx) =>
  admin("appeals", ctx, async (viewer) => (
    <AppealsView {...(await loadAppeals(ctx.repo, parseAppealStatus(url.searchParams.get("status"))))} viewer={viewer} actions={ctx.actions.admin} />
  )),
);

registerRoute("/admin/comments", async (_p, url, ctx) =>
  admin("comments", ctx, async (viewer) => (
    <CommentsView {...(await loadAdminComments(ctx.repo, parseCommentStatus(url.searchParams.get("status"))))} viewer={viewer} actions={ctx.actions.admin} />
  )),
);

registerRoute("/admin/nominations", async (_p, url, ctx) =>
  admin("nominations", ctx, async (viewer) => (
    <IncidentsAdminView
      {...(await loadAdminIncidents(ctx.repo, {
        status: parseIncidentAdminStatus(url.searchParams.get("status")),
        query: url.searchParams.get("q")?.trim() || undefined,
      }))}
      viewer={viewer}
      actions={ctx.actions.admin}
    />
  )),
);

registerRoute("/admin/members", async (_p, url, ctx) =>
  admin("members", ctx, async (viewer) => (
    <MembersView {...(await loadMembers(ctx.repo, url.searchParams.get("q")?.trim() || undefined))} viewer={viewer} actions={ctx.actions.admin} />
  )),
);

registerRoute("/admin/categories", async (_p, _url, ctx) =>
  admin("categories", ctx, async (viewer) => <CategoriesView viewer={viewer} actions={ctx.actions.admin} />),
);

registerRoute("/admin/templates", async (_p, _url, ctx) =>
  admin("templates", ctx, async (viewer) => <TemplatesView viewer={viewer} actions={ctx.actions.admin} />),
);

registerRoute("/admin/audit", async (_p, _url, ctx) =>
  admin("audit", ctx, async (viewer) => <AuditView {...(await loadAudit(ctx.repo))} viewer={viewer} actions={ctx.actions.admin} />),
);
