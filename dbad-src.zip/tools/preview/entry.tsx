import * as React from "react";
import { createRoot } from "react-dom/client";
import { SiteShell } from "@/components/layout/site-shell";
import { DemoRepository } from "@/lib/data/demo/demo-repository";
import { PROFILES } from "@/lib/data/demo/seed";
import type { ViewerOrNull } from "@/lib/data/repository";
import { matchRoute } from "./routes";
import "./extra-routes";
import { makeActions } from "./actions";

/**
 * Mini SPA shell for the preview harness. URL is the state; `preview:navigate` events
 * (from the next/link shim) drive pushState; every navigation re-runs the route loader
 * against the browser-side demo repository.
 */
const repo = new DemoRepository();

function viewerFromId(id: string | null): ViewerOrNull {
  const p = PROFILES.find((x) => x.id === id);
  return p ? { id: p.id, handle: p.handle, displayName: p.displayName, role: p.role } : null;
}

function App() {
  const [href, setHref] = React.useState(() => window.location.pathname + window.location.search + window.location.hash);
  const [viewerId, setViewerId] = React.useState<string | null>(() => new URLSearchParams(window.location.search).get("viewer") ?? sessionStorage.getItem("dbad_preview_viewer"));
  const [page, setPage] = React.useState<React.ReactNode>(null);
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    const nav = (e: Event) => {
      const to = (e as CustomEvent<string>).detail;
      history.pushState(null, "", to);
      setHref(to);
      window.dispatchEvent(new Event("preview:navigated"));
      window.scrollTo(0, 0);
    };
    const pop = () => setHref(window.location.pathname + window.location.search + window.location.hash);
    const refresh = () => setTick((t) => t + 1);
    window.addEventListener("preview:navigate", nav);
    window.addEventListener("popstate", pop);
    window.addEventListener("preview:refresh", refresh);
    return () => {
      window.removeEventListener("preview:navigate", nav);
      window.removeEventListener("popstate", pop);
      window.removeEventListener("preview:refresh", refresh);
    };
  }, []);

  const viewer = viewerFromId(viewerId);
  const actions = React.useMemo(() => makeActions(repo, () => viewerFromId(viewerId), () => setTick((t) => t + 1)), [viewerId]);

  React.useEffect(() => {
    let cancelled = false;
    const url = new URL(href, window.location.origin);
    const v = url.searchParams.get("viewer");
    if (v !== null && v !== viewerId) {
      sessionStorage.setItem("dbad_preview_viewer", v);
      setViewerId(v || null);
      return;
    }
    matchRoute(url, {
      repo,
      viewer,
      actions,
      signIn: (id) => {
        sessionStorage.setItem("dbad_preview_viewer", id);
        setViewerId(id);
      },
      signOut: () => {
        sessionStorage.removeItem("dbad_preview_viewer");
        setViewerId(null);
      },
    })
      .then((node) => {
        if (!cancelled) setPage(node);
      })
      .catch((err) => {
        console.error(err);
        if (!cancelled) setPage(<pre className="p-6 text-alert-600">{String(err?.stack ?? err)}</pre>);
      });
    return () => {
      cancelled = true;
    };
  }, [href, viewer?.id, tick, actions]);

  const unread = 0;
  return (
    <SiteShell viewer={viewer} unread={unread}>
      {page ?? <div className="p-10 font-mono text-sm">Loading…</div>}
    </SiteShell>
  );
}

createRoot(document.getElementById("root")!).render(<App />);
