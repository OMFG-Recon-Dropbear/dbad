// Additional preview routes are registered here as pages are built.
import * as React from "react";
import { registerRoute } from "./routes";
import { loadFeed } from "@/lib/loaders/feed";
import { FeedView } from "@/components/feed/feed-view";
import { loadIncident } from "@/lib/loaders/incident";
import { IncidentView } from "@/components/incident/incident-view";
import { WeekView } from "@/components/feed/week-view";
import { loadMap } from "@/lib/loaders/map";
import { MapView } from "@/components/map/map-view";
import { NominateWizard } from "@/components/nominate/nominate-wizard";
import { createNoticeFor, loadNotice } from "@/lib/loaders/notice";
import { NoticeStudio } from "@/components/notice/notice-studio";
import { AboutView } from "@/components/content/about-view";
import { StandardsView } from "@/components/content/standards-view";
import { PrivacyView } from "@/components/content/privacy-view";
import { AboutYouView } from "@/components/content/about-you-view";
import { SignInView } from "@/components/auth/sign-in-view";
import { NotificationsView, ProfileView } from "@/components/profile/profile-view";
import { DEMO_ACCOUNTS } from "@/lib/auth/demo-accounts";
import { PROFILES } from "@/lib/data/demo/seed";
import type { AppealAction, CategoryId } from "@/lib/domain/types";
import { CATEGORY_MAP } from "@/lib/domain/categories";
import "./admin-routes";

function sp(url: URL): Record<string, string> {
  return Object.fromEntries(url.searchParams.entries());
}

const NotFound = () => (
  <div className="mx-auto max-w-3xl p-10">
    <h1 className="text-5xl">Not found</h1>
  </div>
);

registerRoute("/feed", async (_p, url, ctx) => <FeedView {...(await loadFeed(ctx.repo, ctx.viewer, sp(url), "dick_move", "/feed"))} />);
registerRoute("/not-a-dick", async (_p, url, ctx) => <FeedView {...(await loadFeed(ctx.repo, ctx.viewer, sp(url), "not_a_dick", "/not-a-dick"))} />);
registerRoute("/moves/:slug", async (p, _url, ctx) => {
  const data = await loadIncident(ctx.repo, ctx.viewer, p.slug!);
  if (!data) return <NotFound />;
  return <IncidentView {...data} actions={ctx.actions.community} />;
});
registerRoute("/week", async (_p, _url, ctx) => <WeekView featured={await ctx.repo.getFeatured()} />);
registerRoute("/map", async (_p, url, ctx) => <MapView {...(await loadMap(ctx.repo, ctx.viewer, url.searchParams.get("region") ?? undefined))} />);
registerRoute("/nominate", async (_p, url, ctx) => {
  const cat = url.searchParams.get("category");
  return (
    <NominateWizard
      key={url.search}
      viewer={ctx.viewer}
      actions={ctx.actions.nomination}
      initialKind={url.searchParams.get("kind") === "not_a_dick" ? "not_a_dick" : "dick_move"}
      initialCategory={cat && cat in CATEGORY_MAP ? (cat as CategoryId) : undefined}
    />
  );
});
registerRoute("/notice/new", async (_p, url, ctx) => {
  const data = await createNoticeFor(ctx.repo, ctx.viewer, url.searchParams.get("incident") ?? undefined);
  history.replaceState(null, "", `/notice/${data.notice.id}`);
  return <NoticeStudio {...data} actions={ctx.actions.notice} />;
});
registerRoute("/notice/:id", async (p, _url, ctx) => {
  const data = await loadNotice(ctx.repo, ctx.viewer, p.id!);
  if (!data) return <NotFound />;
  return <NoticeStudio {...data} actions={ctx.actions.notice} />;
});
registerRoute("/about", async () => <AboutView />);
registerRoute("/standards", async () => <StandardsView />);
registerRoute("/privacy", async () => <PrivacyView />);
registerRoute("/about-you", async (_p, url, ctx) => {
  const code = url.searchParams.get("code")?.trim().toUpperCase();
  const incident = code ? await ctx.repo.getIncidentByCode(code) : null;
  const a = url.searchParams.get("action") as AppealAction | null;
  return <AboutYouView incident={incident} code={code || undefined} actions={ctx.actions.appeal} initialAction={a ?? undefined} />;
});
registerRoute("/sign-in", async (_p, url, ctx) => {
  const next = url.searchParams.get("next") ?? "/";
  return (
    <SignInView
      mode="demo"
      next={next}
      demoAccounts={DEMO_ACCOUNTS.map((a) => ({ ...a, handle: PROFILES.find((p) => p.id === a.id)?.handle ?? a.id }))}
      actions={{
        demoSignIn: async (id, n) => {
          ctx.signIn(id);
          window.dispatchEvent(new CustomEvent("preview:navigate", { detail: n }));
        },
      }}
    />
  );
});
registerRoute("/me", async (_p, _url, ctx) => {
  if (!ctx.viewer) return <SignInView mode="demo" next="/me" demoAccounts={DEMO_ACCOUNTS.map((a) => ({ ...a, handle: a.id }))} actions={{ demoSignIn: async (id) => ctx.signIn(id) }} />;
  const page = await ctx.repo.getProfileById(ctx.viewer.id);
  if (!page) return <NotFound />;
  return <ProfileView page={page} viewer={ctx.viewer} isSelf signOutAction={async () => ctx.signOut()} />;
});
registerRoute("/u/:handle", async (p, _url, ctx) => {
  const page = await ctx.repo.getProfileByHandle(p.handle!);
  if (!page) return <NotFound />;
  return <ProfileView page={page} viewer={ctx.viewer} isSelf={ctx.viewer?.id === page.profile.id} />;
});
registerRoute("/notifications", async (_p, _url, ctx) => {
  if (!ctx.viewer) return <NotFound />;
  const list = await ctx.repo.listNotifications(ctx.viewer);
  await ctx.repo.markNotificationsRead(ctx.viewer);
  return <NotificationsView notifications={list} />;
});
