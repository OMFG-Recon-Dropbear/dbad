import * as React from "react";
import type { Repository, ViewerOrNull } from "@/lib/data/repository";
import type { PreviewActions } from "./actions";
import { loadHome } from "@/lib/loaders/home";
import { HomeView } from "@/components/home/home-view";

export interface RouteContext {
  repo: Repository;
  viewer: ViewerOrNull;
  actions: PreviewActions;
  signIn: (id: string) => void;
  signOut: () => void;
}

type Loader = (params: Record<string, string>, url: URL, ctx: RouteContext) => Promise<React.ReactNode>;

const routes: Array<{ pattern: string; load: Loader }> = [
  {
    pattern: "/",
    load: async (_p, _u, ctx) => <HomeView {...(await loadHome(ctx.repo, ctx.viewer))} />,
  },
];

export function registerRoute(pattern: string, load: Loader) {
  routes.push({ pattern, load });
}

function match(pattern: string, path: string): Record<string, string> | null {
  const a = pattern.split("/").filter(Boolean);
  const b = path.split("/").filter(Boolean);
  if (a.length !== b.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i]!.startsWith(":")) params[a[i]!.slice(1)] = decodeURIComponent(b[i]!);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

export async function matchRoute(url: URL, ctx: RouteContext): Promise<React.ReactNode> {
  for (const r of routes) {
    const params = match(r.pattern, url.pathname);
    if (params) return r.load(params, url, ctx);
  }
  return (
    <div className="mx-auto max-w-3xl p-10">
      <h1 className="text-5xl">404 — not here, mate.</h1>
      <p className="mt-4">No route for {url.pathname}</p>
    </div>
  );
}
