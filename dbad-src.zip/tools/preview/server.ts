/**
 * DBAD design-preview harness.
 *
 * Runs the real React views against the in-memory demo repository in the browser, with
 * tiny shims standing in for Next.js primitives (next/link, next/image, navigation).
 * It exists so the UI can be exercised and screenshotted anywhere Bun runs — no npm
 * registry, no Next build. It is NOT the production server (that's `next start`).
 *
 *   bun run tools/preview/server.ts            # http://127.0.0.1:4801
 *   PREVIEW_PORT=4802 bun run tools/preview/server.ts
 */
import { resolve, join, extname } from "node:path";
import { existsSync, statSync } from "node:fs";

const root = resolve(import.meta.dir, "../..");
const dist = join(root, "tools/preview/dist");
const port = Number(process.env.PREVIEW_PORT || 4801);
const tailwind = process.env.TAILWIND_BIN || "/home/claude/vendor/tailwindcss";

const SHIMS: Record<string, string> = {
  "next/link": "tools/preview/shims/link.tsx",
  "next/image": "tools/preview/shims/image.tsx",
  "next/navigation": "tools/preview/shims/navigation.ts",
  "next/font/local": "tools/preview/shims/font.ts",
  "server-only": "tools/preview/shims/empty.ts",
  "client-only": "tools/preview/shims/empty.ts",
};

const aliasPlugin: import("bun").BunPlugin = {
  name: "dbad-shims",
  setup(build) {
    build.onResolve({ filter: /^(next\/link|next\/image|next\/navigation|next\/font\/local|server-only|client-only)$/ }, (args) => ({
      path: join(root, SHIMS[args.path]!),
    }));
    build.onResolve({ filter: /^@\// }, (args) => {
      const rel = args.path.slice(2);
      const base = join(root, "src", rel);
      for (const ext of ["", ".ts", ".tsx", "/index.ts", "/index.tsx"]) {
        const p = base + ext;
        if (existsSync(p) && statSync(p).isFile()) return { path: p };
      }
      return { path: base };
    });
  },
};

async function buildBundle() {
  const t0 = performance.now();
  const result = await Bun.build({
    entrypoints: [join(root, "tools/preview/entry.tsx")],
    outdir: dist,
    target: "browser",
    format: "esm",
    minify: false,
    sourcemap: "linked",
    plugins: [aliasPlugin],
    define: {
      "process.env.NODE_ENV": JSON.stringify("development"),
      "process.env.NEXT_PUBLIC_SITE_URL": JSON.stringify(`http://127.0.0.1:${port}`),
      "process.env.NEXT_PUBLIC_SUPABASE_URL": JSON.stringify(""),
      "process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY": JSON.stringify(""),
      "process.env.DBAD_DATA_MODE": JSON.stringify("demo"),
    },
    naming: "[name].js",
  });
  if (!result.success) {
    for (const log of result.logs) console.error(log);
    throw new Error("bundle failed");
  }
  console.log(`bundle ok in ${(performance.now() - t0).toFixed(0)}ms`);
}

async function buildCss() {
  const t0 = performance.now();
  const proc = Bun.spawn([tailwind, "-i", join(root, "src/app/globals.css"), "-o", join(dist, "preview.css"), "--minify"], {
    cwd: root,
    stdout: "pipe",
    stderr: "pipe",
  });
  const code = await proc.exited;
  if (code !== 0) {
    console.error(await new Response(proc.stderr).text());
    throw new Error("tailwind failed");
  }
  console.log(`css ok in ${(performance.now() - t0).toFixed(0)}ms`);
}

const MIME: Record<string, string> = {
  ".js": "text/javascript",
  ".css": "text/css",
  ".map": "application/json",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".webmanifest": "application/manifest+json",
  ".json": "application/json",
  ".ico": "image/x-icon",
  ".html": "text/html; charset=utf-8",
  ".pdf": "application/pdf",
  ".jpeg": "image/jpeg",
  ".ttf": "font/ttf",
};

const html = `<!doctype html>
<html lang="en-AU">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
<title>DBAD — preview harness</title>
<link rel="preload" href="/fonts/DBADDisplay-Black.woff" as="font" type="font/woff" crossorigin />
<link rel="stylesheet" href="/__preview/preview.css" />
</head>
<body><div id="root"></div><script type="module" src="/__preview/entry.js"></script></body>
</html>`;

async function apiHandler(req: Request, url: URL): Promise<Response | null> {
  // Mount the real Next.js route handlers (they are standard Request -> Response functions).
  if (url.pathname.startsWith("/api/qr")) {
    const mod = await import(join(root, "src/app/api/qr/route.ts"));
    return mod.GET(req);
  }
  const pdf = url.pathname.match(/^\/api\/notices\/([^/]+)\/pdf$/);
  if (pdf) {
    const mod = await import(join(root, "src/app/api/notices/[id]/pdf/route.ts"));
    return mod.GET(req, { params: Promise.resolve({ id: pdf[1]! }) });
  }
  if (url.pathname === "/api/ai/rewrite") {
    const mod = await import(join(root, "src/app/api/ai/rewrite/route.ts"));
    return mod.POST(req);
  }
  return null;
}

await buildCss();
await buildBundle();

Bun.serve({
  port,
  hostname: "127.0.0.1",
  async fetch(req) {
    const url = new URL(req.url);
    if (url.pathname === "/__preview/rebuild") {
      await buildCss();
      await buildBundle();
      return new Response("rebuilt");
    }
    if (url.pathname.startsWith("/__preview/")) {
      const file = Bun.file(join(dist, url.pathname.replace("/__preview/", "")));
      if (await file.exists()) return new Response(file, { headers: { "content-type": MIME[extname(url.pathname)] ?? "application/octet-stream" } });
      return new Response("not found", { status: 404 });
    }
    const api = await apiHandler(req, url);
    if (api) return api;
    const pub = join(root, "public", url.pathname);
    if (url.pathname !== "/" && existsSync(pub) && statSync(pub).isFile()) {
      return new Response(Bun.file(pub), { headers: { "content-type": MIME[extname(pub)] ?? "application/octet-stream", "cache-control": "public, max-age=3600" } });
    }
    return new Response(html, { headers: { "content-type": "text/html; charset=utf-8" } });
  },
});

console.log(`DBAD preview: http://127.0.0.1:${port}`);
