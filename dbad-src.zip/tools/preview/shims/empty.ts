// Empty module for `server-only` and other server-side markers in the browser harness.
export {};
