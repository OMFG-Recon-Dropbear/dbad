// next/font shim — fonts are loaded via @font-face in globals.css so nothing to do here.
export default function localFont() {
  return { className: "", variable: "", style: {} };
}
