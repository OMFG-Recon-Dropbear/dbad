import * as React from "react";

/** next/image shim: a plain <img>. `fill` maps to absolute positioning like Next does. */
export default function Image({
  src,
  alt,
  fill,
  width,
  height,
  sizes: _sizes,
  priority: _priority,
  quality: _quality,
  placeholder: _placeholder,
  unoptimized: _unoptimized,
  style,
  className,
  ...rest
}: Omit<React.ImgHTMLAttributes<HTMLImageElement>, "src" | "width" | "height"> & {
  src: string | { src: string };
  alt: string;
  fill?: boolean;
  width?: number;
  height?: number;
  sizes?: string;
  priority?: boolean;
  quality?: number;
  placeholder?: string;
  unoptimized?: boolean;
}) {
  void _sizes;
  void _priority;
  void _quality;
  void _placeholder;
  void _unoptimized;
  const s = typeof src === "string" ? src : src.src;
  const fillStyle: React.CSSProperties = fill ? { position: "absolute", inset: 0, width: "100%", height: "100%" } : {};
  return <img src={s} alt={alt} width={fill ? undefined : width} height={fill ? undefined : height} loading="lazy" decoding="async" className={className} style={{ ...fillStyle, ...style }} {...rest} />;
}
