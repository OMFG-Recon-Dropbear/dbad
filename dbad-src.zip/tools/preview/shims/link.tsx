import * as React from "react";

/** next/link shim for the preview harness: a plain anchor that talks to the mini router. */
export default function Link({
  href,
  children,
  prefetch: _prefetch,
  scroll: _scroll,
  replace: _replace,
  ...rest
}: React.AnchorHTMLAttributes<HTMLAnchorElement> & { href: string | { pathname?: string; query?: Record<string, string> }; prefetch?: boolean; scroll?: boolean; replace?: boolean }) {
  void _prefetch;
  void _scroll;
  void _replace;
  const h = typeof href === "string" ? href : `${href.pathname ?? ""}${href.query ? "?" + new URLSearchParams(href.query).toString() : ""}`;
  return (
    <a
      href={h}
      {...rest}
      onClick={(e) => {
        rest.onClick?.(e);
        if (e.defaultPrevented || e.metaKey || e.ctrlKey || h.startsWith("http") || h.startsWith("#")) return;
        e.preventDefault();
        window.dispatchEvent(new CustomEvent("preview:navigate", { detail: h }));
      }}
    >
      {children}
    </a>
  );
}
