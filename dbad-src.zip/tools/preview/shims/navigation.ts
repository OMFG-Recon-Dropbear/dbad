import * as React from "react";

/** next/navigation shim for the preview harness. */
export function useRouter() {
  return {
    push: (href: string) => window.dispatchEvent(new CustomEvent("preview:navigate", { detail: href })),
    replace: (href: string) => window.dispatchEvent(new CustomEvent("preview:navigate", { detail: href })),
    back: () => history.back(),
    refresh: () => window.dispatchEvent(new CustomEvent("preview:refresh")),
    prefetch: () => {},
  };
}

export function usePathname() {
  const [p, setP] = React.useState(() => (typeof window === "undefined" ? "/" : window.location.pathname));
  React.useEffect(() => {
    const h = () => setP(window.location.pathname);
    window.addEventListener("popstate", h);
    window.addEventListener("preview:navigated", h);
    return () => {
      window.removeEventListener("popstate", h);
      window.removeEventListener("preview:navigated", h);
    };
  }, []);
  return p;
}

export function useSearchParams() {
  const [sp, setSp] = React.useState(() => new URLSearchParams(typeof window === "undefined" ? "" : window.location.search));
  React.useEffect(() => {
    const h = () => setSp(new URLSearchParams(window.location.search));
    window.addEventListener("popstate", h);
    window.addEventListener("preview:navigated", h);
    return () => {
      window.removeEventListener("popstate", h);
      window.removeEventListener("preview:navigated", h);
    };
  }, []);
  return sp;
}

export function notFound(): never {
  throw new Error("NOT_FOUND");
}

export function redirect(href: string): never {
  window.dispatchEvent(new CustomEvent("preview:navigate", { detail: href }));
  throw new Error("REDIRECT");
}
