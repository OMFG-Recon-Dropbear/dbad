#!/usr/bin/env bash
# Verifies the dependency-free QR encoder (src/lib/domain/qr.ts) against OpenCV's decoder.
# Requires: bun, python3 with cv2 + numpy. Renders each SVG to a bitmap and decodes it.
set -euo pipefail
cd "$(dirname "$0")/../.."
OUT=$(mktemp -d)
cat > "$OUT/gen.ts" <<TS
import { encodeQr, qrSvg } from "$(pwd)/src/lib/domain/qr";
const levels = ["L","M","Q","H"] as const;
let i = 0;
for (const len of [10, 26, 38, 55, 78, 95, 120, 150, 190, 230]) for (const l of levels) {
  const t = ("https://dontbeadick.com.au/moves/" + "abcdefghij0123456789-".repeat(20)).slice(0, len);
  try { encodeQr(t, l); } catch { continue; }
  await Bun.write("$OUT/q" + i + ".svg", qrSvg(t, { size: 400, ecLevel: l }));
  await Bun.write("$OUT/q" + i + ".txt", t);
  i++;
}
console.log("generated", i);
TS
bun run "$OUT/gen.ts"
python3 - "$OUT" <<'PY'
import re, glob, sys, cv2, numpy as np
out = sys.argv[1]; det = cv2.QRCodeDetector(); ok = fail = 0
for f in sorted(glob.glob(f"{out}/q*.svg")):
    svg = open(f).read(); dim = int(re.search(r'viewBox="0 0 (\d+)', svg).group(1)); d = re.search(r'<path d="([^"]+)"', svg).group(1)
    expected = open(f[:-4] + ".txt").read(); good = False
    for scale in (8, 12, 6, 16, 10, 20):  # OpenCV is flaky at some scales; the encoder is right if any decodes
        pad = scale * 8; img = np.full((dim*scale + 2*pad, dim*scale + 2*pad), 255, np.uint8)
        for m in re.finditer(r'M(\d+) (\d+)h(\d+)v1h-\d+z', d):
            x, y, w = map(int, m.groups()); img[pad+y*scale:pad+(y+1)*scale, pad+x*scale:pad+(x+w)*scale] = 0
        data, _, _ = det.detectAndDecode(img)
        if data == expected: good = True; break
    ok += good; fail += (not good)
    if not good: print("FAIL", f)
print(f"QR verify: {ok} ok, {fail} failed"); sys.exit(1 if fail else 0)
PY
