#!/usr/bin/env bash
#
# Offline strict type-check for the DBAD app.
#
# Runs `tsc` against tools/typecheck/tsconfig.json, which uses the hand-written
# vendor declarations in tools/typecheck/types/ instead of the real `next`,
# `@types/react`, `@types/react-dom` and `@supabase/*` packages (this sandbox has
# no npm registry). pdf-lib and @types/node resolve normally from node_modules.
#
# Usage:
#   bash tools/typecheck/run.sh          # summary + full error list
#   bash tools/typecheck/run.sh --quiet  # summary only
#
# Exit code: 0 when clean, 1 when there are type errors.

set -uo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPO_ROOT" || exit 2

PROJECT="tools/typecheck/tsconfig.json"
QUIET=0
[ "${1:-}" = "--quiet" ] && QUIET=1

TSC="tsc"
command -v "$TSC" >/dev/null 2>&1 || TSC="npx --no-install tsc"

OUT="$(mktemp)"
trap 'rm -f "$OUT"' EXIT

# shellcheck disable=SC2086
$TSC -p "$PROJECT" --pretty false >"$OUT" 2>&1
TSC_STATUS=$?

# Only lines of the form  path(line,col): error TSxxxx: message  are diagnostics;
# tsc indents the continuation lines of a multi-line explanation.
ERRORS="$(grep -E '^[^ ].*\([0-9]+,[0-9]+\): error TS[0-9]+:' "$OUT" || true)"
COUNT="$(printf '%s' "$ERRORS" | grep -c . || true)"

# Anything tsc printed that is not a diagnostic (a bad config, a crash) matters too.
NOISE="$(grep -vE '^[^ ].*\([0-9]+,[0-9]+\): error TS[0-9]+:' "$OUT" | grep -vE '^\s' | grep -c . || true)"

printf '\n'
printf 'DBAD offline typecheck (%s)\n' "$PROJECT"
printf '%s\n' '--------------------------------------------------------------'

if [ "$COUNT" -eq 0 ] && [ "$TSC_STATUS" -eq 0 ]; then
  printf 'No type errors.\n\n'
  exit 0
fi

if [ "$COUNT" -eq 0 ] && [ "$TSC_STATUS" -ne 0 ]; then
  printf 'tsc exited %s without emitting file diagnostics:\n\n' "$TSC_STATUS"
  cat "$OUT"
  exit 1
fi

printf '%s error(s)\n\n' "$COUNT"
printf 'By file:\n'
printf '%s\n' "$ERRORS" \
  | sed -E 's/\(([0-9]+),[0-9]+\): error TS[0-9]+:.*$//' \
  | sort | uniq -c | sort -rn \
  | awk '{ printf "  %5d  %s\n", $1, $2 }'

printf '\nBy rule:\n'
printf '%s\n' "$ERRORS" \
  | grep -oE 'error TS[0-9]+' \
  | sort | uniq -c | sort -rn \
  | awk '{ printf "  %5d  %s %s\n", $1, $2, $3 }'

if [ "$QUIET" -eq 0 ]; then
  printf '\nDetail:\n'
  cat "$OUT"
fi

if [ "${NOISE:-0}" -gt 0 ]; then
  printf '\nNote: tsc also printed non-diagnostic output (see detail above).\n'
fi

printf '\n'
exit 1
