/**
 * Odds and ends: optional peer packages and non-code module imports that a
 * bundler resolves but `tsc` cannot.
 */

/** Optional peer of pdf-lib, loaded lazily in src/lib/notice/pdf.ts. */
declare module "@pdf-lib/fontkit" {
  export interface Fontkit {
    create(buffer: Uint8Array | ArrayBuffer, postscriptName?: string): unknown;
    openSync(filename: string, postscriptName?: string): unknown;
  }
  const fontkit: Fontkit;
  export default fontkit;
}

// ---------------------------------------------------------------------------
// Stylesheets (Next/Turbopack resolve these; tsc needs telling)
// ---------------------------------------------------------------------------
declare module "*.module.css" {
  const classes: { readonly [key: string]: string };
  export default classes;
}
declare module "*.module.scss" {
  const classes: { readonly [key: string]: string };
  export default classes;
}
declare module "*.css";
declare module "*.scss";
declare module "*.sass";

// ---------------------------------------------------------------------------
// Static assets — shape matches next/image's StaticImageData
// ---------------------------------------------------------------------------
declare module "*.svg" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}
declare module "*.png" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}
declare module "*.jpg" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}
declare module "*.jpeg" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}
declare module "*.gif" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}
declare module "*.webp" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}
declare module "*.avif" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}
declare module "*.ico" {
  import type { StaticImageData } from "next/image";
  const content: StaticImageData;
  export default content;
}

declare module "*.woff" {
  const src: string;
  export default src;
}
declare module "*.woff2" {
  const src: string;
  export default src;
}

// Note: the Shape Detection API (FaceDetector) is feature-detected inside
// src/lib/client/images.ts with its own local types, so nothing global is
// declared for it here.
