/**
 * Next.js 15 (App Router) type declarations for the offline type-check.
 *
 * Only the surface this codebase can plausibly use is declared, but the shapes
 * follow the real ones closely enough that correct usage passes and misuse
 * (wrong prop name, missing `alt`, string where an object is expected) fails.
 */

// ---------------------------------------------------------------------------
// next  (config + metadata)
// ---------------------------------------------------------------------------
declare module "next" {
  import type { ReactNode } from "react";

  export interface RouteHas {
    type: "header" | "query" | "cookie" | "host";
    key?: string;
    value?: string;
  }

  export interface Header {
    source: string;
    basePath?: false;
    locale?: false;
    headers: Array<{ key: string; value: string }>;
    has?: RouteHas[];
    missing?: RouteHas[];
  }

  export interface Rewrite {
    source: string;
    destination: string;
    basePath?: false;
    locale?: false;
    has?: RouteHas[];
    missing?: RouteHas[];
  }

  export type Redirect = {
    source: string;
    destination: string;
    basePath?: false;
    locale?: false;
    has?: RouteHas[];
    missing?: RouteHas[];
  } & ({ permanent: boolean; statusCode?: never } | { permanent?: never; statusCode: number });

  export interface RemotePattern {
    protocol?: "http" | "https";
    hostname: string;
    port?: string;
    pathname?: string;
    search?: string;
  }

  export interface ImageConfig {
    deviceSizes?: number[];
    imageSizes?: number[];
    loader?: "default" | "imgix" | "cloudinary" | "akamai" | "custom";
    loaderFile?: string;
    path?: string;
    domains?: string[];
    remotePatterns?: Array<RemotePattern | URL>;
    localPatterns?: Array<{ pathname?: string; search?: string }>;
    qualities?: number[];
    disableStaticImages?: boolean;
    minimumCacheTTL?: number;
    formats?: Array<"image/avif" | "image/webp">;
    dangerouslyAllowSVG?: boolean;
    contentSecurityPolicy?: string;
    contentDispositionType?: "inline" | "attachment";
    unoptimized?: boolean;
  }

  export interface ServerActionsConfig {
    /** e.g. "8mb", or a byte count. */
    bodySizeLimit?: number | string;
    allowedOrigins?: string[];
  }

  /**
   * Experimental flags change every minor release, so the known keys are typed
   * and the rest is left open rather than fabricated.
   */
  export interface ExperimentalConfig {
    serverActions?: ServerActionsConfig;
    typedRoutes?: boolean;
    ppr?: boolean | "incremental";
    reactCompiler?: boolean | { compilationMode?: "annotation" | "infer" | "all" };
    optimizePackageImports?: string[];
    optimizeCss?: boolean;
    scrollRestoration?: boolean;
    webVitalsAttribution?: string[];
    instrumentationHook?: boolean;
    staleTimes?: { dynamic?: number; static?: number };
    dynamicIO?: boolean;
    useCache?: boolean;
    authInterrupts?: boolean;
    viewTransition?: boolean;
    clientSegmentCache?: boolean;
    [key: string]: unknown;
  }

  export interface NextConfig {
    reactStrictMode?: boolean;
    reactMaxHeadersLength?: number;
    poweredByHeader?: boolean;
    compress?: boolean;
    generateEtags?: boolean;
    pageExtensions?: string[];
    distDir?: string;
    cleanDistDir?: boolean;
    basePath?: string;
    assetPrefix?: string;
    crossOrigin?: "anonymous" | "use-credentials";
    env?: Record<string, string | undefined>;
    trailingSlash?: boolean;
    output?: "standalone" | "export";
    outputFileTracingRoot?: string;
    outputFileTracingIncludes?: Record<string, string[]>;
    outputFileTracingExcludes?: Record<string, string[]>;
    serverExternalPackages?: string[];
    bundlePagesRouterDependencies?: boolean;
    transpilePackages?: string[];
    productionBrowserSourceMaps?: boolean;
    staticPageGenerationTimeout?: number;
    skipMiddlewareUrlNormalize?: boolean;
    skipTrailingSlashRedirect?: boolean;
    useFileSystemPublicRoutes?: boolean;
    expireTime?: number;
    cacheHandler?: string;
    cacheMaxMemorySize?: number;
    deploymentId?: string;
    allowedDevOrigins?: string[];
    devIndicators?: false | { position?: "bottom-right" | "bottom-left" | "top-right" | "top-left" };
    httpAgentOptions?: { keepAlive?: boolean };
    logging?: false | { fetches?: { fullUrl?: boolean; hmrRefreshes?: boolean } };
    modularizeImports?: Record<
      string,
      { transform: string | Record<string, string>; preventFullImport?: boolean; skipDefaultConversion?: boolean }
    >;
    images?: ImageConfig;
    experimental?: ExperimentalConfig;
    typescript?: { ignoreBuildErrors?: boolean; tsconfigPath?: string };
    eslint?: { ignoreDuringBuilds?: boolean; dirs?: string[] };
    compiler?: {
      removeConsole?: boolean | { exclude?: string[] };
      reactRemoveProperties?: boolean | { properties?: string[] };
      styledComponents?: boolean | Record<string, unknown>;
      emotion?: boolean | Record<string, unknown>;
      define?: Record<string, string>;
    };
    sassOptions?: Record<string, unknown>;
    publicRuntimeConfig?: Record<string, unknown>;
    serverRuntimeConfig?: Record<string, unknown>;
    turbopack?: Record<string, unknown>;
    webpack?: (config: unknown, context: Record<string, unknown>) => unknown;
    generateBuildId?: () => string | null | Promise<string | null>;
    headers?: () => Promise<Header[]>;
    rewrites?: () => Promise<
      Rewrite[] | { beforeFiles: Rewrite[]; afterFiles: Rewrite[]; fallback: Rewrite[] }
    >;
    redirects?: () => Promise<Redirect[]>;
  }

  export type NextPage<P = {}, IP = P> = ((props: P) => ReactNode) & {
    getInitialProps?(context: unknown): IP | Promise<IP>;
  };

  // ---- Metadata ----------------------------------------------------------
  export type TemplateString =
    | { default: string; template: string }
    | { absolute: string; template?: null };

  export interface Author {
    url?: string | URL;
    name?: string;
  }

  export interface OpenGraphImage {
    url: string | URL;
    secureUrl?: string | URL;
    alt?: string;
    type?: string;
    width?: string | number;
    height?: string | number;
  }

  export interface OpenGraph {
    determiner?: "a" | "an" | "the" | "auto" | "";
    title?: string | TemplateString;
    description?: string;
    emails?: string | string[];
    phoneNumbers?: string | string[];
    faxNumbers?: string | string[];
    siteName?: string;
    locale?: string;
    alternateLocale?: string | string[];
    images?: string | OpenGraphImage | URL | Array<string | OpenGraphImage | URL>;
    audio?: string | string[] | Array<{ url: string | URL; secureUrl?: string | URL; type?: string }>;
    videos?: string | string[] | Array<{ url: string | URL; width?: number; height?: number; type?: string }>;
    url?: string | URL;
    countryName?: string;
    ttl?: number;
    type?:
      | "article"
      | "book"
      | "music.song"
      | "music.album"
      | "music.playlist"
      | "music.radio_station"
      | "profile"
      | "website"
      | "video.tv_show"
      | "video.other"
      | "video.movie"
      | "video.episode";
    publishedTime?: string;
    modifiedTime?: string;
    expirationTime?: string;
    authors?: null | string | URL | Array<string | URL>;
    section?: string;
    tags?: null | string | string[];
  }

  export interface Twitter {
    card?: "summary" | "summary_large_image" | "app" | "player";
    site?: string;
    siteId?: string;
    creator?: string;
    creatorId?: string;
    title?: string | TemplateString;
    description?: string;
    images?: string | OpenGraphImage | URL | Array<string | OpenGraphImage | URL>;
  }

  export interface Robots {
    index?: boolean;
    follow?: boolean;
    noarchive?: boolean;
    nosnippet?: boolean;
    noimageindex?: boolean;
    nocache?: boolean;
    notranslate?: boolean;
    indexifembedded?: boolean;
    nositelinkssearchbox?: boolean;
    unavailable_after?: string;
    "max-video-preview"?: number | string;
    "max-image-preview"?: "none" | "standard" | "large";
    "max-snippet"?: number;
    googleBot?: string | Omit<Robots, "googleBot">;
  }

  export type IconURL = string | URL;
  export interface IconDescriptor {
    url: string | URL;
    type?: string;
    sizes?: string;
    color?: string;
    rel?: string;
    media?: string;
    fetchPriority?: "high" | "low" | "auto";
  }
  export type Icon = IconURL | IconDescriptor;
  export interface Icons {
    icon?: Icon | Icon[];
    shortcut?: Icon | Icon[];
    apple?: Icon | Icon[];
    other?: IconDescriptor | IconDescriptor[];
  }

  export interface AlternateURLs {
    canonical?: null | string | URL | { url: string | URL; title?: string };
    languages?: Record<string, null | string | URL | Array<{ url: string | URL; title?: string }>>;
    media?: Record<string, null | string | URL>;
    types?: Record<string, null | string | URL>;
  }

  export interface Metadata {
    metadataBase?: URL | null;
    title?: null | string | TemplateString;
    description?: null | string;
    applicationName?: null | string;
    authors?: null | Author | Author[];
    generator?: null | string;
    keywords?: null | string | string[];
    referrer?:
      | null
      | "no-referrer"
      | "origin"
      | "no-referrer-when-downgrade"
      | "origin-when-cross-origin"
      | "same-origin"
      | "strict-origin"
      | "strict-origin-when-cross-origin";
    creator?: null | string;
    publisher?: null | string;
    robots?: null | string | Robots;
    alternates?: null | AlternateURLs;
    icons?: null | IconURL | Icon[] | Icons;
    manifest?: null | string | URL;
    openGraph?: null | OpenGraph;
    twitter?: null | Twitter;
    facebook?: null | { appId?: string; admins?: string | string[] };
    pinterest?: null | { richPin?: string | boolean };
    verification?: null | {
      google?: null | string | number | Array<string | number>;
      yahoo?: null | string | number | Array<string | number>;
      yandex?: null | string | number | Array<string | number>;
      me?: null | string | number | Array<string | number>;
      other?: Record<string, string | number | Array<string | number>>;
    };
    appleWebApp?:
      | null
      | boolean
      | {
          capable?: boolean;
          title?: string;
          startupImage?: string | { url: string; media?: string } | Array<string | { url: string; media?: string }>;
          statusBarStyle?: "default" | "black" | "black-translucent";
        };
    formatDetection?: null | {
      telephone?: boolean;
      date?: boolean;
      address?: boolean;
      email?: boolean;
      url?: boolean;
    };
    itunes?: null | { appId: string; appArgument?: string };
    abstract?: null | string;
    appLinks?: null | Record<string, unknown>;
    archives?: null | string | string[];
    assets?: null | string | string[];
    bookmarks?: null | string | string[];
    category?: null | string;
    classification?: null | string;
    other?: null | Record<string, string | number | Array<string | number>>;
  }

  export type ResolvedMetadata = Metadata;
  export type ResolvingMetadata = Promise<ResolvedMetadata>;

  export interface Viewport {
    width?: string | number;
    height?: string | number;
    initialScale?: number;
    minimumScale?: number;
    maximumScale?: number;
    userScalable?: boolean;
    viewportFit?: "auto" | "cover" | "contain";
    interactiveWidget?: "resizes-visual" | "resizes-content" | "overlays-content";
    themeColor?:
      | null
      | string
      | { media?: string; color: string }
      | Array<{ media?: string; color: string }>;
    colorScheme?:
      | null
      | "normal"
      | "light"
      | "dark"
      | "light dark"
      | "dark light"
      | "only light";
  }
  export type ResolvingViewport = Promise<Viewport>;

  export namespace MetadataRoute {
    type Robots = {
      rules:
        | {
            userAgent?: string | string[];
            allow?: string | string[];
            disallow?: string | string[];
            crawlDelay?: number;
          }
        | Array<{
            userAgent?: string | string[];
            allow?: string | string[];
            disallow?: string | string[];
            crawlDelay?: number;
          }>;
      sitemap?: string | string[];
      host?: string;
    };

    type Sitemap = Array<{
      url: string;
      lastModified?: string | Date;
      changeFrequency?:
        | "always"
        | "hourly"
        | "daily"
        | "weekly"
        | "monthly"
        | "yearly"
        | "never";
      priority?: number;
      alternates?: { languages?: Record<string, string> };
      images?: string[];
      videos?: Array<{ title: string; thumbnail_loc: string; description: string }>;
    }>;

    type Manifest = {
      name?: string;
      short_name?: string;
      description?: string;
      start_url?: string;
      scope?: string;
      id?: string;
      display?: "fullscreen" | "standalone" | "minimal-ui" | "browser";
      display_override?: string[];
      orientation?: string;
      background_color?: string;
      theme_color?: string;
      lang?: string;
      dir?: "ltr" | "rtl" | "auto";
      categories?: string[];
      prefer_related_applications?: boolean;
      related_applications?: Array<{ platform: string; url: string; id?: string }>;
      icons?: Array<{
        src: string;
        sizes?: string;
        type?: string;
        purpose?: "any" | "maskable" | "monochrome" | string;
      }>;
      screenshots?: Array<{
        src: string;
        sizes?: string;
        type?: string;
        form_factor?: "narrow" | "wide";
        label?: string;
        platform?: string;
      }>;
      shortcuts?: Array<{
        name: string;
        short_name?: string;
        description?: string;
        url: string;
        icons?: Array<{ src: string; sizes?: string; type?: string }>;
      }>;
      share_target?: Record<string, unknown>;
      protocol_handlers?: Array<{ protocol: string; url: string }>;
    };
  }

  const nextTypesPlaceholder: unique symbol;
  export type { nextTypesPlaceholder };
}

// ---------------------------------------------------------------------------
// next/link
// ---------------------------------------------------------------------------
declare module "next/link" {
  import type * as React from "react";

  export interface UrlObject {
    auth?: string | null;
    hash?: string | null;
    host?: string | null;
    hostname?: string | null;
    href?: string | null;
    pathname?: string | null;
    protocol?: string | null;
    search?: string | null;
    slashes?: boolean | null;
    port?: string | number | null;
    query?:
      | string
      | null
      | Record<string, string | number | boolean | readonly string[] | undefined>;
  }
  export type Url = string | UrlObject;

  export interface LinkProps
    extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "href"> {
    href: Url;
    as?: Url;
    replace?: boolean;
    scroll?: boolean;
    shallow?: boolean;
    passHref?: boolean;
    prefetch?: boolean | null;
    locale?: string | false;
    legacyBehavior?: boolean;
    children?: React.ReactNode;
  }

  const Link: React.ForwardRefExoticComponent<
    LinkProps & React.RefAttributes<HTMLAnchorElement>
  >;
  export default Link;
}

// ---------------------------------------------------------------------------
// next/image
// ---------------------------------------------------------------------------
declare module "next/image" {
  import type * as React from "react";

  export interface StaticImageData {
    src: string;
    height: number;
    width: number;
    blurDataURL?: string;
    blurWidth?: number;
    blurHeight?: number;
  }
  export type StaticImport = StaticImageData | { default: StaticImageData };

  export interface ImageLoaderProps {
    src: string;
    width: number;
    quality?: number;
  }
  export type ImageLoader = (p: ImageLoaderProps) => string;

  export interface ImageProps
    extends Omit<
      React.ImgHTMLAttributes<HTMLImageElement>,
      "src" | "srcSet" | "alt" | "width" | "height" | "loading" | "ref"
    > {
    src: string | StaticImport;
    alt: string;
    width?: number | `${number}`;
    height?: number | `${number}`;
    fill?: boolean;
    sizes?: string;
    quality?: number | `${number}`;
    priority?: boolean;
    loading?: "eager" | "lazy";
    placeholder?: "blur" | "empty" | `data:image/${string}`;
    blurDataURL?: string;
    unoptimized?: boolean;
    overrideSrc?: string;
    loader?: ImageLoader;
    onLoad?: React.ReactEventHandler<HTMLImageElement>;
    onError?: React.ReactEventHandler<HTMLImageElement>;
    onLoadingComplete?: (img: HTMLImageElement) => void;
  }

  const Image: React.ForwardRefExoticComponent<
    ImageProps & React.RefAttributes<HTMLImageElement>
  >;
  export default Image;

  export function getImageProps(props: ImageProps): {
    props: React.ImgHTMLAttributes<HTMLImageElement> & { src: string };
  };
}

// ---------------------------------------------------------------------------
// next/navigation
// ---------------------------------------------------------------------------
declare module "next/navigation" {
  export class ReadonlyURLSearchParams extends URLSearchParams {
    /** Unavailable on ReadonlyURLSearchParams — throws at runtime. */
    append(): void;
    /** Unavailable on ReadonlyURLSearchParams — throws at runtime. */
    delete(): void;
    /** Unavailable on ReadonlyURLSearchParams — throws at runtime. */
    set(): void;
    /** Unavailable on ReadonlyURLSearchParams — throws at runtime. */
    sort(): void;
  }

  export interface NavigateOptions {
    scroll?: boolean;
  }
  export interface PrefetchOptions {
    kind?: "auto" | "full" | "temporary";
  }

  export interface AppRouterInstance {
    back(): void;
    forward(): void;
    refresh(): void;
    push(href: string, options?: NavigateOptions): void;
    replace(href: string, options?: NavigateOptions): void;
    prefetch(href: string, options?: PrefetchOptions): void;
  }

  export function useRouter(): AppRouterInstance;
  export function usePathname(): string;
  export function useSearchParams(): ReadonlyURLSearchParams;
  export function useParams<
    T extends Record<string, string | string[]> = Record<string, string | string[]>,
  >(): T;
  export function useSelectedLayoutSegment(parallelRouteKey?: string): string | null;
  export function useSelectedLayoutSegments(parallelRouteKey?: string): string[];

  export enum RedirectType {
    push = "push",
    replace = "replace",
  }

  export function redirect(url: string, type?: RedirectType): never;
  export function permanentRedirect(url: string, type?: RedirectType): never;
  export function notFound(): never;
  export function forbidden(): never;
  export function unauthorized(): never;
  export function unstable_rethrow(error: unknown): void;
  export function isRedirectError(error: unknown): boolean;
  export function isNotFoundError(error: unknown): boolean;
}

// ---------------------------------------------------------------------------
// next/headers
// ---------------------------------------------------------------------------
declare module "next/headers" {
  export interface RequestCookie {
    name: string;
    value: string;
  }

  export interface ResponseCookie extends RequestCookie {
    domain?: string;
    expires?: Date | number;
    httpOnly?: boolean;
    maxAge?: number;
    path?: string;
    priority?: "low" | "medium" | "high";
    sameSite?: boolean | "lax" | "strict" | "none";
    secure?: boolean;
    partitioned?: boolean;
  }

  export interface ReadonlyRequestCookies {
    readonly size: number;
    get(name: string): RequestCookie | undefined;
    get(cookie: Pick<RequestCookie, "name">): RequestCookie | undefined;
    getAll(name?: string): RequestCookie[];
    getAll(cookie: Pick<RequestCookie, "name">): RequestCookie[];
    has(name: string): boolean;
    set(name: string, value: string, cookie?: Partial<ResponseCookie>): ReadonlyRequestCookies;
    set(options: ResponseCookie): ReadonlyRequestCookies;
    delete(names: string | string[] | Pick<ResponseCookie, "name" | "path" | "domain">): ReadonlyRequestCookies;
    clear(): ReadonlyRequestCookies;
    toString(): string;
    [Symbol.iterator](): IterableIterator<[string, RequestCookie]>;
  }

  export interface ReadonlyHeaders extends Headers {
    append(): void;
    delete(): void;
    set(): void;
  }

  export interface DraftMode {
    readonly isEnabled: boolean;
    enable(): void;
    disable(): void;
  }

  export function cookies(): Promise<ReadonlyRequestCookies>;
  export function headers(): Promise<ReadonlyHeaders>;
  export function draftMode(): Promise<DraftMode>;
  export function connection(): Promise<void>;
}

// ---------------------------------------------------------------------------
// next/server
// ---------------------------------------------------------------------------
declare module "next/server" {
  import type { RequestCookie, ResponseCookie } from "next/headers";

  export type { RequestCookie, ResponseCookie };

  export class RequestCookies {
    readonly size: number;
    get(name: string): RequestCookie | undefined;
    get(cookie: Pick<RequestCookie, "name">): RequestCookie | undefined;
    getAll(name?: string): RequestCookie[];
    getAll(cookie: Pick<RequestCookie, "name">): RequestCookie[];
    has(name: string): boolean;
    set(name: string, value: string): this;
    set(cookie: RequestCookie): this;
    delete(names: string | string[]): boolean | boolean[];
    clear(): this;
    toString(): string;
    [Symbol.iterator](): IterableIterator<[string, RequestCookie]>;
  }

  export class ResponseCookies {
    readonly size: number;
    get(name: string): ResponseCookie | undefined;
    get(cookie: Pick<ResponseCookie, "name">): ResponseCookie | undefined;
    getAll(name?: string): ResponseCookie[];
    getAll(cookie: Pick<ResponseCookie, "name">): ResponseCookie[];
    has(name: string): boolean;
    set(name: string, value: string, cookie?: Partial<ResponseCookie>): this;
    set(cookie: ResponseCookie): this;
    delete(
      names: string | string[] | Pick<ResponseCookie, "name" | "path" | "domain">,
    ): this;
    toString(): string;
    [Symbol.iterator](): IterableIterator<[string, ResponseCookie]>;
  }

  export class NextURL extends URL {
    constructor(input: string | URL, base?: string | URL);
    analyze(): { pathname: string; detectedLocale?: string };
    formatPathname(): string;
    formatSearch(): string;
    basePath: string;
    buildId?: string;
    locale: string;
    readonly defaultLocale?: string;
    readonly domainLocale?: { defaultLocale: string; domain: string; locales?: string[] };
    clone(): NextURL;
  }

  export interface NextRequestInit extends RequestInit {
    signal?: AbortSignal;
  }

  export class NextRequest extends Request {
    constructor(input: URL | string | Request, init?: NextRequestInit);
    readonly cookies: RequestCookies;
    readonly nextUrl: NextURL;
    readonly page: never;
    readonly ua: never;
  }

  export interface ModifiedRequest {
    headers?: Headers;
  }
  export interface MiddlewareResponseInit extends ResponseInit {
    request?: ModifiedRequest;
  }

  export class NextResponse<Body = unknown> extends Response {
    constructor(body?: BodyInit | null, init?: ResponseInit);
    readonly cookies: ResponseCookies;
    static json<JsonBody>(body: JsonBody, init?: ResponseInit): NextResponse<JsonBody>;
    static redirect(url: string | URL, init?: number | ResponseInit): NextResponse<unknown>;
    static rewrite(
      destination: string | URL,
      init?: MiddlewareResponseInit,
    ): NextResponse<unknown>;
    static next(init?: MiddlewareResponseInit): NextResponse<unknown>;
  }

  export interface NextFetchEvent {
    readonly sourcePage: string;
    waitUntil(promise: Promise<unknown>): void;
  }

  export type NextMiddlewareResult = Response | NextResponse | undefined | null | void;
  export type NextMiddleware = (
    request: NextRequest,
    event: NextFetchEvent,
  ) => NextMiddlewareResult | Promise<NextMiddlewareResult>;

  export interface MiddlewareMatcher {
    source: string;
    locale?: false;
    has?: Array<{ type: "header" | "query" | "cookie" | "host"; key?: string; value?: string }>;
    missing?: Array<{ type: "header" | "query" | "cookie" | "host"; key?: string; value?: string }>;
    regexp?: string;
  }

  export interface MiddlewareConfig {
    matcher?: string | string[] | MiddlewareMatcher[];
    regions?: string | string[];
    unstable_allowDynamic?: string | string[];
  }

  export function userAgent(request: { headers: Headers }): {
    isBot: boolean;
    ua: string;
    browser: { name?: string; version?: string; major?: string };
    device: { model?: string; type?: string; vendor?: string };
    engine: { name?: string; version?: string };
    os: { name?: string; version?: string };
    cpu: { architecture?: string };
  };

  export function after(task: (() => unknown) | Promise<unknown>): void;
  export function connection(): Promise<void>;

  export const unstable_after: typeof after;
}

// ---------------------------------------------------------------------------
// next/og
// ---------------------------------------------------------------------------
declare module "next/og" {
  import type { ReactElement } from "react";

  export interface ImageResponseFont {
    name: string;
    data: ArrayBuffer | Buffer | Uint8Array;
    weight?: 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900;
    style?: "normal" | "italic";
    lang?: string;
  }

  export interface ImageResponseOptions {
    width?: number;
    height?: number;
    emoji?: "twemoji" | "blobmoji" | "noto" | "openmoji" | "fluent" | "fluentFlat";
    fonts?: ImageResponseFont[];
    debug?: boolean;
    status?: number;
    statusText?: string;
    headers?: HeadersInit;
  }

  export class ImageResponse extends Response {
    constructor(element: ReactElement, options?: ImageResponseOptions);
  }
}

// ---------------------------------------------------------------------------
// next/font
// ---------------------------------------------------------------------------
declare module "next/font" {
  export interface NextFont {
    className: string;
    style: { fontFamily: string; fontWeight?: number; fontStyle?: string };
  }
  export interface NextFontWithVariable extends NextFont {
    variable: string;
  }
  export type Display = "auto" | "block" | "swap" | "fallback" | "optional";
}

declare module "next/font/local" {
  import type { Display, NextFontWithVariable } from "next/font";

  export interface LocalFontSrc {
    path: string;
    weight?: string;
    style?: string;
  }

  export interface LocalFontOptions {
    src: string | LocalFontSrc | LocalFontSrc[];
    display?: Display;
    weight?: string;
    style?: string;
    variable?: string;
    preload?: boolean;
    fallback?: string[];
    adjustFontFallback?: "Arial" | "Times New Roman" | false;
    declarations?: Array<{ prop: string; value: string }>;
    subsets?: string[];
    axes?: string[];
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [key: string]: unknown;
  }

  export default function localFont(options: LocalFontOptions): NextFontWithVariable;
}

declare module "next/font/google" {
  import type { Display, NextFontWithVariable } from "next/font";

  export interface GoogleFontOptions {
    weight?: string | string[];
    style?: string | string[];
    display?: Display;
    variable?: string;
    preload?: boolean;
    fallback?: string[];
    adjustFontFallback?: boolean;
    subsets?: string[];
    axes?: string[];
  }

  /**
   * Real @next/font exposes one named export per family (`Inter`, `Roboto`, …).
   * This project loads fonts from `public/fonts` via @font-face, so only the
   * callable shape is modelled here.
   */
  export default function googleFont(options?: GoogleFontOptions): NextFontWithVariable;
}

// ---------------------------------------------------------------------------
// next/cache
// ---------------------------------------------------------------------------
declare module "next/cache" {
  export function revalidatePath(originalPath: string, type?: "layout" | "page"): void;
  export function revalidateTag(tag: string): void;
  export function unstable_cache<T extends (...args: never[]) => Promise<unknown>>(
    cb: T,
    keyParts?: string[],
    options?: { revalidate?: number | false; tags?: string[] },
  ): T;
  export function unstable_noStore(): void;
  export function unstable_expirePath(path: string, type?: "layout" | "page"): void;
  export function unstable_expireTag(...tags: string[]): void;
  export function cacheTag(...tags: string[]): void;
  export function cacheLife(profile: string): void;
}

// ---------------------------------------------------------------------------
// next/dynamic, next/script
// ---------------------------------------------------------------------------
declare module "next/dynamic" {
  import type * as React from "react";

  export interface DynamicOptions {
    loading?: (props: { error?: Error | null; isLoading?: boolean; pastDelay?: boolean; retry?: () => void }) => React.ReactNode;
    ssr?: boolean;
  }

  export default function dynamic<P extends object = {}>(
    loader: () => Promise<{ default: React.ComponentType<P> } | React.ComponentType<P>>,
    options?: DynamicOptions,
  ): React.ComponentType<P>;
}

declare module "next/script" {
  import type * as React from "react";

  export interface ScriptProps extends React.ScriptHTMLAttributes<HTMLScriptElement> {
    strategy?: "afterInteractive" | "lazyOnload" | "beforeInteractive" | "worker";
    onLoad?: (e: unknown) => void;
    onReady?: () => void;
    onError?: (e: unknown) => void;
    id?: string;
  }

  const Script: React.FunctionComponent<ScriptProps>;
  export default Script;
}

// ---------------------------------------------------------------------------
// server-only / client-only
// ---------------------------------------------------------------------------
declare module "server-only" {}
declare module "client-only" {}
