/**
 * react-dom / react-dom/client / react-dom/server declarations for the offline
 * type-check. Subset of @types/react-dom@19.
 */

declare module "react-dom" {
  import type { ReactNode, ReactPortal } from "react";

  export function createPortal(
    children: ReactNode,
    container: Element | DocumentFragment,
    key?: string | null,
  ): ReactPortal;

  export function flushSync<R>(fn: () => R): R;

  export function preload(
    href: string,
    options: { as: string; crossOrigin?: string; integrity?: string; nonce?: string },
  ): void;
  export function preconnect(href: string, options?: { crossOrigin?: string }): void;
  export function prefetchDNS(href: string): void;
  export function preinit(
    href: string,
    options: { as: string; precedence?: string; crossOrigin?: string; integrity?: string },
  ): void;
  export function preloadModule(href: string, options?: { as?: string }): void;
  export function preinitModule(href: string, options?: { as?: string }): void;

  export function requestFormReset(form: HTMLFormElement): void;
  export function useFormStatus(): {
    pending: boolean;
    data: FormData | null;
    method: string | null;
    action: string | ((formData: FormData) => void | Promise<void>) | null;
  };
  export function useFormState<State>(
    action: (state: Awaited<State>) => State | Promise<State>,
    initialState: Awaited<State>,
    permalink?: string,
  ): [state: Awaited<State>, dispatch: () => void];

  export const version: string;
}

declare module "react-dom/client" {
  import type { ReactNode } from "react";

  export interface RootOptions {
    identifierPrefix?: string;
    onUncaughtError?: (error: unknown, errorInfo: { componentStack?: string }) => void;
    onCaughtError?: (
      error: unknown,
      errorInfo: { componentStack?: string; errorBoundary?: unknown },
    ) => void;
    onRecoverableError?: (error: unknown, errorInfo: { componentStack?: string }) => void;
  }

  export interface Root {
    render(children: ReactNode): void;
    unmount(): void;
  }

  export function createRoot(
    container: Element | DocumentFragment,
    options?: RootOptions,
  ): Root;

  export function hydrateRoot(
    container: Element | Document,
    initialChildren: ReactNode,
    options?: RootOptions & { formState?: unknown },
  ): Root;
}

declare module "react-dom/server" {
  import type { ReactNode } from "react";

  export interface RenderToReadableStreamOptions {
    identifierPrefix?: string;
    namespaceURI?: string;
    nonce?: string;
    bootstrapScriptContent?: string;
    bootstrapScripts?: Array<string | { src: string; integrity?: string; crossOrigin?: string }>;
    bootstrapModules?: Array<string | { src: string; integrity?: string; crossOrigin?: string }>;
    progressiveChunkSize?: number;
    signal?: AbortSignal;
    onError?: (error: unknown) => string | void;
  }

  export interface ReactDOMServerReadableStream extends ReadableStream<Uint8Array> {
    allReady: Promise<void>;
  }

  export function renderToString(element: ReactNode): string;
  export function renderToStaticMarkup(element: ReactNode): string;
  export function renderToReadableStream(
    children: ReactNode,
    options?: RenderToReadableStreamOptions,
  ): Promise<ReactDOMServerReadableStream>;

  export const version: string;
}

declare module "react-dom/server.edge" {
  export * from "react-dom/server";
}
