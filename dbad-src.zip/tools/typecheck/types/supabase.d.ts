/**
 * @supabase/supabase-js + @supabase/ssr declarations for the offline type-check.
 *
 * The real packages infer result shapes from the select string; that inference is
 * out of scope here. What IS modelled, because it catches real bugs:
 *   - `from()` only accepts a table or view that exists in the generated Database;
 *   - `rpc()` only accepts a declared function, with its declared Args;
 *   - filter methods only accept columns that exist on the row, with matching
 *     value types;
 *   - builders are thenable and resolve to a discriminated {data|error} union.
 *
 * Row shapes returned by aliased/embedded selects are the base row type; the
 * repository already casts those through its own `rows<T>()`/`maybeRow<T>()`.
 */

declare module "@supabase/supabase-js" {
  // -------------------------------------------------------------------------
  // Schema plumbing
  // -------------------------------------------------------------------------
  export interface GenericTable {
    Row: Record<string, unknown>;
    Insert: Record<string, unknown>;
    Update: Record<string, unknown>;
  }
  export interface GenericView {
    Row: Record<string, unknown>;
  }
  export interface GenericFunction {
    Args: Record<string, unknown>;
    Returns: unknown;
  }
  export interface GenericSchema {
    Tables: Record<string, GenericTable>;
    Views: Record<string, GenericView>;
    Functions: Record<string, GenericFunction>;
  }
  export interface GenericDatabase {
    public: GenericSchema;
  }

  type PublicSchemaOf<Db> = Db extends { public: infer S } ? S : never;
  type TablesOf<Db> = PublicSchemaOf<Db> extends { Tables: infer T } ? T : never;
  type ViewsOf<Db> = PublicSchemaOf<Db> extends { Views: infer V } ? V : never;
  type FunctionsOf<Db> = PublicSchemaOf<Db> extends { Functions: infer F } ? F : never;
  type RelationsOf<Db> = TablesOf<Db> & ViewsOf<Db>;

  type RowOf<Db, N extends keyof RelationsOf<Db>> = RelationsOf<Db>[N] extends { Row: infer R }
    ? R
    : never;
  type InsertOf<Db, N extends keyof RelationsOf<Db>> = RelationsOf<Db>[N] extends {
    Insert: infer I;
  }
    ? I
    : never;
  type UpdateOf<Db, N extends keyof RelationsOf<Db>> = RelationsOf<Db>[N] extends {
    Update: infer U;
  }
    ? U
    : never;
  type ArgsOf<Db, N extends keyof FunctionsOf<Db>> = FunctionsOf<Db>[N] extends {
    Args: infer A;
  }
    ? A
    : never;
  type ReturnsOf<Db, N extends keyof FunctionsOf<Db>> = FunctionsOf<Db>[N] extends {
    Returns: infer R;
  }
    ? R
    : never;

  // -------------------------------------------------------------------------
  // PostgREST
  // -------------------------------------------------------------------------
  export class PostgrestError extends Error {
    readonly message: string;
    readonly details: string;
    readonly hint: string;
    readonly code: string;
    readonly name: "PostgrestError";
  }

  export type CountOption = "exact" | "planned" | "estimated";

  export type PostgrestResponse<Data> =
    | {
        data: Data;
        error: null;
        count: number | null;
        status: number;
        statusText: string;
      }
    | {
        data: null;
        error: PostgrestError;
        count: number | null;
        status: number;
        statusText: string;
      };

  export type PostgrestSingleResponse<T> = PostgrestResponse<T>;
  export type PostgrestMaybeSingleResponse<T> = PostgrestResponse<T | null>;

  type UnwrapArray<T> = T extends readonly (infer E)[] ? E : T;

  export interface SelectOptions {
    head?: boolean;
    count?: CountOption;
  }

  export interface OrderOptions {
    ascending?: boolean;
    nullsFirst?: boolean;
    referencedTable?: string;
    /** @deprecated use referencedTable */
    foreignTable?: string;
  }

  export interface ReferencedTableOption {
    referencedTable?: string;
    /** @deprecated use referencedTable */
    foreignTable?: string;
  }

  export interface TextSearchOptions extends ReferencedTableOption {
    config?: string;
    type?: "plain" | "phrase" | "websearch";
  }

  /** Anything awaitable that resolves to a PostgREST response. */
  export interface PostgrestBuilder<Data> extends PromiseLike<PostgrestResponse<Data>> {
    throwOnError(): this;
    abortSignal(signal: AbortSignal): this;
    setHeader(name: string, value: string): this;
    returns<NewData>(): PostgrestBuilder<NewData>;
    overrideTypes<NewData>(): PostgrestBuilder<NewData>;
  }

  export interface PostgrestTransformBuilder<Row, Data> extends PostgrestBuilder<Data> {
    select<NewRow = Row>(columns?: string, options?: SelectOptions): PostgrestFilterBuilder<Row, NewRow[]>;
    order<K extends string & keyof Row>(column: K, options?: OrderOptions): this;
    limit(count: number, options?: ReferencedTableOption): this;
    range(from: number, to: number, options?: ReferencedTableOption): this;
    single(): PostgrestBuilder<UnwrapArray<Data>>;
    maybeSingle(): PostgrestBuilder<UnwrapArray<Data> | null>;
    csv(): PostgrestBuilder<string>;
    geojson(): PostgrestBuilder<Record<string, unknown>>;
    explain(options?: {
      analyze?: boolean;
      verbose?: boolean;
      settings?: boolean;
      buffers?: boolean;
      wal?: boolean;
      format?: "json" | "text";
    }): PostgrestBuilder<string>;
    rollback(): this;
    returns<NewData>(): PostgrestFilterBuilder<Row, NewData>;
    overrideTypes<NewData>(): PostgrestFilterBuilder<Row, NewData>;
  }

  export interface PostgrestFilterBuilder<Row, Data = Row[]>
    extends PostgrestTransformBuilder<Row, Data> {
    eq<K extends string & keyof Row>(column: K, value: NonNullable<Row[K]>): this;
    neq<K extends string & keyof Row>(column: K, value: NonNullable<Row[K]>): this;
    gt<K extends string & keyof Row>(column: K, value: NonNullable<Row[K]>): this;
    gte<K extends string & keyof Row>(column: K, value: NonNullable<Row[K]>): this;
    lt<K extends string & keyof Row>(column: K, value: NonNullable<Row[K]>): this;
    lte<K extends string & keyof Row>(column: K, value: NonNullable<Row[K]>): this;
    like<K extends string & keyof Row>(column: K, pattern: string): this;
    likeAllOf<K extends string & keyof Row>(column: K, patterns: readonly string[]): this;
    likeAnyOf<K extends string & keyof Row>(column: K, patterns: readonly string[]): this;
    ilike<K extends string & keyof Row>(column: K, pattern: string): this;
    ilikeAllOf<K extends string & keyof Row>(column: K, patterns: readonly string[]): this;
    ilikeAnyOf<K extends string & keyof Row>(column: K, patterns: readonly string[]): this;
    is<K extends string & keyof Row>(column: K, value: null | boolean): this;
    in<K extends string & keyof Row>(column: K, values: ReadonlyArray<NonNullable<Row[K]>>): this;
    contains<K extends string & keyof Row>(
      column: K,
      value: string | readonly unknown[] | Record<string, unknown>,
    ): this;
    containedBy<K extends string & keyof Row>(
      column: K,
      value: string | readonly unknown[] | Record<string, unknown>,
    ): this;
    rangeGt<K extends string & keyof Row>(column: K, range: string): this;
    rangeGte<K extends string & keyof Row>(column: K, range: string): this;
    rangeLt<K extends string & keyof Row>(column: K, range: string): this;
    rangeLte<K extends string & keyof Row>(column: K, range: string): this;
    rangeAdjacent<K extends string & keyof Row>(column: K, range: string): this;
    overlaps<K extends string & keyof Row>(column: K, value: string | readonly unknown[]): this;
    textSearch<K extends string & keyof Row>(
      column: K,
      query: string,
      options?: TextSearchOptions,
    ): this;
    match(query: Partial<Row>): this;
    not<K extends string & keyof Row>(column: K, operator: string, value: unknown): this;
    or(filters: string, options?: ReferencedTableOption): this;
    filter<K extends string & keyof Row>(column: K, operator: string, value: unknown): this;
  }

  export interface PostgrestQueryBuilder<Row, Insert = Row, Update = Partial<Row>> {
    select<NewRow = Row>(
      columns?: string,
      options?: SelectOptions,
    ): PostgrestFilterBuilder<Row, NewRow[]>;
    insert(
      values: Insert | readonly Insert[],
      options?: { count?: CountOption; defaultToNull?: boolean },
    ): PostgrestFilterBuilder<Row, Row[]>;
    upsert(
      values: Insert | readonly Insert[],
      options?: {
        onConflict?: string;
        ignoreDuplicates?: boolean;
        count?: CountOption;
        defaultToNull?: boolean;
      },
    ): PostgrestFilterBuilder<Row, Row[]>;
    update(values: Update, options?: { count?: CountOption }): PostgrestFilterBuilder<Row, Row[]>;
    delete(options?: { count?: CountOption }): PostgrestFilterBuilder<Row, Row[]>;
  }

  // -------------------------------------------------------------------------
  // Auth
  // -------------------------------------------------------------------------
  export class AuthError extends Error {
    readonly name: string;
    readonly message: string;
    readonly status: number | undefined;
    readonly code: string | undefined;
  }

  export interface UserIdentity {
    id: string;
    user_id: string;
    identity_data?: Record<string, unknown>;
    identity_id: string;
    provider: string;
    created_at?: string;
    last_sign_in_at?: string;
    updated_at?: string;
  }

  export interface User {
    id: string;
    aud: string;
    role?: string;
    email?: string;
    email_confirmed_at?: string;
    phone?: string;
    phone_confirmed_at?: string;
    confirmed_at?: string;
    last_sign_in_at?: string;
    app_metadata: { provider?: string; providers?: string[] } & Record<string, unknown>;
    user_metadata: Record<string, unknown>;
    identities?: UserIdentity[];
    created_at: string;
    updated_at?: string;
    is_anonymous?: boolean;
  }

  export interface Session {
    provider_token?: string | null;
    provider_refresh_token?: string | null;
    access_token: string;
    refresh_token: string;
    expires_in: number;
    expires_at?: number;
    token_type: string;
    user: User;
  }

  export type AuthChangeEvent =
    | "INITIAL_SESSION"
    | "SIGNED_IN"
    | "SIGNED_OUT"
    | "USER_UPDATED"
    | "PASSWORD_RECOVERY"
    | "TOKEN_REFRESHED"
    | "MFA_CHALLENGE_VERIFIED";

  export interface Subscription {
    id: string;
    callback: (event: AuthChangeEvent, session: Session | null) => void;
    unsubscribe: () => void;
  }

  export type Provider =
    | "apple"
    | "azure"
    | "discord"
    | "facebook"
    | "github"
    | "gitlab"
    | "google"
    | "twitter"
    | (string & {});

  export interface SignInWithOtpCredentials {
    email?: string;
    phone?: string;
    options?: {
      emailRedirectTo?: string;
      shouldCreateUser?: boolean;
      data?: Record<string, unknown>;
      captchaToken?: string;
      channel?: "sms" | "whatsapp";
    };
  }

  export interface SignInWithOAuthCredentials {
    provider: Provider;
    options?: {
      redirectTo?: string;
      scopes?: string;
      queryParams?: Record<string, string>;
      skipBrowserRedirect?: boolean;
    };
  }

  export interface SupabaseAuthClient {
    getUser(
      jwt?: string,
    ): Promise<
      { data: { user: User }; error: null } | { data: { user: null }; error: AuthError }
    >;
    getSession(): Promise<
      | { data: { session: Session }; error: null }
      | { data: { session: null }; error: AuthError | null }
    >;
    getClaims(jwt?: string): Promise<
      { data: { claims: Record<string, unknown> } | null; error: AuthError | null }
    >;
    signInWithOtp(credentials: SignInWithOtpCredentials): Promise<{
      data: { user: User | null; session: Session | null };
      error: AuthError | null;
    }>;
    signInWithOAuth(credentials: SignInWithOAuthCredentials): Promise<{
      data: { provider: Provider; url: string | null };
      error: AuthError | null;
    }>;
    signInWithPassword(credentials: {
      email?: string;
      phone?: string;
      password: string;
    }): Promise<{
      data: { user: User | null; session: Session | null };
      error: AuthError | null;
    }>;
    signUp(credentials: {
      email?: string;
      phone?: string;
      password: string;
      options?: { emailRedirectTo?: string; data?: Record<string, unknown> };
    }): Promise<{
      data: { user: User | null; session: Session | null };
      error: AuthError | null;
    }>;
    verifyOtp(params: {
      email?: string;
      phone?: string;
      token?: string;
      token_hash?: string;
      type: string;
      options?: { redirectTo?: string };
    }): Promise<{
      data: { user: User | null; session: Session | null };
      error: AuthError | null;
    }>;
    exchangeCodeForSession(authCode: string): Promise<{
      data: { user: User | null; session: Session | null };
      error: AuthError | null;
    }>;
    updateUser(attributes: {
      email?: string;
      phone?: string;
      password?: string;
      data?: Record<string, unknown>;
    }): Promise<{ data: { user: User | null }; error: AuthError | null }>;
    resetPasswordForEmail(
      email: string,
      options?: { redirectTo?: string; captchaToken?: string },
    ): Promise<{ data: {}; error: AuthError | null }>;
    refreshSession(currentSession?: {
      refresh_token: string;
    }): Promise<{
      data: { user: User | null; session: Session | null };
      error: AuthError | null;
    }>;
    signOut(options?: { scope?: "global" | "local" | "others" }): Promise<{
      error: AuthError | null;
    }>;
    onAuthStateChange(
      callback: (event: AuthChangeEvent, session: Session | null) => void | Promise<void>,
    ): { data: { subscription: Subscription } };
  }

  // -------------------------------------------------------------------------
  // Storage
  // -------------------------------------------------------------------------
  export class StorageError extends Error {
    readonly message: string;
    readonly name: string;
    status?: number;
  }

  export interface FileObject {
    name: string;
    id: string;
    bucket_id: string;
    owner: string;
    updated_at: string;
    created_at: string;
    last_accessed_at: string;
    metadata: Record<string, unknown>;
  }

  export type StorageFileBody =
    | ArrayBuffer
    | ArrayBufferView
    | Blob
    | File
    | FormData
    | ReadableStream<Uint8Array>
    | URLSearchParams
    | string;

  export interface FileOptions {
    cacheControl?: string;
    contentType?: string;
    upsert?: boolean;
    duplex?: string;
    metadata?: Record<string, unknown>;
    headers?: Record<string, string>;
  }

  export interface TransformOptions {
    width?: number;
    height?: number;
    resize?: "cover" | "contain" | "fill";
    quality?: number;
    format?: "origin";
  }

  export interface StorageFileApi {
    upload(
      path: string,
      fileBody: StorageFileBody,
      fileOptions?: FileOptions,
    ): Promise<
      | { data: { id: string; path: string; fullPath: string }; error: null }
      | { data: null; error: StorageError }
    >;
    update(
      path: string,
      fileBody: StorageFileBody,
      fileOptions?: FileOptions,
    ): Promise<
      | { data: { id: string; path: string; fullPath: string }; error: null }
      | { data: null; error: StorageError }
    >;
    uploadToSignedUrl(
      path: string,
      token: string,
      fileBody: StorageFileBody,
      fileOptions?: FileOptions,
    ): Promise<
      { data: { path: string; fullPath: string }; error: null } | { data: null; error: StorageError }
    >;
    createSignedUploadUrl(
      path: string,
      options?: { upsert?: boolean },
    ): Promise<
      | { data: { signedUrl: string; token: string; path: string }; error: null }
      | { data: null; error: StorageError }
    >;
    createSignedUrl(
      path: string,
      expiresIn: number,
      options?: { download?: string | boolean; transform?: TransformOptions },
    ): Promise<
      { data: { signedUrl: string }; error: null } | { data: null; error: StorageError }
    >;
    createSignedUrls(
      paths: string[],
      expiresIn: number,
    ): Promise<
      | { data: Array<{ error: string | null; path: string | null; signedUrl: string }>; error: null }
      | { data: null; error: StorageError }
    >;
    getPublicUrl(
      path: string,
      options?: { download?: string | boolean; transform?: TransformOptions },
    ): { data: { publicUrl: string } };
    download(
      path: string,
      options?: { transform?: TransformOptions },
    ): Promise<{ data: Blob; error: null } | { data: null; error: StorageError }>;
    remove(
      paths: string[],
    ): Promise<{ data: FileObject[]; error: null } | { data: null; error: StorageError }>;
    list(
      path?: string,
      options?: {
        limit?: number;
        offset?: number;
        sortBy?: { column: string; order: "asc" | "desc" };
        search?: string;
      },
    ): Promise<{ data: FileObject[]; error: null } | { data: null; error: StorageError }>;
    move(
      fromPath: string,
      toPath: string,
    ): Promise<{ data: { message: string }; error: null } | { data: null; error: StorageError }>;
    copy(
      fromPath: string,
      toPath: string,
    ): Promise<{ data: { path: string }; error: null } | { data: null; error: StorageError }>;
  }

  export interface StorageBucket {
    id: string;
    name: string;
    owner: string;
    public: boolean;
    file_size_limit?: number | null;
    allowed_mime_types?: string[] | null;
    created_at: string;
    updated_at: string;
  }

  export interface SupabaseStorageClient {
    from(bucketId: string): StorageFileApi;
    listBuckets(): Promise<
      { data: StorageBucket[]; error: null } | { data: null; error: StorageError }
    >;
    getBucket(
      id: string,
    ): Promise<{ data: StorageBucket; error: null } | { data: null; error: StorageError }>;
    createBucket(
      id: string,
      options?: { public?: boolean; fileSizeLimit?: number | string; allowedMimeTypes?: string[] },
    ): Promise<{ data: { name: string }; error: null } | { data: null; error: StorageError }>;
    emptyBucket(
      id: string,
    ): Promise<{ data: { message: string }; error: null } | { data: null; error: StorageError }>;
    deleteBucket(
      id: string,
    ): Promise<{ data: { message: string }; error: null } | { data: null; error: StorageError }>;
  }

  // -------------------------------------------------------------------------
  // Realtime (minimal)
  // -------------------------------------------------------------------------
  export interface RealtimeChannel {
    on(type: string, filter: Record<string, unknown>, callback: (payload: unknown) => void): this;
    subscribe(callback?: (status: string, err?: Error) => void): this;
    unsubscribe(): Promise<"ok" | "timed out" | "error">;
    send(payload: Record<string, unknown>): Promise<"ok" | "timed out" | "error">;
  }

  // -------------------------------------------------------------------------
  // Client
  // -------------------------------------------------------------------------
  export interface SupabaseClientOptions<SchemaName extends string = "public"> {
    db?: { schema?: SchemaName };
    auth?: {
      autoRefreshToken?: boolean;
      persistSession?: boolean;
      detectSessionInUrl?: boolean;
      storageKey?: string;
      storage?: unknown;
      flowType?: "implicit" | "pkce";
      debug?: boolean;
      lock?: unknown;
    };
    global?: {
      fetch?: typeof fetch;
      headers?: Record<string, string>;
    };
    realtime?: Record<string, unknown>;
    accessToken?: () => Promise<string | null>;
  }

  export interface SupabaseClient<Database = GenericDatabase> {
    readonly auth: SupabaseAuthClient;
    readonly storage: SupabaseStorageClient;
    readonly realtime: unknown;
    readonly supabaseUrl: string;
    readonly supabaseKey: string;

    from<Name extends string & keyof RelationsOf<Database>>(
      relation: Name,
    ): PostgrestQueryBuilder<RowOf<Database, Name>, InsertOf<Database, Name>, UpdateOf<Database, Name>>;

    rpc<Name extends string & keyof FunctionsOf<Database>>(
      fn: Name,
      args?: ArgsOf<Database, Name>,
      options?: { head?: boolean; get?: boolean; count?: CountOption },
    ): PostgrestFilterBuilder<Record<string, never>, ReturnsOf<Database, Name>>;

    schema<Name extends string>(name: Name): SupabaseClient<Database>;
    channel(name: string, opts?: Record<string, unknown>): RealtimeChannel;
    getChannels(): RealtimeChannel[];
    removeChannel(channel: RealtimeChannel): Promise<"ok" | "timed out" | "error">;
    removeAllChannels(): Promise<Array<"ok" | "timed out" | "error">>;
  }

  export function createClient<Database = GenericDatabase>(
    supabaseUrl: string,
    supabaseKey: string,
    options?: SupabaseClientOptions,
  ): SupabaseClient<Database>;
}

// ---------------------------------------------------------------------------
// @supabase/ssr
// ---------------------------------------------------------------------------
declare module "@supabase/ssr" {
  import type {
    GenericDatabase,
    SupabaseClient,
    SupabaseClientOptions,
  } from "@supabase/supabase-js";

  export interface CookieOptions {
    domain?: string;
    expires?: Date | number;
    httpOnly?: boolean;
    maxAge?: number;
    path?: string;
    priority?: "low" | "medium" | "high";
    sameSite?: boolean | "lax" | "strict" | "none";
    secure?: boolean;
    partitioned?: boolean;
    encode?: (value: string) => string;
  }

  export interface CookieOptionsWithName extends CookieOptions {
    name?: string;
  }

  export interface SerializeCookie {
    name: string;
    value: string;
    options: CookieOptions;
  }

  export interface GetCookie {
    name: string;
    value: string;
  }

  export interface CookieMethodsBrowser {
    getAll: () => GetCookie[] | Promise<GetCookie[]>;
    setAll?: (cookiesToSet: SerializeCookie[]) => void | Promise<void>;
  }

  export interface CookieMethodsServer {
    getAll: () => GetCookie[] | Promise<GetCookie[]>;
    setAll?: (cookiesToSet: SerializeCookie[]) => void | Promise<void>;
  }

  export interface SSRClientOptions extends SupabaseClientOptions {
    cookieOptions?: CookieOptionsWithName;
    cookieEncoding?: "raw" | "base64url";
    isSingleton?: boolean;
  }

  export function createServerClient<Database = GenericDatabase>(
    supabaseUrl: string,
    supabaseKey: string,
    options: SSRClientOptions & { cookies: CookieMethodsServer },
  ): SupabaseClient<Database>;

  export function createBrowserClient<Database = GenericDatabase>(
    supabaseUrl: string,
    supabaseKey: string,
    options?: SSRClientOptions & { cookies?: CookieMethodsBrowser },
  ): SupabaseClient<Database>;

  export function parseCookieHeader(header: string): Array<{ name: string; value: string | undefined }>;
  export function serializeCookieHeader(
    name: string,
    value: string,
    options?: CookieOptions,
  ): string;
  export function combineChunks(
    key: string,
    retrieveChunk: (name: string) => Promise<string | null | undefined> | string | null | undefined,
  ): Promise<string | null>;
  export const isBrowser: () => boolean;
}
